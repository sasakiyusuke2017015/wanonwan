#!/bin/sh

commit_msg=$(cat "$1")

# Conventional Commits pattern
pattern="^(feat|fix|refactor|docs|chore|test|style|perf|ci|build|revert)(\(.+\))?: .+"

if ! echo "$commit_msg" | grep -qE "$pattern"; then
  echo "❌ コミットメッセージが Conventional Commits 形式ではありません"
  echo ""
  echo "形式: <type>: <description>"
  echo ""
  echo "type:"
  echo "  feat:     新機能"
  echo "  fix:      バグ修正"
  echo "  refactor: リファクタリング"
  echo "  docs:     ドキュメント"
  echo "  chore:    その他"
  echo "  test:     テスト"
  echo "  style:    フォーマット"
  echo "  perf:     パフォーマンス"
  echo "  ci:       CI/CD"
  echo "  build:    ビルド"
  echo "  revert:   リバート"
  echo ""
  echo "例: feat: add login feature"
  echo "例: fix(auth): resolve token issue"
  exit 1
fi
