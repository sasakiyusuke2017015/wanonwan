#!/bin/bash

# ui-catalog コンポーネントのバージョンアップグレード検証
# コンポーネントファイルが変更されている場合、バージョン番号が実際に上がっているかを確認

set -e

UI_CATALOG_DIR="packages/ui-catalog"
VERSION_FILE="$UI_CATALOG_DIR/version.ts"
VERSIONS_JSON="$UI_CATALOG_DIR/ui-catalog.versions.json"

# コンポーネントディレクトリ
COMPONENT_DIRS=(
  "atoms"
  "molecules"
  "organisms"
  "templates"
  "decorations"
)

# ステージングされたui-catalogのファイルを取得
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACMR | grep "^$UI_CATALOG_DIR/" || true)

if [ -z "$STAGED_FILES" ]; then
  exit 0
fi

# 変更されたコンポーネントを検出
declare -A CHANGED_COMPONENTS

for file in $STAGED_FILES; do
  # version.ts と ui-catalog.versions.json 自体は除外
  if [[ "$file" == "$VERSION_FILE" ]] || [[ "$file" == "$VERSIONS_JSON" ]]; then
    continue
  fi

  # コンポーネントディレクトリ内のファイルかチェック
  for dir in "${COMPONENT_DIRS[@]}"; do
    # パターン: packages/ui-catalog/{dir}/{ComponentName}.tsx or .ts
    # サブディレクトリも対応: packages/ui-catalog/{dir}/{ComponentName}/{file}.tsx
    if [[ "$file" =~ ^$UI_CATALOG_DIR/$dir/([^/]+)(\.tsx?|/.+\.tsx?)$ ]]; then
      component_name="${BASH_REMATCH[1]}"
      # .stories や .test は除外
      if [[ ! "$component_name" =~ \.(stories|test)$ ]] && [[ ! "$file" =~ \.(stories|test)\. ]]; then
        CHANGED_COMPONENTS["$component_name"]=1
      fi
    fi
  done
done

if [ ${#CHANGED_COMPONENTS[@]} -eq 0 ]; then
  exit 0
fi

# セマンティックバージョン比較関数
# 戻り値: 0=等しい, 1=v1>v2, 2=v1<v2
compare_versions() {
  local v1=$1
  local v2=$2

  if [[ "$v1" == "$v2" ]]; then
    return 0
  fi

  IFS='.' read -ra V1_PARTS <<< "$v1"
  IFS='.' read -ra V2_PARTS <<< "$v2"

  for i in 0 1 2; do
    local n1=${V1_PARTS[$i]:-0}
    local n2=${V2_PARTS[$i]:-0}
    if (( n1 > n2 )); then
      return 1
    elif (( n1 < n2 )); then
      return 2
    fi
  done

  return 0
}

# version.ts からコンポーネントのバージョンを抽出
get_version_from_ts() {
  local content="$1"
  local component="$2"
  echo "$content" | grep -E "^\s*${component}:\s*'" | sed -E "s/.*'([0-9]+\.[0-9]+\.[0-9]+)'.*/\1/" | head -1
}

# ui-catalog.versions.json からコンポーネントのバージョンを抽出
get_version_from_json() {
  local content="$1"
  local component="$2"
  echo "$content" | grep -E "\"${component}\":" | sed -E 's/.*"([0-9]+\.[0-9]+\.[0-9]+)".*/\1/' | head -1
}

ERRORS=()

# HEAD（コミット前）のバージョンファイルを取得
OLD_VERSION_TS=$(git show HEAD:"$VERSION_FILE" 2>/dev/null || echo "")
OLD_VERSIONS_JSON=$(git show HEAD:"$VERSIONS_JSON" 2>/dev/null || echo "")

# ステージング中のバージョンファイルを取得
NEW_VERSION_TS=$(git show :"$VERSION_FILE" 2>/dev/null || cat "$VERSION_FILE" 2>/dev/null || echo "")
NEW_VERSIONS_JSON=$(git show :"$VERSIONS_JSON" 2>/dev/null || cat "$VERSIONS_JSON" 2>/dev/null || echo "")

for component in "${!CHANGED_COMPONENTS[@]}"; do
  # 旧バージョンを取得
  OLD_VER_TS=$(get_version_from_ts "$OLD_VERSION_TS" "$component")
  OLD_VER_JSON=$(get_version_from_json "$OLD_VERSIONS_JSON" "$component")

  # 新バージョンを取得
  NEW_VER_TS=$(get_version_from_ts "$NEW_VERSION_TS" "$component")
  NEW_VER_JSON=$(get_version_from_json "$NEW_VERSIONS_JSON" "$component")

  # 新規コンポーネントの場合（HEADに存在しない）
  if [ -z "$OLD_VER_TS" ] && [ -z "$OLD_VER_JSON" ]; then
    # 新規の場合、バージョンが定義されていればOK
    if [ -z "$NEW_VER_TS" ]; then
      ERRORS+=("$component: version.ts にバージョン定義がありません（新規コンポーネント）")
    fi
    if [ -z "$NEW_VER_JSON" ]; then
      ERRORS+=("$component: ui-catalog.versions.json にバージョン定義がありません（新規コンポーネント）")
    fi
    continue
  fi

  # version.ts のバージョン比較
  if [ -n "$OLD_VER_TS" ] && [ -n "$NEW_VER_TS" ]; then
    set +e
    compare_versions "$NEW_VER_TS" "$OLD_VER_TS"
    result=$?
    set -e
    if [ $result -eq 0 ]; then
      ERRORS+=("$component: version.ts のバージョンが更新されていません ($OLD_VER_TS → $NEW_VER_TS)")
    elif [ $result -eq 2 ]; then
      ERRORS+=("$component: version.ts のバージョンがダウングレードされています ($OLD_VER_TS → $NEW_VER_TS)")
    fi
  elif [ -z "$NEW_VER_TS" ]; then
    ERRORS+=("$component: version.ts にバージョン定義がありません")
  fi

  # ui-catalog.versions.json のバージョン比較
  if [ -n "$OLD_VER_JSON" ] && [ -n "$NEW_VER_JSON" ]; then
    set +e
    compare_versions "$NEW_VER_JSON" "$OLD_VER_JSON"
    result=$?
    set -e
    if [ $result -eq 0 ]; then
      ERRORS+=("$component: ui-catalog.versions.json のバージョンが更新されていません ($OLD_VER_JSON → $NEW_VER_JSON)")
    elif [ $result -eq 2 ]; then
      ERRORS+=("$component: ui-catalog.versions.json のバージョンがダウングレードされています ($OLD_VER_JSON → $NEW_VER_JSON)")
    fi
  elif [ -z "$NEW_VER_JSON" ]; then
    ERRORS+=("$component: ui-catalog.versions.json にバージョン定義がありません")
  fi

  # version.ts と ui-catalog.versions.json の整合性チェック
  if [ -n "$NEW_VER_TS" ] && [ -n "$NEW_VER_JSON" ] && [ "$NEW_VER_TS" != "$NEW_VER_JSON" ]; then
    ERRORS+=("$component: version.ts ($NEW_VER_TS) と ui-catalog.versions.json ($NEW_VER_JSON) のバージョンが一致しません")
  fi
done

if [ ${#ERRORS[@]} -gt 0 ]; then
  echo ""
  echo "========================================"
  echo "  ui-catalog バージョン更新エラー"
  echo "========================================"
  echo ""
  echo "以下のコンポーネントでバージョン更新が必要です:"
  echo ""
  for error in "${ERRORS[@]}"; do
    echo "  ❌ $error"
  done
  echo ""
  echo "バージョン更新ルール:"
  echo "  - patch (0.0.x): 内部変更のみ（バグ修正、リファクタなど）"
  echo "  - minor (0.x.0): UI/API変更（機能追加など）"
  echo "  - major (x.0.0): 破壊的変更"
  echo ""
  echo "更新対象ファイル:"
  echo "  - $VERSION_FILE"
  echo "  - $VERSIONS_JSON"
  echo ""
  echo "意図的にスキップする場合:"
  echo "  git commit --no-verify"
  echo ""
  echo "========================================"
  exit 1
fi

exit 0
