# 1on1 - 面談管理システム

TypeScript完全統一のモダンな面談管理システム。Vite + React + Hono による型安全なフルスタック構成。

## 特徴

- **TypeScript完全統一**: フロントエンド・バックエンド・型定義をすべてTypeScriptで統一
- **型安全なAPI**: Hono + Valibot によるエンドツーエンドの型安全性
- **モダンなフロントエンド**: Vite + React 19 + TanStack Query
- **高速なバックエンド**: Hono (軽量・高速なWebフレームワーク)
- **インタラクティブなAPI Documentation**: Scalar API Reference
- **包括的なテスト**: E2Eテスト (Playwright) + VRTテスト + Storybook
- **CI/CD完全対応**: Gitea Actions による自動テスト・デプロイ

## 技術スタック

### Frontend
- **Framework**: Vite + React 19
- **Language**: TypeScript 5.9
- **Styling**: Tailwind CSS 4
- **State Management**: Jotai + TanStack Query
- **Testing**: Playwright (E2E), Vitest
- **Component Development**: Storybook 10

### Backend
- **Framework**: Hono 4
- **Language**: TypeScript 5.9
- **Validation**: Valibot
- **Authentication**: JWT (Cookie-based, HttpOnly)
- **API Documentation**: Scalar API Reference

### Infrastructure
- **Package Manager**: pnpm (workspace)
- **Build Tool**: Vite (Web), esbuild (API)
- **Container**: Docker + Docker Compose
- **CI/CD**: Gitea Actions
- **Deployment**: Ubuntu 24.04 (本番環境)

## プロジェクト構成

```
1on1/
├── apps/
│   ├── api/              # Hono バックエンド
│   │   ├── src/
│   │   │   ├── index.ts          # エントリーポイント
│   │   │   ├── routes/           # REST API ルーター
│   │   │   ├── services/         # ビジネスロジック
│   │   │   └── middlewares/      # 認証・CORS等
│   │   └── package.json
│   └── web/              # Vite + React フロントエンド
│       ├── src/
│       │   ├── pages/            # ページコンポーネント
│       │   ├── layouts/          # レイアウト
│       │   ├── hooks/            # カスタムhooks
│       │   └── state/            # Jotai atoms
│       ├── tests/e2e/            # E2Eテスト (Playwright)
│       └── package.json
├── libs/
│   └── domain/           # 共有型定義・定数
├── packages/
│   └── ui-catalog/       # 汎用UIコンポーネント
├── package.json          # ルートworkspace
├── pnpm-workspace.yaml
└── docker-compose.yml
```

## クイックスタート

### 開発環境

```bash
# リポジトリクローン & セットアップ
git clone http://1on1.sdt-autolabo.com:3000/sasaki_yusuke/1on1.git
cd 1on1
pnpm install

# 環境変数設定
cp .env.example .env

# 開発サーバー起動
pnpm dev
```

起動後のアクセス:
- **Web**: http://localhost:3000
- **API**: http://localhost:8000
- **API Docs**: http://localhost:8000/api-docs
- **Storybook**: http://localhost:6006

詳細な開発環境構築手順は [DEVELOPMENT.md](./docs/DEVELOPMENT.md) を参照。

### 本番環境

```bash
pnpm prod              # 起動
pnpm prod:down         # 停止
```

本番URL: https://1on1.sdt-autolabo.com

## npm scripts

### ルートワークスペース

```bash
pnpm dev              # 開発サーバー起動 (API + Web + Storybook)
pnpm dev:down         # 開発サーバー停止
pnpm build            # 全プロジェクトビルド
pnpm check:type       # 型チェック
pnpm check:lint       # Lint実行
pnpm test:unit        # ユニットテスト
pnpm test:e2e         # E2Eテスト実行
pnpm clean:all        # 完全クリーンアップ (Docker含む)
```

## API仕様

### インタラクティブドキュメント (Scalar)

開発環境: http://localhost:8000/api-docs
本番環境: https://1on1.sdt-autolabo.com/api-docs

### 主要エンドポイント

#### 認証
- `POST /api/auth/login` - ログイン
- `POST /api/auth/logout` - ログアウト
- `POST /api/auth/refresh` - トークンリフレッシュ
- `GET /api/auth/me` - 現在のユーザー取得

#### ユーザー
- `GET /api/users` - ユーザー一覧
- `GET /api/users/:id` - ユーザー詳細

#### アンケート
- `GET /api/surveys` - アンケート一覧
- `GET /api/surveys/:id` - アンケート詳細
- `POST /api/surveys/:id/submit` - 回答送信

#### ダッシュボード
- `GET /api/dashboard/stats` - 統計情報取得

### 認証方式

JWT認証（Cookie-based, HttpOnly, Secure）を使用。

### バッチジョブAPI (X-API-Key認証)

```bash
# アンケート開始
curl -X GET "https://1on1.sdt-autolabo.com/api/job/start-surveys" \
  -H "X-API-Key: secret-key-1"
```

## テスト

### E2Eテスト (Playwright)

```bash
# E2Eテスト実行
pnpm test:e2e

# UI modeでテスト
pnpm --filter @1on1/web exec playwright test --ui

# レポート表示
pnpm test:e2e:report
```

### Storybook

```bash
# Storybook起動
pnpm storybook
```

コンポーネントカタログ: http://localhost:6006

## 本番環境

### サーバー構成

- **OS**: Ubuntu 24.04 LTS
- **Web Server**: Nginx (リバースプロキシ)
- **SSL**: Let's Encrypt
- **Container**: Docker Compose

### ポート構成

- **3000**: Vite + React (内部)
- **8000**: Hono API (内部)
- **80/443**: Nginx (外部公開)

### デプロイ

```bash
# サーバーにSSH接続
ssh user@1on1.sdt-autolabo.com

# 最新コード取得 & 再起動
cd /path/to/1on1
git pull origin main
pnpm prod:build
```

## トラブルシューティング

### ポート競合

```bash
# ポート使用状況確認
lsof -ti:3000,8000

# プロセス停止
pnpm dev:down
pnpm prod:down
```

### 完全クリーンアップ

```bash
# すべて停止・削除・キャッシュクリア
pnpm clean:all
```

### Docker関連

```bash
# コンテナログ確認
docker compose --profile dev logs -f

# コンテナ再起動
pnpm dev:down && pnpm dev
```

## ライセンス

非公開プロジェクト - SMS Data Tech, Co., Ltd.

## リンク

- **本番環境**: https://1on1.sdt-autolabo.com
- **API Documentation**: https://1on1.sdt-autolabo.com/api-docs
- **Gitea Repository**: http://1on1.sdt-autolabo.com:3000/sasaki_yusuke/1on1
