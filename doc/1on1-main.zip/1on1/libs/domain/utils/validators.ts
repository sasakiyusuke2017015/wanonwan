/**
 * バリデーションユーティリティ
 *
 * Valibot を使用した実行時バリデーション関数
 * Fail Fast 原則に基づき、不正な値は即座にエラーを投げる
 */

import * as v from 'valibot'

/**
 * スキーマでパースし、失敗時はエラーを投げる
 *
 * @param schema - Valibot スキーマ
 * @param value - パース対象の値
 * @param fieldName - エラーメッセージ用のフィールド名
 * @returns パース結果
 * @throws Error - バリデーション失敗時
 */
export function parseOrThrow<T extends v.BaseSchema<unknown, unknown, v.BaseIssue<unknown>>>(
  schema: T,
  value: unknown,
  fieldName: string
): v.InferOutput<T> {
  const result = v.safeParse(schema, value)
  if (!result.success) {
    throw new Error(`Invalid ${fieldName}: ${JSON.stringify(value)}`)
  }
  return result.output
}

/**
 * オプショナルフィールド用: 値が存在する場合のみパース
 *
 * @param schema - Valibot スキーマ
 * @param value - パース対象の値（undefined/null/空文字の場合は undefined を返す）
 * @param fieldName - エラーメッセージ用のフィールド名
 * @returns パース結果 または undefined
 * @throws Error - 値が存在しバリデーション失敗時
 */
export function parseOptionalOrThrow<T extends v.BaseSchema<unknown, unknown, v.BaseIssue<unknown>>>(
  schema: T,
  value: unknown,
  fieldName: string
): v.InferOutput<T> | undefined {
  // 空値の場合は undefined を返す
  if (value === undefined || value === null || value === '') {
    return undefined
  }
  return parseOrThrow(schema, value, fieldName)
}
