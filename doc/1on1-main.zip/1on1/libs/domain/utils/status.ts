/**
 * ステータスコード ユーティリティ
 *
 * 純粋関数のみ提供
 */

import { 回答状況 } from '../generated/schemas'

// ===========================
// ヘルパー関数
// ===========================

/**
 * ステータスコードを数値に変換（文字列対応）
 *
 * Pleasanterは文字列で返す場合があるため、安全に数値変換
 */
export function toStatusCode(value: unknown): number | undefined {
  if (typeof value === 'number') {
    return value
  }
  if (typeof value === 'string') {
    const parsed = parseInt(value, 10)
    return isNaN(parsed) ? undefined : parsed
  }
  return undefined
}

/**
 * 回答状況が未回答かどうか判定
 */
export function isAnswerPending(status: number | undefined): boolean {
  return status === undefined || status === 回答状況['アンケート未回答'].value
}

/**
 * 回答状況が回答済かどうか判定
 */
export function isAnswerCompleted(status: number | undefined): boolean {
  return status === 回答状況['アンケート回答済'].value
}
