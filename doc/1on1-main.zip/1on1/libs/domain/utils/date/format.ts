/**
 * 日付フォーマット用ユーティリティ関数
 */

/**
 * 日付をYYYY/MM/DD形式の文字列に変換
 * @param date - Dateオブジェクト、日付文字列、またはnull/undefined
 * @returns YYYY/MM/DD形式の文字列、nullの場合はnull
 */
export function formatDate(date: Date): string
export function formatDate(dateStr: string): string
export function formatDate(dateOrStr: null | undefined): null
export function formatDate(dateOrStr: Date | string | null | undefined): string | null
export function formatDate(dateOrStr: Date | string | null | undefined): string | null {
  if (dateOrStr === null || dateOrStr === undefined) {
    return null
  }
  if (dateOrStr instanceof Date) {
    const year = dateOrStr.getFullYear()
    // Pleasanterの空日付（1899年）はnullとして扱う
    if (year === 1899) {
      return null
    }
    const month = String(dateOrStr.getMonth() + 1).padStart(2, '0')
    const day = String(dateOrStr.getDate()).padStart(2, '0')
    return `${year}/${month}/${day}`
  }
  // 文字列の場合: YYYY-MM-DDTHH:mm:ss → YYYY/MM/DD
  // Pleasanterの空日付（1899年）はnullとして扱う
  if (dateOrStr.startsWith('1899')) {
    return null
  }
  return dateOrStr.split('T')[0].replace(/-/g, '/')
}

/**
 * DateオブジェクトをYYYY/MM/DD形式に変換
 */
export function formatToJapaneseDate(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}/${month}/${day}`
}

/**
 * データの開始日を比較用形式に変換
 * @param dateString - 元の日付文字列 例: "2025/06/01", "2025-06-01", "2025年06月"
 * @returns 比較用日付文字列 例: "2025-06"
 */
export function formatDateForComparison(dateString: string): string {
  if (!dateString) return ''
  // "YYYY年MM月" 形式に対応（バッチ開始月で使用）
  const jpMatch = dateString.match(/^(\d{4})年(\d{1,2})月/)
  if (jpMatch) {
    return `${jpMatch[1]}-${jpMatch[2].padStart(2, '0')}`
  }
  return dateString.substring(0, 7).replace('/', '-')
}
