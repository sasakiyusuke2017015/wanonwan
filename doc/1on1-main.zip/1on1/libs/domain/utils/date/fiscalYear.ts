/**
 * 会計年度関連のユーティリティ関数
 */

import { formatToJapaneseDate } from './format'

export interface DateRange {
  start: string // YYYY/MM/DD
  end: string   // YYYY/MM/DD
}

export interface DateFilterOption {
  label: string
  value: string // JSON化したDateRange
}

/**
 * 今日の日付範囲を取得
 */
export function getTodayRange(): DateRange {
  const today = new Date()
  const formatted = formatToJapaneseDate(today)
  return { start: formatted, end: formatted }
}

/**
 * 今週の日付範囲を取得（日曜始まり）
 */
export function getThisWeekRange(): DateRange {
  const today = new Date()
  const dayOfWeek = today.getDay() // 0=日曜, 1=月曜, ...

  // 日曜日を見つける
  const sunday = new Date(today)
  sunday.setDate(today.getDate() - dayOfWeek)

  // 土曜日を見つける
  const saturday = new Date(sunday)
  saturday.setDate(sunday.getDate() + 6)

  return {
    start: formatToJapaneseDate(sunday),
    end: formatToJapaneseDate(saturday),
  }
}

/**
 * 今年の日付範囲を取得
 */
export function getThisYearRange(): DateRange {
  const today = new Date()
  const year = today.getFullYear()

  return {
    start: `${year}/01/01`,
    end: `${year}/12/31`,
  }
}

/**
 * 指定年度の開始日・終了日を取得（4月始まり）
 */
export function getFiscalYearRange(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/04/01`,
    end: `${fiscalYear + 1}/03/31`,
  }
}

/**
 * 指定年度の上半期を取得（4月〜9月）
 */
export function getFiscalYearFirstHalf(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/04/01`,
    end: `${fiscalYear}/09/30`,
  }
}

/**
 * 指定年度の下半期を取得（10月〜3月）
 */
export function getFiscalYearSecondHalf(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/10/01`,
    end: `${fiscalYear + 1}/03/31`,
  }
}

/**
 * 指定年度のQ1を取得（4月〜6月）
 */
export function getFiscalYearQ1(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/04/01`,
    end: `${fiscalYear}/06/30`,
  }
}

/**
 * 指定年度のQ2を取得（7月〜9月）
 */
export function getFiscalYearQ2(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/07/01`,
    end: `${fiscalYear}/09/30`,
  }
}

/**
 * 指定年度のQ3を取得（10月〜12月）
 */
export function getFiscalYearQ3(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear}/10/01`,
    end: `${fiscalYear}/12/31`,
  }
}

/**
 * 指定年度のQ4を取得（1月〜3月）
 */
export function getFiscalYearQ4(fiscalYear: number): DateRange {
  return {
    start: `${fiscalYear + 1}/01/01`,
    end: `${fiscalYear + 1}/03/31`,
  }
}

/**
 * 指定年月の日付範囲を取得
 */
export function getMonthRange(year: number, month: number): DateRange {
  const lastDay = new Date(year, month, 0).getDate()
  const monthStr = String(month).padStart(2, '0')

  return {
    start: `${year}/${monthStr}/01`,
    end: `${year}/${monthStr}/${String(lastDay).padStart(2, '0')}`,
  }
}

/**
 * 現在の年度を取得（4月始まり）
 */
export function getCurrentFiscalYear(): number {
  const today = new Date()
  const year = today.getFullYear()
  const month = today.getMonth() + 1

  // 1〜3月は前年度
  return month >= 4 ? year : year - 1
}

/**
 * YYYY/MM/DD形式の日付文字列を比較
 */
export function isDateInRange(date: string | null, range: DateRange): boolean {
  if (!date) return false

  // YYYY/MM/DD形式をYYYYMMDD数値に変換して比較
  const dateNum = parseInt(date.replace(/\//g, ''), 10)
  const startNum = parseInt(range.start.replace(/\//g, ''), 10)
  const endNum = parseInt(range.end.replace(/\//g, ''), 10)

  return dateNum >= startNum && dateNum <= endNum
}

/**
 * 日付フィルター用の選択肢を生成
 * @param monthsToShow - 表示する月数（デフォルト36ヶ月 = 3年）
 */
export function generateDateFilterOptions(monthsToShow: number = 36): DateFilterOption[] {
  const options: DateFilterOption[] = []
  const currentFiscalYear = getCurrentFiscalYear()

  // 年数を計算（12ヶ月 = 1年）
  const yearsToShow = Math.ceil(monthsToShow / 12)

  // 今日、今週、今年
  options.push(
    { label: '今日', value: JSON.stringify(getTodayRange()) },
    { label: '今週', value: JSON.stringify(getThisWeekRange()) },
    { label: '今年', value: JSON.stringify(getThisYearRange()) }
  )

  // 直近N ヶ月
  const today = new Date()
  for (let i = 0; i < monthsToShow; i++) {
    const date = new Date(today.getFullYear(), today.getMonth() - i, 1)
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const range = getMonthRange(year, month)

    options.push({
      label: `${year}年${String(month).padStart(2, '0')}月`,
      value: JSON.stringify(range),
    })
  }
  
  // 直近N年度
  for (let i = 0; i < yearsToShow; i++) {
    const fiscalYear = currentFiscalYear - i
    options.push({
      label: `${fiscalYear}年度`,
      value: JSON.stringify(getFiscalYearRange(fiscalYear)),
    })
  }

  // 直近N年度の上半期・下半期
  for (let i = 0; i < yearsToShow; i++) {
    const fiscalYear = currentFiscalYear - i
    options.push(
      {
        label: `${fiscalYear}年度上半期`,
        value: JSON.stringify(getFiscalYearFirstHalf(fiscalYear)),
      },
      {
        label: `${fiscalYear}年度下半期`,
        value: JSON.stringify(getFiscalYearSecondHalf(fiscalYear)),
      }
    )
  }

  // 直近N年度のQ1-Q4
  for (let i = 0; i < yearsToShow; i++) {
    const fiscalYear = currentFiscalYear - i
    options.push(
      {
        label: `${fiscalYear}年度1Q`,
        value: JSON.stringify(getFiscalYearQ1(fiscalYear)),
      },
      {
        label: `${fiscalYear}年度2Q`,
        value: JSON.stringify(getFiscalYearQ2(fiscalYear)),
      },
      {
        label: `${fiscalYear}年度3Q`,
        value: JSON.stringify(getFiscalYearQ3(fiscalYear)),
      },
      {
        label: `${fiscalYear}年度4Q`,
        value: JSON.stringify(getFiscalYearQ4(fiscalYear)),
      }
    )
  }


  return options
}
