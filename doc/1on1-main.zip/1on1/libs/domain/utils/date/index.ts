/**
 * 日付ユーティリティモジュール
 *
 * 使用例:
 * import { formatDate, getCurrentFiscalYear } from '@1on1/shared/utils/date'
 */

// フォーマット関数
export {
  formatDate,
  formatToJapaneseDate,
  formatDateForComparison,
} from './format'

// 会計年度・日付範囲関数
export {
  type DateRange,
  type DateFilterOption,
  getTodayRange,
  getThisWeekRange,
  getThisYearRange,
  getFiscalYearRange,
  getFiscalYearFirstHalf,
  getFiscalYearSecondHalf,
  getFiscalYearQ1,
  getFiscalYearQ2,
  getFiscalYearQ3,
  getFiscalYearQ4,
  getMonthRange,
  getCurrentFiscalYear,
  isDateInRange,
  generateDateFilterOptions,
} from './fiscalYear'
