/**
 * URLユーティリティ
 */

/**
 * URLテンプレートを実際のパラメータに置換
 *
 * @param template - URLテンプレート（例: '/employees/:userId'）
 * @param params - 置換するパラメータのオブジェクト（例: { userId: '123' }）
 * @returns 置換後のURL（例: '/employees/123'）
 *
 * @example
 * resolveUrlTemplate('/employees/:userId', { userId: '123' })
 * // => '/employees/123'
 *
 * resolveUrlTemplate('/teams/:teamId/members/:userId', { teamId: 'A', userId: '123' })
 * // => '/teams/A/members/123'
 */
export function resolveUrlTemplate(
  template: string,
  params: Record<string, string | undefined>
): string {
  let resolved = template

  Object.entries(params).forEach(([key, value]) => {
    resolved = resolved.replace(`:${key}`, value || '')
  })

  return resolved
}
