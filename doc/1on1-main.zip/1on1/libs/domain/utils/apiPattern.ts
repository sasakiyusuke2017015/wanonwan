/**
 * API パターンマッチングユーティリティ
 * ワイルドカード（*）を含むAPIパターンのマッチング処理を提供
 *
 * 使用例:
 * ```typescript
 * matchesAPIPattern('/api/users/123', '/api/users/*') // true
 * matchesAPIPattern('/api/dashboard/stats', '/api/*') // true
 * canAccessAPI('/api/users/123', ['/api/users/*', '/api/auth/*']) // true
 * ```
 */

/**
 * APIパスがパターンにマッチするか判定
 * @param apiPath チェック対象のAPIパス（例: '/api/users/123'）
 * @param pattern ワイルドカードを含むパターン（例: '/api/users/*'）
 * @returns マッチする場合 true
 */
export function matchesAPIPattern(apiPath: string, pattern: string): boolean {
  // ワイルドカードと特殊文字をエスケープして正規表現に変換
  // '/api/users/*' → '^/api/users/.*$'
  const regex = new RegExp(
    '^' + pattern.replace(/\*/g, '.*').replace(/\//g, '\\/') + '$'
  )
  return regex.test(apiPath)
}

/**
 * APIパスが許可されたパターンリストのいずれかにマッチするか判定
 * @param apiPath チェック対象のAPIパス
 * @param allowedPatterns 許可されたAPIパターンのリスト
 * @returns いずれかのパターンにマッチする場合 true
 */
export function canAccessAPI(apiPath: string, allowedPatterns: string[]): boolean {
  return allowedPatterns.some((pattern) => matchesAPIPattern(apiPath, pattern))
}
