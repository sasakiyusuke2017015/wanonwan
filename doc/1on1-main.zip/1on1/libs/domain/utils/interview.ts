/**
 * 面談関連ユーティリティ
 * 面談メモの閲覧権限チェック等
 */

/**
 * 面談内容閲覧者のJSON文字列をパースしてユーザーIDの配列を取得
 * @param viewersJson ["userId1", "userId2"] 形式のJSON文字列
 * @returns ユーザーIDの配列
 */
export function parseInterviewViewers(viewersJson: string | undefined | null): string[] {
  if (!viewersJson) return [];
  try {
    const parsed = JSON.parse(viewersJson);
    if (Array.isArray(parsed)) {
      return parsed.map(String);
    }
    return [];
  } catch {
    return [];
  }
}

/**
 * 面談メモの表示内容を決定（閲覧権限チェック）
 * - 閲覧権限がある場合: 元の面談メモを表示
 * - 閲覧権限がない場合: 「○○さんが面談メモを記入」に置き換え
 *
 * @param memo 元の面談メモ
 * @param interviewerName 面談者の名前
 * @param viewersJson 面談内容閲覧者のJSON文字列
 * @param currentUserId 現在のログインユーザーID
 * @returns 表示用の面談メモ（閲覧権限がない場合はマスク済み）
 */
export function getMaskedInterviewMemo(
  memo: string | undefined | null,
  interviewerName: string | undefined | null,
  viewersJson: string | undefined | null,
  currentUserId: string | undefined | null
): string | null {
  // 面談メモがない場合はnull
  if (!memo) return null;

  // 現在のユーザーIDがない場合は閲覧不可
  if (!currentUserId) {
    return interviewerName ? `${interviewerName}さんが面談メモを記入` : '面談メモあり';
  }

  // 閲覧者リストをパース
  const viewers = parseInterviewViewers(viewersJson);

  // 閲覧者リストが空（＝未設定）の場合は元の内容を表示
  // ※面談実施済でない場合は面談内容閲覧者が設定されていないため
  if (viewers.length === 0) {
    return memo;
  }

  // 現在のユーザーが閲覧者リストに含まれているかチェック
  if (viewers.includes(currentUserId)) {
    return memo;
  }

  // 閲覧権限がない場合は置き換え
  return interviewerName ? `${interviewerName}さんが面談メモを記入` : '面談メモあり';
}
