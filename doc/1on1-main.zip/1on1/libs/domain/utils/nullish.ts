/**
 * Nullish チェック用ユーティリティ
 *
 * 値が「空」かどうかを判定する純粋関数
 */

/**
 * 値がnull的（nullish）かどうかを判定（型ガード版）
 *
 * 以下の値をnull的として扱い、trueを返します：
 * - null
 * - undefined
 * - 空文字列 ""
 * - NaN
 * - 空配列 []
 * - 空オブジェクト {}
 *
 * @param value - チェックする値
 * @returns null的な値の場合true、それ以外はfalse
 *
 * @example
 * isNullish(null) // true
 * isNullish(undefined) // true
 * isNullish('') // true
 * isNullish(NaN) // true
 * isNullish([]) // true
 * isNullish({}) // true
 * isNullish(0) // false
 * isNullish('text') // false
 * isNullish([1, 2]) // false
 */
export function isNullish(value: unknown): value is null | undefined | '' {
  // null または undefined
  if (value === null || value === undefined) {
    return true
  }

  // 空文字列
  if (value === '') {
    return true
  }

  // NaN
  if (typeof value === 'number' && Number.isNaN(value)) {
    return true
  }

  // 空配列
  if (Array.isArray(value) && value.length === 0) {
    return true
  }

  // 空オブジェクト
  if (
    typeof value === 'object' &&
    value !== null &&
    Object.keys(value).length === 0 &&
    value.constructor === Object
  ) {
    return true
  }

  return false
}

/**
 * ブラウザ環境かどうかを判定
 *
 * @returns ブラウザ環境の場合 true、Node.js などサーバー環境の場合 false
 *
 * @example
 * if (isBrowser()) {
 *   localStorage.setItem('key', 'value')
 * }
 */
export function isBrowser(): boolean {
  return !isNullish(globalThis) && 'window' in globalThis
}
