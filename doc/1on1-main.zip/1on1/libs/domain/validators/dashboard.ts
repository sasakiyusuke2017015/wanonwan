/**
 * Dashboard (ダッシュボード) 関連の Valibot スキーマ
 */

import * as v from 'valibot'

// ダッシュボード統計結果スキーマ（完全版）
export const DashboardResultSchema = v.object({
  総ユーザー数: v.number(),
  総アンケート数: v.number(),
  総回答数: v.number(),
  未回答数: v.number(),
  回答率: v.number(),
  平均満足度: v.optional(v.number()),
  最新アンケート: v.optional(
    v.object({
      掲載ID: v.number(),
      タイトル: v.string(),
      掲載状況: v.optional(v.string()),
      開始: v.optional(v.string()),
      完了: v.optional(v.string()),
    })
  ),
})

// トレンドデータポイント
export const TrendDataPointSchema = v.object({
  日付: v.string(),
  満足度: v.optional(v.number()),
  業務負荷: v.optional(v.number()),
  職場環境: v.optional(v.number()),
  人間関係: v.optional(v.number()),
  ストレス: v.optional(v.number()),
  回答数: v.number(),
})

// トレンドデータスキーマ（配列）
export const TrendDataSchema = v.array(TrendDataPointSchema)

// チャートデータスキーマ（レスポンス）
export const ChartDataSchema = v.object({
  trends: TrendDataSchema,
  summary: v.optional(
    v.object({
      averageSatisfaction: v.optional(v.number()),
      totalResponses: v.number(),
    })
  ),
})

// リクエストスキーマ
export const GetChartDataRequestSchema = v.object({
  startDate: v.optional(v.string()),
  endDate: v.optional(v.string()),
  userId: v.optional(v.string()),
})

// 型エクスポート
export type DashboardResult = v.InferOutput<typeof DashboardResultSchema>
export type TrendDataPoint = v.InferOutput<typeof TrendDataPointSchema>
export type TrendData = v.InferOutput<typeof TrendDataSchema>
export type ChartData = v.InferOutput<typeof ChartDataSchema>
export type GetChartDataRequest = v.InferOutput<typeof GetChartDataRequestSchema>
