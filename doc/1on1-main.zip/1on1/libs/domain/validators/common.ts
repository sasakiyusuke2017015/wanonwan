/**
 * 共通スキーマ定義
 *
 * すべてのAPIエンドポイントで使用される共通の型定義
 */

import * as v from 'valibot'

/**
 * 1on1統一レスポンス
 *
 * すべてのAPIエンドポイントで使用される共通レスポンス形式。
 * data フィールドはジェネリック型で、各エンドポイント固有のデータ型を指定可能。
 */
export const createOneOnOneResponseSchema = <TData extends v.BaseSchema<unknown, unknown, v.BaseIssue<unknown>>>(
  dataSchema: TData
) =>
  v.object({
    code: v.optional(v.string(), '200'),
    status: v.optional(v.string(), 'success'),
    message: v.optional(v.string(), ''),
    data: v.optional(v.nullable(dataSchema)),
  })

/**
 * OneOnOneResponse の型推論ヘルパー
 */
export type OneOnOneResponse<T> = {
  code: string
  status: string
  message: string
  data: T | null | undefined
}

/**
 * エラーレスポンス
 */
export const ErrorResponseSchema = v.object({
  code: v.string(),
  status: v.string(),
  message: v.string(),
  detail: v.optional(v.nullable(v.string())),
})

export type ErrorResponse = v.InferOutput<typeof ErrorResponseSchema>

/**
 * 評価結果データ（definitions.yamlの評価項目から動的生成）
 *
 * 各評価項目（満足度、業務負荷、職場環境、人間関係、ストレス）の値を格納
 */
export const EvaluationDataSchema = v.object({
  満足度: v.optional(v.nullable(v.number())),
  業務負荷: v.optional(v.nullable(v.number())),
  職場環境: v.optional(v.nullable(v.number())),
  人間関係: v.optional(v.nullable(v.number())),
  ストレス: v.optional(v.nullable(v.number())),
})

export type EvaluationData = v.InferOutput<typeof EvaluationDataSchema>

// ===========================
// ステータス定義（Pleasanter Wiki 区分値マスタに準拠）
// ===========================

/**
 * 回答状況（数値コード）
 * - 100: 未回答
 * - 900: アンケート回答済
 */
export const AnswerStatusCodeSchema = v.pipe(
  v.union([v.number(), v.null()]),
  v.transform((val) => val ?? undefined)
)
export type AnswerStatusCode = number | undefined

/**
 * 掲載状況（数値コード）
 * - 100: 未掲載
 * - 150: 予約
 * - 200: 実施中
 * - 900: 完了
 * - 910: 保留
 * - 999: エラー
 */
export const PublishStatusCodeSchema = v.pipe(
  v.union([v.number(), v.null()]),
  v.transform((val) => val ?? undefined)
)
export type PublishStatusCode = number | undefined

/**
 * 健康状態（数値コード）
 */
export const HealthStatusCodeSchema = v.pipe(
  v.union([v.number(), v.null()]),
  v.transform((val) => val ?? undefined)
)
export type HealthStatusCode = number | undefined

/**
 * 面談方式（文字列: 対面/Web/電話）
 */
export const InterviewMethodSchema = v.optional(v.string())
export type InterviewMethodValue = string | undefined

