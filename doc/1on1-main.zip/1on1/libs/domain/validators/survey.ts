/**
 * Survey (アンケート) 関連の Valibot スキーマ
 */

import * as v from 'valibot'
import {
  PublishStatusCodeSchema,
  AnswerStatusCodeSchema,
  InterviewMethodSchema,
} from './common'

/**
 * 回答形式
 */
export const AnswerFormatSchema = v.union([
  v.literal('ラジオボタン'),
  v.literal('セレクトボックス'),
  v.literal('チェックボックス'),
  v.literal('テキストボックス'),
  v.literal('テキストエリア'),
  v.literal('電話番号'),
  v.literal('郵便番号'),
])

/**
 * 質問データの型
 */
export const QuestionSchema = v.object({
  質問ID: v.number(),
  タイトル: v.string(),
  タイトル備考: v.optional(v.string(), ''),
  質問内容: v.string(),
  内容備考: v.optional(v.string(), ''),
  回答形式: AnswerFormatSchema,
  選択肢: v.optional(v.array(v.string()), []),
  ソート順: v.number(),
  必須回答: v.boolean(),
  追加記入欄あり: v.boolean(),
})

/**
 * 回答済み質問データの型
 */
export const QuestionWithAnswerSchema = v.intersect([
  QuestionSchema,
  v.object({
    回答内容: v.string(),
  }),
])

/**
 * アンケート詳細データの型（掲載設定から取得）
 */
export const SurveyDetailSchema = v.object({
  掲載ID: v.number(),
  タイトル: v.string(),
  アンケート内容JSON: v.array(QuestionSchema),
  掲載状況: v.optional(PublishStatusCodeSchema),
  開始: v.optional(v.string()),
  完了: v.optional(v.string()),
  回答率: v.optional(v.number()),
  // AI関連
  ユーザー用生成プロンプト: v.optional(v.string()),
  サポーター用生成プロンプト: v.optional(v.string()),
  ユーザー用生成回答: v.optional(v.string()),
})

/**
 * アンケート一覧アイテム（掲載設定）
 *
 * - 掲載状況: 数値コード (200=実施中, 900=完了 等)
 * - 回答状況: 数値コード (100=未回答, 900=アンケート回答済)
 */
export const SurveyListItemSchema = v.object({
  // 掲載設定
  掲載ID: v.number(),
  タイトル: v.string(),
  掲載内容: v.optional(v.string()), // Body
  掲載状況: v.optional(PublishStatusCodeSchema),
  開始: v.optional(v.string()),
  完了: v.optional(v.string()),
  回答率: v.optional(v.number()),
  アンケート選択: v.optional(v.string()),
  // 回答結果（結合クエリで取得）
  回答ID: v.optional(v.number()),
  回答状況: v.optional(AnswerStatusCodeSchema),
  アンケート内容JSON: v.optional(v.unknown()),
  ユーザー用生成回答: v.optional(v.nullable(v.string())),
  ユーザー用生成プロンプト: v.optional(v.nullable(v.string())),
  サポーター用生成プロンプト: v.optional(v.nullable(v.string())),
})

/**
 * アンケート一覧レスポンス
 */
export const SurveyListResponseSchema = v.object({
  surveys: v.array(SurveyListItemSchema),
  total: v.number(),
})

/**
 * フォーム回答データの型（オブジェクト形式）
 */
export const SurveyAnswersSchema = v.record(v.string(), v.string())

/**
 * 送信用回答アイテムの型
 */
export const AnswerItemSchema = v.object({
  question_id: v.string(),
  question: v.string(),
  answer: v.string(),
})

/**
 * アンケート回答送信リクエスト
 */
export const SubmitAnswerRequestSchema = v.object({
  surveyId: v.string(),
  answers: v.array(AnswerItemSchema),
  // AI生成関連（オプション）
  aiGenerated: v.optional(
    v.object({
      userPrompt: v.optional(v.string()),
      userResponse: v.optional(v.string()),
      supporterPrompt: v.optional(v.string()),
      supporterResponse: v.optional(v.string()),
    })
  ),
})

/**
 * アンケート回答送信レスポンス
 */
export const SubmitAnswerResponseSchema = v.object({
  success: v.boolean(),
  message: v.string(),
  answerId: v.optional(v.number()),
})

/**
 * アンケート詳細取得リクエスト
 */
export const GetSurveyRequestSchema = v.object({
  surveyId: v.string(),
})

/**
 * クエリパラメータ用の数値変換ヘルパー
 * クエリパラメータは常に文字列で送られるため、数値に変換する
 */
const queryNumberSchema = (defaultValue: number) =>
  v.optional(
    v.pipe(
      v.union([v.string(), v.number()]),
      v.transform((val: string | number) => (typeof val === 'string' ? parseInt(val, 10) : val))
    ),
    defaultValue
  )

/**
 * アンケート一覧取得リクエスト
 */
export const GetSurveysRequestSchema = v.object({
  limit: queryNumberSchema(50),
  offset: queryNumberSchema(0),
  answerStatus: v.optional(v.string()), // 回答状況フィルター
  publishStatus: v.optional(v.string()), // 掲載状況フィルター
  recentMonths: v.optional(
    v.pipe(
      v.union([v.string(), v.number()]),
      v.transform((val: string | number) => (typeof val === 'string' ? parseInt(val, 10) : val))
    )
  ), // 期間フィルター（過去Nヶ月）
  orderBy: v.optional(v.string()), // ソート順（例: "開始 DESC", "回答率 ASC"）
})

/**
 * AI生成リクエスト（ストリーミング）
 */
export const GenerateAIRequestSchema = v.object({
  answerId: v.string(),
  userPrompt: v.string(),
  agentId: v.optional(v.string(), ''),
})

/**
 * AI生成レスポンス（非ストリーミング版）
 */
export const GenerateAIResponseSchema = v.object({
  success: v.boolean(),
  message: v.string(),
})

/**
 * 面談実施リクエスト
 */
export const SubmitInterviewRequestSchema = v.object({
  answerId: v.string(),
  userId: v.string(),
  userCode: v.string(),
  interviewMemo: v.string(),
  nextAction: v.string(),
  interviewMethod: InterviewMethodSchema,
})

/**
 * 面談実施レスポンス
 */
export const SubmitInterviewResponseSchema = v.object({
  success: v.boolean(),
  message: v.string(),
})

/**
 * アンケート保存（途中保存）リクエスト
 */
export const SaveSurveyRequestSchema = v.object({
  surveyId: v.string(),
  answers: v.array(AnswerItemSchema),
  // AI生成関連（オプション）
  aiGenerated: v.optional(
    v.object({
      userPrompt: v.optional(v.string()),
      userResponse: v.optional(v.string()),
      supporterPrompt: v.optional(v.string()),
      supporterResponse: v.optional(v.string()),
    })
  ),
})

/**
 * アンケート保存（途中保存）レスポンス
 */
export const SaveSurveyResponseSchema = v.object({
  success: v.boolean(),
  message: v.string(),
  answerId: v.optional(v.number()),
})

// 型推論エクスポート
export type AnswerFormat = v.InferOutput<typeof AnswerFormatSchema>
export type Question = v.InferOutput<typeof QuestionSchema>
export type QuestionWithAnswer = v.InferOutput<typeof QuestionWithAnswerSchema>
export type SurveyDetail = v.InferOutput<typeof SurveyDetailSchema>
export type SurveyListItem = v.InferOutput<typeof SurveyListItemSchema>
export type SurveyListResponse = v.InferOutput<typeof SurveyListResponseSchema>
export type SurveyAnswers = v.InferOutput<typeof SurveyAnswersSchema>
export type AnswerItem = v.InferOutput<typeof AnswerItemSchema>
export type SubmitAnswerRequest = v.InferOutput<typeof SubmitAnswerRequestSchema>
export type SubmitAnswerResponse = v.InferOutput<typeof SubmitAnswerResponseSchema>
export type GetSurveyRequest = v.InferOutput<typeof GetSurveyRequestSchema>
export type GetSurveysRequest = v.InferOutput<typeof GetSurveysRequestSchema>
export type GenerateAIRequest = v.InferOutput<typeof GenerateAIRequestSchema>
export type GenerateAIResponse = v.InferOutput<typeof GenerateAIResponseSchema>
export type SubmitInterviewRequest = v.InferOutput<typeof SubmitInterviewRequestSchema>
export type SubmitInterviewResponse = v.InferOutput<typeof SubmitInterviewResponseSchema>
export type SaveSurveyRequest = v.InferOutput<typeof SaveSurveyRequestSchema>
export type SaveSurveyResponse = v.InferOutput<typeof SaveSurveyResponseSchema>
