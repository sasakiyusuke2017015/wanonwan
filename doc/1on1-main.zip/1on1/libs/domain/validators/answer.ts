/**
 * Answer (回答) 関連の Valibot スキーマ
 *
 * ステータス値は数値コードで返却
 */

import * as v from 'valibot'
import {
  AnswerStatusCodeSchema,
  HealthStatusCodeSchema,
  InterviewMethodSchema,
} from './common'

/**
 * 回答結果スキーマ
 *
 * ステータスは数値コード:
 * - 回答状況: 100=未回答, 200=回答済, 400=面談日程調整済, 900=完了
 * - 健康状態: 数値コード
 */
export const AnswerResultSchema = v.object({
  回答ID: v.number(),
  回答状況: v.optional(AnswerStatusCodeSchema),
  回答者: v.optional(v.string()),
  掲載設定: v.optional(v.string()),
  面談者: v.optional(v.string()),
  健康状態: v.optional(HealthStatusCodeSchema),
  面談方式: v.optional(InterviewMethodSchema),
  面談候補: v.optional(v.string()),
  回答日: v.optional(v.string()),
  面談日: v.optional(v.string()),
  サポーター用生成プロンプト: v.optional(v.string(), ''),
  サポーター用生成回答: v.optional(v.string(), ''),
  ユーザー用生成プロンプト: v.optional(v.string(), ''),
  ユーザー用生成回答: v.optional(v.string(), ''),
  アンケート内容JSON: v.optional(v.string(), ''),
  評価結果JSON: v.optional(v.string(), ''),
  面談メモ: v.optional(v.string(), ''),
  面談内容閲覧者: v.optional(v.string()), // ["userId1", "userId2"] 形式のJSON文字列
  次回までのアクション: v.optional(v.string(), ''),
  作成日時: v.optional(v.string()),
  コメント: v.optional(v.string(), ''),
})

/**
 * 回答結果一覧アイテムスキーマ（Python互換）
 * 一覧表示に必要なフィールドを全て含む
 * ユーザー情報（名前、役職、部署）はユーザーマスタから結合
 */
export const AnswerListItemSchema = v.object({
  回答ID: v.number(),
  回答状況: v.optional(AnswerStatusCodeSchema),
  回答者: v.optional(v.string()),
  掲載設定: v.optional(v.string()),
  アンケートタイトル: v.optional(v.string()), // アンケートマスタから結合
  バッチ開始月: v.optional(v.string()), // 掲載設定から結合
  健康状態: v.optional(HealthStatusCodeSchema),
  面談方式: v.optional(InterviewMethodSchema),
  面談候補: v.optional(v.string()), // ["userId1", "userId2"] 形式のJSON文字列
  回答日: v.optional(v.string()),
  面談日: v.optional(v.string()),
  評価結果JSON: v.optional(v.string()),
  面談メモ: v.optional(v.string()),
  面談内容閲覧者: v.optional(v.string()), // ["userId1", "userId2"] 形式のJSON文字列
  作成日時: v.optional(v.string()),
  // ユーザーマスタから結合するフィールド
  回答者名: v.optional(v.string()),
  役職: v.optional(v.string()),
  所属本部: v.optional(v.string()),
  所属部: v.optional(v.string()),
  所属課: v.optional(v.string()),
  メールアドレス: v.optional(v.string()),
  面談者: v.optional(v.string()), // 面談者の名前（APIで解決済み）
})

// メンバースキーマ
export const EmployeeSchema = v.object({
  ユーザーID: v.number(),
  名前: v.string(),
  メールアドレス: v.optional(v.string()),
  役職: v.optional(v.string()),
  所属本部: v.optional(v.string()),
  所属部: v.optional(v.string()),
  所属課: v.optional(v.string()),
})

/**
 * クエリパラメータ用の数値変換ヘルパー
 * クエリパラメータは常に文字列で送られるため、数値に変換する
 */
const queryNumberSchema = (defaultValue: number) =>
  v.optional(
    v.pipe(
      v.union([v.string(), v.number()]),
      v.transform((val: string | number) => (typeof val === 'string' ? parseInt(val, 10) : val))
    ),
    defaultValue
  )

const optionalQueryNumberSchema = () =>
  v.optional(
    v.pipe(
      v.union([v.string(), v.number()]),
      v.transform((val: string | number) => (typeof val === 'string' ? parseInt(val, 10) : val))
    )
  )

// リクエスト・レスポンススキーマ
export const GetAnswersRequestSchema = v.object({
  limit: optionalQueryNumberSchema(),
  offset: queryNumberSchema(0),
  recentMonths: optionalQueryNumberSchema(), // 期間フィルター（過去Nヶ月）
})

export const GetAnswerRequestSchema = v.object({
  answerId: v.string(),
})

/**
 * 回答更新リクエスト（Python互換: 数値コード）
 */
export const UpdateAnswerRequestSchema = v.object({
  answerId: v.string(),
  data: v.object({
    回答状況: v.optional(AnswerStatusCodeSchema),
    健康状態: v.optional(HealthStatusCodeSchema),
    面談方式: v.optional(InterviewMethodSchema),
    // 面談候補はアクセス制御の根幹のためAPI経由での変更を禁止
    面談日: v.optional(v.string()),
    面談メモ: v.optional(v.string()),
    次回までのアクション: v.optional(v.string()),
    評価結果JSON: v.optional(v.string()),
  }),
})

// 型エクスポート
export type AnswerResult = v.InferOutput<typeof AnswerResultSchema>
export type AnswerListItem = v.InferOutput<typeof AnswerListItemSchema>
export type Employee = v.InferOutput<typeof EmployeeSchema>
export type GetAnswersRequest = v.InferOutput<typeof GetAnswersRequestSchema>
export type GetAnswerRequest = v.InferOutput<typeof GetAnswerRequestSchema>
export type UpdateAnswerRequest = v.InferOutput<typeof UpdateAnswerRequestSchema>
