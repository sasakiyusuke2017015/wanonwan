/**
 * ユーザー・認証関連のValibot スキーマ
 *
 * Python からの移行:
 * - apps/api/app/routers/auth/schemas.py
 * - apps/api/app/routers/answers/schemas.py (User)
 */

import * as v from 'valibot'

// ============================================================
// ユーザー基本情報
// ============================================================

/**
 * User スキーマ
 *
 * Python: apps/api/app/routers/answers/schemas.py - User
 */
export const UserSchema = v.object({
  ユーザーID: v.optional(v.nullable(v.union([v.number(), v.string()]))),
  ユーザーコード: v.optional(v.nullable(v.string())),
  名前: v.optional(v.nullable(v.string())),
  メールアドレス: v.optional(v.nullable(v.pipe(v.string(), v.email()))),
  所属本部: v.optional(v.nullable(v.string())),
  所属部: v.optional(v.nullable(v.string())),
  所属課: v.optional(v.nullable(v.string())),
  役職: v.optional(v.nullable(v.string())),
})

export type User = v.InferOutput<typeof UserSchema>

// ============================================================
// ログイン関連
// ============================================================

/**
 * LoginRequest スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - LoginRequest
 * Note: Python では OAuth2 標準の username を使用していたが、TypeScript では email に統一
 */
export const LoginRequestSchema = v.object({
  email: v.pipe(v.string(), v.email()),
  password: v.string(),
})

export type LoginRequest = v.InferOutput<typeof LoginRequestSchema>

/**
 * LoginResponse スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - LoginResponse
 */
export const LoginResponseSchema = v.object({
  access_token: v.string(),
  refresh_token: v.string(),
  token_type: v.optional(v.string(), 'bearer'),
  user: UserSchema,
})

export type LoginResponse = v.InferOutput<typeof LoginResponseSchema>

// ============================================================
// トークンリフレッシュ関連
// ============================================================

/**
 * RefreshRequest スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - RefreshRequest
 */
export const RefreshRequestSchema = v.object({
  refresh_token: v.string(),
})

export type RefreshRequest = v.InferOutput<typeof RefreshRequestSchema>

/**
 * RefreshResponse スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - RefreshResponse
 */
export const RefreshResponseSchema = v.object({
  access_token: v.string(),
  token_type: v.optional(v.string(), 'bearer'),
})

export type RefreshResponse = v.InferOutput<typeof RefreshResponseSchema>

// ============================================================
// パスワードリセット関連
// ============================================================

/**
 * ForgotPasswordRequest スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - ForgotPasswordRequest
 */
export const ForgotPasswordRequestSchema = v.object({
  email: v.pipe(v.string(), v.email()),
})

export type ForgotPasswordRequest = v.InferOutput<typeof ForgotPasswordRequestSchema>

/**
 * ResetPasswordRequest スキーマ
 *
 * Python: apps/api/app/routers/auth/schemas.py - ResetPasswordRequest
 */
export const ResetPasswordRequestSchema = v.object({
  token: v.string(),
  new_password: v.pipe(
    v.string(),
    v.minLength(8, 'パスワードは8文字以上必要です'),
    v.maxLength(30, 'パスワードは30文字以内にしてください')
  ),
})

export type ResetPasswordRequest = v.InferOutput<typeof ResetPasswordRequestSchema>

// ============================================================
// パスワード変更関連
// ============================================================

/**
 * ChangePasswordRequest スキーマ
 *
 * ログイン済みユーザーが自分のパスワードを変更する際に使用
 */
export const ChangePasswordRequestSchema = v.object({
  current_password: v.string(),
  new_password: v.pipe(
    v.string(),
    v.minLength(8, 'パスワードは8文字以上必要です'),
    v.maxLength(30, 'パスワードは30文字以内にしてください')
  ),
  confirm_password: v.string(),
})

export type ChangePasswordRequest = v.InferOutput<typeof ChangePasswordRequestSchema>
