/**
 * スケジュールアダプター
 *
 * Pleasanter レコード → CalendarEvent の変換（読み取り方向のみ）
 * 書き込み方向はサービス層で SITE_SCHEDULE.columns を使い直接 payload を構築
 */

// NOTE: CalendarEvent 型は @ui-catalog/core/types から import すべきだが、
// 循環依存を避けるため、ここでは型定義をコピーしている
export type DayOfWeek = 0 | 1 | 2 | 3 | 4 | 5 | 6

export interface CalendarEvent {
  readonly id: string
  readonly title: string
  readonly startTime: Date
  readonly endTime: Date
  readonly color: string
  readonly description?: string
  readonly icon?: string
  readonly allDay?: boolean
  readonly repeat?: readonly DayOfWeek[]
  readonly repeatPeriodStart?: Date
  readonly repeatPeriodEnd?: Date
}

// ========================================
// 曜日変換マップ（日本語名 → 数値）
// ========================================

const DAY_NAME_TO_NUMBER: Record<string, DayOfWeek> = {
  '日': 0,
  '月': 1,
  '火': 2,
  '水': 3,
  '木': 4,
  '金': 5,
  '土': 6,
}

// ========================================
// 変換関数: Pleasanter → CalendarEvent
// ========================================

/**
 * Pleasanter レコード → CalendarEvent
 */
export function toCalendarEvent(record: Record<string, unknown>): CalendarEvent {
  const id = String(record['イベントID'] || record['IssueId'] || '')
  const title = String(record['タイトル'] || '')
  const startTime = new Date(String(record['開始日時'] || ''))
  const endTime = new Date(String(record['終了日時'] || ''))
  const allDay = Boolean(record['終日'])
  const description = record['説明'] ? String(record['説明']) : undefined
  const color = String(record['色'] || '#3b82f6')
  const icon = record['アイコン'] ? String(record['アイコン']) : undefined

  // 繰り返し曜日のパース（日本語名 → 数値）
  let repeat: readonly DayOfWeek[] | undefined
  if (record['繰り返し曜日']) {
    try {
      const parsed = JSON.parse(String(record['繰り返し曜日']))
      if (Array.isArray(parsed)) {
        repeat = parsed
          .map((name: string) => DAY_NAME_TO_NUMBER[name])
          .filter((n): n is DayOfWeek => n !== undefined) as DayOfWeek[]
      }
    } catch {
      // パース失敗時は undefined
    }
  }

  // 繰り返し期間
  const repeatPeriodStart = record['繰り返し期間開始'] ? new Date(String(record['繰り返し期間開始'])) : undefined
  const repeatPeriodEnd = record['繰り返し期間終了'] ? new Date(String(record['繰り返し期間終了'])) : undefined

  return {
    id,
    title,
    startTime,
    endTime,
    color,
    allDay,
    description,
    icon,
    repeat,
    repeatPeriodStart,
    repeatPeriodEnd,
  }
}

