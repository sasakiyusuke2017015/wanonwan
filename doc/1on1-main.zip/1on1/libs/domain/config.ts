/**
 * アプリケーション設定
 *
 * 評価項目、ステータス定義、権限、サイト設定などの定数
 */

import type {
  Definitions,
  Permissions,
  HttpStatus,
} from './types/config'

export const DEFINITIONS: Definitions = {
  "評価項目": {
    "満足度": {
      "order": 1,
      "label": "満足度",
      "shortLabel": "満足度",
      "key": "satisfaction",
      "borderColor": "rgb(75, 192, 192)",
      "backgroundColor": "rgba(75, 192, 192, 0.2)"
    },
    "業務負荷": {
      "order": 2,
      "label": "業務負荷",
      "shortLabel": "業務負荷",
      "key": "workload",
      "borderColor": "rgb(255, 205, 86)",
      "backgroundColor": "rgba(255, 205, 86, 0.2)"
    },
    "職場環境": {
      "order": 3,
      "label": "職場環境",
      "shortLabel": "職場環境",
      "key": "environment",
      "borderColor": "rgb(54, 162, 235)",
      "backgroundColor": "rgba(54, 162, 235, 0.2)"
    },
    "人間関係": {
      "order": 4,
      "label": "人間関係",
      "shortLabel": "人間関係",
      "key": "relationship",
      "borderColor": "rgb(153, 102, 255)",
      "backgroundColor": "rgba(153, 102, 255, 0.2)"
    },
    "ストレス": {
      "order": 5,
      "label": "ストレス",
      "shortLabel": "ストレス",
      "key": "stress",
      "borderColor": "rgb(255, 99, 132)",
      "backgroundColor": "rgba(255, 99, 132, 0.2)"
    }
  },
} as const


export const PERMISSIONS: Permissions = {
  "permissions": {
    "page": {
      "home": {
        "description": "ホームページ表示",
        "path": "/home"
      },
      "dashboard": {
        "description": "ダッシュボード表示",
        "path": "/dashboard"
      },
      "answers": {
        "description": "回答一覧表示",
        "path": "/answers"
      },
      "answer-detail": {
        "description": "回答詳細表示",
        "path": "/answers/details"
      },
      "surveys": {
        "description": "アンケート一覧表示",
        "path": "/surveys"
      },
      "survey-detail": {
        "description": "アンケート詳細表示",
        "path": "/surveys/:id"
      },
      "schedule": {
        "description": "スケジュール表示",
        "path": "/schedule"
      },
      "chat": {
        "description": "チャット表示",
        "path": "/chat"
      },
      "attendance": {
        "description": "勤怠表示",
        "path": "/attendance"
      },
      "project": {
        "description": "プロジェクト表示",
        "path": "/project"
      }
    },
    "api": {
      "auth": {
        "description": "認証",
        "endpoints": [
          "/api/auth/login",
          "/api/auth/refresh",
          "/api/auth/logout"
        ]
      },
      "users_read": {
        "description": "ユーザー情報読取",
        "endpoints": [
          "/api/users/me"
        ]
      },
      "users_write": {
        "description": "ユーザー情報更新",
        "endpoints": [
          "/api/users/password"
        ]
      },
      "dashboard_read": {
        "description": "ダッシュボードデータ読取",
        "endpoints": [
          "/api/dashboard/summary"
        ]
      },
      "answers_read": {
        "description": "回答データ読取",
        "endpoints": [
          "/api/answers",
          "/api/answers/*"
        ]
      },
      "answers_write": {
        "description": "回答データ更新",
        "endpoints": []
      },
      "surveys_read": {
        "description": "アンケート読取",
        "endpoints": [
          "/api/surveys",
          "/api/surveys/*"
        ]
      },
      "surveys_write": {
        "description": "アンケート作成・編集",
        "endpoints": [
          "/api/surveys/*/submit",
          "/api/surveys/*/save",
          "/api/surveys/*/interview",
          "/api/surveys/*/ai/user",
          "/api/surveys/*/ai/supporter"
        ]
      },
      "surveys_delete": {
        "description": "アンケート削除",
        "endpoints": []
      },
      "log": {
        "description": "ログ",
        "endpoints": [
          "/api/log",
          "/api/log/recent",
          "/api/log/error"
        ]
      },
      "job": {
        "description": "管理者API",
        "endpoints": [
          "/api/job/start-surveys",
          "/api/job/finish-surveys",
          "/api/job/delete-surveys"
        ]
      }
    },
    "feature": {
      "settings": {
        "description": "設定ページ表示"
      },
      "notifications": {
        "description": "お知らせ表示"
      },
      "export": {
        "description": "データエクスポート"
      }
    }
  },
  "roles": {
    "employee": {
      "description": "一般メンバー - Answer/Survey",
      "positionCode": {
        "min": 300,
        "max": 499
      },
      "permissions": {
        "page": [
          "answers",
          "answer-detail",
          "surveys",
          "survey-detail",
          "schedule"
        ],
        "api": [
          "auth",
          "users_read",
          "answers_read",
          "surveys_read",
          "log"
        ],
        "feature": [
          "notifications"
        ]
      }
    },
    "section_head": {
      "description": "課長 - Answer/Survey + 課内データ閲覧",
      "positionCode": {
        "min": 500,
        "max": 699
      },
      "permissions": {
        "page": [
          "answers",
          "answer-detail",
          "surveys",
          "survey-detail",
          "schedule"
        ],
        "api": [
          "auth",
          "users_read",
          "answers_read",
          "surveys_read",
          "log"
        ],
        "feature": [
          "notifications"
        ]
      }
    },
    "department_head": {
      "description": "部長 - Answer/Survey + 部内データ閲覧",
      "positionCode": {
        "min": 700,
        "max": 899
      },
      "permissions": {
        "page": [
          "answers",
          "answer-detail",
          "surveys",
          "survey-detail",
          "schedule"
        ],
        "api": [
          "auth",
          "users_read",
          "answers_read",
          "surveys_read",
          "log"
        ],
        "feature": [
          "notifications"
        ]
      }
    },
    "division_head": {
      "description": "本部長 - Answer/Survey + 本部内データ閲覧",
      "positionCode": {
        "min": 900,
        "max": 989
      },
      "permissions": {
        "page": [
          "answers",
          "answer-detail",
          "surveys",
          "survey-detail",
          "schedule"
        ],
        "api": [
          "auth",
          "users_read",
          "answers_read",
          "surveys_read",
          "log"
        ],
        "feature": [
          "notifications"
        ]
      }
    },
    "admin": {
      "description": "管理者 - 全権限",
      "positionCode": {
        "min": 990,
        "max": 999
      },
      "permissions": {
        "page": [
          "home",
          "dashboard",
          "answers",
          "answer-detail",
          "surveys",
          "survey-detail",
          "schedule"
        ],
        "api": [
          "auth",
          "users_read",
          "users_write",
          "dashboard_read",
          "answers_read",
          "answers_write",
          "surveys_read",
          "surveys_write",
          "surveys_delete",
          "log",
          "admin"
        ],
        "feature": [
          "notifications",
          "export",
          "user_management",
          "system_settings"
        ]
      }
    }
  },
  "publicEndpoints": [
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/forgot-password",
    "/api/auth/reset-password"
  ],
  "position_levels": {
    "basic": 300,
    "chief": 500,
    "manager": 700,
    "owner": 900
  }
} as const

export const HTTP_STATUS: HttpStatus = {
  "errors": {
    "bad_request": {
      "code": 400,
      "generic": {
        "title": "リクエストエラー",
        "detail": "不正なリクエストです"
      }
    },
    "unauthorized": {
      "code": 401,
      "triggers": [
        "refresh"
      ],
      "generic": {
        "title": "認証エラー",
        "detail": "認証に失敗しました"
      },
      "pleasanter": "Pleasanter APIキー認証エラー: APIキーが無効または期限切れです"
    },
    "forbidden": {
      "code": 403,
      "generic": {
        "title": "アクセス拒否",
        "detail": "アクセスが拒否されました"
      },
      "pleasanter": "Pleasanter API権限エラー: アクセス権限がありません"
    },
    "not_found": {
      "code": 404,
      "generic": {
        "title": "見つかりません",
        "detail": "リソースが見つかりません"
      },
      "pleasanter": "Pleasanter APIエラー: 指定されたリソースが見つかりません"
    },
    "unprocessable": {
      "code": 422,
      "generic": {
        "title": "入力エラー",
        "detail": "入力値が正しくありません"
      }
    },
    "locked": {
      "code": 423,
      "generic": {
        "title": "ロック中",
        "detail": "リソースがロックされています"
      }
    },
    "too_many_requests": {
      "code": 429,
      "generic": {
        "title": "リクエスト制限",
        "detail": "リクエストが多すぎます。しばらく待ってから再試行してください"
      }
    },
    "server_error": {
      "code": [
        500,
        502,
        503,
        504
      ],
      "behavior": "error_page",
      "generic": {
        "title": "サーバーエラー",
        "detail": "サーバー内部でエラーが発生しました"
      },
      "pleasanter": "Pleasanter APIサーバーエラー: サーバーが応答していません"
    },
    "default": {
      "code": null,
      "generic": {
        "title": "エラー",
        "detail": "エラーが発生しました: {status_code}"
      },
      "pleasanter": "Pleasanter APIエラー: {status_code}"
    },
    "ssl_error": {
      "code": null,
      "generic": {
        "title": "SSL証明書エラー",
        "detail": "SSL証明書の検証に失敗しました"
      },
      "pleasanter": "Pleasanter接続エラー: SSL証明書の検証に失敗しました"
    },
    "connection_error": {
      "code": null,
      "generic": {
        "title": "接続エラー",
        "detail": "サーバーに接続できません"
      },
      "pleasanter": "Pleasanter接続エラー: サーバーに接続できません"
    },
    "timeout": {
      "code": null,
      "generic": {
        "title": "タイムアウト",
        "detail": "サーバーの応答がタイムアウトしました"
      },
      "pleasanter": "Pleasanter接続エラー: サーバーの応答がタイムアウトしました"
    },
    "password_incorrect": {
      "code": null,
      "generic": {
        "title": "パスワードエラー",
        "detail": "パスワードが正しくありません"
      }
    },
    "password_not_set": {
      "code": null,
      "generic": {
        "title": "パスワード未設定",
        "detail": "パスワードが設定されていません"
      }
    },
    "user_not_found": {
      "code": null,
      "generic": {
        "title": "ユーザー不在",
        "detail": "ユーザーが見つかりません"
      }
    },
    "account_locked": {
      "code": null,
      "generic": {
        "title": "アカウントロック",
        "detail": "アカウントがロックされています。{minutes}分後に再試行してください"
      }
    },
    "login_attempts_exceeded": {
      "code": null,
      "generic": {
        "title": "ログイン試行超過",
        "detail": "ログイン試行回数が上限に達しました。{minutes}分後に再試行してください"
      }
    },
    "login_locked": {
      "code": 423,
      "generic": {
        "title": "ログインロック",
        "detail": "ログイン試行回数が上限に達しました。パスワードリセットを行ってください。"
      }
    },
    "token_expired": {
      "code": 401,
      "generic": {
        "title": "トークン期限切れ",
        "detail": "トークンの有効期限が切れています"
      }
    },
    "token_invalid": {
      "code": null,
      "generic": {
        "title": "トークン無効",
        "detail": "トークンが無効です"
      }
    },
    "session_expired": {
      "code": null,
      "generic": {
        "title": "セッション期限切れ",
        "detail": "セッションが切れました。再度ログインしてください"
      }
    },
    "credentials_invalid": {
      "code": 401,
      "generic": {
        "title": "認証情報エラー",
        "detail": "認証情報を検証できませんでした"
      }
    },
    "refresh_token_invalid": {
      "code": 401,
      "generic": {
        "title": "リフレッシュトークン無効",
        "detail": "リフレッシュトークンが無効です"
      }
    },
    "refresh_token_expired": {
      "code": 401,
      "generic": {
        "title": "リフレッシュトークン期限切れ",
        "detail": "リフレッシュトークンの有効期限が切れています"
      }
    },
    "reset_token_invalid": {
      "code": 400,
      "generic": {
        "title": "リセットトークン無効",
        "detail": "リセットトークンが無効です"
      }
    },
    "reset_token_expired": {
      "code": 400,
      "generic": {
        "title": "リセットトークン期限切れ",
        "detail": "リセットトークンの有効期限が切れています"
      }
    },
    "permission_denied": {
      "code": 403,
      "generic": {
        "title": "権限エラー",
        "detail": "アクセス権限がありません"
      }
    },
    "password_too_short": {
      "code": 400,
      "generic": {
        "title": "パスワード短すぎ",
        "detail": "パスワードは8文字以上である必要があります"
      }
    },
    "password_too_long": {
      "code": 400,
      "generic": {
        "title": "パスワード長すぎ",
        "detail": "パスワードは30文字以内である必要があります"
      }
    },
    "required_field": {
      "code": null,
      "generic": {
        "title": "必須項目",
        "detail": "この項目は必須です"
      }
    },
    "invalid_format": {
      "code": null,
      "generic": {
        "title": "形式エラー",
        "detail": "形式が正しくありません"
      }
    },
    "current_password_required": {
      "code": null,
      "generic": {
        "title": "現在のパスワード必須",
        "detail": "現在のパスワードを入力してください"
      }
    },
    "new_password_required": {
      "code": null,
      "generic": {
        "title": "新パスワード必須",
        "detail": "新しいパスワードを入力してください"
      }
    },
    "password_confirm_mismatch": {
      "code": null,
      "generic": {
        "title": "パスワード不一致",
        "detail": "新しいパスワードと確認用パスワードが一致しません"
      }
    },
    "password_same_as_current": {
      "code": null,
      "generic": {
        "title": "同一パスワード",
        "detail": "新しいパスワードは現在のパスワードと異なるものにしてください"
      }
    },
    "password_change_success": {
      "code": null,
      "generic": {
        "title": "パスワード変更完了",
        "detail": "パスワードを変更しました"
      }
    },
    "password_change_failed": {
      "code": null,
      "generic": {
        "title": "パスワード変更失敗",
        "detail": "パスワードの変更に失敗しました"
      }
    },
    "auth_not_found": {
      "code": null,
      "generic": {
        "title": "認証情報不在",
        "detail": "認証情報が見つかりません。再度ログインしてください"
      }
    },
    "password_required": {
      "code": 400,
      "generic": {
        "title": "パスワード必須",
        "detail": "パスワードが必要です"
      }
    },
    "data_inconsistency": {
      "code": 500,
      "generic": {
        "title": "データ不整合",
        "detail": "登録データに不具合があります"
      }
    },
    "user_data_invalid": {
      "code": 500,
      "generic": {
        "title": "ユーザーデータ無効",
        "detail": "ユーザーデータの形式が不正です"
      }
    },
    "user_id_missing": {
      "code": 500,
      "generic": {
        "title": "ユーザーID不在",
        "detail": "ユーザーIDが取得できません"
      }
    },
    "answer_id_invalid": {
      "code": 500,
      "generic": {
        "title": "回答ID無効",
        "detail": "回答IDが正しくありません"
      }
    },
    "answer_data_inconsistency": {
      "code": 500,
      "generic": {
        "title": "回答データ不整合",
        "detail": "登録回答データに不具合があります"
      }
    },
    "answer_auth_failed": {
      "code": 500,
      "generic": {
        "title": "回答認証失敗",
        "detail": "回答認証処理中にエラーが発生しました"
      }
    },
    "survey_auth_required": {
      "code": 403,
      "generic": {
        "title": "アンケート認証必要",
        "detail": "このアンケートは認証が必要です"
      }
    },
    "survey_no_questions": {
      "code": 404,
      "generic": {
        "title": "アンケート質問なし",
        "detail": "アンケートに質問データが設定されていません"
      }
    },
    "survey_not_found": {
      "code": null,
      "generic": {
        "title": "アンケート不在",
        "detail": "アンケートが見つかりません"
      }
    },
    "survey_already_submitted": {
      "code": null,
      "generic": {
        "title": "アンケート回答済",
        "detail": "このアンケートは既に回答済みです"
      }
    },
    "survey_not_published": {
      "code": 400,
      "generic": {
        "title": "アンケート非掲載",
        "detail": "アンケートが掲載中ではありません"
      }
    },
    "survey_list_empty": {
      "code": 400,
      "generic": {
        "title": "アンケート一覧空",
        "detail": "掲載アンケートがありません"
      }
    },
    "answer_invalid_id": {
      "code": 400,
      "generic": {
        "title": "回答者IDエラー",
        "detail": "無効な回答者IDです"
      }
    },
    "answer_list_error": {
      "code": null,
      "generic": {
        "title": "回答者一覧エラー",
        "detail": "回答者データの取得に失敗しました"
      }
    },
    "log_template_not_found": {
      "code": null,
      "generic": {
        "title": "テンプレート不在",
        "detail": "ログビューアーテンプレートが見つかりません"
      }
    },
    "log_fetch_failed": {
      "code": null,
      "generic": {
        "title": "ログ取得失敗",
        "detail": "ログの取得に失敗しました: {error}"
      }
    },
    "log_save_failed": {
      "code": null,
      "generic": {
        "title": "ログ保存失敗",
        "detail": "エラーの保存に失敗しました: {error}"
      }
    }
  }
} as const

