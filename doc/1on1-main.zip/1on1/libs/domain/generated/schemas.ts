/**
 * 区分値マスタ（自動生成）
 *
 * このファイルは scripts/generate-schemas.ts によって自動生成されます。
 * 手動で編集しないでください。
 *
 * 生成元: infra/pleasanter/site_package_2026_04.json
 * 生成日時: 2026-04-08T18:33:11.192Z
 */

export const 掲載状況 = {
  '未掲載': { value: 100, shortLabel: '未掲載', color: 'gray' },
  '予約': { value: 150, shortLabel: '予約', color: 'blue' },
  '処理中': { value: 160, shortLabel: '処理中', color: 'blue' },
  '実施中': { value: 200, shortLabel: '実施中', color: 'green' },
  '完了': { value: 900, shortLabel: '完了', color: 'green' },
  '保留': { value: 910, shortLabel: '保留', color: 'yellow' },
  'エラー': { value: 990, shortLabel: 'エラー', color: 'red' },
} as const

export const 本部 = {
  '経営企画部': { value: 10, shortLabel: '経営企画部', color: 'white' },
  '事業開発室': { value: 11, shortLabel: '事業開発室', color: 'white' },
  '管理本部': { value: 12, shortLabel: '管理本部', color: 'white' },
  '内部監査室': { value: 13, shortLabel: '内部監査室', color: 'white' },
  '営業推進本部': { value: 20, shortLabel: '営業推進本部', color: 'white' },
  'システム開発本部': { value: 30, shortLabel: '開発本部', color: 'white' },
  'ソリューションサービス本部': { value: 40, shortLabel: 'SS本部', color: 'white' },
  '工場DX部': { value: 50, shortLabel: '工場DX部', color: 'white' },
} as const

export const 健康状態 = {
  '未判定': { value: 100, shortLabel: '未判定', color: 'gray' },
  '非常に良好': { value: 200, shortLabel: '最高', color: 'blue' },
  '良好': { value: 300, shortLabel: '良好', color: 'blue' },
  '要観察': { value: 400, shortLabel: '要観察', color: 'yellow' },
  '環境課題あり': { value: 500, shortLabel: '悪環境', color: 'yellow' },
  '不満あり': { value: 600, shortLabel: '不満', color: 'yellow' },
  '疲労あり': { value: 700, shortLabel: '疲労', color: 'yellow' },
  '要注意': { value: 800, shortLabel: '要注意', color: 'orange' },
  '過重負荷': { value: 900, shortLabel: '過重', color: 'orange' },
  '要緊急対応': { value: 999, shortLabel: '要緊急', color: 'red' },
} as const

export const 課 = {
  '第一運用': { value: 400201, color: 'red' },
  '第二運用': { value: 400202, color: 'red' },
  '第三運用': { value: 400203, color: 'red' },
  'ITアウトソーシング': { value: 400204, color: 'red' },
  '第一NW': { value: 400301, color: 'red' },
  '第二NW': { value: 400302, color: 'red' },
  '第三NW': { value: 400303, color: 'red' },
  '第一DC': { value: 400304, color: 'red' },
  '第一公共': { value: 400401, color: 'red' },
  '第二公共': { value: 400402, color: 'red' },
  'ITコンサルティング': { value: 400501, color: 'red' },
  'クライアントサポート': { value: 400502, color: 'red' },
  '第一システムサポート': { value: 400503, color: 'red' },
  '第二システムサポート': { value: 400504, color: 'red' },
  '自動化開発': { value: 400601, color: 'red' },
  'インフラ開発': { value: 400602, color: 'red' },
  'DX推進': { value: 400603, color: 'red' },
} as const

export const 回答状況 = {
  'アンケート未回答': { value: 100, shortLabel: '未回答', color: 'gray' },
  'アンケート回答済': { value: 200, shortLabel: '回答済', color: 'green' },
  '面談日程調整済': { value: 400, shortLabel: '調整済', color: 'yellow' },
  '完了': { value: 900, shortLabel: '完了', color: 'green' },
} as const

export const 部 = {
  'サービス企画部': { value: 4000, color: 'red' },
  '営業部': { value: 4001, color: 'red' },
  'ITアウトソーシング部': { value: 4002, color: 'red' },
  '第一インフラソリューション部': { value: 4003, color: 'red' },
  '第二インフラソリューション部': { value: 4004, color: 'red' },
  'ITソリューションコンサルティング部': { value: 4005, color: 'red' },
  '自動化DX部': { value: 4006, color: 'red' },
  '名古屋オフィス': { value: 4007, color: 'red' },
} as const

export const 役職 = {
  '派遣社員': { value: 100, shortLabel: '派遣', color: 'gray' },
  '一般社員': { value: 150, shortLabel: '一般', color: 'blue' },
  'TL': { value: 200, shortLabel: 'TL', color: 'green' },
  'GL': { value: 300, shortLabel: 'GL', color: 'blue' },
  '課長代理': { value: 400, shortLabel: '代理', color: 'yellow' },
  'SP': { value: 500, shortLabel: 'SP', color: 'yellow' },
  '課長': { value: 600, shortLabel: '課長', color: 'yellow' },
  '副部長': { value: 700, shortLabel: '副部長', color: 'orange' },
  '部門長': { value: 800, shortLabel: '部門長', color: 'orange' },
  '事務局': { value: 900, shortLabel: '事務局', color: 'green' },
  '管理者': { value: 999, shortLabel: '管理者', color: 'red' },
} as const

export const 面談方式 = {
  '対面': { value: 1, shortLabel: '対面', color: 'white' },
  'Web': { value: 2, shortLabel: 'Web', color: 'white' },
  '電話': { value: 3, shortLabel: '電話', color: 'white' },
} as const

export const AIモデル = {
  'OpenAI - gpt-4.1-nano': { value: 10300, shortLabel: 'gpt-4.1-nano', color: 'red' },
  'OpenAI - gpt-3.5-turbo': { value: 10350, shortLabel: 'gpt-3.5-turbo', color: 'red' },
  'OpenAI - gpt-4': { value: 10400, shortLabel: 'gpt-4', color: 'red' },
  'Anthropic - Claude 3 Opus': { value: 20300, shortLabel: 'Claude 3 Opus', color: 'red' },
  'Anthropic - Claude 3.5 Haiku': { value: 20350, shortLabel: 'Claude 3.5 Haiku', color: 'red' },
  'Anthropic - Claude 3.5 Sonnet': { value: 20351, shortLabel: 'Claude 3.5 Sonnet', color: 'red' },
  'Anthropic - Claude 3.7 Sonnet': { value: 20370, shortLabel: 'Claude 3.7 Sonnet', color: 'red' },
  'Google - Gemini Nano': { value: 30100, shortLabel: 'Gemini Nano', color: 'red' },
  'Google - Gemini Pro': { value: 30101, shortLabel: 'Gemini Pro', color: 'red' },
  'Google - Gemini Ultra': { value: 30102, shortLabel: 'Gemini Ultra', color: 'red' },
  'Meta - Llama 2': { value: 40200, shortLabel: 'Llama 2', color: 'red' },
  'Meta - Llama 3': { value: 40300, shortLabel: 'Llama 3', color: 'red' },
} as const
