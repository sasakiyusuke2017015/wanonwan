/**
 * 設定ファイル用の型定義
 *
 * config.ts で使用される定数データの型
 * - 評価項目
 * - RBAC 権限システム
 * - HTTP ステータス・エラー定義
 */

// ===========================
// 評価項目
// ===========================

export interface EvaluationItem {
  order: number
  label: string
  shortLabel: string
  key: string
  borderColor: string
  backgroundColor: string
}

export interface Definitions {
  評価項目: Record<string, EvaluationItem>
}

// ===========================
// 権限システム
// ===========================

export interface PermissionDetail {
  description: string
  path?: string
  endpoints?: string[]
}

export interface PagePermissions {
  [key: string]: PermissionDetail
}

export interface ApiPermissions {
  [key: string]: PermissionDetail
}

export interface FeaturePermissions {
  [key: string]: PermissionDetail
}

export interface PermissionDefinitions {
  page: PagePermissions
  api: ApiPermissions
  feature: FeaturePermissions
}

export interface RolePermissions {
  page: string[]
  api: string[]
  feature: string[]
}

export interface Role {
  description: string
  positionCode: {
    min: number
    max: number
  }
  permissions: RolePermissions
}

export interface PositionLevels {
  basic: number
  chief: number
  manager: number
  owner: number
}

export interface Permissions {
  permissions: PermissionDefinitions
  roles: Record<string, Role>
  publicEndpoints: string[]
  position_levels: PositionLevels
}

// ===========================
// HTTP ステータス・エラー
// ===========================

export interface ErrorGeneric {
  title: string
  detail: string
}

export interface ErrorDefinition {
  code: number | number[] | null
  triggers?: string[]
  behavior?: string
  generic: ErrorGeneric
  [context: string]: unknown
}

export interface HttpStatus {
  errors: Record<string, ErrorDefinition>
}


