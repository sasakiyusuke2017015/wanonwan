/**
 * API 共通型定義
 *
 * api と web で共有する Request/Response 型
 * バリデーションが必要なものは validators/ で Valibot スキーマとして定義
 */

// ===========================
// 汎用レスポンス
// ===========================

/** API レスポンス型（汎用） */
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

/** 成功/失敗を返す汎用レスポンス */
export interface MutationResponse {
  success: boolean
  message: string
}

// ===========================
// 認証関連
// ===========================

/** 認証トークン型（フロントエンド用） */
export interface AuthTokens {
  accessToken: string
  refreshToken: string
}

/** トークン検証レスポンス */
export interface VerifyTokenResponse {
  valid: boolean
  user?: {
    ユーザーID?: string | number | null
    メールアドレス?: string | null
    名前?: string | null
    役職?: string | null
  }
}

/** パスワード変更レスポンス */
export interface ChangePasswordResponse {
  success: boolean
  message?: string
}

/** ログイン結果 */
export interface LoginResult {
  access_token: string
  refresh_token: string
  token_type: string
  user: {
    userId: string
    name: string
    email: string
    role?: string
  }
}

/** トークンリフレッシュ結果 */
export interface RefreshResult {
  access_token: string
  token_type: string
}
