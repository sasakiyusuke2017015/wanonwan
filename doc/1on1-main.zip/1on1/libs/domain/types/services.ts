/**
 * サービス層インターフェース定義
 *
 * apps/api/src/services/ で実装される
 *
 * サービスを追加する場合:
 * 1. このファイルにインターフェースを追加
 * 2. apps/api/src/services/ に実装を追加
 * 3. apps/api/src/services/index.ts で services オブジェクトに追加
 */

import type { User } from '../validators/user'
import type {
  SurveyListItem,
  SurveyDetail,
  AnswerItem,
  SubmitAnswerResponse,
  SaveSurveyResponse,
  SubmitInterviewResponse,
} from '../validators/survey'
import type {
  AnswerResult,
  AnswerListItem,
} from '../validators/answer'
import type { ChartData, DashboardResult, TrendData } from '../validators/dashboard'
import type { MutationResponse, LoginResult, RefreshResult } from './api'

// ===========================
// 認証サービス
// ===========================

export interface AuthService {
  login: (email: string, password: string) => Promise<LoginResult>
  refreshAccessToken: (refreshToken: string) => Promise<RefreshResult>
}

// ===========================
// ユーザーサービス
// ===========================

export interface UsersService {
  getAllUsers: () => Promise<User[]>
  getUserById: (userId: string) => Promise<User>
  updateUser: (userId: string, data: Partial<User>) => Promise<MutationResponse>
  changePassword: (
    userId: string,
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ) => Promise<MutationResponse>
}

// ===========================
// アンケートサービス
// ===========================

export interface SurveysService {
  getAllSurveys: (
    limit?: number,
    offset?: number,
    answerStatus?: string,
    publishStatus?: string,
    recentMonths?: number,
    orderBy?: string,
    userId?: number
  ) => Promise<{ data: SurveyListItem[]; total: number }>
  getSurveyById: (surveyId: string) => Promise<SurveyDetail>
  submitAnswer: (
    surveyId: string,
    answers: AnswerItem[],
    aiGenerated?: {
      userPrompt?: string
      userResponse?: string
      supporterPrompt?: string
      supporterResponse?: string
    },
    userId?: number
  ) => Promise<SubmitAnswerResponse>
  saveSurvey: (
    surveyId: string,
    answers: AnswerItem[],
    aiGenerated?: {
      userPrompt?: string
      userResponse?: string
      supporterPrompt?: string
      supporterResponse?: string
    },
    userId?: number
  ) => Promise<SaveSurveyResponse>
  updateAnswerAIUser: (answerId: string, aiMessage: string) => Promise<void>
  updateAnswerAISupporter: (answerId: string, aiMessage: string) => Promise<void>
  submitInterview: (
    answerId: string,
    userId: string,
    interviewMemo: string,
    nextAction: string,
    interviewMethod: string
  ) => Promise<SubmitInterviewResponse>
}

// ===========================
// 回答サービス
// ===========================

export interface AnswersService {
  getAllAnswers: (
    limit?: number,
    offset?: number,
    recentMonths?: number,
    userId?: string
  ) => Promise<{ answers: AnswerListItem[]; total: number }>
  getAnswerById: (answerId: string) => Promise<AnswerResult>
  updateAnswer: (answerId: string, data: Partial<AnswerResult>) => Promise<AnswerResult>
}

// ===========================
// ダッシュボードサービス
// ===========================

export interface DashboardService {
  getStats: () => Promise<DashboardResult>
  getChartData: (startDate?: string, endDate?: string, userId?: string) => Promise<TrendData>
}

// ===========================
// AIサービス
// ===========================

export interface AIService {
  askAgent: (prompt: string, agentId: string, sessionId: string) => Promise<string>
  askAgentStream?: (
    prompt: string,
    agentId: string,
    sessionId: string
  ) => AsyncGenerator<string, void, unknown>
}

// ===========================
// ログサービス
// ===========================

export interface LogEntry {
  timestamp: string
  userId?: string
  action: string
  details?: string
  ipAddress?: string
  status?: string
}

export interface LogsService {
  writeLog: (entry: LogEntry) => void
  logAction: (userId: string | undefined, action: string, details?: string) => void
  logError: (error: Error | string, context?: { userId?: string; action?: string }) => void
}

// ===========================
// サービス集約型
// ===========================

/**
 * 全サービスの集約インターフェース
 *
 * apps/api/src/services/index.ts の services オブジェクトは
 * この型を満たす必要があります。
 */
export interface Services {
  authService: AuthService
  usersService: UsersService
  surveysService: SurveysService
  answersService: AnswersService
  dashboardService: DashboardService
  aiService: AIService
  logsService: LogsService
}

export type ServiceName = keyof Services
