/**
 * @1on1/shared - 共通定義パッケージ
 *
 * 型定義、バリデータ、ユーティリティ、設定を提供
 *
 * クリーンアーキテクチャの「内側」として、
 * 外側への依存（React, apps層）を禁止
 */

// 型定義
export * from './types'

// バリデータ（Valibot スキーマ）
export * from './validators'

// ユーティリティ（純粋TypeScript関数）
export * from './utils'

// 設定データ
export {
  DEFINITIONS,
  PERMISSIONS,
  HTTP_STATUS,
} from './config'
