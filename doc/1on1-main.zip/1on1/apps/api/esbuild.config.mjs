/**
 * esbuild 設定
 *
 * TypeScript を ESM JavaScript にバンドル
 */

import * as esbuild from 'esbuild'
import { readFileSync } from 'fs'

// package.json から依存関係を取得
const pkg = JSON.parse(readFileSync('./package.json', 'utf-8'))

// 外部パッケージ = node_modules の依存（@1on1/* 以外）
const externalDeps = [
  ...Object.keys(pkg.dependencies || {}),
  ...Object.keys(pkg.devDependencies || {}),
].filter((dep) => !dep.startsWith('@1on1/'))

await esbuild.build({
  entryPoints: ['src/index.ts'],
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'esm',
  outdir: 'dist',
  sourcemap: true,
  // ワークスペースパッケージ以外を外部扱い
  external: externalDeps,
  // パスエイリアスを解決
  alias: {
    '@1on1/domain/config': '../../libs/domain/config.ts',
    '@1on1/domain': '../../libs/domain',
  },
})

console.log('✅ Build complete: dist/index.js')
