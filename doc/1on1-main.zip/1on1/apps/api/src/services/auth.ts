/**
 * 認証サービス
 *
 * ログイン、トークンリフレッシュなどの認証ロジック
 * ログイン試行回数はPleasanterで永続管理（メモリ不使用）
 *
 * ユーザー検索: PostgreSQL 直接接続（REST API の 200 件制限を回避）
 * ユーザー更新: REST API 経由（Pleasanter の内部ロジックを活用）
 */

import { ServiceError } from './errors'
import { pleasync } from '../infrastructure/pleasync'
import { verifyPassword, isBcryptHash } from './password'
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from './jwt'
import { tokenStore } from './token-store'
import { logger, type AppLogger } from '../config/logger'

const MAX_LOGIN_ATTEMPTS = 5

/**
 * Pleasanter の選択肢カラム値を文字列に変換
 * 配列の場合は最初の要素を返す
 */
function normalizeClassValue(value: unknown): string {
  if (Array.isArray(value)) {
    return value[0]?.toString() || ''
  }
  return value?.toString() || ''
}

/**
 * 役職の選択肢カラム値から役職コード（数値部分）を抽出
 * 例: "["150"]" → "150"、"["150,一般社員"]" → "150"
 * PostgreSQL 直接取得時: ["150"] (配列) → "150"
 */
function extractPositionCode(value: unknown): string {
  const normalized = normalizeClassValue(value)
  // カンマ区切りの場合は最初の部分（役職コード）を取得
  const code = normalized.split(',')[0]
  return code || ''
}

/**
 * ログイン処理
 *
 * @param email メールアドレス
 * @param password パスワード（平文）
 * @returns アクセストークンとリフレッシュトークン
 */
export async function login(email: string, password: string, log?: AppLogger) {
  const appLog = log || logger
  appLog.info({ operation: 'login', email }, 'login started')

  // Step 1: PostgreSQL から直接ユーザーを検索
  const users = await pleasync.findMany('ユーザーマスタ', [
      'ResultId', 'ユーザーID', 'ユーザーコード', '名前', 'メールアドレス',
      '初期パスワード', '変更済パスワード', '役職', '所属本部', '所属部', '所属課',
      'アカウントロック', 'ログイン連続失敗回数', '最終ログイン日時',
    ], { メールアドレス: email })

  const user = users[0]

  // Pleasanter側のアカウントロックフラグをチェック
  if (user && user.アカウントロック === true) {
    throw new ServiceError(
      'RATE_LIMITED',
      'アカウントがロックされました。ss-kikaku@sms-datatech.co.jp へ連絡してください。',
      { failedAttempts: MAX_LOGIN_ATTEMPTS, maxAttempts: MAX_LOGIN_ATTEMPTS, remainingAttempts: 0, locked: true }
    )
  }

  if (!user) {
    // ユーザーが存在しない場合（Pleasanterに記録不可）
    appLog.warn({ operation: 'login', email }, 'login failed: user not found')
    throw new ServiceError(
      'UNAUTHORIZED',
      'パスワードが正しくありません',
      { failedAttempts: 0, maxAttempts: MAX_LOGIN_ATTEMPTS, remainingAttempts: MAX_LOGIN_ATTEMPTS, locked: false }
    )
  }

  // ユーザーID取得（Fail Fast 原則）
  // Note: PostgreSQLは数値で返すため、文字列に変換して統一
  const userId = String(user.ユーザーID)
  const userIdNum = parseInt(userId, 10)
  const userName = user.名前 as string
  const role = user.役職 as string | undefined

  // パスワード検証（変更済パスワード優先、なければ初期パスワード）
  const changedPassword = user.変更済パスワード as string | undefined
  const initialPassword = user.初期パスワード as string
  const requirePasswordChange = !changedPassword
  const storedPassword = changedPassword || initialPassword
  if (!storedPassword) {
    throw new ServiceError('INTERNAL_ERROR', 'ユーザーのパスワードが設定されていません')
  }

  // パスワード検証
  let isPasswordValid: boolean
  if (isBcryptHash(storedPassword)) {
    isPasswordValid = await verifyPassword(password, storedPassword)
  } else if (requirePasswordChange) {
    // 初期パスワード（平文）との比較
    isPasswordValid = password === storedPassword
  } else {
    // 変更済パスワードが平文で残存 → ログイン不可
    throw new ServiceError(
      'FORBIDDEN',
      'パスワードの初期設定が必要です。管理者に連絡してください。',
      { failedAttempts: 0, maxAttempts: MAX_LOGIN_ATTEMPTS, remainingAttempts: MAX_LOGIN_ATTEMPTS, locked: false }
    )
  }

  if (!isPasswordValid) {
    appLog.warn({ operation: 'login', user_id: userId }, 'login failed: invalid password')
    // Pleasanterの失敗回数を更新
    const currentFailures = (user.ログイン連続失敗回数 as number) || 0
    const newFailures = currentFailures + 1
    const isLockedOut = newFailures >= MAX_LOGIN_ATTEMPTS

    await pleasync.update('ユーザーマスタ', userIdNum, {
      ログイン連続失敗回数: newFailures,
      ...(isLockedOut && { アカウントロック: true }),
    })

    if (isLockedOut) {
      throw new ServiceError(
        'RATE_LIMITED',
        'アカウントがロックされました。ss-kikaku@sms-datatech.co.jp へ連絡してください。',
        { failedAttempts: MAX_LOGIN_ATTEMPTS, maxAttempts: MAX_LOGIN_ATTEMPTS, remainingAttempts: 0, locked: true }
      )
    }

    throw new ServiceError(
      'UNAUTHORIZED',
      'パスワードが正しくありません',
      { failedAttempts: newFailures, maxAttempts: MAX_LOGIN_ATTEMPTS, remainingAttempts: MAX_LOGIN_ATTEMPTS - newFailures, locked: false }
    )
  }

  // JWT トークン生成
  const accessToken = generateAccessToken(userId, email, role)
  const refreshToken = generateRefreshToken(userId, email)

  // リフレッシュトークンをストアに保存
  const now = Date.now()
  const expiresIn = 7 * 24 * 60 * 60 * 1000 // 7日間（ミリ秒）
  tokenStore.save(refreshToken, {
    userId,
    email,
    issuedAt: now,
    expiresAt: now + expiresIn,
  })

  appLog.info({ operation: 'login', user_id: userId }, 'login succeeded')

  // ログイン成功: 失敗回数リセット + 最終ログイン日時を記録
  await pleasync.update('ユーザーマスタ', userIdNum, {
    ログイン連続失敗回数: 0,
    最終ログイン日時: new Date().toISOString(),
  })

  return {
    access_token: accessToken,
    refresh_token: refreshToken,
    token_type: 'Bearer',
    requirePasswordChange,
    user: {
      userId,
      name: userName,
      email,
      role,
      // 日本語フィールド（Header.tsx で表示）
      '名前': userName,
      'ユーザーコード': user.ユーザーコード as string,
      'ユーザーID': userId,
      'メールアドレス': email,
      '所属本部': normalizeClassValue(user.所属本部),
      '所属部': normalizeClassValue(user.所属部),
      '所属課': normalizeClassValue(user.所属課),
      '役職': normalizeClassValue(user.役職),
      '役職コード': extractPositionCode(user.役職),
    },
  }
}

/**
 * トークンリフレッシュ処理（リフレッシュトークンローテーション対応）
 *
 * @param oldRefreshToken 既存のリフレッシュトークン
 * @returns 新しいアクセストークンと新しいリフレッシュトークン
 */
export async function refreshAccessToken(oldRefreshToken: string) {
  // Step 1: JWT検証
  let payload
  try {
    payload = verifyRefreshToken(oldRefreshToken)
  } catch (error) {
    throw new ServiceError(
      'UNAUTHORIZED',
      error instanceof Error ? error.message : 'リフレッシュトークンが無効です'
    )
  }

  // Step 2: トークンストア検証（トークン再利用検知）
  const tokenEntry = tokenStore.validate(oldRefreshToken)

  if (!tokenEntry) {
    // トークンが存在しない、無効化済み、または有効期限切れ
    tokenStore.revokeTokenFamily(oldRefreshToken)

    throw new ServiceError('UNAUTHORIZED', 'リフレッシュトークンが無効です')
  }

  // Step 3: 古いトークンを無効化
  tokenStore.revoke(oldRefreshToken)

  // Step 4: 新しいトークンを生成
  const accessToken = generateAccessToken(
    payload.sub,
    payload.email,
    payload.role
  )
  const newRefreshToken = generateRefreshToken(payload.sub, payload.email)

  // Step 5: 新しいリフレッシュトークンをストアに保存（ローテーション追跡）
  const now = Date.now()
  const expiresIn = 7 * 24 * 60 * 60 * 1000 // 7日間（ミリ秒）
  tokenStore.save(newRefreshToken, {
    userId: payload.sub,
    email: payload.email,
    issuedAt: now,
    expiresAt: now + expiresIn,
    previousToken: oldRefreshToken, // トークンチェーン追跡用
  })

  return {
    access_token: accessToken,
    refresh_token: newRefreshToken,
    token_type: 'Bearer',
  }
}
