/**
 * JWT (JSON Web Token) サービス
 *
 * アクセストークンとリフレッシュトークンの生成・検証を提供
 */

import jwt from 'jsonwebtoken'
import { env } from '../config/env'

/**
 * JWT ペイロード（トークンに含まれるデータ）
 */
export interface JWTPayload {
  sub: string // ユーザーID（subject）
  email: string
  role?: string
  type: 'access' | 'refresh' // トークンの種類
  iat?: number // Issued At（発行日時）
  exp?: number // Expiration Time（有効期限）
}

/**
 * アクセストークンを生成
 *
 * @param userId ユーザーID
 * @param email メールアドレス
 * @param role ユーザーロール（オプション）
 * @returns アクセストークン
 */
export function generateAccessToken(
  userId: string,
  email: string,
  role?: string
): string {
  if (!env.JWT_SECRET_KEY) {
    throw new Error('JWT_SECRET_KEY is not set')
  }

  const payload: JWTPayload = {
    sub: userId,
    email,
    role,
    type: 'access',
  }

  return jwt.sign(payload, env.JWT_SECRET_KEY, {
    expiresIn: `${env.JWT_ACCESS_TOKEN_EXPIRE_MINUTES}m`,
    algorithm: 'HS256',
  })
}

/**
 * リフレッシュトークンを生成
 *
 * @param userId ユーザーID
 * @param email メールアドレス
 * @returns リフレッシュトークン
 */
export function generateRefreshToken(userId: string, email: string): string {
  if (!env.JWT_SECRET_KEY) {
    throw new Error('JWT_SECRET_KEY is not set')
  }

  const payload: JWTPayload = {
    sub: userId,
    email,
    type: 'refresh',
  }

  return jwt.sign(payload, env.JWT_SECRET_KEY, {
    expiresIn: `${env.JWT_REFRESH_TOKEN_EXPIRE_DAYS}d`,
    algorithm: 'HS256',
  })
}

/**
 * トークンを検証し、ペイロードを取得
 *
 * @param token JWT トークン
 * @param expectedType 期待するトークンタイプ（'access' または 'refresh'）
 * @returns ペイロード
 * @throws トークンが無効な場合
 */
export function verifyToken(token: string, expectedType: 'access' | 'refresh'): JWTPayload {
  if (!env.JWT_SECRET_KEY) {
    throw new Error('JWT_SECRET_KEY is not set')
  }

  try {
    const decoded = jwt.verify(token, env.JWT_SECRET_KEY, {
      algorithms: ['HS256'],
    }) as JWTPayload

    // トークンタイプの検証
    if (decoded.type !== expectedType) {
      throw new Error(`Invalid token type: expected ${expectedType}, got ${decoded.type}`)
    }

    return decoded
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      throw new Error(`Invalid token: ${error.message}`)
    }
    if (error instanceof jwt.TokenExpiredError) {
      throw new Error('Token has expired')
    }
    throw error
  }
}

/**
 * アクセストークンを検証
 *
 * @param token アクセストークン
 * @returns ペイロード
 */
export function verifyAccessToken(token: string): JWTPayload {
  return verifyToken(token, 'access')
}

/**
 * リフレッシュトークンを検証
 *
 * @param token リフレッシュトークン
 * @returns ペイロード
 */
export function verifyRefreshToken(token: string): JWTPayload {
  return verifyToken(token, 'refresh')
}

/**
 * トークンをデコード（検証なし）
 *
 * デバッグ用途。本番環境では使用しないこと。
 *
 * @param token JWT トークン
 * @returns デコードされたペイロード（検証なし）
 */
export function decodeToken(token: string): JWTPayload | null {
  try {
    return jwt.decode(token) as JWTPayload
  } catch {
    return null
  }
}
