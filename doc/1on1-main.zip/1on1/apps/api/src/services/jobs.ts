/**
 * ジョブサービス（バッチ処理ビジネスロジック）
 *
 * アンケート配信・終了・削除・プロンプト更新の業務ロジックを提供。
 * ルーター層から分離し、テスタビリティと保守性を確保する。
 *
 * ファイル分割:
 * - jobs.helpers.ts: ユーティリティ関数・組織フィルタ
 * - jobs.core.ts: メインバッチ処理
 */

// ヘルパー
export {
  safeParseJson,
  ensureArray,
  parseAnyDate,
  formatYearMonth,
  filterUsersByOrganization,
  getSupervisors,
  type OrganizationFilter,
} from './jobs.helpers'

// コアバッチ処理
export {
  startSurveys,
  finishSurveys,
  deleteSurveys,
  updatePrompts,
  type StartSurveysResult,
  type FinishSurveysResult,
  type DeleteSurveysResult,
  type UpdatePromptsResult,
} from './jobs.core'
