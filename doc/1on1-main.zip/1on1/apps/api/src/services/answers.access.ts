/**
 * Answers サービス - アクセス制御
 */

import { pleasync } from '../infrastructure/pleasync'
import { parseSupervisorIds } from './answers.helpers'

/**
 * 回答レコードへのアクセス権限をチェック
 *
 * @returns true: アクセス可能, false: アクセス不可
 */
export function canAccessAnswer(
  answer: { 回答者?: string; 面談候補?: string },
  userId?: string | number
): boolean {
  // userIdがない場合はアクセス不可
  if (!userId) return false
  // userIdを文字列に変換（JWTから数値で渡される場合の後方互換性）
  const userIdStr = String(userId)

  // 自分が回答者（文字列比較で統一）
  if (String(answer.回答者) === userIdStr) return true
  // 自分が面談候補に含まれている
  const supervisorIds = parseSupervisorIds(answer.面談候補)
  if (supervisorIds.includes(userIdStr)) return true
  return false
}

/**
 * 掲載設定IDに紐づく回答の回答者が自分かチェック
 *
 * @param publishId 掲載設定ID（掲載設定のResultId）
 * @param userId 認証ユーザーID
 * @returns true: 回答者が自分のレコードが存在する
 */
export async function isRespondentForPublish(
  publishId: string,
  userId: string
): Promise<boolean> {
  const records = await pleasync.findMany('回答結果', ['回答者'], { 掲載設定: publishId })

  return records.some((r) => String(r.回答者) === userId)
}

/**
 * 対象ユーザーの回答にアクセス可能かチェック
 *
 * 認証ユーザーが対象ユーザーの回答を閲覧できるか：
 * - 自分自身の回答
 * - 面談候補に自分が含まれる回答がある
 */
export function canAccessUserAnswers(
  answerRecords: Array<{ 回答者?: string; 面談候補?: string }>,
  targetUserId: string,
  authUserId: string
): boolean {
  // 自分自身のデータならアクセス可能
  if (targetUserId === authUserId) return true
  // 対象ユーザーの回答のいずれかで、自分が面談候補に含まれているか
  return answerRecords.some((answer) => {
    const supervisorIds = parseSupervisorIds(answer.面談候補)
    return supervisorIds.includes(authUserId)
  })
}

/**
 * 対象ユーザーへのアクセス権限を軽量にチェック
 *
 * getEmployeeDetail の前に呼び出し、権限がない場合は全データ取得を回避する
 */
export async function checkUserAccess(
  targetUserId: string,
  authUserId: string
): Promise<boolean> {
  // 自分自身のデータならアクセス可能
  if (targetUserId === authUserId) return true

  // 対象ユーザーの回答から面談候補のみ取得（軽量）
  const records = await pleasync.findMany('回答結果', ['面談候補'], { 回答者: targetUserId })

  return records.some((record) => {
    const supervisorIds = parseSupervisorIds(record.面談候補 as string)
    return supervisorIds.includes(authUserId)
  })
}
