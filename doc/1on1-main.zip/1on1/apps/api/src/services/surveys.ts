/**
 * Survey (アンケート) サービス
 *
 * 掲載設定テーブルからアンケート一覧・詳細を取得
 * 回答結果の作成
 */

import { pleasync } from '../infrastructure/pleasync'
import type { SurveyListItem, SurveyDetail, Question } from '@1on1/domain/validators'
import { toStatusCode } from '@1on1/domain/utils'
import { createAnswer, calculateInterviewViewers, getAnswerById } from './answers'

/**
 * アンケート一覧を取得（回答結果 + 掲載設定を結合）
 */
export async function getAllSurveys(
  limit = 50,
  offset = 0,
  answerStatus?: string,
  publishStatus?: string,
  recentMonths?: number,
  orderBy?: string,
  userId?: number
): Promise<{ data: SurveyListItem[]; total: number }> {
  // 0. アンケートマスタからタイトルを取得してマップ作成
  const surveyMasterRecords = await pleasync.findMany('アンケートマスタ', ['アンケートID', 'タイトル'])

  const surveyTitleMap = new Map<string, string>()
  for (const record of surveyMasterRecords) {
    const surveyId = String(record.アンケートID)
    const title = record.タイトル as string
    if (surveyId && title) {
      surveyTitleMap.set(surveyId, title)
    }
  }

  // 1. 掲載設定テーブルから取得
  // publishStatus フィルタは raw クエリで対応（Issues テーブルの Status カラム）
  const publishSiteId = pleasync.getSiteId('掲載設定')
  const publishConditions: string[] = [`"SiteId" = $1::bigint`]
  const publishParams: unknown[] = [publishSiteId]

  if (publishStatus) {
    publishParams.push(publishStatus)
    publishConditions.push(`"Status" = $${publishParams.length}`)
  }

  const 掲載IDCol = pleasync.getColumnName('掲載設定', '掲載ID')
  const 回答率Col = pleasync.getColumnName('掲載設定', '回答率')
  const アンケート選択Col = pleasync.getColumnName('掲載設定', 'アンケート選択')

  const publishRecords = await pleasync.raw(
    `SELECT
      "IssueId" as "掲載ID",
      "Status" as "掲載状況",
      "StartTime" as "開始",
      ("CompletionTime" - INTERVAL '1 day') as "完了",
      "${回答率Col}" as "回答率",
      "${アンケート選択Col}" as "アンケート選択",
      "Body" as "掲載内容"
     FROM "Issues"
     WHERE ${publishConditions.join(' AND ')}`,
    publishParams
  )

  // 2. 回答結果テーブルから認証ユーザーの回答を取得
  const filteredAnswers = await pleasync.findMany('回答結果',
    ['回答ID', '回答状況', '回答者', '掲載設定', 'アンケート内容JSON', 'ユーザー用生成回答', 'ユーザー用生成プロンプト', 'サポーター用生成プロンプト'],
    userId ? { 回答者: String(userId) } : null,
  )

  // 回答を掲載設定IDでマップ化
  const answerMap = new Map<number, Record<string, unknown>>()
  for (const record of filteredAnswers) {
    const publishIdStr = record.掲載設定 as string
    const publishId = parseInt(publishIdStr, 10)
    if (!isNaN(publishId)) {
      answerMap.set(publishId, record as Record<string, unknown>)
    }
  }

  // 3. 掲載設定と回答結果を結合
  let surveys: SurveyListItem[] = publishRecords
    .filter((publishRecord) => {
      const publishId = parseInt(String(publishRecord['掲載ID'] ?? ''), 10)
      return !isNaN(publishId) && answerMap.has(publishId)
    })
    .map((publishRecord) => {
    const publishId = parseInt(String(publishRecord['掲載ID'] ?? ''), 10)
    const answerRecord = answerMap.get(publishId)

    let questionData: unknown = undefined
    if (answerRecord) {
      const jsonStr = answerRecord['アンケート内容JSON'] as string
      if (jsonStr) {
        try {
          questionData = JSON.parse(jsonStr)
        } catch {
          questionData = undefined
        }
      }
    }

    const publishStatusNum = toStatusCode(publishRecord['掲載状況'])
    const answerStatusNum = toStatusCode(answerRecord?.['回答状況'])

    const surveySelection = publishRecord['アンケート選択'] as string
    const surveyTitle = surveyTitleMap.get(surveySelection) || surveySelection

    return {
      掲載ID: publishId,
      タイトル: surveyTitle,
      掲載内容: publishRecord['掲載内容'] as string | undefined,
      掲載状況: isNaN(publishStatusNum as number) ? undefined : publishStatusNum,
      開始: publishRecord['開始'] instanceof Date ? (publishRecord['開始'] as Date).toISOString() : (publishRecord['開始'] as string) || undefined,
      完了: publishRecord['完了'] instanceof Date ? (publishRecord['完了'] as Date).toISOString() : (publishRecord['完了'] as string) || undefined,
      回答率: publishRecord['回答率'] as number | undefined,
      アンケート選択: surveySelection,
      ...(answerRecord && {
        回答ID: answerRecord['回答ID'] as number,
        回答状況: answerStatusNum,
        アンケート内容JSON: questionData,
        ユーザー用生成回答: answerRecord['ユーザー用生成回答'] as string | null,
        ユーザー用生成プロンプト: answerRecord['ユーザー用生成プロンプト'] as string | null,
        サポーター用生成プロンプト: answerRecord['サポーター用生成プロンプト'] as string | null,
      }),
    }
  })

  // 回答状況フィルター
  if (answerStatus) {
    const statusCode = parseInt(answerStatus, 10)
    if (!isNaN(statusCode)) {
      surveys = surveys.filter((s) => s.回答状況 === statusCode)
    }
  }

  // 期間フィルター
  if (recentMonths !== undefined && recentMonths > 0) {
    const cutoffDate = new Date()
    cutoffDate.setMonth(cutoffDate.getMonth() - recentMonths)
    const cutoffDateStr = cutoffDate.toISOString().split('T')[0]

    surveys = surveys.filter((s) => {
      if (!s.開始) return false
      return s.開始 >= cutoffDateStr
    })
  }

  // ソート
  if (orderBy) {
    try {
      const parsed = JSON.parse(orderBy) as Record<string, string>
      const sortFields = Object.entries(parsed).map(([field, dir]) => ({
        field: field as keyof SurveyListItem,
        desc: dir.toLowerCase() === 'desc',
      }))

      if (sortFields.length > 0) {
        surveys.sort((a, b) => {
          for (const { field, desc } of sortFields) {
            const aVal = a[field] ?? ''
            const bVal = b[field] ?? ''
            const cmp = typeof aVal === 'number' && typeof bVal === 'number'
              ? aVal - bVal
              : String(aVal).localeCompare(String(bVal))
            if (cmp !== 0) return desc ? -cmp : cmp
          }
          return 0
        })
      }
    } catch {
      // パース失敗時は無視
    }
  }

  // ページネーション
  const paginatedSurveys = surveys.slice(offset, offset + limit)

  return {
    data: paginatedSurveys,
    total: surveys.length,
  }
}

/**
 * アンケート詳細を取得（掲載設定テーブル）
 */
export async function getSurveyById(publishId: string): Promise<SurveyDetail> {
  const record = await pleasync.getRecord('掲載設定', parseInt(publishId, 10), [
    '掲載ID', '掲載状況', '開始', '完了', '回答率', 'アンケート選択',
  ], 'Value')

  // Body は REST API で直接取得（スキーマ外のシステムカラム）
  const bodyRecord = await pleasync.getRecordRaw(parseInt(publishId, 10), {
    ApiDataType: 'KeyValues',
    ApiColumnKeyDisplayType: 'ColumnName',
    ApiColumnValueDisplayType: 'Value',
    GridColumns: ['Body'],
  }) as Record<string, unknown>

  let questionData: Question[] = []
  try {
    const bodyContent = bodyRecord['Body'] as string
    if (bodyContent) {
      questionData = JSON.parse(bodyContent)
    }
  } catch {
    questionData = []
  }

  const survey: SurveyDetail = {
    掲載ID: record['掲載ID'] as number,
    タイトル: record['アンケート選択'] as string,
    アンケート内容JSON: questionData,
    掲載状況: record['掲載状況'] as number | undefined,
    開始: record['開始'] as string | undefined,
    完了: record['完了'] as string | undefined,
    回答率: record['回答率'] as number | undefined,
  }

  return survey
}

/**
 * 評価項目ごとの重み付きスコアを計算
 */
interface WeightedScore {
  total: number
  weightSum: number
}

async function calculateEvaluationScores(
  answers: Array<{ question_id: string; question: string; answer: string }>
): Promise<Record<string, number>> {
  const weightedScores: Record<string, WeightedScore> = {}

  // 質問マスタを一括取得（N+1回避）
  const questionRecords = await pleasync.findMany('質問マスタ', ['質問ID', '評価項目', '重み'])

  const questionMap = new Map<string, Record<string, unknown>>()
  for (const record of questionRecords) {
    const questionId = String(record.質問ID ?? '')
    if (questionId) {
      questionMap.set(questionId, record as Record<string, unknown>)
    }
  }

  for (const item of answers) {
    const questionId = item.question_id
    const question = questionMap.get(questionId)
    if (!question) continue

    const evalItem = question['評価項目'] as string | undefined
    const weight = parseFloat(String(question['重み'] || 0))

    const answerParts = item.answer.split(':')
    const point = parseInt(answerParts[0], 10)

    if (!evalItem || isNaN(point) || point < 1 || point > 5 || weight <= 0) {
      continue
    }

    if (!weightedScores[evalItem]) {
      weightedScores[evalItem] = { total: 0, weightSum: 0 }
    }
    weightedScores[evalItem].total += point * weight
    weightedScores[evalItem].weightSum += weight
  }

  const evalScores: Record<string, number> = {}
  for (const [item, score] of Object.entries(weightedScores)) {
    if (score.weightSum > 0) {
      evalScores[item] = Math.round((score.total / score.weightSum) * 10) / 10
    }
  }

  return evalScores
}

/**
 * アンケート回答を送信
 */
export async function submitAnswer(
  publishId: string,
  answers: Array<{ question_id: string; question: string; answer: string }>,
  aiGenerated?: {
    userPrompt?: string
    userResponse?: string
    supporterPrompt?: string
    supporterResponse?: string
  },
  userId?: number
): Promise<{ success: boolean; message: string; answerId?: number }> {

  if (!userId) {
    throw new Error('ユーザーIDが指定されていません')
  }

  // 掲載ID + 回答者IDで自分の回答レコードを検索
  const answerRecords = await pleasync.findMany('回答結果',
    ['回答ID', '回答者'],
    { 掲載設定: publishId, 回答者: String(userId) },
  )

  if (answerRecords.length === 0) {
    throw new Error(`掲載ID=${publishId}に対するユーザー${userId}の回答レコードが見つかりません`)
  }

  const answerId = answerRecords[0].回答ID as number
  if (!answerId) {
    throw new Error('回答IDの取得に失敗しました')
  }

  const answersJSON = JSON.stringify(answers)
  const now = new Date().toISOString()

  const evalScores = await calculateEvaluationScores(answers)
  const evalScoresJSON = JSON.stringify(evalScores)
  const healthStatusCode = evaluateHealthStatus(evalScores)

  await pleasync.update('回答結果',Number(answerId), {
    回答状況: pleasync.status('回答状況', 'アンケート回答済').value,
    アンケート内容JSON: answersJSON,
    評価結果JSON: evalScoresJSON,
    健康状態: healthStatusCode,
    回答日: now,
    ...(aiGenerated?.userPrompt && { ユーザー用生成プロンプト: aiGenerated.userPrompt }),
    ...(aiGenerated?.userResponse && { ユーザー用生成回答: aiGenerated.userResponse }),
    ...(aiGenerated?.supporterPrompt && { サポーター用生成プロンプト: aiGenerated.supporterPrompt }),
    ...(aiGenerated?.supporterResponse && { サポーター用生成回答: aiGenerated.supporterResponse }),
  })

  return {
    success: true,
    message: 'アンケート回答を送信しました',
    answerId,
  }
}

/**
 * AI生成結果を回答結果に保存（ユーザー向け）
 */
export async function updateAnswerAIUser(answerId: string, aiMessage: string): Promise<void> {
  await pleasync.update('回答結果',Number(answerId), {
    ユーザー用生成回答: aiMessage,
  })
}

/**
 * AI生成結果を回答結果に保存（サポーター向け）
 */
export async function updateAnswerAISupporter(answerId: string, aiMessage: string): Promise<void> {
  await pleasync.update('回答結果',Number(answerId), {
    サポーター用生成回答: aiMessage,
  })
}

/**
 * アンケート回答を保存（途中保存）
 */
export async function saveSurvey(
  publishId: string,
  answers: Array<{ question_id: string; question: string; answer: string }>,
  aiGenerated?: {
    userPrompt?: string
    userResponse?: string
    supporterPrompt?: string
    supporterResponse?: string
  },
  userId?: number
): Promise<{ success: boolean; message: string; answerId?: number }> {

  if (!userId) {
    throw new Error('ユーザーIDが指定されていません')
  }

  const answersJSON = JSON.stringify(answers)
  const now = new Date().toISOString()

  try {
    const result = await createAnswer({
      回答者: userId.toString(),
      掲載設定: publishId,
      回答状況: 'アンケート未回答',
      アンケート内容JSON: answersJSON,
      回答日: now,
      ユーザー用生成プロンプト: aiGenerated?.userPrompt,
      ユーザー用生成回答: aiGenerated?.userResponse,
      サポーター用生成プロンプト: aiGenerated?.supporterPrompt,
      サポーター用生成回答: aiGenerated?.supporterResponse,
    })

    return {
      success: true,
      message: 'アンケートを途中保存しました',
      answerId: result.answerId,
    }
  } catch (error) {
    throw new Error(`アンケートの保存に失敗しました: ${error}`)
  }
}

/**
 * 面談実施
 */
export async function submitInterview(
  answerId: string,
  userId: string,
  interviewMemo: string,
  nextAction: string,
  interviewMethod: string
): Promise<{ success: boolean; message: string }> {
  const now = new Date().toISOString().split('T')[0]

  const currentAnswer = await getAnswerById(answerId)
  const interviewViewers = currentAnswer.面談候補
    ? await calculateInterviewViewers(userId, currentAnswer.面談候補)
    : '[]'

  try {
    await pleasync.update('回答結果',Number(answerId), {
      面談メモ: interviewMemo,
      次回までのアクション: nextAction,
      面談者: userId,
      面談日: now,
      回答状況: pleasync.status('回答状況', '完了').value,
      面談方式: interviewMethod,
      面談内容閲覧者: interviewViewers,
    })
    return {
      success: true,
      message: '面談が実施されました',
    }
  } catch (error) {
    throw new Error(`面談実施に失敗しました: ${error}`)
  }
}

// ===========================
// 健康状態判定
// ===========================

export function evaluateHealthStatus(evalScores: Record<string, number>): number {
  if (!evalScores || Object.keys(evalScores).length === 0) {
    return pleasync.status('健康状態', '未判定').value
  }

  const stress = evalScores['ストレス'] as number | undefined
  const workload = evalScores['業務負荷'] as number | undefined
  const satisfaction = evalScores['満足度'] as number | undefined
  const environment = evalScores['職場環境'] as number | undefined
  const relationship = evalScores['人間関係'] as number | undefined

  const scores = [stress, workload, satisfaction, environment, relationship]
  const validScores = scores.filter((s): s is number => s !== undefined)
  const avgScore = validScores.length > 0
    ? validScores.reduce((sum, s) => sum + s, 0) / validScores.length
    : 0

  const lowScoreCount = scores.filter((s) => s !== undefined && s < 2).length
  if (lowScoreCount >= 3) {
    return pleasync.status('健康状態', '要緊急対応').value
  }

  if (stress !== undefined && workload !== undefined && stress < 2 && workload < 2) {
    return pleasync.status('健康状態', '過重負荷').value
  }

  if (stress === 1 || workload === 1 || satisfaction === 1) {
    return pleasync.status('健康状態', '要注意').value
  }

  if ((stress !== undefined && stress > 1 && stress < 2.5) ||
      (workload !== undefined && workload > 1 && workload < 2.5)) {
    return pleasync.status('健康状態', '疲労あり').value
  }

  if (satisfaction !== undefined && satisfaction < 2.5) {
    return pleasync.status('健康状態', '不満あり').value
  }

  if ((relationship !== undefined && relationship < 2.5) ||
      (environment !== undefined && environment < 2.5)) {
    return pleasync.status('健康状態', '環境課題あり').value
  }

  if (avgScore < 3) {
    return pleasync.status('健康状態', '要観察').value
  }

  if (avgScore < 4) {
    return pleasync.status('健康状態', '良好').value
  }

  return pleasync.status('健康状態', '非常に良好').value
}
