/**
 * Answers サービス
 * 回答結果の取得・更新・作成処理
 *
 * ファイル分割:
 * - answers.helpers.ts: 共通ヘルパー
 * - answers.core.ts: 基本CRUD操作
 * - answers.access.ts: アクセス制御
 * - answers.delegation.ts: 委任機能
 */

// ヘルパー
export { parseSupervisorIds, ANSWER_STATUS_LABEL_TO_CODE } from './answers.helpers'

// コアCRUD
export {
  getAllAnswers,
  getAnswerById,
  getEmployeeDetail,
  createAnswer,
  updateAnswer,
  calculateInterviewViewers,
} from './answers.core'

// アクセス制御
export {
  canAccessAnswer,
  isRespondentForPublish,
  canAccessUserAnswers,
  checkUserAccess,
} from './answers.access'

// 委任機能
export {
  type DelegationType,
  addDelegate,
  removeDelegate,
  isDelegateTargetValid,
  getSubordinates,
} from './answers.delegation'
