/**
 * ジョブサービス - ヘルパー関数
 */

import { pleasync } from '../infrastructure/pleasync'

// カラム名を起動時に解決（毎回呼ばない）
const USER_COLS = {
  ユーザーID: pleasync.getColumnName('ユーザーマスタ', 'ユーザーID'),
  役職: pleasync.getColumnName('ユーザーマスタ', '役職'),
  所属本部: pleasync.getColumnName('ユーザーマスタ', '所属本部'),
  所属部: pleasync.getColumnName('ユーザーマスタ', '所属部'),
  所属課: pleasync.getColumnName('ユーザーマスタ', '所属課'),
  追加面談候補: pleasync.getColumnName('ユーザーマスタ', '追加面談候補'),
}

// ===========================
// ユーティリティ関数
// ===========================

/**
 * JSON文字列を安全にパース
 */
export function safeParseJson<T>(value: unknown): T | null {
  if (typeof value !== 'string' || !value) return null
  try {
    return JSON.parse(value) as T
  } catch {
    return null
  }
}

/**
 * 値を配列として確保（null/undefinedは空配列）
 */
export function ensureArray<T>(value: T | T[] | null | undefined): T[] {
  if (value === null || value === undefined) return []
  return Array.isArray(value) ? value : [value]
}

/**
 * 日付文字列をパース（複数形式対応）
 */
export function parseAnyDate(value: unknown): Date | null {
  if (!value) return null
  if (value instanceof Date) return value
  if (typeof value === 'string') {
    const date = new Date(value)
    return isNaN(date.getTime()) ? null : date
  }
  return null
}

/**
 * 日付を「YYYY年MM月」形式に変換
 */
export function formatYearMonth(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  return `${year}年${month}月`
}

// ===========================
// 役職コード定数（上司判定用）
// ===========================

/** 課長クラス（500-699）: 同一本部/部/課で、対象者が500以下 */
const POSITION_SECTION_MANAGER = 500
/** 部長クラス（700-899）: 同一本部/部で、対象者が700以下（課なし） */
const POSITION_DEPARTMENT_MANAGER = 700
/** 本部長クラス（900-999）: 同一本部で、対象者が900以下（部なし/課なし） */
const POSITION_DIVISION_MANAGER = 900

// ===========================
// 組織フィルタ関連
// ===========================

export interface OrganizationFilter {
  positionCodes: string[]
  divisionCodes: string[]
  departmentCodes: string[]
  sectionCodes: string[]
}

/**
 * 組織条件でユーザーをフィルタリング
 */
export function filterUsersByOrganization(
  users: Record<string, unknown>[],
  filter: OrganizationFilter
): Record<string, unknown>[] {
  return users.filter((user) => {
    // 役職フィルタ
    if (filter.positionCodes.length > 0) {
      const userPosition = String(user[USER_COLS.役職] || '')
      if (!filter.positionCodes.includes(userPosition)) return false
    }
    // 本部フィルタ
    if (filter.divisionCodes.length > 0) {
      const userDivision = String(user[USER_COLS.所属本部] || '')
      if (!filter.divisionCodes.includes(userDivision)) return false
    }
    // 部フィルタ
    if (filter.departmentCodes.length > 0) {
      const userDept = String(user[USER_COLS.所属部] || '')
      if (!filter.departmentCodes.includes(userDept)) return false
    }
    // 課フィルタ
    if (filter.sectionCodes.length > 0) {
      const userSection = String(user[USER_COLS.所属課] || '')
      if (!filter.sectionCodes.includes(userSection)) return false
    }
    return true
  })
}

/**
 * ユーザーの面談候補（上司リスト）を取得
 */
export function getSupervisors(
  user: Record<string, unknown>,
  allUsers: Record<string, unknown>[]
): string {
  const candidateIds: string[] = []
  const addedUserIds = new Set<string>()

  const parseOrgArray = (value: unknown): string[] => {
    if (!value) return []
    const parsed = safeParseJson<string[]>(value as string)
    return parsed || []
  }

  const hasIntersection = (arr1: string[], arr2: string[]): boolean => {
    if (arr1.length === 0 || arr2.length === 0) return true
    return arr1.some((item) => arr2.includes(item))
  }

  const userId = user[USER_COLS.ユーザーID] as number
  const userPosition = Number(user[USER_COLS.役職] || 0)
  const userDivision = String(user[USER_COLS.所属本部] || '')
  const userDepartments = parseOrgArray(user[USER_COLS.所属部])
  const userSections = parseOrgArray(user[USER_COLS.所属課])

  for (const supervisor of allUsers) {
    const supervisorId = supervisor[USER_COLS.ユーザーID] as number

    if (supervisorId === userId) continue

    const supervisorPosition = Number(supervisor[USER_COLS.役職] || 0)
    const supervisorDivision = String(supervisor[USER_COLS.所属本部] || '')
    const supervisorDepartments = parseOrgArray(supervisor[USER_COLS.所属部])
    const supervisorSections = parseOrgArray(supervisor[USER_COLS.所属課])

    const sameDivision =
      !supervisorDivision ||
      !userDivision ||
      userDivision === supervisorDivision
    const sameDepartment = hasIntersection(supervisorDepartments, userDepartments)
    const sameSection = hasIntersection(supervisorSections, userSections)

    let isSupervisor = false

    if (supervisorPosition >= POSITION_SECTION_MANAGER && supervisorPosition < POSITION_DEPARTMENT_MANAGER) {
      isSupervisor = sameDivision && sameDepartment && sameSection && userPosition < POSITION_SECTION_MANAGER
    }
    else if (supervisorPosition >= POSITION_DEPARTMENT_MANAGER && supervisorPosition < POSITION_DIVISION_MANAGER) {
      isSupervisor = sameDivision && sameDepartment && userPosition < POSITION_DEPARTMENT_MANAGER
    }
    else if (supervisorPosition >= POSITION_DIVISION_MANAGER && supervisorPosition <= 999) {
      isSupervisor = sameDivision && userPosition < POSITION_DIVISION_MANAGER
    }

    const supervisorIdStr = String(supervisorId)
    if (isSupervisor && !addedUserIds.has(supervisorIdStr)) {
      candidateIds.push(supervisorIdStr)
      addedUserIds.add(supervisorIdStr)
    }
  }

  const additionalCandidates = user[USER_COLS.追加面談候補]
  if (additionalCandidates) {
    const parsed = safeParseJson<string[]>(additionalCandidates as string)
    if (parsed) {
      for (const candidateId of parsed) {
        if (addedUserIds.has(candidateId)) continue
        candidateIds.push(candidateId)
        addedUserIds.add(candidateId)
      }
    }
  }

  return JSON.stringify(candidateIds)
}
