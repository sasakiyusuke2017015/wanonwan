/**
 * ジョブサービス - コアバッチ処理
 */

import { pleasync } from '../infrastructure/pleasync'
import { logger as baseLogger } from '../config/logger'
import {
  safeParseJson,
  ensureArray,
  parseAnyDate,
  formatYearMonth,
  filterUsersByOrganization,
  getSupervisors,
  type OrganizationFilter,
} from './jobs.helpers'

/** バッチ処理用ロガー（log_type: "app" 付き、request_id なし） */
const logger = baseLogger.child({ log_type: 'app' })

// カラム名を起動時に解決
const PUB = {
  siteId: pleasync.getSiteId('掲載設定'),
  掲載ID: pleasync.getColumnName('掲載設定', '掲載ID'),
  掲載状況: pleasync.getColumnName('掲載設定', '掲載状況'),
  開始: pleasync.getColumnName('掲載設定', '開始'),
  完了: pleasync.getColumnName('掲載設定', '完了'),
  バッチ開始月: pleasync.getColumnName('掲載設定', 'バッチ開始月'),
  アンケート選択: pleasync.getColumnName('掲載設定', 'アンケート選択'),
  回答率: pleasync.getColumnName('掲載設定', '回答率'),
}

const ANS = {
  siteId: pleasync.getSiteId('回答結果'),
  回答ID: pleasync.getColumnName('回答結果', '回答ID'),
  回答者: pleasync.getColumnName('回答結果', '回答者'),
  掲載設定: pleasync.getColumnName('回答結果', '掲載設定'),
  回答状況: pleasync.getColumnName('回答結果', '回答状況'),
  アンケート内容JSON: pleasync.getColumnName('回答結果', 'アンケート内容JSON'),
  ユーザー用生成プロンプト: pleasync.getColumnName('回答結果', 'ユーザー用生成プロンプト'),
  サポーター用生成プロンプト: pleasync.getColumnName('回答結果', 'サポーター用生成プロンプト'),
  面談候補: pleasync.getColumnName('回答結果', '面談候補'),
}

const USR = {
  siteId: pleasync.getSiteId('ユーザーマスタ'),
  ユーザーID: pleasync.getColumnName('ユーザーマスタ', 'ユーザーID'),
  ユーザーコード: pleasync.getColumnName('ユーザーマスタ', 'ユーザーコード'),
  名前: pleasync.getColumnName('ユーザーマスタ', '名前'),
  役職: pleasync.getColumnName('ユーザーマスタ', '役職'),
  所属本部: pleasync.getColumnName('ユーザーマスタ', '所属本部'),
  所属部: pleasync.getColumnName('ユーザーマスタ', '所属部'),
  所属課: pleasync.getColumnName('ユーザーマスタ', '所属課'),
  メールアドレス: pleasync.getColumnName('ユーザーマスタ', 'メールアドレス'),
  追加面談候補: pleasync.getColumnName('ユーザーマスタ', '追加面談候補'),
}

const SURVEY = {
  対象役職区分: pleasync.getColumnName('アンケートマスタ', '対象役職区分'),
  対象本部区分: pleasync.getColumnName('アンケートマスタ', '対象本部区分'),
  対象部区分: pleasync.getColumnName('アンケートマスタ', '対象部区分'),
  対象課区分: pleasync.getColumnName('アンケートマスタ', '対象課区分'),
  使用質問: pleasync.getColumnName('アンケートマスタ', '使用質問'),
  ユーザー向けプロンプト: pleasync.getColumnName('アンケートマスタ', 'ユーザー向けプロンプト'),
  サポーター向けプロンプト: pleasync.getColumnName('アンケートマスタ', 'サポーター向けプロンプト'),
}

const QUESTION = {
  質問ID: pleasync.getColumnName('質問マスタ', '質問ID'),
  タイトル: pleasync.getColumnName('質問マスタ', 'タイトル'),
  タイトル備考: pleasync.getColumnName('質問マスタ', 'タイトル備考'),
  質問内容: pleasync.getColumnName('質問マスタ', '質問内容'),
  内容備考: pleasync.getColumnName('質問マスタ', '内容備考'),
  回答形式: pleasync.getColumnName('質問マスタ', '回答形式'),
  選択肢: pleasync.getColumnName('質問マスタ', '選択肢'),
  ソート順: pleasync.getColumnName('質問マスタ', 'ソート順'),
  必須回答: pleasync.getColumnName('質問マスタ', '必須回答'),
  追加記入欄あり: pleasync.getColumnName('質問マスタ', '追加記入欄あり'),
}

// ===========================
// レスポンス型
// ===========================

export interface StartSurveysResult {
  started_pub_ids: number[]
  started_count: number
  created_answer_count: number
  error_count: number
  errors: { pub_id: number; message: string }[]
  message: string
}

export interface FinishSurveysResult {
  finished_pub_ids: number[]
  finished_count: number
  message: string
}

export interface DeleteSurveysResult {
  deleted_pub_ids: string[]
  deleted_pub_count: number
  deleted_answer_count: number
  message: string
}

export interface UpdatePromptsResult {
  updated_pub_ids: string[]
  updated_pub_count: number
  updated_answer_count: number
  message: string
}

// ===========================
// 1. アンケート開始
// ===========================

export async function startSurveys(pubIds?: string[] | null): Promise<StartSurveysResult> {
  logger.info({ pubIds: pubIds || '全件' }, '[jobs/startSurveys] の実行')

  // 掲載設定の一覧取得（掲載状況=予約）
  logger.info('アンケートの一覧取得をします（掲載状況=予約）')
  const rawRecords = await pleasync.raw(
    `SELECT
      "IssueId" as "${PUB.掲載ID}",
      "Status" as "${PUB.掲載状況}",
      "StartTime" as "${PUB.開始}",
      "${PUB.バッチ開始月}" as "${PUB.バッチ開始月}",
      "${PUB.アンケート選択}" as "${PUB.アンケート選択}"
     FROM "Issues"
     WHERE "SiteId" = $1::bigint AND "Status" = $2`,
    [PUB.siteId, pleasync.status('掲載状況', '予約').value]
  )

  // 掲載期間中で絞り込み
  logger.info('掲載期間中のアンケートのみ抽出します')
  const now = new Date()
  const filteredRecords = rawRecords.filter((r) => {
    const startDate = parseAnyDate(r[PUB.開始])
    if (!startDate || startDate > now) return false
    if (pubIds) {
      const pubId = String(r[PUB.掲載ID])
      if (!pubIds.includes(pubId)) return false
    }
    return true
  })

  if (filteredRecords.length === 0) {
    logger.info('実施予定かつ掲載期間中のアンケートはありません')
    return {
      started_pub_ids: [], started_count: 0, created_answer_count: 0,
      error_count: 0, errors: [], message: '開始対象のアンケートがありません',
    }
  }

  logger.info(`実施予定かつ掲載期間中のアンケート件数: ${filteredRecords.length}件`)

  // 2重実行チェック用: 全掲載設定を取得
  const allPublishRecords = await pleasync.raw(
    `SELECT
      "IssueId" as "${PUB.掲載ID}",
      "${PUB.バッチ開始月}" as "${PUB.バッチ開始月}",
      "${PUB.アンケート選択}" as "${PUB.アンケート選択}"
     FROM "Issues"
     WHERE "SiteId" = $1::bigint`,
    [PUB.siteId]
  )
  const executedBatch: [string, string][] = []

  // 全ユーザー取得
  const users = await pleasync.raw(
    `SELECT
      "${USR.ユーザーID}" as "${USR.ユーザーID}",
      "${USR.ユーザーコード}" as "${USR.ユーザーコード}",
      "${USR.名前}" as "${USR.名前}",
      "${USR.役職}" as "${USR.役職}",
      "${USR.所属本部}" as "${USR.所属本部}",
      "${USR.所属部}" as "${USR.所属部}",
      "${USR.所属課}" as "${USR.所属課}",
      "${USR.メールアドレス}" as "${USR.メールアドレス}",
      "${USR.追加面談候補}" as "${USR.追加面談候補}"
     FROM "Results"
     WHERE "SiteId" = $1::bigint`,
    [USR.siteId]
  )

  const successPubIds: number[] = []
  const errors: { pub_id: number; message: string }[] = []
  let totalCreatedAnswerCount = 0

  for (const r of filteredRecords) {
    const pubId = r[PUB.掲載ID] as number
    const surveyId = r[PUB.アンケート選択] as string

    // アンケートマスタ情報を取得
    const surveyRecord = await pleasync.getRecord('アンケートマスタ', Number(surveyId), [
      '対象役職区分', '対象本部区分', '対象部区分', '対象課区分',
      '使用質問', 'ユーザー向けプロンプト', 'サポーター向けプロンプト',
    ], 'Value')

    // 開始日から年月を取得
    const startDate = parseAnyDate(r[PUB.開始])
    if (!startDate) continue
    const currentMonth = formatYearMonth(startDate)

    // 2重実行チェック
    const duplicate = allPublishRecords.find(
      (rec) =>
        rec[PUB.バッチ開始月] === currentMonth &&
        rec[PUB.アンケート選択] === surveyId &&
        rec[PUB.掲載ID] !== pubId
    )

    const isDuplicateInBatch = executedBatch.some(
      ([m, s]) => m === currentMonth && s === surveyId
    )

    if (duplicate || isDuplicateInBatch) {
      const errorMessage = `${currentMonth} は既にアンケートが実施されています`
      logger.error({ pubId }, errorMessage)
      await pleasync.updateRecord(Number(pubId), {
        [PUB.掲載状況]: pleasync.status('掲載状況', 'エラー').value,
        Comments: errorMessage,
      })
      errors.push({ pub_id: pubId, message: errorMessage })
      continue
    }

    executedBatch.push([currentMonth, surveyId])

    // 組織フィルタ条件
    const orgFilter: OrganizationFilter = {
      positionCodes: ensureArray(safeParseJson<string[]>(surveyRecord[SURVEY.対象役職区分] as string)),
      divisionCodes: ensureArray(safeParseJson<string[]>(surveyRecord[SURVEY.対象本部区分] as string)),
      departmentCodes: ensureArray(safeParseJson<string[]>(surveyRecord[SURVEY.対象部区分] as string)),
      sectionCodes: ensureArray(safeParseJson<string[]>(surveyRecord[SURVEY.対象課区分] as string)),
    }

    // アンケート内容JSON（質問スナップショット）の作成
    const surveyContentJson: Record<string, unknown>[] = []
    const rawQuestions = surveyRecord[SURVEY.使用質問]
    if (rawQuestions) {
      const qIds = safeParseJson<number[]>(rawQuestions as string) || []
      for (const qid of qIds) {
        const questionRecord = await pleasync.getRecord('質問マスタ', Number(qid), [
          '質問ID', 'タイトル', 'タイトル備考', '質問内容', '内容備考',
          '回答形式', '選択肢', 'ソート順', '必須回答', '追加記入欄あり',
        ], 'Value')
        if (questionRecord && Object.keys(questionRecord).length > 0) {
          const choices = questionRecord['選択肢']
          questionRecord['選択肢'] =
            typeof choices === 'string' ? choices.split('\n') : []
          surveyContentJson.push(questionRecord)
        }
      }
    }

    surveyContentJson.sort((a, b) => {
      const aSort = (a['ソート順'] as number) || 0
      const bSort = (b['ソート順'] as number) || 0
      return aSort - bSort
    })

    const surveyContentJsonStr = JSON.stringify(surveyContentJson)
    logger.info(
      { pubId, questionCount: surveyContentJson.length },
      `掲載ID: ${pubId} のアンケート内容JSON(質問数: ${surveyContentJson.length})を作成しました`
    )

    // プロンプトのスナップショット取得
    const userPromptSnapshot = (surveyRecord[SURVEY.ユーザー向けプロンプト] as string) || ''
    const suppPromptSnapshot = (surveyRecord[SURVEY.サポーター向けプロンプト] as string) || ''

    logger.info(
      { pubId },
      `掲載ID: ${pubId} を実施中へ更新した上で、対象ユーザーの未回答データを新規作成します`
    )

    // 対象ユーザーに絞り込み未回答データを新規作成
    const targetUsers = filterUsersByOrganization(users, orgFilter)
    let createdCount = 0

    for (const u of targetUsers) {
      const supervisorsJson = getSupervisors(u, users)

      await pleasync.createRecord(ANS.siteId, {
        [ANS.回答者]: u[USR.ユーザーID],
        [ANS.掲載設定]: pubId,
        [ANS.回答状況]: pleasync.status('回答状況', 'アンケート未回答').value,
        [ANS.アンケート内容JSON]: surveyContentJsonStr,
        [ANS.ユーザー用生成プロンプト]: userPromptSnapshot,
        [ANS.サポーター用生成プロンプト]: suppPromptSnapshot,
        [ANS.面談候補]: supervisorsJson,
      })
      createdCount++
    }

    totalCreatedAnswerCount += createdCount
    logger.info(
      { pubId, createdCount },
      `掲載ID: ${pubId} の回答データ ${createdCount} 件を作成しました`
    )

    // 掲載設定のステータス更新
    await pleasync.updateRecord(Number(pubId), {
      [PUB.掲載状況]: pleasync.status('掲載状況', '実施中').value,
      [PUB.回答率]: 0,
      [PUB.バッチ開始月]: currentMonth,
    })
    successPubIds.push(pubId)
  }

  const messageParts: string[] = []
  if (successPubIds.length > 0) messageParts.push(`掲載設定 ${successPubIds.length} 件を開始`)
  if (totalCreatedAnswerCount > 0) messageParts.push(`回答データ ${totalCreatedAnswerCount} 件を作成`)
  if (errors.length > 0) messageParts.push(`重複エラー ${errors.length} 件`)
  const message = messageParts.length > 0 ? messageParts.join('、') : '処理対象がありません'

  return {
    started_pub_ids: successPubIds, started_count: successPubIds.length,
    created_answer_count: totalCreatedAnswerCount,
    error_count: errors.length, errors, message,
  }
}

// ===========================
// 2. アンケート終了
// ===========================

export async function finishSurveys(pubIds?: string[] | null): Promise<FinishSurveysResult> {
  logger.info({ pubIds: pubIds || '全件' }, '[jobs/finishSurveys] の実行')

  logger.info('アンケートの一覧取得をします（掲載状況=実施中）')
  const rawRecords = await pleasync.raw(
    `SELECT
      "IssueId" as "${PUB.掲載ID}",
      "Status" as "${PUB.掲載状況}",
      "StartTime" as "${PUB.開始}",
      ("CompletionTime" - INTERVAL '1 day') as "${PUB.完了}"
     FROM "Issues"
     WHERE "SiteId" = $1::bigint AND "Status" = $2`,
    [PUB.siteId, pleasync.status('掲載状況', '実施中').value]
  )

  logger.info('掲載期間外のアンケートのみ抽出します')
  const now = new Date()
  const records = rawRecords.filter((r) => {
    const endDate = parseAnyDate(r[PUB.完了])
    if (!endDate || endDate >= now) return false
    if (pubIds) {
      const pubId = String(r[PUB.掲載ID])
      if (!pubIds.includes(pubId)) return false
    }
    return true
  })

  if (records.length === 0) {
    logger.info('実施中かつ掲載期間外のアンケートはありません')
    return { finished_pub_ids: [], finished_count: 0, message: '終了対象のアンケートがありません' }
  }

  logger.info(`実施中かつ掲載期間外のアンケート件数: ${records.length}件`)

  const finishedPubIds: number[] = []
  for (const r of records) {
    const pubId = r[PUB.掲載ID] as number
    logger.info({ pubId }, `掲載ID: ${pubId} を終了へ更新します`)

    await pleasync.updateRecord(Number(pubId), {
      [PUB.掲載状況]: pleasync.status('掲載状況', '完了').value,
    })
    finishedPubIds.push(pubId)
  }

  return {
    finished_pub_ids: finishedPubIds,
    finished_count: finishedPubIds.length,
    message: `掲載設定 ${finishedPubIds.length} 件を終了しました`,
  }
}

// ===========================
// 3. アンケート削除
// ===========================

export async function deleteSurveys(pubIds?: string[] | null): Promise<DeleteSurveysResult> {
  logger.info({ pubIds: pubIds || '全件' }, '[jobs/deleteSurveys] の実行')

  let targetPubIds = pubIds ?? null

  if (!targetPubIds) {
    logger.info('掲載IDが指定されていないため、全件取得します')
    const allRecords = await pleasync.raw(
      `SELECT "IssueId" as "${PUB.掲載ID}" FROM "Issues" WHERE "SiteId" = $1::bigint`,
      [PUB.siteId]
    )
    targetPubIds = allRecords.map((r) => String(r[PUB.掲載ID]))

    if (targetPubIds.length === 0) {
      logger.info('削除対象のアンケートがありません')
      return { deleted_pub_ids: [], deleted_pub_count: 0, deleted_answer_count: 0, message: '削除対象のアンケートがありません' }
    }
  }

  logger.info({ pubIds: targetPubIds }, `掲載ID: ${targetPubIds.join(', ')} の削除を開始`)

  let totalDeletedAnswerCount = 0
  const deletedPubIds: string[] = []

  for (const pubId of targetPubIds) {
    logger.info({ pubId }, `掲載ID: ${pubId} の削除処理を開始します`)

    const targetAnswers = await pleasync.raw(
      `SELECT "ResultId" as "${ANS.回答ID}" FROM "Results" WHERE "SiteId" = $1::bigint AND "${ANS.掲載設定}" = $2`,
      [ANS.siteId, pubId]
    )

    logger.info({ pubId, targetCount: targetAnswers.length }, `掲載ID ${pubId} の削除対象回答結果件数: ${targetAnswers.length}件`)

    for (const ans of targetAnswers) {
      const ansId = ans[ANS.回答ID] as number
      await pleasync.deleteRecord(Number(ansId))
      totalDeletedAnswerCount++
    }

    logger.info({ pubId, deletedCount: targetAnswers.length }, `掲載ID ${pubId} の回答結果 ${targetAnswers.length} 件を削除しました`)

    logger.info({ pubId }, `掲載ID: ${pubId} を削除します`)
    await pleasync.deleteRecord(Number(pubId))
    deletedPubIds.push(pubId)
  }

  logger.info(
    { deletedPubCount: deletedPubIds.length, deletedAnswerCount: totalDeletedAnswerCount },
    `削除完了: 掲載設定 ${deletedPubIds.length} 件、回答結果 ${totalDeletedAnswerCount} 件`
  )

  return {
    deleted_pub_ids: deletedPubIds, deleted_pub_count: deletedPubIds.length,
    deleted_answer_count: totalDeletedAnswerCount,
    message: `掲載設定 ${deletedPubIds.length} 件と回答結果 ${totalDeletedAnswerCount} 件を削除しました`,
  }
}

// ===========================
// 4. プロンプト更新
// ===========================

export async function updatePrompts(pubIds: string[]): Promise<UpdatePromptsResult> {
  logger.info({ pubIds }, '[jobs/updatePrompts] の実行')

  const publishRecords = await pleasync.raw(
    `SELECT
      "IssueId" as "${PUB.掲載ID}",
      "${PUB.アンケート選択}" as "${PUB.アンケート選択}"
     FROM "Issues"
     WHERE "SiteId" = $1::bigint`,
    [PUB.siteId]
  )

  const targetPublishes = publishRecords.filter((r) => {
    const pubId = String(r[PUB.掲載ID])
    return pubIds.includes(pubId)
  })

  if (targetPublishes.length === 0) {
    return { updated_pub_ids: [], updated_pub_count: 0, updated_answer_count: 0, message: '指定された掲載IDが見つかりません' }
  }

  let totalUpdatedCount = 0
  const updatedPubIds: string[] = []

  for (const pub of targetPublishes) {
    const pubId = pub[PUB.掲載ID] as number
    const surveyId = pub[PUB.アンケート選択] as string

    const surveyRecord = await pleasync.getRecord('アンケートマスタ', Number(surveyId), [
      'ユーザー向けプロンプト', 'サポーター向けプロンプト',
    ], 'Value')

    const userPrompt = (surveyRecord[SURVEY.ユーザー向けプロンプト] as string) || ''
    const suppPrompt = (surveyRecord[SURVEY.サポーター向けプロンプト] as string) || ''

    logger.info(
      { pubId, userPromptLength: userPrompt.length, suppPromptLength: suppPrompt.length },
      `掲載ID: ${pubId} のプロンプトを取得`
    )

    const targetAnswers = await pleasync.raw(
      `SELECT "ResultId" as "${ANS.回答ID}" FROM "Results" WHERE "SiteId" = $1::bigint AND "${ANS.掲載設定}" = $2`,
      [ANS.siteId, String(pubId)]
    )

    logger.info({ pubId, targetCount: targetAnswers.length }, `掲載ID: ${pubId} の更新対象回答件数: ${targetAnswers.length}件`)

    for (const ans of targetAnswers) {
      const ansId = ans[ANS.回答ID] as number
      await pleasync.updateRecord(Number(ansId), {
        [ANS.ユーザー用生成プロンプト]: userPrompt,
        [ANS.サポーター用生成プロンプト]: suppPrompt,
      })
      totalUpdatedCount++
    }

    updatedPubIds.push(String(pubId))
  }

  logger.info(
    { updatedPubIds, totalUpdatedCount },
    `プロンプト更新完了: 掲載設定 ${updatedPubIds.length} 件、回答 ${totalUpdatedCount} 件`
  )

  return {
    updated_pub_ids: updatedPubIds, updated_pub_count: updatedPubIds.length,
    updated_answer_count: totalUpdatedCount,
    message: `掲載設定 ${updatedPubIds.length} 件の回答 ${totalUpdatedCount} 件のプロンプトを更新しました`,
  }
}
