/**
 * ユーザーサービス
 *
 * ユーザーマスタの取得・更新ロジック
 */

import { ServiceError } from './errors'
import { pleasync } from '../infrastructure/pleasync'
import { hashPassword, verifyPassword, isBcryptHash } from './password'
import { logger, type AppLogger } from '../config/logger'


/**
 * 全ユーザー取得
 *
 * @returns ユーザー一覧
 */
export async function getAllUsers() {
  return await pleasync.findMany('ユーザーマスタ', ['ユーザーID', 'ユーザーコード', '名前', 'メールアドレス', '役職', '所属本部', '所属部', '所属課'])
}

/**
 * 特定ユーザー取得
 *
 * @param userId ユーザーID
 * @returns ユーザー情報
 */
export async function getUserById(userId: string) {
  const record = await pleasync.getRecord('ユーザーマスタ', Number(userId), [
    'ユーザーID', 'ユーザーコード', '名前', 'メールアドレス', '役職', '所属本部', '所属部', '所属課',
  ], 'Value')

  if (!record || Object.keys(record).length === 0) {
    throw new ServiceError('NOT_FOUND', `ユーザーが見つかりません (ID: ${userId})`)
  }

  return record
}

/**
 * ユーザー情報更新
 *
 * @param userId ユーザーID
 * @param data 更新データ
 * @returns 更新後のユーザー情報
 */
export async function updateUser(
  userId: string,
  data: Partial<{
    ユーザーコード: string
    名前: string
    メールアドレス: string
    役職: string
    所属本部: string
    所属部: string
    所属課: string
  }>
): Promise<{ success: boolean; message: string }> {
  if (Object.keys(data).length === 0) {
    throw new ServiceError('BAD_REQUEST', '更新するデータがありません')
  }

  await pleasync.update('ユーザーマスタ', parseInt(userId, 10), data)

  return {
    success: true,
    message: 'ユーザー情報を更新しました',
  }
}

/**
 * パスワード変更
 *
 * @param userId ユーザーID
 * @param currentPassword 現在のパスワード
 * @param newPassword 新しいパスワード
 * @param confirmPassword 新しいパスワード（確認）
 * @returns 成功メッセージ
 */
export async function changePassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
  confirmPassword: string,
  log?: AppLogger
): Promise<{ success: boolean; message: string }> {
  const appLog = log || logger
  appLog.info({ operation: 'change_password', user_id: userId }, 'change_password started')
  // 1. 新しいパスワードと確認パスワードの一致チェック（Fail Fast）
  if (newPassword !== confirmPassword) {
    throw new ServiceError('BAD_REQUEST', '新しいパスワードと確認パスワードが一致しません')
  }

  // 2. ユーザー情報取得（パスワード含む）
  const user = await pleasync.getRecord('ユーザーマスタ', parseInt(userId, 10), [
    'ユーザーID', '初期パスワード', '変更済パスワード',
  ], 'Value')

  if (!user || Object.keys(user).length === 0) {
    throw new ServiceError('NOT_FOUND', 'ユーザーが見つかりません')
  }

  const changedPassword = user['変更済パスワード'] as string | undefined
  const initialPassword = user['初期パスワード'] as string
  const currentHashedPassword = changedPassword || initialPassword

  // Fail Fast: パスワードが設定されていない場合
  if (!currentHashedPassword) {
    throw new ServiceError('INTERNAL_ERROR', 'パスワードが設定されていません')
  }

  // 3. 現在のパスワード検証（bcryptハッシュまたは初期パスワード平文比較）
  let isCurrentPasswordValid: boolean
  if (isBcryptHash(currentHashedPassword)) {
    isCurrentPasswordValid = await verifyPassword(currentPassword, currentHashedPassword)
  } else {
    // 初期パスワード（平文）との比較（初回パスワード変更時）
    isCurrentPasswordValid = currentPassword === currentHashedPassword
  }

  if (!isCurrentPasswordValid) {
    appLog.warn({ operation: 'change_password', user_id: userId }, 'password verification failed')
    throw new ServiceError('UNAUTHORIZED', '現在のパスワードが正しくありません')
  }

  // 4. 新しいパスワードをbcryptハッシュ化して保存
  const newHashedPassword = await hashPassword(newPassword)

  // 5. Pleasanterで更新
  await pleasync.update('ユーザーマスタ', parseInt(userId, 10), {
    変更済パスワード: newHashedPassword,
  })

  appLog.info({ operation: 'change_password', user_id: userId }, 'change_password succeeded')

  return {
    success: true,
    message: 'パスワードを変更しました',
  }
}
