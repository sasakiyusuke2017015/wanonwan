/**
 * Answers サービス - 委任機能
 */

import { pleasync } from '../infrastructure/pleasync'
import { parseSupervisorIds } from './answers.helpers'
import { getAnswerById } from './answers.core'

/**
 * 委任タイプ
 */
export type DelegationType = 'this_answer_only' | 'this_answer_and_future'

/**
 * 委任追加
 *
 * @param answerId 回答ID
 * @param delegatorUserId 委任者（課長等）のユーザーID
 * @param delegateToUserId 委任先ユーザーID
 * @param delegationType 委任タイプ
 * @param respondentUserId 回答者のユーザーID
 */
export async function addDelegate(
  answerId: string,
  delegatorUserId: string,
  delegateToUserId: string,
  delegationType: DelegationType,
  respondentUserId: string
): Promise<{ success: boolean; message: string }> {
  // 1. 回答レコードの面談候補を更新（両方の委任タイプで実行）
  const answer = await getAnswerById(answerId)
  const currentCandidates = parseSupervisorIds(answer.面談候補)

  // 既に含まれているかチェック
  if (!currentCandidates.includes(delegateToUserId)) {
    const newCandidates = [...currentCandidates, delegateToUserId]
    await pleasync.update('回答結果', parseInt(answerId, 10), {
      面談候補: JSON.stringify(newCandidates),
    })
  }

  // 2. 今後ずっとの場合、ユーザーマスタの追加面談候補も更新
  if (delegationType === 'this_answer_and_future') {
    const userRecords = await pleasync.findMany('ユーザーマスタ',
      ['ユーザーID', '追加面談候補'],
      { ユーザーID: respondentUserId },
    )

    if (userRecords.length > 0) {
      const userRecord = userRecords[0]
      const userId = userRecord.ユーザーID as number
      const currentAdditional = parseSupervisorIds((userRecord.追加面談候補 as string) || '')

      // 既に含まれていなければ追加
      if (!currentAdditional.includes(delegateToUserId)) {
        const newAdditional = [...currentAdditional, delegateToUserId]
        await pleasync.update('ユーザーマスタ', Number(userId), {
          追加面談候補: JSON.stringify(newAdditional),
        })
      }
    }
  }

  const typeLabel = delegationType === 'this_answer_only' ? 'この回答のみ' : 'この回答+今後ずっと'
  return {
    success: true,
    message: `委任を追加しました（${typeLabel}）`,
  }
}

/**
 * 委任解除
 *
 * @param answerId 回答ID
 * @param delegateToUserId 委任先ユーザーID（解除対象）
 * @param removeFromFuture 今後の委任も解除するか
 * @param respondentUserId 回答者のユーザーID
 */
export async function removeDelegate(
  answerId: string,
  delegateToUserId: string,
  removeFromFuture: boolean,
  respondentUserId: string
): Promise<{ success: boolean; message: string }> {
  // 1. 回答レコードの面談候補から削除
  const answer = await getAnswerById(answerId)
  const currentCandidates = parseSupervisorIds(answer.面談候補)
  const newCandidates = currentCandidates.filter((id) => id !== delegateToUserId)

  await pleasync.update('回答結果', parseInt(answerId, 10), {
    面談候補: JSON.stringify(newCandidates),
  })

  // 2. 今後の委任も解除する場合、ユーザーマスタの追加面談候補からも削除
  if (removeFromFuture) {
    const userRecords = await pleasync.findMany('ユーザーマスタ',
      ['ユーザーID', '追加面談候補'],
      { ユーザーID: respondentUserId },
    )

    if (userRecords.length > 0) {
      const userRecord = userRecords[0]
      const userId = userRecord.ユーザーID as number
      const currentAdditional = parseSupervisorIds((userRecord.追加面談候補 as string) || '')
      const newAdditional = currentAdditional.filter((id) => id !== delegateToUserId)

      await pleasync.update('ユーザーマスタ', Number(userId), {
        追加面談候補: JSON.stringify(newAdditional),
      })
    }
  }

  const typeLabel = removeFromFuture ? 'この回答+今後の委任' : 'この回答のみ'
  return {
    success: true,
    message: `委任を解除しました（${typeLabel}）`,
  }
}

/**
 * 委任先が配下かどうかをチェック
 *
 * 委任先は回答一覧に表示されている他の社員（=自分が面談候補に含まれている人）のみ
 */
export async function isDelegateTargetValid(
  delegatorUserId: string,
  delegateToUserId: string
): Promise<boolean> {
  // 自分自身への委任は不可
  if (delegatorUserId === delegateToUserId) {
    return false
  }

  // 委任先ユーザーの回答一覧から、委任者が面談候補に含まれているかチェック
  const records = await pleasync.findMany('回答結果', ['回答者', '面談候補'])

  // 委任先ユーザーが回答者で、かつ委任者が面談候補に含まれているレコードがあるか
  return records.some((record) => {
    const respondent = String(record.回答者 || '')
    if (respondent !== delegateToUserId) return false

    const supervisorIds = parseSupervisorIds(record.面談候補 as string)
    return supervisorIds.includes(delegatorUserId)
  })
}

/**
 * 配下一覧取得
 *
 * 自分が面談候補に含まれている回答の回答者（＝配下）を取得
 * ユーザー情報（名前、役職、部署）も含めて返す
 */
export async function getSubordinates(
  userId: string
): Promise<Array<{
  ユーザーID: string
  名前: string
  役職: string | null
  部署: string | null
}>> {
  // 1. 回答レコードから自分が面談候補に含まれているものを取得
  const answerRecords = await pleasync.findMany('回答結果', ['回答者', '面談候補'])

  // 2. 自分が面談候補に含まれている回答者（配下）のIDを収集
  const subordinateIds = new Set<string>()
  for (const record of answerRecords) {
    const supervisorIds = parseSupervisorIds(record.面談候補 as string)
    if (supervisorIds.includes(userId)) {
      const respondentId = String(record.回答者 || '')
      if (respondentId && respondentId !== userId) {
        subordinateIds.add(respondentId)
      }
    }
  }

  if (subordinateIds.size === 0) {
    return []
  }

  // 3. ユーザーマスタから配下の情報を取得（WHERE IN）
  const userRecords = await pleasync.findMany('ユーザーマスタ',
    ['ユーザーID', '名前', '役職', '所属部', '所属課'],
    null,
    { ユーザーID: Array.from(subordinateIds) },
  )

  // 4. 配下のユーザー情報をマッピング
  return userRecords.map((user) => {
    const 所属部 = (user.所属部 as string) || ''
    const 所属課 = (user.所属課 as string) || ''
    const 部署 = [所属部, 所属課].filter(Boolean).join(' / ') || null

    return {
      ユーザーID: user.ユーザーID as string,
      名前: (user.名前 as string) || '',
      役職: (user.役職 as string) || null,
      部署,
    }
  })
}
