/**
 * ログサービス
 *
 * Pinoベースの構造化ログ出力を提供。
 * log_type: "app" を付与してアクセスログと分離する。
 */

import { logger } from '../config/logger'

/** アプリケーションログ用の子ロガー */
const appLogger = logger.child({ log_type: 'app' })

/**
 * ログエントリの型
 */
export interface LogEntry {
  timestamp: string
  userId?: string
  action: string
  details?: string
  ipAddress?: string
  status?: string
}

/**
 * ログを記録
 */
export function writeLog(entry: LogEntry): void {
  const data = {
    operation: entry.action,
    user_id: entry.userId,
    details: entry.details,
    ip_address: entry.ipAddress,
  }

  if (entry.status === 'error') {
    appLogger.error(data, entry.details || entry.action)
  } else {
    appLogger.info(data, entry.details || entry.action)
  }
}

/**
 * アクションログを記録（ユーザーアクション用）
 */
export function logAction(
  userId: string | undefined,
  action: string,
  details?: string
): void {
  appLogger.info({ operation: action, user_id: userId }, details || action)
}

/**
 * エラーログを記録
 */
export function logError(
  error: Error | string,
  context?: { userId?: string; action?: string }
): void {
  const message = error instanceof Error ? error.message : error
  appLogger.error(
    { operation: context?.action || 'error', user_id: context?.userId, err: error instanceof Error ? error : undefined },
    message
  )
}
