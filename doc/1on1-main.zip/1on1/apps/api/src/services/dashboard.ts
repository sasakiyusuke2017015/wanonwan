/**
 * Dashboard サービス
 * ダッシュボード統計データとチャートデータの取得
 *
 * PostgreSQL 直接クエリで最適化:
 * - COUNT(*) で件数のみ取得（全件取得を回避）
 * - WHERE 句で日付範囲フィルタ（メモリフィルタを回避）
 */

import { pleasync } from '../infrastructure/pleasync'

// 型定義
export interface DashboardResult {
  総ユーザー数: number
  総アンケート数: number
  総回答数: number
  未回答数: number
  回答率: number
  最新アンケート?: {
    掲載ID: number
    タイトル: string
    掲載状況?: string
    開始?: string
    完了?: string
  }
}

export interface TrendData {
  日付: string
  回答数: number
  満足度?: number
}

/**
 * ダッシュボード統計取得
 *
 * 最適化: COUNT(*) で件数のみ取得（全件取得を回避）
 */
export async function getStats(): Promise<DashboardResult> {
  const userSiteId = pleasync.getSiteId('ユーザーマスタ')
  const publishSiteId = pleasync.getSiteId('掲載設定')
  const answerSiteId = pleasync.getSiteId('回答結果')

  const [userCountResult, surveyCountResult, answerCountResult, surveys] = await Promise.all([
    pleasync.rawOne(
      `SELECT COUNT(*) as count FROM "Results" WHERE "SiteId" = $1`,
      [userSiteId]
    ),
    pleasync.rawOne(
      `SELECT COUNT(*) as count FROM "Issues" WHERE "SiteId" = $1`,
      [publishSiteId]
    ),
    pleasync.rawOne(
      `SELECT COUNT(*) as count FROM "Results" WHERE "SiteId" = $1`,
      [answerSiteId]
    ),
    pleasync.findMany('掲載設定', ['掲載ID', '掲載状況', '開始', '完了', 'アンケート選択']),
  ])

  const 総ユーザー数 = userCountResult ? parseInt(userCountResult.count, 10) : 0
  const 総アンケート数 = surveyCountResult ? parseInt(surveyCountResult.count, 10) : 0
  const 総回答数 = answerCountResult ? parseInt(answerCountResult.count, 10) : 0

  // 回答率計算（簡易版：総回答数 / (総ユーザー数 * 総アンケート数)）
  const 回答率 =
    総ユーザー数 > 0 && 総アンケート数 > 0
      ? Math.round((総回答数 / (総ユーザー数 * 総アンケート数)) * 100 * 10) / 10
      : 0

  // 未回答数（理論上の最大回答数 - 実際の回答数）
  const 未回答数 = 総ユーザー数 * 総アンケート数 - 総回答数

  // 最新アンケート取得（最も新しい開始日のアンケート）
  const sortedSurveys = surveys
    .map((s) => ({
      掲載ID: s.掲載ID as number,
      タイトル: (s.アンケート選択 as string) || '（タイトルなし）',
      掲載状況: s.掲載状況 ? String(s.掲載状況) : undefined,
      開始: (s.開始 as string) || undefined,
      完了: (s.完了 as string) || undefined,
    }))
    .filter((s) => s.開始)
    .sort((a, b) => {
      const dateA = a.開始 ? new Date(a.開始).getTime() : 0
      const dateB = b.開始 ? new Date(b.開始).getTime() : 0
      return dateB - dateA // 降順（新しい順）
    })

  const 最新アンケート = sortedSurveys.length > 0 ? sortedSurveys[0] : undefined

  return {
    総ユーザー数,
    総アンケート数,
    総回答数,
    未回答数,
    回答率,
    最新アンケート,
  }
}

/**
 * チャートデータ取得（トレンドデータ）
 *
 * 最適化: WHERE 句で日付範囲フィルタ（メモリフィルタを回避）
 */
export async function getChartData(
  startDate?: string,
  endDate?: string,
  _userId?: string
): Promise<TrendData[]> {
  const answerSiteId = pleasync.getSiteId('回答結果')
  const 回答日Col = pleasync.getColumnName('回答結果', '回答日')
  const 評価結果JSONCol = pleasync.getColumnName('回答結果', '評価結果JSON')

  // WHERE 句を動的構築
  const conditions: string[] = [`"SiteId" = $1`]
  const params: unknown[] = [answerSiteId]

  // 無効な日付（1899-12-30）を除外
  conditions.push(`"${回答日Col}" > '1900-01-01'`)

  if (startDate) {
    params.push(startDate)
    conditions.push(`"${回答日Col}" >= $${params.length}`)
  }
  if (endDate) {
    params.push(endDate + 'T23:59:59')
    conditions.push(`"${回答日Col}" <= $${params.length}`)
  }

  const answers = await pleasync.raw(
    `SELECT "${回答日Col}" as "DateA", "${評価結果JSONCol}" as "DescriptionA"
     FROM "Results"
     WHERE ${conditions.join(' AND ')}`,
    params
  )

  // 日付でグルーピング
  const dateMap = new Map<string, { count: number; scores: number[] }>()

  answers.forEach((answer) => {
    const 回答日 = answer.DateA
    if (!回答日) return

    // 日付のみを抽出（YYYY-MM-DD形式）
    const dateStr = 回答日.split('T')[0]

    if (!dateMap.has(dateStr)) {
      dateMap.set(dateStr, { count: 0, scores: [] })
    }

    const data = dateMap.get(dateStr)!
    data.count++

    // 評価結果JSONをパース
    const 評価結果JSON = answer.DescriptionA
    if (評価結果JSON) {
      try {
        const parsed = JSON.parse(評価結果JSON)
        if (typeof parsed === 'object' && parsed.score) {
          data.scores.push(parsed.score)
        }
      } catch {
        // JSON パースエラーは無視
      }
    }
  })

  // Map をソートして配列に変換
  const trendData: TrendData[] = Array.from(dateMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([日付, data]) => ({
      日付,
      回答数: data.count,
      満足度:
        data.scores.length > 0
          ? Math.round((data.scores.reduce((a, b) => a + b, 0) / data.scores.length) * 10) / 10
          : undefined,
    }))

  return trendData
}
