/**
 * Answers サービス - 共通ヘルパー
 */

import { pleasync } from '../infrastructure/pleasync'

// 回答状況ラベルを数値コードに変換するマッピング
export const ANSWER_STATUS_LABEL_TO_CODE = Object.fromEntries(
  Object.entries(pleasync.statusAll('回答状況')).map(([key, def]) => [key, def.value])
) as Record<string, number>

/**
 * 面談候補JSONをパースしてユーザーIDの配列を取得
 */
export function parseSupervisorIds(supervisorJson: string | undefined): string[] {
  if (!supervisorJson) return []
  try {
    const parsed = JSON.parse(supervisorJson)
    if (Array.isArray(parsed)) {
      return parsed.map(String)
    }
    return []
  } catch {
    return []
  }
}
