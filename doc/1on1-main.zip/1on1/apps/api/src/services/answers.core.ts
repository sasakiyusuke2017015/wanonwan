/**
 * Answers サービス - コアCRUD操作
 */

import { pleasync } from '../infrastructure/pleasync'
import type {
  AnswerListItem,
  AnswerResult,
  AnswerStatusCode,
  HealthStatusCode,
} from '@1on1/domain/validators'
import { parseSupervisorIds, ANSWER_STATUS_LABEL_TO_CODE } from './answers.helpers'

/**
 * 回答結果一覧取得
 *
 * アクセス制御:
 * - userId指定時: 自分が回答者 OR 自分が面談候補に含まれるレコードのみ
 */
export async function getAllAnswers(
  limit?: number,
  offset?: number,
  recentMonths?: number,
  userId?: string
): Promise<{ answers: AnswerListItem[]; total: number }> {

  // userIdは必須（認証済みユーザーのみアクセス可能）
  if (!userId) {
    return { answers: [], total: 0 }
  }
  const userIdStr = String(userId)

  // 1. 回答結果・掲載設定・アンケートマスタを並列取得
  const [answerRecords, publishRecords, surveyRecords] = await Promise.all([
    pleasync.findMany('回答結果', [
        '回答ID', '回答状況', '回答者', '掲載設定', '面談者', '健康状態',
        '面談方式', '面談候補', '回答日', '面談日', '評価結果JSON', '面談メモ',
        '面談内容閲覧者', '作成日時',
      ]),
    pleasync.findMany('掲載設定', ['掲載ID', 'アンケート選択', 'バッチ開始月', '開始', '完了']),
    pleasync.findMany('アンケートマスタ', ['アンケートID', 'タイトル']),
  ])

  // 2. アクセス制御: 回答テーブルから自分が関係するレコードのみ抽出
  const filteredRecords = answerRecords.filter((record) => {
    const 回答者 = String(record.回答者 || '')
    if (回答者 === userIdStr) return true
    const supervisorIds = parseSupervisorIds(record.面談候補 as string)
    if (supervisorIds.includes(userIdStr)) return true
    return false
  })

  // 3. フィルタ後の回答者・面談者IDリストを収集（PII最小化）
  const neededUserIds = new Set<string>()
  for (const record of filteredRecords) {
    const 回答者ID = String(record.回答者 || '')
    const 面談者ID = String(record.面談者 || '')
    if (回答者ID) neededUserIds.add(回答者ID)
    if (面談者ID) neededUserIds.add(面談者ID)
  }

  // 4. 必要なユーザーのみマスタ取得（WHERE IN）
  const userMap = new Map<string, {
    名前?: string
    役職?: string
    所属本部?: string
    所属部?: string
    所属課?: string
    メールアドレス?: string
  }>()

  if (neededUserIds.size > 0) {
    const userRecords = await pleasync.findMany('ユーザーマスタ',
      ['ユーザーID', '名前', '役職', '所属本部', '所属部', '所属課', 'メールアドレス'],
      null,
      { ユーザーID: Array.from(neededUserIds) },
    )

    for (const user of userRecords) {
      userMap.set(String(user.ユーザーID), {
        名前: (user.名前 as string) || undefined,
        役職: (user.役職 as string) || undefined,
        所属本部: (user.所属本部 as string) || undefined,
        所属部: (user.所属部 as string) || undefined,
        所属課: (user.所属課 as string) || undefined,
        メールアドレス: (user.メールアドレス as string) || undefined,
      })
    }
  }

  // アンケートマスタをMapに変換
  const surveyTitleMap = new Map<string, string>()
  for (const survey of surveyRecords) {
    const surveyId = String(survey.アンケートID)
    const title = survey.タイトル as string
    if (surveyId && title) {
      surveyTitleMap.set(surveyId, title)
    }
  }

  // 掲載設定をMapに変換
  const publishMap = new Map<string, { アンケート選択?: string; バッチ開始月?: string; 開始?: string; 完了?: string }>()
  for (const publish of publishRecords) {
    const publishId = String(publish.掲載ID)
    if (publishId) {
      publishMap.set(publishId, {
        アンケート選択: (publish.アンケート選択 as string) || undefined,
        バッチ開始月: (publish.バッチ開始月 as string) || undefined,
        開始: (publish.開始 as string) || undefined,
        完了: (publish.完了 as string) || undefined,
      })
    }
  }

  // 5. フィルタ済みレコードを論理名に変換・ユーザー情報を結合
  const resolveCode = (category: string, code: string | undefined): string | undefined => {
    if (!code) return undefined
    const all = pleasync.statusAll(category) as Record<string, { value: number }>
    const entry = Object.entries(all).find(([, item]) => String(item.value) === code)
    return entry?.[0]
  }

  const resolveJsonArrayCode = (category: string, jsonStr: string | undefined): string | undefined => {
    if (!jsonStr) return undefined
    try {
      const ids = JSON.parse(jsonStr)
      if (!Array.isArray(ids) || ids.length === 0) return undefined
      return resolveCode(category, String(ids[0]))
    } catch {
      return resolveCode(category, jsonStr)
    }
  }

  let answers: AnswerListItem[] = filteredRecords.map((record) => {
    const 回答者ID = String(record.回答者 || '') || undefined
    const 面談者ID = String(record.面談者 || '') || undefined
    const userInfo = 回答者ID ? userMap.get(回答者ID) : undefined
    const 面談者Info = 面談者ID ? userMap.get(面談者ID) : undefined
    const 掲載設定ID = String(record.掲載設定 || '') || undefined
    const publishInfo = 掲載設定ID ? publishMap.get(掲載設定ID) : undefined
    const アンケート選択 = publishInfo?.アンケート選択
    const アンケートタイトル = アンケート選択 ? surveyTitleMap.get(アンケート選択) : undefined
    const バッチ開始月 = publishInfo?.バッチ開始月
    const 開始 = publishInfo?.開始
    const 完了 = publishInfo?.完了
    const 役職ラベル = resolveCode('役職', userInfo?.役職)
    const 所属本部ラベル = resolveCode('本部', userInfo?.所属本部)
    const 所属部ラベル = resolveJsonArrayCode('部', userInfo?.所属部)
    const 所属課ラベル = resolveJsonArrayCode('課', userInfo?.所属課)
    return {
      回答ID: record.回答ID as number,
      回答状況: record.回答状況 as number | undefined,
      回答者: 回答者ID,
      掲載設定: 掲載設定ID,
      アンケートタイトル,
      バッチ開始月,
      開始,
      完了,
      健康状態: record.健康状態 as number | undefined,
      面談方式: (record.面談方式 as string) || undefined,
      面談候補: (record.面談候補 as string) || undefined,
      回答日: (record.回答日 as string) || undefined,
      面談日: (record.面談日 as string) || undefined,
      評価結果JSON: (record.評価結果JSON as string) || undefined,
      面談メモ: (record.面談メモ as string) || undefined,
      面談内容閲覧者: (record.面談内容閲覧者 as string) || undefined,
      作成日時: record.作成日時 instanceof Date ? record.作成日時.toISOString() : (record.作成日時 as string) || undefined,
      回答者名: userInfo?.名前,
      役職: 役職ラベル,
      所属本部: 所属本部ラベル,
      所属部: 所属部ラベル,
      所属課: 所属課ラベル,
      メールアドレス: userInfo?.メールアドレス,
      面談者: 面談者Info?.名前,
    }
  })

  // 期間フィルター
  if (recentMonths !== undefined && recentMonths > 0) {
    const cutoffDate = new Date()
    cutoffDate.setMonth(cutoffDate.getMonth() - recentMonths)
    const cutoffDateStr = cutoffDate.toISOString().split('T')[0]

    answers = answers.filter((a) => {
      const dateToCompare = a.作成日時 || a.回答日
      if (!dateToCompare) return false
      if (dateToCompare.startsWith('1899')) return true
      return dateToCompare >= cutoffDateStr
    })
  }

  // ページネーション
  const paginatedAnswers = limit !== undefined
    ? answers.slice(offset ?? 0, (offset ?? 0) + limit)
    : answers

  return {
    answers: paginatedAnswers,
    total: answers.length,
  }
}

/**
 * 回答結果詳細取得
 */
export async function getAnswerById(answerId: string): Promise<AnswerResult> {
  const record = await pleasync.getRecord('回答結果', parseInt(answerId, 10), [
    '回答ID', '回答状況', '回答者', '掲載設定', '面談者', '健康状態',
    '面談方式', '面談候補', '回答日', '面談日',
    'サポーター用生成プロンプト', 'サポーター用生成回答',
    'ユーザー用生成プロンプト', 'ユーザー用生成回答',
    'アンケート内容JSON', '評価結果JSON', '面談メモ', '面談内容閲覧者',
    '次回までのアクション', '作成日時', 'コメント',
  ], 'Value')

  const answer: AnswerResult = {
    回答ID: record['回答ID'] as number,
    回答状況: record['回答状況'] as number | undefined,
    回答者: (record['回答者'] as string) || undefined,
    掲載設定: (record['掲載設定'] as string) || undefined,
    面談者: (record['面談者'] as string) || undefined,
    健康状態: record['健康状態'] as number | undefined,
    面談方式: (record['面談方式'] as string) || undefined,
    面談候補: (record['面談候補'] as string) || undefined,
    回答日: (record['回答日'] as string) || undefined,
    面談日: (record['面談日'] as string) || undefined,
    サポーター用生成プロンプト: (record['サポーター用生成プロンプト'] as string) || '',
    サポーター用生成回答: (record['サポーター用生成回答'] as string) || '',
    ユーザー用生成プロンプト: (record['ユーザー用生成プロンプト'] as string) || '',
    ユーザー用生成回答: (record['ユーザー用生成回答'] as string) || '',
    アンケート内容JSON: (record['アンケート内容JSON'] as string) || '',
    評価結果JSON: (record['評価結果JSON'] as string) || '',
    面談メモ: (record['面談メモ'] as string) || '',
    面談内容閲覧者: (record['面談内容閲覧者'] as string) || undefined,
    次回までのアクション: (record['次回までのアクション'] as string) || '',
    作成日時: record['作成日時'] instanceof Date ? (record['作成日時'] as Date).toISOString() : (record['作成日時'] as string) || undefined,
    コメント: (record['コメント'] as string) || '',
  }

  return answer
}

/**
 * 回答詳細取得（ユーザーID指定）
 *
 * フロントエンドの EmployeeDetailResponse に対応
 */
export async function getEmployeeDetail(targetUserId: string): Promise<Record<string, unknown>> {

  // 1. 回答結果・掲載設定・アンケートマスタを並列取得
  const [answerRecords, publishRecords, surveyRecords] = await Promise.all([
    pleasync.findMany('回答結果', [
        '回答ID', '回答状況', '回答者', '掲載設定', '面談者', '健康状態',
        '面談方式', '面談候補', '回答日', '面談日',
        'サポーター用生成プロンプト', 'サポーター用生成回答',
        'ユーザー用生成プロンプト', 'ユーザー用生成回答',
        'アンケート内容JSON', '評価結果JSON', '面談メモ', '面談内容閲覧者',
        '次回までのアクション', '作成日時',
      ], { 回答者: targetUserId }),
    pleasync.findMany('掲載設定', ['掲載ID', 'アンケート選択', 'バッチ開始月']),
    pleasync.findMany('アンケートマスタ', ['アンケートID', 'タイトル']),
  ])

  // 2. 回答レコードから必要なユーザーIDを収集
  const neededUserIds = new Set<string>([targetUserId])
  for (const record of answerRecords) {
    const 面談者ID = String(record.面談者 || '')
    if (面談者ID) neededUserIds.add(面談者ID)
    const 面談候補JSON = String(record.面談候補 || '')
    const supervisorIds = parseSupervisorIds(面談候補JSON)
    for (const sid of supervisorIds) {
      neededUserIds.add(sid)
    }
  }

  // 3. 必要なユーザーのみマスタ取得
  const userRecords = await pleasync.findMany('ユーザーマスタ',
    ['ユーザーID', '名前', 'ユーザーコード', '役職', '所属本部', '所属部', '所属課', 'メールアドレス'],
    null,
    { ユーザーID: Array.from(neededUserIds) },
  )

  const targetUser = userRecords.find((u) => String(u.ユーザーID) === targetUserId)

  // 掲載設定Map
  const publishMap = new Map<string, { アンケート選択?: string; バッチ開始月?: string }>()
  for (const pub of publishRecords) {
    const publishId = String(pub.掲載ID)
    if (publishId) {
      publishMap.set(publishId, {
        アンケート選択: (pub.アンケート選択 as string) || undefined,
        バッチ開始月: (pub.バッチ開始月 as string) || undefined,
      })
    }
  }

  // アンケートマスタMap
  const surveyTitleMap = new Map<string, string>()
  for (const survey of surveyRecords) {
    const surveyId = String(survey.アンケートID)
    const title = survey.タイトル as string
    if (surveyId && title) {
      surveyTitleMap.set(surveyId, title)
    }
  }

  // ユーザーマスタMap
  const userMap = new Map<string, { 名前?: string; 役職?: string }>()
  for (const u of userRecords) {
    userMap.set(String(u.ユーザーID), {
      名前: (u.名前 as string) || undefined,
      役職: (u.役職 as string) || undefined,
    })
  }

  // 回答結果を変換
  const 回答結果 = answerRecords.map((record) => {
    const 掲載設定ID = String(record.掲載設定 || '') || undefined
    const publishInfo = 掲載設定ID ? publishMap.get(掲載設定ID) : undefined
    const バッチ開始月 = publishInfo?.バッチ開始月
    const アンケート選択 = publishInfo?.アンケート選択
    const アンケートタイトル = アンケート選択 ? surveyTitleMap.get(アンケート選択) : undefined

    const 面談候補JSON = String(record.面談候補 || '')
    const supervisorIds = parseSupervisorIds(面談候補JSON)
    const 追加面談候補者 = supervisorIds.length > 0 ? userMap.get(supervisorIds[0]) : undefined

    let 評価結果: Record<string, number> | undefined
    const 評価結果JSONStr = String(record.評価結果JSON || '')
    if (評価結果JSONStr) {
      try {
        評価結果 = JSON.parse(評価結果JSONStr)
      } catch {
        // パース失敗は無視
      }
    }

    return {
      回答ID: record.回答ID as number,
      回答状況: record.回答状況,
      回答者: String(record.回答者 || '') || undefined,
      掲載設定: 掲載設定ID,
      面談者: (() => {
        const rawInterviewer = String(record.面談者 || '') || undefined
        if (!rawInterviewer) return undefined
        const user = userMap.get(rawInterviewer)
        return user?.名前 || rawInterviewer
      })(),
      面談方式: String(record.面談方式 || '') || undefined,
      面談候補: 面談候補JSON || undefined,
      健康状態: record.健康状態,
      回答日: String(record.回答日 || '') || undefined,
      面談日: String(record.面談日 || '') || undefined,
      面談メモ: String(record.面談メモ || ''),
      面談内容閲覧者: String(record.面談内容閲覧者 || '') || undefined,
      次回までのアクション: String(record.次回までのアクション || ''),
      コメント: '',
      開始: バッチ開始月,
      アンケートタイトル,
      評価結果,
      追加面談候補者名: 追加面談候補者?.名前,
      追加面談候補者役職: 追加面談候補者?.役職,
      サポーター用生成プロンプト: String(record.サポーター用生成プロンプト || ''),
      サポーター用生成回答: String(record.サポーター用生成回答 || ''),
      ユーザー用生成プロンプト: String(record.ユーザー用生成プロンプト || ''),
      ユーザー用生成回答: String(record.ユーザー用生成回答 || ''),
      アンケート内容JSON: String(record.アンケート内容JSON || ''),
      評価結果JSON: 評価結果JSONStr,
      作成日時: record.作成日時 instanceof Date ? record.作成日時.toISOString() : (record.作成日時 as string) || undefined,
    }
  })

  return {
    ユーザーID: targetUserId,
    ユーザーコード: (targetUser?.ユーザーコード as string) || '',
    名前: (targetUser?.名前 as string) || '',
    役職: (targetUser?.役職 as string) || '',
    所属本部: (targetUser?.所属本部 as string) || '',
    所属部: (targetUser?.所属部 as string) || '',
    所属課: (targetUser?.所属課 as string) || '',
    メールアドレス: (targetUser?.メールアドレス as string) || '',
    回答結果,
  }
}

/**
 * 回答結果作成
 */
export async function createAnswer(data: {
  回答者: string
  掲載設定: string
  回答状況?: AnswerStatusCode | string
  アンケート内容JSON?: string
  ユーザー用生成プロンプト?: string
  ユーザー用生成回答?: string
  サポーター用生成プロンプト?: string
  サポーター用生成回答?: string
  回答日?: string
}): Promise<{ answerId: number }> {

  const createData: Record<string, unknown> = {
    回答者: data.回答者,
    掲載設定: data.掲載設定,
  }

  if (data.回答状況 !== undefined) {
    const statusValue = typeof data.回答状況 === 'string'
      ? ANSWER_STATUS_LABEL_TO_CODE[data.回答状況] ?? data.回答状況
      : data.回答状況
    createData['回答状況'] = statusValue
  }
  if (data.アンケート内容JSON !== undefined) createData['アンケート内容JSON'] = data.アンケート内容JSON
  if (data.ユーザー用生成プロンプト !== undefined) createData['ユーザー用生成プロンプト'] = data.ユーザー用生成プロンプト
  if (data.ユーザー用生成回答 !== undefined) createData['ユーザー用生成回答'] = data.ユーザー用生成回答
  if (data.サポーター用生成プロンプト !== undefined) createData['サポーター用生成プロンプト'] = data.サポーター用生成プロンプト
  if (data.サポーター用生成回答 !== undefined) createData['サポーター用生成回答'] = data.サポーター用生成回答
  if (data.回答日 !== undefined) createData['回答日'] = data.回答日

  const answerId = await pleasync.create('回答結果', createData)

  if (!answerId) {
    throw new Error('回答結果の作成に失敗しました')
  }

  return { answerId }
}

/**
 * 面談内容閲覧者を計算
 *
 * 面談者自身 + 面談候補の中から面談者より大きい役職Codeを持つユーザーを抽出
 */
export async function calculateInterviewViewers(
  interviewerUserId: string,
  interviewCandidatesJson: string
): Promise<string> {
  const candidateIds = parseSupervisorIds(interviewCandidatesJson)
  const allUserIds = [interviewerUserId, ...candidateIds]

  const userRecords = await pleasync.findMany('ユーザーマスタ',
    ['ユーザーID', '役職'],
    null,
    { ユーザーID: allUserIds },
  )

  const userRoleMap = new Map<string, number>()
  for (const user of userRecords) {
    const roleCode = parseInt(String(user.役職 || '0'), 10)
    userRoleMap.set(String(user.ユーザーID), roleCode)
  }

  const interviewerRoleCode = userRoleMap.get(interviewerUserId) || 0
  const viewers = [interviewerUserId]

  for (const candidateId of candidateIds) {
    const candidateRoleCode = userRoleMap.get(candidateId) || 0
    if (candidateRoleCode > interviewerRoleCode) {
      viewers.push(candidateId)
    }
  }

  return JSON.stringify(viewers)
}

/**
 * 回答結果更新
 */
export async function updateAnswer(
  answerId: string,
  data: {
    回答状況?: AnswerStatusCode
    健康状態?: HealthStatusCode
    面談方式?: string
    面談日?: string
    面談メモ?: string
    次回までのアクション?: string
    評価結果JSON?: string
  },
  interviewerUserId?: string
): Promise<AnswerResult> {

  const updateData: Record<string, unknown> = {}

  if (data.回答状況 !== undefined) updateData['回答状況'] = data.回答状況
  if (data.健康状態 !== undefined) updateData['健康状態'] = data.健康状態
  if (data.面談方式 !== undefined) updateData['面談方式'] = data.面談方式
  if (data.面談日 !== undefined) updateData['面談日'] = data.面談日
  if (data.面談メモ !== undefined) updateData['面談メモ'] = data.面談メモ
  if (data.次回までのアクション !== undefined) updateData['次回までのアクション'] = data.次回までのアクション
  if (data.評価結果JSON !== undefined) updateData['評価結果JSON'] = data.評価結果JSON

  // 面談完了時（回答状況=900）に面談内容閲覧者を自動設定
  if (data.回答状況 === 900 && interviewerUserId) {
    const currentRecord = await getAnswerById(answerId)
    if (currentRecord.面談候補) {
      const viewers = await calculateInterviewViewers(interviewerUserId, currentRecord.面談候補)
      updateData['面談内容閲覧者'] = viewers
      updateData['面談者'] = interviewerUserId
    }
  }

  await pleasync.update('回答結果', parseInt(answerId, 10), updateData)

  return await getAnswerById(answerId)
}
