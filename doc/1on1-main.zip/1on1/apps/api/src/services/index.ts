/**
 * サービス層 一括エクスポート
 *
 * すべてのサービスをここで集約します。
 * Services 型を満たすオブジェクトとしてエクスポートします。
 *
 * 🎯 サービスを追加する場合:
 * 1. libs/domain/types/services.ts にインターフェースを追加
 * 2. このディレクトリに実装ファイルを追加
 * 3. 下の services オブジェクトに追加
 */

import type { Services } from '@1on1/domain/types'

// 各サービス実装を import
import * as authService from './auth'
import * as usersService from './users'
import * as surveysService from './surveys'
import * as answersService from './answers'
import * as dashboardService from './dashboard'
import * as logsService from './logs'
import * as aiService from '../infrastructure/ai_agent'

/**
 * 全サービスを集約したオブジェクト
 *
 * Services 型を満たすことで、型安全性を保証します。
 * 新しいサービスを追加し忘れるとコンパイルエラーになります。
 */
// Note: Pleasync は Record<string, unknown> を返すため、
// Services 型との互換性のために as を使用
export const services = {
  authService,
  usersService,
  surveysService,
  answersService,
  dashboardService,
  aiService,
  logsService,
}

// 個別エクスポート（後方互換性のため）
export {
  authService,
  usersService,
  surveysService,
  answersService,
  dashboardService,
  logsService,
  aiService,
}

// 内部サービス（Context には含めない）
export * as jobsService from './jobs'
export * as jwtService from './jwt'
export * as passwordService from './password'

export * as tokenStore from './token-store'
