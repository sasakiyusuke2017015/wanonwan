/**
 * スケジュールサービス層
 *
 * ビジネスロジック（権限チェック、フィルタ条件構築）のみ
 * データ変換は p() クエリビルダーで動的にカラム名を解決
 */

import { pleasync } from '../infrastructure/pleasync'
import type { CalendarEvent, DayOfWeek } from '@ui-catalog/core/types'
import { toCalendarEvent } from '@1on1/domain/adapters/pleasanter'

// ========================================
// 色 → イベント種別マッピング
// ========================================

const COLOR_TO_EVENT_TYPE: Record<string, string> = {
  '#3b82f6': '会議',
  '#f59e0b': 'タスク',
  '#ec4899': 'リマインダー',
  '#8b5cf6': 'その他',
}

function inferEventType(color: string): string {
  return COLOR_TO_EVENT_TYPE[color] || 'その他'
}

// ========================================
// 曜日変換（数値 → 日本語名）
// ========================================

const DAY_NUMBER_TO_NAME: Record<DayOfWeek, string> = {
  0: '日',
  1: '月',
  2: '火',
  3: '水',
  4: '木',
  5: '金',
  6: '土',
}

// ========================================
// サービス層関数
// ========================================

export interface GetSchedulesParams {
  readonly startDate?: Date
  readonly endDate?: Date
  readonly userId?: string
}

/**
 * スケジュール一覧取得（PostgreSQL 直接クエリ）
 */
export async function getSchedules(params?: GetSchedulesParams): Promise<readonly CalendarEvent[]> {
  const siteId = pleasync.getSiteId('スケジュール')
  const 作成者Col = pleasync.getColumnName('スケジュール', '作成者')
  const 終日Col = pleasync.getColumnName('スケジュール', '終日')
  const 色Col = pleasync.getColumnName('スケジュール', '色')
  const アイコンCol = pleasync.getColumnName('スケジュール', 'アイコン')
  const イベント種別Col = pleasync.getColumnName('スケジュール', 'イベント種別')
  const 繰り返し曜日Col = pleasync.getColumnName('スケジュール', '繰り返し曜日')
  const 繰り返し期間開始Col = pleasync.getColumnName('スケジュール', '繰り返し期間開始')
  const 繰り返し期間終了Col = pleasync.getColumnName('スケジュール', '繰り返し期間終了')

  // WHERE 条件を構築
  const conditions: string[] = [`"SiteId" = $1::bigint`]
  const queryParams: unknown[] = [siteId]

  if (params?.startDate) {
    queryParams.push(params.startDate.toISOString())
    conditions.push(`"StartTime" >= $${queryParams.length}`)
  }

  if (params?.userId) {
    queryParams.push(params.userId)
    conditions.push(`"${作成者Col}" = $${queryParams.length}`)
  }

  const records = await pleasync.raw(
    `SELECT
      "IssueId" as "イベントID",
      "Title" as "タイトル",
      "StartTime" as "開始日時",
      ("CompletionTime" - INTERVAL '1 day') as "終了日時",
      "${終日Col}" as "終日",
      "Body" as "説明",
      "${色Col}" as "色",
      "${アイコンCol}" as "アイコン",
      "${イベント種別Col}" as "イベント種別",
      "${繰り返し曜日Col}" as "繰り返し曜日",
      "${繰り返し期間開始Col}" as "繰り返し期間開始",
      "${繰り返し期間終了Col}" as "繰り返し期間終了",
      "${作成者Col}" as "作成者"
     FROM "Issues"
     WHERE ${conditions.join(' AND ')}`,
    queryParams
  )

  // CalendarEvent に変換（adapter 使用）
  const events = records.map(toCalendarEvent)

  // endDate フィルタ
  if (params?.endDate) {
    return events.filter((e) => e.startTime <= params.endDate!)
  }

  return events
}

/**
 * スケジュール作成
 */
export async function createSchedule(event: Omit<CalendarEvent, 'id'>, userId: string): Promise<CalendarEvent> {
  const siteId = pleasync.getSiteId('スケジュール')

  const payload: Record<string, unknown> = {
    Title: event.title,
    StartTime: event.startTime.toISOString(),
    CompletionTime: event.endTime.toISOString(),
    Body: event.description || '',
    [pleasync.getColumnName('スケジュール', '終日')]: event.allDay || false,
    [pleasync.getColumnName('スケジュール', '色')]: event.color,
    [pleasync.getColumnName('スケジュール', 'アイコン')]: event.icon || 'calendar',
    [pleasync.getColumnName('スケジュール', 'イベント種別')]: inferEventType(event.color),
    [pleasync.getColumnName('スケジュール', '作成者')]: userId,
  }

  // 繰り返し設定
  if (event.repeat && event.repeat.length > 0) {
    const dayNames = event.repeat.map((n) => DAY_NUMBER_TO_NAME[n])
    payload[pleasync.getColumnName('スケジュール', '繰り返し曜日')] = JSON.stringify(dayNames)
    if (event.repeatPeriodStart) {
      payload[pleasync.getColumnName('スケジュール', '繰り返し期間開始')] = event.repeatPeriodStart.toISOString()
    }
    if (event.repeatPeriodEnd) {
      payload[pleasync.getColumnName('スケジュール', '繰り返し期間終了')] = event.repeatPeriodEnd.toISOString()
    }
  }

  const newId = await pleasync.createRecord(siteId, payload)
  if (!newId) {
    throw new Error('スケジュールの作成に失敗しました（ID が取得できません）')
  }

  return {
    ...event,
    id: String(newId),
  }
}

/**
 * スケジュール更新
 */
export async function updateSchedule(event: CalendarEvent, userId: string): Promise<CalendarEvent> {
  const payload: Record<string, unknown> = {
    Title: event.title,
    StartTime: event.startTime.toISOString(),
    CompletionTime: event.endTime.toISOString(),
    Body: event.description || '',
    [pleasync.getColumnName('スケジュール', '終日')]: event.allDay || false,
    [pleasync.getColumnName('スケジュール', '色')]: event.color,
    [pleasync.getColumnName('スケジュール', 'アイコン')]: event.icon || 'calendar',
    [pleasync.getColumnName('スケジュール', 'イベント種別')]: inferEventType(event.color),
    [pleasync.getColumnName('スケジュール', '作成者')]: userId,
  }

  // 繰り返し設定
  if (event.repeat && event.repeat.length > 0) {
    const dayNames = event.repeat.map((n) => DAY_NUMBER_TO_NAME[n])
    payload[pleasync.getColumnName('スケジュール', '繰り返し曜日')] = JSON.stringify(dayNames)
    if (event.repeatPeriodStart) {
      payload[pleasync.getColumnName('スケジュール', '繰り返し期間開始')] = event.repeatPeriodStart.toISOString()
    }
    if (event.repeatPeriodEnd) {
      payload[pleasync.getColumnName('スケジュール', '繰り返し期間終了')] = event.repeatPeriodEnd.toISOString()
    }
  }

  await pleasync.updateRecord(Number(event.id), payload)

  return event
}

/**
 * スケジュール削除
 */
export async function deleteSchedule(eventId: string): Promise<void> {
  await pleasync.delete('スケジュール', Number(eventId))
}
