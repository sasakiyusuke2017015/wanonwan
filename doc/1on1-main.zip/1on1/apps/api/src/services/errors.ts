/**
 * サービス層エラー定義
 *
 * サービス層はHTTPに依存しない。
 * エラーコードでビジネスロジック上の失敗を表現し、
 * ルーター層がHTTPステータスコードにマッピングする。
 */

export type ServiceErrorCode =
  | 'UNAUTHORIZED'
  | 'FORBIDDEN'
  | 'NOT_FOUND'
  | 'BAD_REQUEST'
  | 'RATE_LIMITED'
  | 'INTERNAL_ERROR'

/**
 * サービス層の業務エラー
 *
 * HTTPに依存せず、ビジネスロジック上のエラーを表現する。
 * ルーター層で ServiceError をキャッチし、HTTPレスポンスに変換する。
 */
export class ServiceError extends Error {
  constructor(
    public readonly code: ServiceErrorCode,
    message: string,
    public readonly details?: Record<string, unknown>
  ) {
    super(message)
    this.name = 'ServiceError'
  }
}

/**
 * ServiceErrorCode → HTTPステータスコードのマッピング
 *
 * ルーター層で使用する。
 * ContentfulStatusCode リテラル型を維持するため as const を使用。
 */
export const SERVICE_ERROR_STATUS_MAP = {
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  BAD_REQUEST: 400,
  RATE_LIMITED: 429,
  INTERNAL_ERROR: 500,
} as const satisfies Record<ServiceErrorCode, number>
