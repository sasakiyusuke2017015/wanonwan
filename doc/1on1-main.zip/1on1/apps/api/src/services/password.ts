/**
 * パスワードサービス
 *
 * bcrypt を使用したパスワードのハッシュ化と検証
 */

import bcrypt from 'bcrypt'

/**
 * bcrypt のソルトラウンド数
 *
 * 値が大きいほど安全だが処理時間が増加する。
 * - 10: 開発環境
 * - 12: 本番環境（推奨）
 */
const SALT_ROUNDS = 10

/**
 * bcryptハッシュ形式かどうか判定
 *
 * @param value 検証する文字列
 * @returns bcryptハッシュ形式の場合 true
 */
export function isBcryptHash(value: string): boolean {
  return /^\$2[aby]\$\d+\$/.test(value)
}

/**
 * パスワードをハッシュ化
 *
 * @param password 平文パスワード
 * @returns ハッシュ化されたパスワード
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS)
}

/**
 * パスワードを検証
 *
 * @param password 平文パスワード
 * @param hashedPassword ハッシュ化されたパスワード
 * @returns パスワードが一致する場合 true
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}
