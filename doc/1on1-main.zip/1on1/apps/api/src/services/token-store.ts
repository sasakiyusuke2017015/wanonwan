/**
 * リフレッシュトークンストア
 *
 * リフレッシュトークンの有効/無効状態を管理
 * トークンローテーションとトークン再利用検知をサポート
 */

/**
 * トークンストアエントリ
 */
interface TokenEntry {
  userId: string
  email: string
  issuedAt: number // Unix timestamp
  expiresAt: number // Unix timestamp
  isRevoked: boolean // 無効化フラグ
  previousToken?: string // 前のトークン（ローテーション追跡用）
}

/**
 * メモリベースのトークンストア
 *
 * NOTE: 本番環境では Pleasanter や Redis に移行することを推奨
 */
class RefreshTokenStore {
  private tokens: Map<string, TokenEntry> = new Map()

  /**
   * トークンを保存
   */
  save(token: string, entry: Omit<TokenEntry, 'isRevoked'>): void {
    this.tokens.set(token, {
      ...entry,
      isRevoked: false,
    })

    // 古いトークンのクリーンアップ（有効期限切れ）
    this.cleanup()
  }

  /**
   * トークンを検証
   *
   * @returns トークンエントリ（有効な場合）、null（無効な場合）
   */
  validate(token: string): TokenEntry | null {
    const entry = this.tokens.get(token)

    if (!entry) {
      return null // トークンが存在しない
    }

    if (entry.isRevoked) {
      return null // 無効化されている
    }

    const now = Date.now()
    if (entry.expiresAt < now) {
      return null // 有効期限切れ
    }

    return entry
  }

  /**
   * トークンを無効化
   */
  revoke(token: string): void {
    const entry = this.tokens.get(token)
    if (entry) {
      entry.isRevoked = true
    }
  }

  /**
   * ユーザーの全トークンを無効化（ログアウト時）
   */
  revokeAllByUser(userId: string): void {
    for (const [token, entry] of this.tokens.entries()) {
      if (entry.userId === userId) {
        entry.isRevoked = true
      }
    }
  }

  /**
   * トークンファミリー全体を無効化（再利用検知時）
   *
   * トークンチェーンを遡って、関連する全てのトークンを無効化
   */
  revokeTokenFamily(token: string): void {
    const visited = new Set<string>()
    const toRevoke: string[] = [token]

    while (toRevoke.length > 0) {
      const currentToken = toRevoke.pop()!
      if (visited.has(currentToken)) continue
      visited.add(currentToken)

      const entry = this.tokens.get(currentToken)
      if (entry) {
        entry.isRevoked = true

        // 前のトークンも無効化対象に追加
        if (entry.previousToken) {
          toRevoke.push(entry.previousToken)
        }

        // このトークンから派生したトークンも無効化
        for (const [otherToken, otherEntry] of this.tokens.entries()) {
          if (otherEntry.previousToken === currentToken) {
            toRevoke.push(otherToken)
          }
        }
      }
    }
  }

  /**
   * 有効期限切れトークンのクリーンアップ
   */
  private cleanup(): void {
    const now = Date.now()
    const toDelete: string[] = []

    for (const [token, entry] of this.tokens.entries()) {
      // 有効期限切れで、かつ無効化済みのトークンを削除
      if (entry.expiresAt < now && entry.isRevoked) {
        toDelete.push(token)
      }
    }

    for (const token of toDelete) {
      this.tokens.delete(token)
    }
  }

  /**
   * ストア内のトークン数を取得（デバッグ用）
   */
  getSize(): number {
    return this.tokens.size
  }

  /**
   * ストアをクリア（テスト用）
   */
  clear(): void {
    this.tokens.clear()
  }
}

/**
 * シングルトンインスタンス
 */
export const tokenStore = new RefreshTokenStore()
