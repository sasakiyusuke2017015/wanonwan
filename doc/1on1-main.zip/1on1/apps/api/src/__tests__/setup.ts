/**
 * Vitest テストセットアップファイル
 *
 * すべてのテスト実行前に実行される共通設定
 */

import { beforeAll, afterAll, afterEach } from 'vitest'
import dotenv from 'dotenv'
import path from 'path'

// テスト専用の環境変数設定
// NOTE: NODE_ENV, SITE_CONFIG_MODE, PORT, HOST はテスト環境固有の設定
// それ以外の環境変数（PLEASANTER_*, JWT_SECRET_KEY等）は.envから読み込み、Fail Fastで検証
process.env.NODE_ENV = 'test'
process.env.SITE_CONFIG_MODE = '2026_04'
process.env.PORT = '8000'
process.env.HOST = '0.0.0.0'

// 環境変数の読み込み（プロジェクトルートの.envファイル）
const envPath = path.resolve(__dirname, '../../../../.env')
const result = dotenv.config({ path: envPath })

if (result.error) {
  throw new Error(`Failed to load .env file from ${envPath}: ${result.error.message}`)
}

// Fail Fast: 必須環境変数のチェック
const requiredEnvVars = [
  'PLEASANTER_URL',
  'PLEASANTER_API_KEY',
  'JWT_SECRET_KEY',
]

for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    throw new Error(`Required environment variable ${envVar} is not set in .env`)
  }
}

// グローバルセットアップ
beforeAll(() => {
  console.log('🧪 Test suite started')
})

// グローバルクリーンアップ
afterAll(() => {
  console.log('✅ Test suite completed')
})

// 各テスト後のクリーンアップ
afterEach(() => {
  // 必要に応じてモックのリセットなど
})
