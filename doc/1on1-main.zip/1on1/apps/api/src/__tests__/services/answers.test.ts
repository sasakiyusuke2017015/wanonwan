/**
 * Answers サービスのユニットテスト
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { getAllAnswers } from '../../services/answers'

// pleasync モック
const mockFindMany = vi.fn()

vi.mock('../../infrastructure/pleasync', () => ({
  pleasync: {
    findMany: mockFindMany,
    findOne: vi.fn(),
    getRecord: vi.fn(),
    update: vi.fn(),
    create: vi.fn(),
    delete: vi.fn(),
    raw: vi.fn(),
    rawOne: vi.fn(),
    rawExec: vi.fn(),
    status: vi.fn(),
    statusAll: vi.fn(() => ({})),
    getSiteId: vi.fn(),
    getColumnName: vi.fn(),
    createRecord: vi.fn(),
    updateRecord: vi.fn(),
    deleteRecord: vi.fn(),
    getRecordRaw: vi.fn(),
    testConnection: vi.fn(),
    close: vi.fn(),
  },
}))

describe('Answers Service', () => {
  describe('getAllAnswers', () => {
    const mockAnswerRecords = [
      {
        回答ID: 1,
        回答状況: 900,
        回答者: '12089',
        掲載設定: '123',
        回答日: '2025-06-15',
        面談日: '2025-06-20',
        面談者: '',
        健康状態: 300,
        面談方式: '対面',
        面談候補: '["12090"]',
        評価結果JSON: '{}',
        面談メモ: '',
        面談内容閲覧者: '',
        作成日時: '2025-06-14 10:00:00',
      },
      {
        回答ID: 2,
        回答状況: 200,
        回答者: '12090',
        掲載設定: '124',
        回答日: '2025-07-01',
        面談日: null,
        面談者: '',
        健康状態: null,
        面談方式: null,
        面談候補: '["12089"]',
        評価結果JSON: null,
        面談メモ: null,
        面談内容閲覧者: null,
        作成日時: '2025-06-30 10:00:00',
      },
      {
        回答ID: 3,
        回答状況: 900,
        回答者: '12091',
        掲載設定: '125',
        回答日: '2024-01-15',
        面談日: '2024-01-20',
        面談者: '',
        健康状態: 200,
        面談方式: 'Web',
        面談候補: '["12089"]',
        評価結果JSON: '{}',
        面談メモ: 'テストメモ',
        面談内容閲覧者: '',
        作成日時: '2024-01-14 10:00:00',
      },
    ]

    const mockPublishRecords = [
      { 掲載ID: 123, アンケート選択: '1' },
      { 掲載ID: 124, アンケート選択: '2' },
      { 掲載ID: 125, アンケート選択: '3' },
    ]

    const mockSurveyRecords = [
      { アンケートID: 1, タイトル: 'アンケートA' },
      { アンケートID: 2, タイトル: 'アンケートB' },
      { アンケートID: 3, タイトル: 'アンケートC' },
    ]

    beforeEach(() => {
      vi.clearAllMocks()

      // getAllAnswers は pleasync.findMany を3回並列で呼ぶ
      // 回答結果 → 掲載設定 → アンケートマスタ
      mockFindMany
        .mockResolvedValueOnce(mockAnswerRecords)
        .mockResolvedValueOnce(mockPublishRecords)
        .mockResolvedValueOnce(mockSurveyRecords)
    })

    it('全件取得が正常に動作すること', async () => {
      const result = await getAllAnswers()

      expect(result.answers.length).toBe(3)
      expect(result.total).toBe(3)
      expect(result.answers[0].回答ID).toBe(1)
      expect(result.answers[0].回答状況).toBe(900)
    })

    it('recent_monthsフィルターが動作すること', async () => {
      const result = await getAllAnswers(50, 0, 6)

      expect(result.answers.length).toBe(2)
      expect(result.answers.every((a) => a.回答日 && a.回答日 >= '2025-')).toBe(true)
    })

    it('ページネーションが動作すること', async () => {
      const result = await getAllAnswers(2, 1)

      expect(result.answers.length).toBe(2)
      expect(result.total).toBe(3)
      expect(result.answers[0].回答ID).toBe(2)
    })

    it('回答日がnullの場合はrecent_monthsフィルターから除外されること', async () => {
      const mockRecordsWithNull = [
        ...mockAnswerRecords,
        {
          回答ID: 4,
          回答状況: 900,
          回答者: '12092',
          掲載設定: '126',
          回答日: null,
          面談日: null,
          面談者: '',
          健康状態: null,
          面談方式: null,
          面談候補: '',
          評価結果JSON: null,
          面談メモ: null,
          面談内容閲覧者: null,
          作成日時: '2025-12-15 10:00:00',
        },
      ]

      mockFindMany
        .mockResolvedValueOnce(mockRecordsWithNull)
        .mockResolvedValueOnce(mockPublishRecords)
        .mockResolvedValueOnce(mockSurveyRecords)

      const result = await getAllAnswers(50, 0, 6)
      expect(result.answers.length).toBe(2)
    })
  })
})
