/**
 * Users サービスのユニットテスト
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { changePassword } from '../../services/users'
import { hashPassword } from '../../services/password'
import { HTTPException } from 'hono/http-exception'

// pleasync モック
const mockGetRecord = vi.fn()
const mockUpdate = vi.fn()

vi.mock('../../infrastructure/pleasync', () => ({
  pleasync: {
    findMany: vi.fn(),
    findOne: vi.fn(),
    getRecord: mockGetRecord,
    update: mockUpdate,
    create: vi.fn(),
    delete: vi.fn(),
    raw: vi.fn(),
    rawOne: vi.fn(),
    rawExec: vi.fn(),
    status: vi.fn(),
    statusAll: vi.fn(),
    getSiteId: vi.fn(),
    getColumnName: vi.fn(),
    createRecord: vi.fn(),
    updateRecord: vi.fn(),
    deleteRecord: vi.fn(),
    getRecordRaw: vi.fn(),
    testConnection: vi.fn(),
    close: vi.fn(),
  },
}))

describe('Users Service', () => {
  describe('changePassword', () => {
    const userId = '12089'
    const currentPassword = 'currentPassword123'
    const newPassword = 'newPassword456'
    const confirmPassword = 'newPassword456'

    beforeEach(() => {
      vi.clearAllMocks()
    })

    it('初期パスワード（平文）から変更でき、bcryptハッシュで保存されること', async () => {
      mockGetRecord.mockResolvedValue({
        ユーザーID: '12089',
        初期パスワード: currentPassword,
        変更済パスワード: '',
      })
      mockUpdate.mockResolvedValue(undefined)

      const result = await changePassword(userId, currentPassword, newPassword, confirmPassword)

      expect(result.success).toBe(true)
      expect(result.message).toBe('パスワードを変更しました')
      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, {
        変更済パスワード: expect.stringMatching(/^\$2[aby]\$\d+\$/),
      })
    })

    it('変更済パスワード（bcrypt）から再変更できること', async () => {
      const hashedCurrentPassword = await hashPassword(currentPassword)

      mockGetRecord.mockResolvedValue({
        ユーザーID: '12089',
        初期パスワード: '1',
        変更済パスワード: hashedCurrentPassword,
      })
      mockUpdate.mockResolvedValue(undefined)

      const result = await changePassword(userId, currentPassword, newPassword, confirmPassword)

      expect(result.success).toBe(true)
      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, {
        変更済パスワード: expect.stringMatching(/^\$2[aby]\$\d+\$/),
      })
    })

    it('新しいパスワードと確認パスワードが不一致の場合はエラーを投げること', async () => {
      await expect(
        changePassword(userId, currentPassword, newPassword, 'differentPassword')
      ).rejects.toThrow(HTTPException)
    })

    it('ユーザーが見つからない場合はエラーを投げること', async () => {
      mockGetRecord.mockResolvedValue({})

      await expect(
        changePassword(userId, currentPassword, newPassword, confirmPassword)
      ).rejects.toThrow(HTTPException)
    })

    it('パスワードが設定されていない場合はエラーを投げること', async () => {
      mockGetRecord.mockResolvedValue({
        ユーザーID: '12089',
        初期パスワード: '',
        変更済パスワード: '',
      })

      await expect(
        changePassword(userId, currentPassword, newPassword, confirmPassword)
      ).rejects.toThrow(HTTPException)
    })

    it('現在のパスワードが正しくない場合はエラーを投げること', async () => {
      mockGetRecord.mockResolvedValue({
        ユーザーID: '12089',
        初期パスワード: 'correctPassword',
        変更済パスワード: '',
      })

      await expect(
        changePassword(userId, 'wrongPassword', newPassword, confirmPassword)
      ).rejects.toThrow(HTTPException)
    })

    it('変更済パスワード（bcrypt）で現在のパスワードが正しくない場合はエラーを投げること', async () => {
      const hashedCurrentPassword = await hashPassword('correctPassword')

      mockGetRecord.mockResolvedValue({
        ユーザーID: '12089',
        初期パスワード: '1',
        変更済パスワード: hashedCurrentPassword,
      })

      await expect(
        changePassword(userId, 'wrongPassword', newPassword, confirmPassword)
      ).rejects.toThrow(HTTPException)
    })
  })
})
