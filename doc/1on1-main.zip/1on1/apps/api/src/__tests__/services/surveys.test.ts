/**
 * サーベイサービステスト
 *
 * saveSurvey, submitAnswer, getAllSurveys 関数のユニットテスト
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { saveSurvey, getAllSurveys } from '../../services/surveys'
import * as answersService from '../../services/answers'

// answers サービスをモック化
vi.mock('../../services/answers', () => ({
  createAnswer: vi.fn(),
}))

// pleasync モック
const mockFindMany = vi.fn()
const mockRaw = vi.fn()

vi.mock('../../infrastructure/pleasync', () => ({
  pleasync: {
    findMany: mockFindMany,
    findOne: vi.fn(),
    getRecord: vi.fn(),
    update: vi.fn(),
    create: vi.fn(),
    delete: vi.fn(),
    raw: mockRaw,
    rawOne: vi.fn(),
    rawExec: vi.fn(),
    status: vi.fn((cat: string, label: string) => {
      const map: Record<string, Record<string, { value: number }>> = {
        回答状況: { アンケート未回答: { value: 100 }, アンケート回答済: { value: 200 }, 完了: { value: 900 } },
        健康状態: { 未判定: { value: 0 }, 良好: { value: 100 } },
      }
      return map[cat]?.[label] ?? { value: 0 }
    }),
    statusAll: vi.fn(() => ({})),
    getSiteId: vi.fn(() => 1),
    getColumnName: vi.fn((_site: string, label: string) => label),
    createRecord: vi.fn(),
    updateRecord: vi.fn(),
    deleteRecord: vi.fn(),
    getRecordRaw: vi.fn(),
    testConnection: vi.fn(),
    close: vi.fn(),
  },
}))

describe('Surveys Service', () => {
  const testSurveyId = '123'
  const testUserId = 12089
  const testAnswers = [
    { question_id: 'q1', question: 'テスト質問1', answer: 'テスト回答1' },
    { question_id: 'q2', question: 'テスト質問2', answer: 'テスト回答2' },
  ]
  const testAIGenerated = {
    userPrompt: 'ユーザープロンプト',
    userResponse: 'ユーザー回答',
    supporterPrompt: 'サポータープロンプト',
    supporterResponse: 'サポーター回答',
  }

  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('saveSurvey', () => {
    it('途中保存が正常に動作すること', async () => {
      const mockCreateAnswer = vi.mocked(answersService.createAnswer)
      mockCreateAnswer.mockResolvedValue({ answerId: 456 })

      const result = await saveSurvey(testSurveyId, testAnswers, testAIGenerated, testUserId)

      expect(result).toEqual({
        success: true,
        message: 'アンケートを途中保存しました',
        answerId: 456,
      })

      expect(mockCreateAnswer).toHaveBeenCalledOnce()
      expect(mockCreateAnswer).toHaveBeenCalledWith(
        expect.objectContaining({
          回答者: testUserId.toString(),
          掲載設定: testSurveyId,
          回答状況: 'アンケート未回答',
          アンケート内容JSON: JSON.stringify(testAnswers),
          ユーザー用生成プロンプト: testAIGenerated.userPrompt,
          ユーザー用生成回答: testAIGenerated.userResponse,
          サポーター用生成プロンプト: testAIGenerated.supporterPrompt,
          サポーター用生成回答: testAIGenerated.supporterResponse,
        })
      )

      const callArgs = mockCreateAnswer.mock.calls[0][0]
      expect(callArgs.回答日).toBeDefined()
    })

    it('AI生成データなしで途中保存できること', async () => {
      const mockCreateAnswer = vi.mocked(answersService.createAnswer)
      mockCreateAnswer.mockResolvedValue({ answerId: 789 })

      const result = await saveSurvey(testSurveyId, testAnswers, undefined, testUserId)

      expect(result).toEqual({
        success: true,
        message: 'アンケートを途中保存しました',
        answerId: 789,
      })
    })

    it('ユーザーIDが未指定の場合はエラーをスローすること', async () => {
      await expect(
        saveSurvey(testSurveyId, testAnswers, undefined, undefined)
      ).rejects.toThrow('ユーザーIDが指定されていません')
    })

    it('createAnswerがエラーを返した場合は適切にエラーをスローすること', async () => {
      const mockCreateAnswer = vi.mocked(answersService.createAnswer)
      mockCreateAnswer.mockRejectedValue(new Error('Pleasanter API error'))

      await expect(
        saveSurvey(testSurveyId, testAnswers, undefined, testUserId)
      ).rejects.toThrow('アンケートの保存に失敗しました')
    })
  })

  describe('getAllSurveys', () => {
    const mockSurveyMasterRecords = [
      { アンケートID: 1, タイトル: 'アンケートA' },
      { アンケートID: 2, タイトル: 'アンケートB' },
      { アンケートID: 3, タイトル: 'アンケートC' },
    ]

    const mockPublishRecords = [
      { 掲載ID: 1, 掲載状況: 900, 開始: '2025-11-01', 完了: '2025-11-30', 回答率: 80, アンケート選択: '1', 掲載内容: '' },
      { 掲載ID: 2, 掲載状況: 100, 開始: '2025-12-01', 完了: '2025-12-31', 回答率: 60, アンケート選択: '2', 掲載内容: '' },
      { 掲載ID: 3, 掲載状況: 900, 開始: '2024-06-01', 完了: '2024-06-30', 回答率: 90, アンケート選択: '3', 掲載内容: '' },
    ]

    const mockAnswerRecords: Record<string, unknown>[] = []

    beforeEach(() => {
      // getAllSurveys:
      // 1. pleasync.findMany('アンケートマスタ', ...) → mockSurveyMasterRecords
      // 2. pleasync.raw(...) → mockPublishRecords (掲載設定)
      // 3. pleasync.findMany('回答結果', ...) → mockAnswerRecords
      mockFindMany
        .mockResolvedValueOnce(mockSurveyMasterRecords)
        .mockResolvedValueOnce(mockAnswerRecords)

      mockRaw.mockResolvedValue(mockPublishRecords)
    })

    it('全件取得が正常に動作すること', async () => {
      const result = await getAllSurveys()

      expect(result.total).toBe(3)
      expect(result.data[0].掲載ID).toBe(1)
    })

    it('期間フィルター（recent_months）が動作すること', async () => {
      const result = await getAllSurveys(50, 0, undefined, undefined, 6)

      expect(result.data.length).toBe(2)
      expect(result.data.every((s) => s.開始 && s.開始 >= '2025-')).toBe(true)
    })

    it('ソート（order_by）が動作すること - 昇順', async () => {
      const result = await getAllSurveys(50, 0, undefined, undefined, undefined, '{"回答率":"asc"}')

      expect(result.data[0].回答率).toBe(60)
      expect(result.data[1].回答率).toBe(80)
      expect(result.data[2].回答率).toBe(90)
    })

    it('ソート（order_by）が動作すること - 降順', async () => {
      const result = await getAllSurveys(50, 0, undefined, undefined, undefined, '{"回答率":"desc"}')

      expect(result.data[0].回答率).toBe(90)
      expect(result.data[1].回答率).toBe(80)
      expect(result.data[2].回答率).toBe(60)
    })

    it('ページネーションが動作すること', async () => {
      const result = await getAllSurveys(2, 1)

      expect(result.data.length).toBe(2)
      expect(result.total).toBe(3)
    })
  })
})
