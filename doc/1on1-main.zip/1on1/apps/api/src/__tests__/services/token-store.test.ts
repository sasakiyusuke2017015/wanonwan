/**
 * トークンストアサービステスト
 *
 * リフレッシュトークンの保存、検証、無効化のテスト
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { tokenStore } from '../../services/token-store'

describe('Token Store Service', () => {
  const testUserId = '12089'
  const testEmail = 'test@example.com'
  const testToken = 'test-refresh-token-123'

  // テスト前にストアをクリア
  beforeEach(() => {
    tokenStore.clear()
  })

  describe('save', () => {
    it('should save a token successfully', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000 // 7 days

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      expect(tokenStore.getSize()).toBe(1)
    })

    it('should save token with default isRevoked=false', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).not.toBeNull()
      expect(entry!.isRevoked).toBe(false)
    })

    it('should save token with previousToken', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000
      const previousToken = 'previous-token-456'

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
        previousToken,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).not.toBeNull()
      expect(entry!.previousToken).toBe(previousToken)
    })

    it('should overwrite existing token', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      // 最初の保存
      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      // 同じトークンで再保存
      tokenStore.save(testToken, {
        userId: 'different-user',
        email: 'different@example.com',
        issuedAt: now,
        expiresAt,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).not.toBeNull()
      expect(entry!.userId).toBe('different-user')
      expect(tokenStore.getSize()).toBe(1) // サイズは変わらない
    })
  })

  describe('validate', () => {
    it('should validate a valid token', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).not.toBeNull()
      expect(entry!.userId).toBe(testUserId)
      expect(entry!.email).toBe(testEmail)
      expect(entry!.isRevoked).toBe(false)
    })

    it('should return null for non-existent token', () => {
      const entry = tokenStore.validate('non-existent-token')
      expect(entry).toBeNull()
    })

    it('should return null for revoked token', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.revoke(testToken)

      const entry = tokenStore.validate(testToken)
      expect(entry).toBeNull()
    })

    it('should return null for expired token', () => {
      const now = Date.now()
      const expiresAt = now - 1000 // 1秒前に期限切れ

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now - 2000,
        expiresAt,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).toBeNull()
    })

    it('should validate token just before expiration', () => {
      const now = Date.now()
      const expiresAt = now + 1000 // 1秒後に期限切れ

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      const entry = tokenStore.validate(testToken)
      expect(entry).not.toBeNull()
    })
  })

  describe('revoke', () => {
    it('should revoke a token', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.revoke(testToken)

      const entry = tokenStore.validate(testToken)
      expect(entry).toBeNull()
    })

    it('should not throw error when revoking non-existent token', () => {
      expect(() => tokenStore.revoke('non-existent-token')).not.toThrow()
    })

    it('should keep token in store after revocation', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save(testToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      const sizeBefore = tokenStore.getSize()
      tokenStore.revoke(testToken)
      const sizeAfter = tokenStore.getSize()

      expect(sizeAfter).toBe(sizeBefore) // サイズは変わらない
    })
  })

  describe('revokeAllByUser', () => {
    it('should revoke all tokens for a user', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      const token1 = 'token-1'
      const token2 = 'token-2'
      const token3 = 'token-3'

      // 同じユーザーのトークン2つ
      tokenStore.save(token1, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.save(token2, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      // 別のユーザーのトークン
      tokenStore.save(token3, {
        userId: 'different-user',
        email: 'different@example.com',
        issuedAt: now,
        expiresAt,
      })

      tokenStore.revokeAllByUser(testUserId)

      // testUserId のトークンは無効
      expect(tokenStore.validate(token1)).toBeNull()
      expect(tokenStore.validate(token2)).toBeNull()

      // 別ユーザーのトークンは有効
      expect(tokenStore.validate(token3)).not.toBeNull()
    })

    it('should not throw error for non-existent user', () => {
      expect(() => tokenStore.revokeAllByUser('non-existent-user')).not.toThrow()
    })
  })

  describe('revokeTokenFamily', () => {
    it('should revoke token family (chain)', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      const token1 = 'token-1' // 最初のトークン
      const token2 = 'token-2' // token1 から派生
      const token3 = 'token-3' // token2 から派生

      tokenStore.save(token1, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.save(token2, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
        previousToken: token1,
      })

      tokenStore.save(token3, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
        previousToken: token2,
      })

      // token2 を無効化すると、ファミリー全体が無効化される
      tokenStore.revokeTokenFamily(token2)

      expect(tokenStore.validate(token1)).toBeNull()
      expect(tokenStore.validate(token2)).toBeNull()
      expect(tokenStore.validate(token3)).toBeNull()
    })

    it('should revoke only related tokens in family', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      const token1 = 'token-1'
      const token2 = 'token-2'
      const token3 = 'token-3' // 無関係なトークン

      tokenStore.save(token1, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.save(token2, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
        previousToken: token1,
      })

      // 無関係なトークン
      tokenStore.save(token3, {
        userId: 'different-user',
        email: 'different@example.com',
        issuedAt: now,
        expiresAt,
      })

      tokenStore.revokeTokenFamily(token2)

      // ファミリー内のトークンは無効
      expect(tokenStore.validate(token1)).toBeNull()
      expect(tokenStore.validate(token2)).toBeNull()

      // 無関係なトークンは有効
      expect(tokenStore.validate(token3)).not.toBeNull()
    })

    it('should not throw error for non-existent token', () => {
      expect(() => tokenStore.revokeTokenFamily('non-existent-token')).not.toThrow()
    })
  })

  describe('cleanup', () => {
    it('should clean up expired and revoked tokens', () => {
      const now = Date.now()
      const expiredTime = now - 1000 // 1秒前に期限切れ
      const futureTime = now + 7 * 24 * 60 * 60 * 1000 // 7日後

      // cleanup のテストは複雑なので、シンプルにする
      // 期限切れ + 無効化済みのトークンが削除されることを確認

      const expiredRevokedToken = 'expired-revoked'
      const expiredValidToken = 'expired-valid'
      const validRevokedToken = 'valid-revoked'
      const validToken = 'valid'

      // 期限切れ + 無効化済み（削除される）
      tokenStore.save(expiredRevokedToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now - 2000,
        expiresAt: expiredTime,
      })
      tokenStore.revoke(expiredRevokedToken)

      // 期限切れだが有効（削除されない）
      tokenStore.save(expiredValidToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now - 2000,
        expiresAt: expiredTime,
      })

      // 有効期限内だが無効化済み（削除されない）
      tokenStore.save(validRevokedToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt: futureTime,
      })
      tokenStore.revoke(validRevokedToken)

      // 有効
      tokenStore.save(validToken, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt: futureTime,
      })

      // cleanup は save() 時に自動実行される
      // すでに上記の save() で cleanup が実行されているはず
      const currentSize = tokenStore.getSize()

      // 期限切れ + 無効化済みのトークンは削除されているはず
      // 残るのは: expiredValidToken, validRevokedToken, validToken = 3つ
      expect(currentSize).toBe(3)
    })
  })

  describe('getSize and clear', () => {
    it('should return correct store size', () => {
      expect(tokenStore.getSize()).toBe(0)

      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save('token-1', {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      expect(tokenStore.getSize()).toBe(1)

      tokenStore.save('token-2', {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      expect(tokenStore.getSize()).toBe(2)
    })

    it('should clear all tokens', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      tokenStore.save('token-1', {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      tokenStore.save('token-2', {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      expect(tokenStore.getSize()).toBe(2)

      tokenStore.clear()

      expect(tokenStore.getSize()).toBe(0)
    })
  })

  describe('Integration: Token Rotation Flow', () => {
    it('should handle token rotation correctly', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      const token1 = 'refresh-token-1'
      const token2 = 'refresh-token-2'
      const token3 = 'refresh-token-3'

      // 最初のトークン発行
      tokenStore.save(token1, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      expect(tokenStore.validate(token1)).not.toBeNull()

      // トークンローテーション: token1 を使って token2 を発行
      tokenStore.save(token2, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now + 1000,
        expiresAt: expiresAt + 1000,
        previousToken: token1,
      })
      tokenStore.revoke(token1) // 古いトークンを無効化

      expect(tokenStore.validate(token1)).toBeNull()
      expect(tokenStore.validate(token2)).not.toBeNull()

      // さらにローテーション: token2 を使って token3 を発行
      tokenStore.save(token3, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now + 2000,
        expiresAt: expiresAt + 2000,
        previousToken: token2,
      })
      tokenStore.revoke(token2) // 古いトークンを無効化

      expect(tokenStore.validate(token2)).toBeNull()
      expect(tokenStore.validate(token3)).not.toBeNull()
    })

    it('should detect token reuse attack', () => {
      const now = Date.now()
      const expiresAt = now + 7 * 24 * 60 * 60 * 1000

      const token1 = 'refresh-token-1'
      const token2 = 'refresh-token-2'

      // 最初のトークン発行
      tokenStore.save(token1, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now,
        expiresAt,
      })

      // トークンローテーション
      tokenStore.save(token2, {
        userId: testUserId,
        email: testEmail,
        issuedAt: now + 1000,
        expiresAt: expiresAt + 1000,
        previousToken: token1,
      })
      tokenStore.revoke(token1)

      // 攻撃者が古い token1 を再利用しようとした場合
      // validate は null を返すべき（既に無効化されている）
      expect(tokenStore.validate(token1)).toBeNull()

      // この時点でトークンファミリー全体を無効化すべき
      tokenStore.revokeTokenFamily(token1)

      // すべてのトークンが無効化される
      expect(tokenStore.validate(token1)).toBeNull()
      expect(tokenStore.validate(token2)).toBeNull()
    })
  })
})
