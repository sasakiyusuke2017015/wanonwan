/**
 * パスワードサービステスト
 *
 * bcrypt を使用したパスワードのハッシュ化と検証のテスト
 */

import { describe, it, expect } from 'vitest'
import { hashPassword, verifyPassword } from '../../services/password'

describe('Password Service', () => {
  const testPassword = 'SecurePassword123!'
  const wrongPassword = 'WrongPassword456!'

  describe('hashPassword', () => {
    it('should hash a password successfully', async () => {
      const hash = await hashPassword(testPassword)

      expect(hash).toBeDefined()
      expect(typeof hash).toBe('string')
      expect(hash).not.toBe(testPassword) // ハッシュは元のパスワードと異なる
      expect(hash.length).toBeGreaterThan(0)
    })

    it('should generate different hashes for the same password', async () => {
      const hash1 = await hashPassword(testPassword)
      const hash2 = await hashPassword(testPassword)

      // bcrypt はソルトを使うため、同じパスワードでも毎回異なるハッシュが生成される
      expect(hash1).not.toBe(hash2)
    })

    it('should generate bcrypt format hash', async () => {
      const hash = await hashPassword(testPassword)

      // bcrypt ハッシュは "$2b$" または "$2a$" で始まる
      expect(hash).toMatch(/^\$2[ab]\$/)
    })

    it('should handle empty password', async () => {
      const hash = await hashPassword('')

      expect(hash).toBeDefined()
      expect(typeof hash).toBe('string')
      expect(hash.length).toBeGreaterThan(0)
    })

    it('should handle long password', async () => {
      const longPassword = 'a'.repeat(100)
      const hash = await hashPassword(longPassword)

      expect(hash).toBeDefined()
      expect(typeof hash).toBe('string')
    })

    it('should handle special characters in password', async () => {
      const specialPassword = '!@#$%^&*()_+-=[]{}|;:,.<>?'
      const hash = await hashPassword(specialPassword)

      expect(hash).toBeDefined()
      expect(typeof hash).toBe('string')
    })
  })

  describe('verifyPassword', () => {
    it('should verify correct password successfully', async () => {
      const hash = await hashPassword(testPassword)
      const isValid = await verifyPassword(testPassword, hash)

      expect(isValid).toBe(true)
    })

    it('should reject incorrect password', async () => {
      const hash = await hashPassword(testPassword)
      const isValid = await verifyPassword(wrongPassword, hash)

      expect(isValid).toBe(false)
    })

    it('should reject empty password when hash is not empty', async () => {
      const hash = await hashPassword(testPassword)
      const isValid = await verifyPassword('', hash)

      expect(isValid).toBe(false)
    })

    it('should verify empty password with correct hash', async () => {
      const hash = await hashPassword('')
      const isValid = await verifyPassword('', hash)

      expect(isValid).toBe(true)
    })

    it('should reject password with invalid hash format', async () => {
      const invalidHash = 'invalid-hash-format'
      const isValid = await verifyPassword(testPassword, invalidHash)

      expect(isValid).toBe(false)
    })

    it('should be case sensitive', async () => {
      const hash = await hashPassword('Password123')
      const isValid = await verifyPassword('password123', hash)

      expect(isValid).toBe(false)
    })

    it('should reject password with extra characters', async () => {
      const hash = await hashPassword(testPassword)
      const isValid = await verifyPassword(testPassword + 'extra', hash)

      expect(isValid).toBe(false)
    })

    it('should reject password with missing characters', async () => {
      const hash = await hashPassword(testPassword)
      const isValid = await verifyPassword(testPassword.slice(0, -1), hash)

      expect(isValid).toBe(false)
    })
  })

  describe('Integration: Hash and Verify', () => {
    it('should hash and verify password in sequence', async () => {
      // ハッシュ化
      const hash = await hashPassword(testPassword)
      expect(hash).toBeDefined()

      // 正しいパスワードで検証
      const isValidCorrect = await verifyPassword(testPassword, hash)
      expect(isValidCorrect).toBe(true)

      // 間違ったパスワードで検証
      const isValidWrong = await verifyPassword(wrongPassword, hash)
      expect(isValidWrong).toBe(false)
    })

    it('should work with multiple passwords', async () => {
      const passwords = ['password1', 'password2', 'password3']
      const hashes = await Promise.all(passwords.map((p) => hashPassword(p)))

      // すべてのハッシュが異なることを確認
      expect(new Set(hashes).size).toBe(passwords.length)

      // 各パスワードが正しく検証されることを確認
      for (let i = 0; i < passwords.length; i++) {
        const isValid = await verifyPassword(passwords[i], hashes[i])
        expect(isValid).toBe(true)
      }

      // 間違ったパスワードで検証すると失敗することを確認
      for (let i = 0; i < passwords.length; i++) {
        const wrongIndex = (i + 1) % passwords.length
        const isValid = await verifyPassword(passwords[wrongIndex], hashes[i])
        expect(isValid).toBe(false)
      }
    })
  })
})
