import { describe, it, expect, vi, beforeEach } from 'vitest'
import { generateAccessToken, generateRefreshToken, verifyToken } from '../../services/jwt'

describe('JWT Service', () => {
  const testUserId = '12089'
  const testEmail = 'test@example.com'
  const testRole = '550'

  describe('generateAccessToken', () => {
    it('should generate a valid access token', () => {
      const token = generateAccessToken(testUserId, testEmail, testRole)

      expect(token).toBeDefined()
      expect(typeof token).toBe('string')
      expect(token.split('.')).toHaveLength(3) // JWT format: header.payload.signature
    })

    it('should include user data in token payload', () => {
      const token = generateAccessToken(testUserId, testEmail, testRole)
      const payload = verifyToken(token, 'access')

      expect(payload).toBeDefined()
      expect(payload.sub).toBe(testUserId)
      expect(payload.email).toBe(testEmail)
      expect(payload.role).toBe(testRole)
      expect(payload.type).toBe('access')
    })

    it('should set correct expiration time (30 minutes)', () => {
      const token = generateAccessToken(testUserId, testEmail, testRole)
      const payload = verifyToken(token, 'access')

      expect(payload.exp).toBeDefined()
      expect(payload.iat).toBeDefined()

      // Access token should expire in 30 minutes (1800 seconds)
      const expectedExp = payload.iat! + 1800
      expect(payload.exp).toBe(expectedExp)
    })
  })

  describe('generateRefreshToken', () => {
    it('should generate a valid refresh token', () => {
      const token = generateRefreshToken(testUserId, testEmail)

      expect(token).toBeDefined()
      expect(typeof token).toBe('string')
      expect(token.split('.')).toHaveLength(3)
    })

    it('should include minimal user data in token payload', () => {
      const token = generateRefreshToken(testUserId, testEmail)
      const payload = verifyToken(token, 'refresh')

      expect(payload).toBeDefined()
      expect(payload.sub).toBe(testUserId)
      expect(payload.email).toBe(testEmail)
      expect(payload.type).toBe('refresh')

      // Refresh token should NOT include role
      expect(payload.role).toBeUndefined()
    })

    it('should set correct expiration time (7 days)', () => {
      const token = generateRefreshToken(testUserId, testEmail)
      const payload = verifyToken(token, 'refresh')

      expect(payload.exp).toBeDefined()
      expect(payload.iat).toBeDefined()

      // Refresh token should expire in 7 days (604800 seconds)
      const expectedExp = payload.iat! + 604800
      expect(payload.exp).toBe(expectedExp)
    })
  })

  describe('verifyToken', () => {
    it('should verify and decode a valid token', () => {
      const token = generateAccessToken(testUserId, testEmail, testRole)
      const payload = verifyToken(token, 'access')

      expect(payload).toBeDefined()
      expect(payload.sub).toBe(testUserId)
    })

    it('should throw error for invalid token', () => {
      const invalidToken = 'invalid.token.here'

      expect(() => verifyToken(invalidToken, 'access')).toThrow()
    })

    it('should throw error for wrong token type', () => {
      const accessToken = generateAccessToken(testUserId, testEmail, testRole)

      // Expecting refresh token but got access token
      expect(() => verifyToken(accessToken, 'refresh')).toThrow('Invalid token type')
    })

    it('should throw error for tampered token', () => {
      const token = generateAccessToken(testUserId, testEmail, testRole)
      const parts = token.split('.')

      // Tamper with the payload
      const tamperedToken = `${parts[0]}.${parts[1]}tampered.${parts[2]}`

      expect(() => verifyToken(tamperedToken, 'access')).toThrow()
    })
  })

})
