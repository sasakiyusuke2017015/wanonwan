/**
 * 認証サービステスト
 *
 * ログイン、トークンリフレッシュのテスト
 * ログイン試行回数はPleasanterで永続管理
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { HTTPException } from 'hono/http-exception'
import { login, refreshAccessToken } from '../../services/auth'
import { hashPassword } from '../../services/password'
import { tokenStore } from '../../services/token-store'

// pleasync モック
const mockFindMany = vi.fn()
const mockUpdate = vi.fn()

vi.mock('../../infrastructure/pleasync', () => ({
  pleasync: {
    findMany: mockFindMany,
    findOne: vi.fn(),
    getRecord: vi.fn(),
    update: mockUpdate,
    create: vi.fn(),
    delete: vi.fn(),
    raw: vi.fn(),
    rawOne: vi.fn(),
    rawExec: vi.fn(),
    status: vi.fn(),
    statusAll: vi.fn(),
    getSiteId: vi.fn(),
    getColumnName: vi.fn(),
    createRecord: vi.fn(),
    updateRecord: vi.fn(),
    deleteRecord: vi.fn(),
    getRecordRaw: vi.fn(),
    testConnection: vi.fn(),
    close: vi.fn(),
  },
}))

describe('Auth Service', () => {
  const testEmail = 'test@example.com'
  const testPassword = 'SecurePassword123!'
  const testUser = {
    ユーザーID: 12089,
    ResultId: 12089,
    メールアドレス: testEmail,
    初期パスワード: '',
    変更済パスワード: '',
    名前: 'テストユーザー',
    ユーザーコード: 'U001',
    役職: '550',
    所属本部: '本部A',
    所属部: '部B',
    所属課: '課C',
    アカウントロック: false,
    ログイン連続失敗回数: 0,
    最終ログイン日時: '',
  }

  beforeEach(() => {
    tokenStore.clear()
    vi.clearAllMocks()
  })

  describe('login', () => {
    it('変更済パスワード（bcryptハッシュ）でログインできること', async () => {
      const hashedPassword = await hashPassword(testPassword)

      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword },
      ])

      const result = await login(testEmail, testPassword)

      expect(result).toBeDefined()
      expect(result.access_token).toBeDefined()
      expect(result.refresh_token).toBeDefined()
      expect(result.token_type).toBe('Bearer')
      expect(result.requirePasswordChange).toBe(false)
      expect(result.user.email).toBe(testEmail)

      // ログイン成功: update が呼ばれる（失敗回数リセット + 最終ログイン日時）
      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, expect.objectContaining({
        ログイン連続失敗回数: 0,
      }))
    })

    it('存在しないユーザーでエラーを投げること', async () => {
      mockFindMany.mockResolvedValue([])

      await expect(login(testEmail, testPassword)).rejects.toThrow(HTTPException)
      expect(mockUpdate).not.toHaveBeenCalled()
    })

    it('パスワード不一致で失敗回数が増加すること', async () => {
      const hashedPassword = await hashPassword(testPassword)

      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword, ログイン連続失敗回数: 0 },
      ])

      await expect(login(testEmail, 'WrongPassword456!')).rejects.toThrow(HTTPException)

      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, {
        ログイン連続失敗回数: 1,
      })
    })

    it('5回失敗でアカウントロックされること', async () => {
      const hashedPassword = await hashPassword(testPassword)

      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword, ログイン連続失敗回数: 4 },
      ])

      await expect(login(testEmail, 'WrongPassword456!')).rejects.toThrow('アカウントがロックされました')

      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, {
        ログイン連続失敗回数: 5,
        アカウントロック: true,
      })
    })

    it('アカウントロック済みユーザーはログインできないこと', async () => {
      const hashedPassword = await hashPassword(testPassword)

      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword, アカウントロック: true, ログイン連続失敗回数: 5 },
      ])

      await expect(login(testEmail, testPassword)).rejects.toThrow('アカウントがロックされました')
      expect(mockUpdate).not.toHaveBeenCalled()
    })

    it('ログイン成功後に失敗回数がリセットされること', async () => {
      const hashedPassword = await hashPassword(testPassword)

      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword, ログイン連続失敗回数: 3 },
      ])

      const result = await login(testEmail, testPassword)
      expect(result.access_token).toBeDefined()

      expect(mockUpdate).toHaveBeenCalledWith('ユーザーマスタ', 12089, expect.objectContaining({
        ログイン連続失敗回数: 0,
      }))
    })

    it('パスワード未設定ユーザーでエラーを投げること', async () => {
      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '', 変更済パスワード: '' },
      ])

      await expect(login(testEmail, testPassword)).rejects.toThrow('ユーザーのパスワードが設定されていません')
    })

    it('未ハッシュパスワードのユーザーはログイン不可であること', async () => {
      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: 'plain-text-password' },
      ])

      await expect(login(testEmail, 'plain-text-password')).rejects.toThrow('パスワードの初期設定が必要です')
    })
  })

  describe('refreshAccessToken', () => {
    it('should refresh access token successfully', async () => {
      const hashedPassword = await hashPassword(testPassword)
      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword },
      ])

      const loginResult = await login(testEmail, testPassword)
      const oldRefreshToken = loginResult.refresh_token

      await new Promise((resolve) => setTimeout(resolve, 1100))

      const refreshResult = await refreshAccessToken(oldRefreshToken)

      expect(refreshResult).toBeDefined()
      expect(refreshResult.access_token).toBeDefined()
      expect(refreshResult.refresh_token).toBeDefined()
      expect(refreshResult.token_type).toBe('Bearer')

      expect(tokenStore.validate(oldRefreshToken)).toBeNull()
      expect(tokenStore.validate(refreshResult.refresh_token)).not.toBeNull()
    })

    it('should throw error for invalid refresh token', async () => {
      await expect(refreshAccessToken('invalid-token-123')).rejects.toThrow(HTTPException)
    })

    it('should throw error for revoked refresh token', async () => {
      const hashedPassword = await hashPassword(testPassword)
      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword },
      ])

      const loginResult = await login(testEmail, testPassword)
      tokenStore.revoke(loginResult.refresh_token)

      await expect(refreshAccessToken(loginResult.refresh_token)).rejects.toThrow(HTTPException)
    })

    it('should detect token reuse attack', async () => {
      const hashedPassword = await hashPassword(testPassword)
      mockFindMany.mockResolvedValue([
        { ...testUser, 初期パスワード: '1', 変更済パスワード: hashedPassword },
      ])

      const loginResult = await login(testEmail, testPassword)
      const oldRefreshToken = loginResult.refresh_token

      await new Promise((resolve) => setTimeout(resolve, 1100))

      const refreshResult1 = await refreshAccessToken(oldRefreshToken)

      await expect(refreshAccessToken(oldRefreshToken)).rejects.toThrow(HTTPException)
      expect(tokenStore.validate(refreshResult1.refresh_token)).toBeNull()
    })
  })

  describe('logout (router-level)', () => {
    it('should return logout message', () => {
      const expectedResponse = {
        message: 'Successfully logged out (client should delete tokens)',
      }
      expect(expectedResponse.message).toContain('logged out')
    })
  })
})
