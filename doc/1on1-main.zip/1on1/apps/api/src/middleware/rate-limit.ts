/**
 * レート制限ミドルウェア
 *
 * IPアドレスベースのレート制限を提供
 */

import { rateLimiter } from 'hono-rate-limiter'
import type { Context } from 'hono'

/**
 * クライアントIPを取得
 *
 * プロキシ経由の場合は X-Forwarded-For を優先
 */
function getClientIP(c: Context): string {
  // プロキシ経由の場合
  const forwarded = c.req.header('x-forwarded-for')
  if (forwarded) {
    // 最初のIPを取得（クライアントIP）
    return forwarded.split(',')[0].trim()
  }

  // 直接接続の場合
  const realIP = c.req.header('x-real-ip')
  if (realIP) {
    return realIP
  }

  // フォールバック
  return 'unknown'
}

/**
 * 標準レート制限（API全体）
 *
 * 1分あたり100リクエストまで
 */
export const standardRateLimiter = rateLimiter({
  windowMs: 60 * 1000, // 1分
  limit: 100, // 100リクエスト/分
  standardHeaders: 'draft-6', // RateLimit-* ヘッダー追加
  keyGenerator: getClientIP,
  message: {
    code: '429',
    status: 'error',
    message: 'リクエスト数が上限を超えました。しばらく待ってから再試行してください。',
  },
})

/**
 * 認証エンドポイント用レート制限
 *
 * ブルートフォース攻撃対策として厳格な制限
 * 1分あたり10リクエストまで
 */
export const authRateLimiter = rateLimiter({
  windowMs: 60 * 1000, // 1分
  limit: 10, // 10リクエスト/分
  standardHeaders: 'draft-6',
  keyGenerator: getClientIP,
  message: {
    code: '429',
    status: 'error',
    message: '認証試行回数が上限を超えました。しばらく待ってから再試行してください。',
  },
})
