/**
 * 認証ミドルウェア
 *
 * JWT 検証とユーザー情報のコンテキスト設定
 */

import { Context, Next } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { verifyAccessToken } from '../services/jwt'
import { env } from '../config/env'

/**
 * JWT トークンから抽出するユーザー情報
 */
export interface AuthUser {
  userId: string
  email: string
  role?: string
}

/**
 * 認証ミドルウェア
 *
 * Authorization: Bearer <token> ヘッダーからトークンを抽出し、
 * 検証してユーザー情報をコンテキストに設定します。
 *
 * @param c Hono Context
 * @param next Next function
 */
export async function authMiddleware(c: Context, next: Next) {
  const authHeader = c.req.header('Authorization')

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new HTTPException(401, {
      message: '認証が必要です（Authorization ヘッダーが必要）',
    })
  }

  const token = authHeader.substring(7) // "Bearer " を除去

  try {
    const payload = verifyAccessToken(token)
    c.set('user', {
      userId: payload.sub,
      email: payload.email,
      role: payload.role,
    })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : '無効なトークンです'
    throw new HTTPException(401, { message: errorMessage })
  }

  await next()
}

/**
 * オプショナル認証ミドルウェア
 *
 * トークンがあれば検証し、なくてもエラーにしない。
 * 公開エンドポイントで使用。
 */
export async function optionalAuthMiddleware(c: Context, next: Next) {
  const authHeader = c.req.header('Authorization')

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7)

    try {
      const payload = verifyAccessToken(token)
      c.set('user', {
        userId: payload.sub,
        email: payload.email,
        role: payload.role,
      })
    } catch {
      // トークンが無効でもエラーにしない
    }
  }

  await next()
}

/**
 * API キー認証ミドルウェア（ジョブエンドポイント用）
 *
 * X-API-Key ヘッダーを検証します。
 */
export async function apiKeyMiddleware(c: Context, next: Next) {
  const apiKey = c.req.header('X-API-Key')

  if (!apiKey) {
    throw new HTTPException(401, {
      message: 'X-API-Key ヘッダーが必要です',
    })
  }

  if (!env.API_KEYS || env.API_KEYS.length === 0) {
    throw new HTTPException(500, { message: 'APIキー設定が不足しています' })
  }
  if (!env.API_KEYS.includes(apiKey)) {
    throw new HTTPException(401, { message: '無効な API キーです' })
  }

  await next()
}
