/**
 * リクエストスコープ・アプリケーションロガー ミドルウェア
 *
 * Hono Context に appLogger を設定し、
 * ルート層 → サービス層へ request_id 付きロガーを伝搬する。
 */

import { createMiddleware } from 'hono/factory'
import { createAppLogger, type AppLogger } from '../config/logger'

/** Hono Variables に appLogger を追加するための型 */
export type LoggerVariables = {
  appLogger: AppLogger
}

/**
 * appLogger ミドルウェア
 *
 * requestId() ミドルウェアの後に適用すること。
 * c.get('appLogger') でサービス層に渡すロガーを取得できる。
 */
export const appLoggerMiddleware = createMiddleware<{
  Variables: LoggerVariables
}>(async (c, next) => {
  const requestId = c.get('requestId')
  c.set('appLogger', createAppLogger(requestId))
  await next()
})
