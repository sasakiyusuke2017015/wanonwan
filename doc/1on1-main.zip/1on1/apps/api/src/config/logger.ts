/**
 * ストラクチャードロガー設定
 *
 * pinoを使用した構造化ログ出力を提供します。
 * 環境に応じてログレベルとフォーマットを切り替えます。
 */

import pino from 'pino'
import { env } from './env'

/**
 * ロガーインスタンス
 *
 * - development: pretty print、debugレベル
 * - production: JSON形式、infoレベル
 */
export const logger = pino({
  level: env.NODE_ENV === 'development' ? 'debug' : 'info',
  transport:
    env.NODE_ENV === 'development'
      ? {
          target: 'pino-pretty',
          options: {
            colorize: true,
            translateTime: 'HH:MM:ss.l',
            ignore: 'pid,hostname',
          },
        }
      : undefined,
  // 本番環境ではJSON形式で出力（ログ集約ツール対応）
  formatters: {
    level: (label) => ({ level: label }),
  },
  // リクエストIDなどの追加フィールド用
  base: {
    service: '1on1-api',
  },
})

/**
 * アクセスログ用ロガーを作成
 *
 * log_type: "access" + request_id を付与した子ロガー。
 * HTTP リクエスト/レスポンスの記録に使用。
 */
export function createAccessLogger(requestId: string) {
  return logger.child({ log_type: 'access', request_id: requestId })
}

/**
 * アプリケーションログ用ロガーを作成
 *
 * log_type: "app" + request_id を付与した子ロガー。
 * サービス層のビジネスロジック記録に使用。
 */
export function createAppLogger(requestId: string) {
  return logger.child({ log_type: 'app', request_id: requestId })
}

/** アプリケーションロガーの型（サービス層の引数用） */
export type AppLogger = ReturnType<typeof createAppLogger>
