/**
 * OpenAPI スペック定義
 *
 * APIのドキュメントを構造化して定義します。
 * /api-docs エンドポイントで Swagger UI / Scalar として公開されます。
 */

export const openApiSpec = {
  openapi: '3.1.0',
  info: {
    title: '1on1 API',
    version: '1.0.0',
    description: '1on1 アンケート管理システム REST API',
  },
  servers: [
    {
      url: '/api',
      description: 'API Base',
    },
  ],
  paths: {
    '/auth/login': {
      post: {
        tags: ['認証'],
        summary: 'ログイン',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['email', 'password'],
                properties: {
                  email: { type: 'string', format: 'email' },
                  password: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '200': { description: 'ログイン成功' },
          '401': { description: '認証失敗' },
          '429': { description: 'レート制限' },
        },
      },
    },
    '/auth/refresh': {
      post: {
        tags: ['認証'],
        summary: 'トークンリフレッシュ',
        responses: {
          '200': { description: 'トークン更新成功' },
          '401': { description: 'リフレッシュトークン無効' },
        },
      },
    },
    '/surveys': {
      get: {
        tags: ['アンケート'],
        summary: 'アンケート一覧取得',
        parameters: [
          { name: 'limit', in: 'query', schema: { type: 'integer', default: 50 } },
          { name: 'offset', in: 'query', schema: { type: 'integer', default: 0 } },
          { name: 'answerStatus', in: 'query', schema: { type: 'string' } },
          { name: 'publishStatus', in: 'query', schema: { type: 'string' } },
          { name: 'recentMonths', in: 'query', schema: { type: 'integer' } },
          { name: 'orderBy', in: 'query', schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'アンケート一覧' },
        },
        security: [{ bearerAuth: [] }],
      },
    },
    '/surveys/{id}': {
      get: {
        tags: ['アンケート'],
        summary: 'アンケート詳細取得',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'アンケート詳細' },
          '404': { description: 'アンケートが見つかりません' },
        },
        security: [{ bearerAuth: [] }],
      },
    },
    '/answers': {
      get: {
        tags: ['回答'],
        summary: '回答一覧取得',
        responses: {
          '200': { description: '回答一覧' },
        },
        security: [{ bearerAuth: [] }],
      },
      post: {
        tags: ['回答'],
        summary: '回答送信',
        responses: {
          '200': { description: '回答送信成功' },
        },
        security: [{ bearerAuth: [] }],
      },
    },
    '/users/me': {
      get: {
        tags: ['ユーザー'],
        summary: '現在のユーザー情報取得',
        responses: {
          '200': { description: 'ユーザー情報' },
          '401': { description: '未認証' },
        },
        security: [{ bearerAuth: [] }],
      },
    },
    '/dashboard': {
      get: {
        tags: ['ダッシュボード'],
        summary: 'ダッシュボードデータ取得',
        responses: {
          '200': { description: 'ダッシュボードデータ' },
        },
        security: [{ bearerAuth: [] }],
      },
    },
    '/jobs/start-surveys': {
      post: {
        tags: ['ジョブ'],
        summary: 'アンケート配信バッチ開始',
        description: '掲載状況=予約 かつ 開始日 ≤ 現在 のレコードを「実施中」に更新',
        responses: {
          '200': { description: 'バッチ実行結果' },
          '401': { description: 'APIキー認証失敗' },
        },
        security: [{ apiKeyAuth: [] }],
      },
    },
    '/jobs/finish-surveys': {
      post: {
        tags: ['ジョブ'],
        summary: 'アンケート終了バッチ',
        description: '掲載状況=実施中 かつ 完了日 ≤ 現在 のレコードを「完了」に更新',
        responses: {
          '200': { description: 'バッチ実行結果' },
          '401': { description: 'APIキー認証失敗' },
        },
        security: [{ apiKeyAuth: [] }],
      },
    },
  },
  components: {
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
      },
      apiKeyAuth: {
        type: 'apiKey',
        in: 'header',
        name: 'X-API-Key',
      },
    },
  },
} as const
