/**
 * 環境変数設定
 *
 * 型安全な環境変数アクセスを提供します。
 * Fail Fast 原則に従い、必須環境変数が未設定の場合は起動時にエラーを発生させます。
 */

import { config } from 'dotenv'
import { fileURLToPath } from 'url'
import path from 'path'

// プロジェクトルートの .env ファイルを読み込む
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const rootDir = path.resolve(__dirname, '../../../..')
config({ path: path.join(rootDir, '.env') })

/**
 * 環境変数の型定義
 */
export interface Env {
  // サーバー設定（必須）
  NODE_ENV: 'development' | 'production' | 'test'
  PORT: number
  HOST: string

  // Pleasanter 設定（必須）
  PLEASANTER_URL: string
  PLEASANTER_API_KEY: string

  // JWT 設定（必須）
  JWT_SECRET_KEY: string
  JWT_ACCESS_TOKEN_EXPIRE_MINUTES: number
  JWT_REFRESH_TOKEN_EXPIRE_DAYS: number

  // CORS 設定（localhost:3000 は自動追加、追加分は環境変数から）
  CORS_ORIGINS: string[]

  // SITE_CONFIG_MODE（必須 - constants/site_${mode}.yml に対応）
  SITE_CONFIG_MODE: string

  // API キー（ジョブエンドポイント用、オプショナル）
  API_KEYS?: string[]
}

/**
 * 環境変数を取得（必須）
 *
 * 環境変数が未設定の場合はエラーを発生させます（Fail Fast 原則）。
 */
function getRequiredEnv(key: string): string {
  const value = process.env[key]
  if (!value) {
    throw new Error(`Required environment variable ${key} is not set`)
  }
  return value
}

/**
 * 環境変数を取得（オプショナル）
 */
function getOptionalEnv(key: string, defaultValue: string): string {
  return process.env[key] || defaultValue
}

/**
 * 環境変数を数値として取得
 */
function getEnvAsNumber(key: string, defaultValue?: number): number | undefined {
  const value = process.env[key]
  if (!value) return defaultValue
  const parsed = parseInt(value, 10)
  if (isNaN(parsed)) {
    throw new Error(`Environment variable ${key} must be a number (got: ${value})`)
  }
  return parsed
}

/**
 * 環境変数を配列として取得（カンマ区切り）
 */
function getEnvAsArray(key: string, defaultValue: string[]): string[] {
  const value = process.env[key]
  if (!value) return defaultValue
  return value.split(',').map((v) => v.trim())
}

/**
 * 環境変数をロード
 *
 * アプリケーション起動時に一度だけ実行し、設定オブジェクトを作成します。
 * Fail Fast 原則に従い、必須環境変数が未設定の場合は起動時にエラーを発生させます。
 */
export function loadEnv(): Env {
  // サーバー設定（必須）
  const nodeEnv = getOptionalEnv('NODE_ENV', 'development') as Env['NODE_ENV']
  const port = 8000
  const host = '0.0.0.0'

  // Pleasanter 設定（必須）
  const pleasanterUrl = getRequiredEnv('PLEASANTER_URL')
  const pleasanterApiKey = getRequiredEnv('PLEASANTER_API_KEY')

  // JWT 設定（必須）
  const jwtSecretKey = getRequiredEnv('JWT_SECRET_KEY')
  const jwtAccessTokenExpireMinutes = getEnvAsNumber('JWT_ACCESS_TOKEN_EXPIRE_MINUTES', 30)
  const jwtRefreshTokenExpireDays = getEnvAsNumber('JWT_REFRESH_TOKEN_EXPIRE_DAYS', 7)

  // CORS 設定（localhost:3000 は常に許可、追加分は環境変数から）
  const corsOrigins = ['http://localhost:3000']
  const extraOrigins = process.env.CORS_ORIGINS
  if (extraOrigins) {
    corsOrigins.push(...extraOrigins.split(',').map((v) => v.trim()))
  }

  // SITE_CONFIG_MODE（必須 - constants/site_${mode}.yml の存在で検証）
  const siteConfigMode = getRequiredEnv('SITE_CONFIG_MODE')

  // API キー（オプショナル）
  const apiKeys = process.env.API_KEYS ? getEnvAsArray('API_KEYS', []) : undefined

  return {
    NODE_ENV: nodeEnv,
    PORT: port,
    HOST: host,
    PLEASANTER_URL: pleasanterUrl,
    PLEASANTER_API_KEY: pleasanterApiKey,
    JWT_SECRET_KEY: jwtSecretKey,
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: jwtAccessTokenExpireMinutes,
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: jwtRefreshTokenExpireDays,
    CORS_ORIGINS: corsOrigins,
    SITE_CONFIG_MODE: siteConfigMode,
    API_KEYS: apiKeys,
  }
}

/**
 * グローバル環境変数設定
 *
 * アプリケーション全体で使用する設定オブジェクト。
 */
export const env = loadEnv()
