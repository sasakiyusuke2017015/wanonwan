/**
 * スケジュールルート
 *
 * GET    /api/schedules          - スケジュール一覧取得
 * POST   /api/schedules          - スケジュール作成
 * PUT    /api/schedules/:id      - スケジュール更新
 * DELETE /api/schedules/:id      - スケジュール削除
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import * as v from 'valibot'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import * as schedulesService from '../services/schedules.js'
import type { DayOfWeek } from '@ui-catalog/core/types'

type Variables = {
  user: AuthUser
}

export const schedulesRouter = new Hono<{ Variables: Variables }>()

// 全ルートに認証を適用
schedulesRouter.use('*', authMiddleware)

// ========================================
// Valibot スキーマ定義
// ========================================

/** スケジュール一覧取得リクエストスキーマ */
const GetSchedulesRequestSchema = v.object({
  startDate: v.optional(v.pipe(v.string(), v.isoTimestamp())),
  endDate: v.optional(v.pipe(v.string(), v.isoTimestamp())),
})

/** 曜日番号（0-6）のバリデーション */
const DayOfWeekSchema = v.union([
  v.literal(0),
  v.literal(1),
  v.literal(2),
  v.literal(3),
  v.literal(4),
  v.literal(5),
  v.literal(6),
])

/** スケジュール作成/更新リクエストスキーマ */
const ScheduleSchema = v.object({
  title: v.pipe(v.string(), v.minLength(1)),
  startTime: v.pipe(v.string(), v.isoTimestamp()),
  endTime: v.pipe(v.string(), v.isoTimestamp()),
  color: v.pipe(v.string(), v.regex(/^#[0-9a-fA-F]{6}$/)),
  allDay: v.optional(v.boolean(), false),
  description: v.optional(v.string()),
  icon: v.optional(v.string()),
  repeat: v.optional(v.array(DayOfWeekSchema)),
  repeatPeriodStart: v.optional(v.pipe(v.string(), v.isoTimestamp())),
  repeatPeriodEnd: v.optional(v.pipe(v.string(), v.isoTimestamp())),
})

// ========================================
// API エンドポイント
// ========================================

/**
 * スケジュール一覧取得
 * GET /api/schedules
 */
schedulesRouter.get('/', vValidator('query', GetSchedulesRequestSchema), async (c) => {
  const { startDate, endDate } = c.req.valid('query')
  const user = c.get('user')

  try {
    const params: schedulesService.GetSchedulesParams = {
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      userId: user.userId, // 自分のスケジュールのみ取得
    }

    const schedules = await schedulesService.getSchedules(params)
    return c.json({ schedules })
  } catch (error) {
    console.error('[schedules.getSchedules] Error:', error)
    throw new HTTPException(500, { message: 'スケジュールの取得に失敗しました' })
  }
})

/**
 * スケジュール作成
 * POST /api/schedules
 */
schedulesRouter.post('/', vValidator('json', ScheduleSchema), async (c) => {
  const data = c.req.valid('json')
  const user = c.get('user')

  try {
    const event = {
      title: data.title,
      startTime: new Date(data.startTime),
      endTime: new Date(data.endTime),
      color: data.color,
      allDay: data.allDay || false,
      description: data.description,
      icon: data.icon,
      repeat: data.repeat as readonly DayOfWeek[] | undefined,
      repeatPeriodStart: data.repeatPeriodStart ? new Date(data.repeatPeriodStart) : undefined,
      repeatPeriodEnd: data.repeatPeriodEnd ? new Date(data.repeatPeriodEnd) : undefined,
    }

    const createdSchedule = await schedulesService.createSchedule(event, user.userId)
    return c.json({ schedule: createdSchedule }, 201)
  } catch (error) {
    console.error('[schedules.createSchedule] Error:', error)
    throw new HTTPException(500, { message: 'スケジュールの作成に失敗しました' })
  }
})

/**
 * スケジュール更新
 * PUT /api/schedules/:id
 */
schedulesRouter.put('/:id', vValidator('json', ScheduleSchema), async (c) => {
  const scheduleId = c.req.param('id')
  const data = c.req.valid('json')
  const user = c.get('user')

  try {
    const event = {
      id: scheduleId,
      title: data.title,
      startTime: new Date(data.startTime),
      endTime: new Date(data.endTime),
      color: data.color,
      allDay: data.allDay || false,
      description: data.description,
      icon: data.icon,
      repeat: data.repeat as readonly DayOfWeek[] | undefined,
      repeatPeriodStart: data.repeatPeriodStart ? new Date(data.repeatPeriodStart) : undefined,
      repeatPeriodEnd: data.repeatPeriodEnd ? new Date(data.repeatPeriodEnd) : undefined,
    }

    const updatedSchedule = await schedulesService.updateSchedule(event, user.userId)
    return c.json({ schedule: updatedSchedule })
  } catch (error) {
    console.error('[schedules.updateSchedule] Error:', error)
    throw new HTTPException(500, { message: 'スケジュールの更新に失敗しました' })
  }
})

/**
 * スケジュール削除
 * DELETE /api/schedules/:id
 */
schedulesRouter.delete('/:id', async (c) => {
  const scheduleId = c.req.param('id')
  const user = c.get('user')

  try {
    await schedulesService.deleteSchedule(scheduleId)
    return c.json({ success: true })
  } catch (error) {
    console.error('[schedules.deleteSchedule] Error:', error)
    throw new HTTPException(500, { message: 'スケジュールの削除に失敗しました' })
  }
})
