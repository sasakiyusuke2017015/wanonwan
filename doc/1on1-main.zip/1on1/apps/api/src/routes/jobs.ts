/**
 * ジョブルート（バッチ処理）
 *
 * GET    /api/jobs/start-surveys   - アンケート配信バッチ開始
 * GET    /api/jobs/finish-surveys  - アンケート終了バッチ
 * DELETE /api/jobs/delete-surveys  - アンケートと回答結果の削除
 * PUT    /api/jobs/update-prompts  - プロンプト更新
 *
 * ビジネスロジックは services/jobs.ts に委譲。
 */

import { Hono } from 'hono'
import { apiKeyMiddleware } from '../middleware/auth'
import * as jobsService from '../services/jobs'

export const jobsRouter = new Hono()

// 全ルートに API キー認証を適用
jobsRouter.use('*', apiKeyMiddleware)

// ===========================
// 1. アンケート開始 (start-surveys)
// ===========================

jobsRouter.get('/start-surveys', async (c) => {
  const pubIdsParam = c.req.queries('pub_ids')
  const pubIds = pubIdsParam && pubIdsParam.length > 0 ? pubIdsParam : null

  const result = await jobsService.startSurveys(pubIds)

  return c.json({
    code: '200',
    status: 'success',
    data: result,
  })
})

// ===========================
// 2. アンケート終了 (finish-surveys)
// ===========================

jobsRouter.get('/finish-surveys', async (c) => {
  const pubIdsParam = c.req.queries('pub_ids')
  const pubIds = pubIdsParam && pubIdsParam.length > 0 ? pubIdsParam : null

  const result = await jobsService.finishSurveys(pubIds)

  return c.json({
    code: '200',
    status: 'success',
    data: result,
  })
})

// ===========================
// 3. アンケート削除 (delete-surveys)
// ===========================

jobsRouter.delete('/delete-surveys', async (c) => {
  const pubIdsParam = c.req.queries('pub_ids')
  const pubIds = pubIdsParam && pubIdsParam.length > 0 ? pubIdsParam : null

  const result = await jobsService.deleteSurveys(pubIds)

  return c.json({
    code: '200',
    status: 'success',
    data: result,
  })
})

// ===========================
// 4. プロンプト更新 (update-prompts)
// ===========================

jobsRouter.put('/update-prompts', async (c) => {
  const pubIdsParam = c.req.queries('pub_ids')
  const pubIds = pubIdsParam && pubIdsParam.length > 0 ? pubIdsParam : null

  if (!pubIds || pubIds.length === 0) {
    return c.json({
      code: '400',
      status: 'error',
      message: 'pub_ids パラメータが必要です',
    }, 400)
  }

  const result = await jobsService.updatePrompts(pubIds)

  if (result.updated_pub_count === 0) {
    return c.json({
      code: '404',
      status: 'error',
      message: '指定された掲載IDが見つかりません',
    }, 404)
  }

  return c.json({
    code: '200',
    status: 'success',
    data: result,
  })
})
