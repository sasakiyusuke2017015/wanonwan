/**
 * 回答ルート
 *
 * GET    /api/answers          - 回答一覧取得
 * GET    /api/answers/:id      - 回答詳細取得
 * PUT    /api/answers/:id      - 回答更新
 * POST   /api/answers/:id/delegate - 委任追加
 * DELETE /api/answers/:id/delegate/:userId - 委任解除
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import * as v from 'valibot'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import { GetAnswersRequestSchema, GetAnswerRequestSchema, UpdateAnswerRequestSchema } from '@1on1/domain/validators'
import { answersService } from '../services'

type Variables = {
  user: AuthUser
}

export const answersRouter = new Hono<{ Variables: Variables }>()

// 全ルートに認証を適用
answersRouter.use('*', authMiddleware)

/**
 * 回答一覧取得
 * GET /api/answers
 *
 * アクセス制御:
 * - 自分が回答者 OR 面談候補に含まれるレコードのみ
 */
answersRouter.get(
  '/',
  vValidator('query', GetAnswersRequestSchema),
  async (c) => {
    const { limit, offset, recentMonths } = c.req.valid('query')
    const user = c.get('user')

    try {
      const result = await answersService.getAllAnswers(
        limit,
        offset,
        recentMonths,
        user.userId
      )
      return c.json(result)
    } catch (error) {
      console.error('[answers.getAllAnswers] Error:', error)
      throw new HTTPException(500, { message: '回答一覧の取得に失敗しました' })
    }
  }
)

/**
 * 回答詳細取得（ユーザーID指定）
 * GET /api/answers/:id
 *
 * :id はユーザーID（Pleasanter ResultId ではない）
 * フロントエンドの EmployeeDetailResponse に対応:
 * ユーザー情報 + そのユーザーの回答結果一覧を返す
 *
 * アクセス制御:
 * - 自分自身のデータ OR 面談候補に含まれる場合のみアクセス可能
 */
answersRouter.get('/:id', async (c) => {
  const targetUserId = c.req.param('id')
  const user = c.get('user')

  try {
    // 権限チェックを先に実行（軽量な回答レコードのみ取得）
    const canAccess = await answersService.checkUserAccess(targetUserId, user.userId)
    if (!canAccess) {
      throw new HTTPException(403, { message: 'このメンバーの回答へのアクセス権限がありません' })
    }

    // 権限確認後にデータ取得
    const result = await answersService.getEmployeeDetail(targetUserId)
    return c.json(result)
  } catch (error) {
    if (error instanceof HTTPException) throw error
    throw new HTTPException(500, { message: '回答詳細の取得に失敗しました' })
  }
})

/**
 * 回答更新
 * PUT /api/answers/:id
 *
 * アクセス制御:
 * - 自分が回答者 OR 面談候補に含まれる場合のみ更新可能
 */
answersRouter.put(
  '/:id',
  vValidator('json', UpdateAnswerRequestSchema.entries.data),
  async (c) => {
    const answerId = c.req.param('id')
    const data = c.req.valid('json')
    const user = c.get('user')

    try {
      // 先に現在のレコードを取得して権限チェック
      const existing = await answersService.getAnswerById(answerId)

      if (!answersService.canAccessAnswer(existing, user.userId)) {
        throw new HTTPException(403, { message: 'この回答を更新する権限がありません' })
      }

      const result = await answersService.updateAnswer(answerId, data, user.userId)
      return c.json(result)
    } catch (error) {
      if (error instanceof HTTPException) throw error
      throw new HTTPException(500, { message: '回答の更新に失敗しました' })
    }
  }
)

// ===========================
// 委任機能
// ===========================

/** 委任追加リクエストスキーマ */
const AddDelegateRequestSchema = v.object({
  delegateToUserId: v.pipe(v.string(), v.minLength(1)),
  delegationType: v.picklist(['this_answer_only', 'this_answer_and_future']),
})

/**
 * 委任追加
 * POST /api/answers/:id/delegate
 *
 * アクセス制御:
 * - 自分が面談候補に含まれる場合のみ委任可能（課長以上）
 * - 委任先は自分の配下のみ
 */
answersRouter.post(
  '/:id/delegate',
  vValidator('json', AddDelegateRequestSchema),
  async (c) => {
    const answerId = c.req.param('id')
    const { delegateToUserId, delegationType } = c.req.valid('json')
    const user = c.get('user')

    try {
      // 回答レコードを取得
      const answer = await answersService.getAnswerById(answerId)

      // 権限チェック: 自分が面談候補に含まれているか
      if (!answersService.canAccessAnswer(answer, user.userId)) {
        throw new HTTPException(403, { message: 'この回答への委任権限がありません' })
      }

      // 自分が回答者の場合は委任不可（回答者は委任する側ではない）
      if (String(answer.回答者) === String(user.userId)) {
        throw new HTTPException(403, { message: '回答者は委任できません' })
      }

      // 委任先が配下かチェック
      const isValidTarget = await answersService.isDelegateTargetValid(user.userId, delegateToUserId)
      if (!isValidTarget) {
        throw new HTTPException(400, { message: '委任先は自分の配下のみ指定できます' })
      }

      // 委任追加
      const result = await answersService.addDelegate(
        answerId,
        user.userId,
        delegateToUserId,
        delegationType,
        String(answer.回答者)
      )

      return c.json(result)
    } catch (error) {
      if (error instanceof HTTPException) throw error
      throw new HTTPException(500, { message: '委任の追加に失敗しました' })
    }
  }
)

/** 委任解除リクエストスキーマ */
const RemoveDelegateRequestSchema = v.object({
  removeFromFuture: v.optional(v.boolean(), false),
})

/**
 * 委任解除
 * DELETE /api/answers/:id/delegate/:userId
 *
 * アクセス制御:
 * - 自分が面談候補に含まれる場合のみ委任解除可能
 */
answersRouter.delete(
  '/:id/delegate/:userId',
  vValidator('query', RemoveDelegateRequestSchema),
  async (c) => {
    const answerId = c.req.param('id')
    const delegateToUserId = c.req.param('userId')
    const { removeFromFuture } = c.req.valid('query')
    const user = c.get('user')

    try {
      // 回答レコードを取得
      const answer = await answersService.getAnswerById(answerId)

      // 権限チェック: 自分が面談候補に含まれているか
      if (!answersService.canAccessAnswer(answer, user.userId)) {
        throw new HTTPException(403, { message: 'この回答への委任解除権限がありません' })
      }

      // 自分が回答者の場合は委任解除不可
      if (String(answer.回答者) === String(user.userId)) {
        throw new HTTPException(403, { message: '回答者は委任解除できません' })
      }

      // 委任解除
      const result = await answersService.removeDelegate(
        answerId,
        delegateToUserId,
        removeFromFuture ?? false,
        String(answer.回答者)
      )

      return c.json(result)
    } catch (error) {
      if (error instanceof HTTPException) throw error
      throw new HTTPException(500, { message: '委任の解除に失敗しました' })
    }
  }
)
