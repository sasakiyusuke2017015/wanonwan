/**
 * ダッシュボードルート
 *
 * GET /api/dashboard/stats  - 統計データ取得
 * GET /api/dashboard/chart  - グラフデータ取得
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import { GetChartDataRequestSchema } from '@1on1/domain/validators'
import { dashboardService } from '../services'

type Variables = {
  user: AuthUser
}

export const dashboardRouter = new Hono<{ Variables: Variables }>()

// 全ルートに認証を適用
dashboardRouter.use('*', authMiddleware)

/**
 * ダッシュボード統計データ取得
 * GET /api/dashboard/stats
 */
dashboardRouter.get('/stats', async (c) => {
  try {
    const result = await dashboardService.getStats()
    return c.json(result)
  } catch {
    throw new HTTPException(500, { message: '統計データの取得に失敗しました' })
  }
})

/**
 * ダッシュボードグラフデータ取得
 * GET /api/dashboard/chart
 */
dashboardRouter.get(
  '/chart',
  vValidator('query', GetChartDataRequestSchema),
  async (c) => {
    const { startDate, endDate, userId } = c.req.valid('query')

    try {
      const result = await dashboardService.getChartData(startDate, endDate, userId)
      return c.json(result)
    } catch {
      throw new HTTPException(500, { message: 'グラフデータの取得に失敗しました' })
    }
  }
)
