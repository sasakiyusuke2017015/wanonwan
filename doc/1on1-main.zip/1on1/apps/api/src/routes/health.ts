/**
 * ヘルスチェック・ドキュメントルート
 */

import { Hono } from 'hono'
import { swaggerUI } from '@hono/swagger-ui'
import { env } from '../config/env'
import { openApiSpec } from '../config/openapi'

export const healthRouter = new Hono()

/**
 * ヘルスチェックエンドポイント
 */
healthRouter.get('/health', (c) => {
  return c.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: '1on1 API',
    env: env.NODE_ENV,
    version: '1.0.0',
  })
})

/**
 * OpenAPI スペック提供
 */
healthRouter.get('/openapi.json', (c) => {
  return c.json(openApiSpec)
})

/**
 * Swagger UI ドキュメント
 */
healthRouter.get('/api-docs', swaggerUI({ url: '/openapi.json' }))
