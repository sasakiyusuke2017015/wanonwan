/**
 * 開発用ルート
 *
 * ui-catalog の操作ログを Docker stdout に出力
 */

import { Hono } from 'hono'
import { env } from '../config/env'

const devRouter = new Hono()

/**
 * 操作ログ受信エンドポイント（開発環境のみ）
 *
 * POST /api/dev/log
 */
devRouter.post('/log', async (c) => {
  // 本番環境では無効
  if (env.NODE_ENV === 'production') {
    return c.json({ error: 'Not available in production' }, 403)
  }

  try {
    const body = await c.req.json()
    const { level, component, action, data, timestamp, prefix } = body

    // 絵文字マップ
    const emojiMap: Record<string, string> = {
      click: '🖱️',
      change: '✏️',
      focus: '🎯',
      blur: '💨',
      submit: '📤',
      open: '📂',
      close: '📁',
      select: '✅',
      toggle: '🔄',
      hover: '👆',
      mount: '🔌',
      unmount: '🔌',
      error: '❌',
      success: '✅',
    }
    const emoji = emojiMap[action] || '📝'

    // Docker stdout に出力
    const logMessage = `${prefix || '[ui-catalog]'} ${emoji} ${component}.${action}`
    const logData = data ? JSON.stringify(data) : ''

    // levelに応じたconsole出力
    switch (level) {
      case 'error':
        console.error(logMessage, logData, `[${timestamp}]`)
        break
      case 'warn':
        console.warn(logMessage, logData, `[${timestamp}]`)
        break
      default:
        console.log(logMessage, logData, `[${timestamp}]`)
    }

    return c.json({ ok: true })
  } catch {
    return c.json({ error: 'Invalid request' }, 400)
  }
})

export { devRouter }
