/**
 * 認証ルート
 *
 * POST /api/auth/login    - ログイン
 * POST /api/auth/refresh  - トークンリフレッシュ
 * POST /api/auth/logout   - ログアウト
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import { LoginRequestSchema, RefreshRequestSchema } from '@1on1/domain/validators'
import { authService } from '../services'
import { ServiceError, SERVICE_ERROR_STATUS_MAP } from '../services/errors'
import type { LoggerVariables } from '../middleware/requestLogger'

export const authRouter = new Hono<{ Variables: LoggerVariables }>()

/**
 * ログイン
 * POST /api/auth/login
 */
authRouter.post(
  '/login',
  vValidator('json', LoginRequestSchema),
  async (c) => {
    const { email, password } = c.req.valid('json')

    try {
      const result = await authService.login(email, password, c.get('appLogger'))
      return c.json(result)
    } catch (error) {
      if (error instanceof ServiceError) {
        const status = SERVICE_ERROR_STATUS_MAP[error.code]
        return c.json({
          message: error.message,
          ...error.details,
        }, status)
      }
      return c.json({ message: 'ログインに失敗しました' }, 500)
    }
  }
)

/**
 * トークンリフレッシュ
 * POST /api/auth/refresh
 */
authRouter.post(
  '/refresh',
  vValidator('json', RefreshRequestSchema),
  async (c) => {
    const { refresh_token } = c.req.valid('json')

    try {
      const result = await authService.refreshAccessToken(refresh_token)
      return c.json(result)
    } catch (error) {
      if (error instanceof ServiceError) {
        const status = SERVICE_ERROR_STATUS_MAP[error.code]
        return c.json({ message: error.message }, status)
      }
      throw new HTTPException(500, { message: 'トークンリフレッシュに失敗しました' })
    }
  }
)

/**
 * ログアウト
 * POST /api/auth/logout
 */
authRouter.post('/logout', (c) => {
  return c.json({
    message: 'Successfully logged out (client should delete tokens)',
  })
})
