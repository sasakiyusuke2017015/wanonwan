/**
 * 公開ルート（認証不要）
 *
 * GET /api/public/health   - ヘルスチェック
 * GET /api/public/version  - バージョン情報
 * GET /api/public          - 公開データ取得
 */

import { Hono } from 'hono'

export const publicRouter = new Hono()

/**
 * ヘルスチェック
 * GET /api/public/health
 */
publicRouter.get('/health', (c) => {
  return c.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  })
})

/**
 * バージョン情報
 * GET /api/public/version
 */
publicRouter.get('/version', (c) => {
  return c.json({
    version: '1.0.0',
    nodeVersion: process.version,
    environment: process.env.NODE_ENV,
  })
})

/**
 * 公開データ取得
 * GET /api/public
 */
publicRouter.get('/', (c) => {
  return c.json({
    data: {
      announcements: [],
      systemStatus: {
        status: 'operational',
        lastUpdated: new Date().toISOString(),
      },
    },
  })
})
