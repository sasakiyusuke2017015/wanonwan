/**
 * アンケートルート
 *
 * GET    /api/surveys                        - アンケート一覧取得
 * GET    /api/surveys/:publishId             - アンケート詳細取得
 * POST   /api/surveys/:publishId/submit      - アンケート回答提出（掲載ID）
 * POST   /api/surveys/:publishId/save        - アンケート保存（掲載ID）
 * POST   /api/surveys/:answerId/ai           - AI生成（回答ID）
 * POST   /api/surveys/:answerId/interview    - 面談実施（回答ID）
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import * as v from 'valibot'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import {
  GetSurveysRequestSchema,
  SubmitAnswerRequestSchema,
  GenerateAIRequestSchema,
  SubmitInterviewRequestSchema,
  SaveSurveyRequestSchema,
} from '@1on1/domain/validators'
import { surveysService, answersService, aiService } from '../services'

type Variables = {
  user: AuthUser
}

export const surveysRouter = new Hono<{ Variables: Variables }>()

// 全ルートに認証を適用
surveysRouter.use('*', authMiddleware)

/**
 * アンケート一覧取得
 * GET /api/surveys
 *
 * 認証ユーザーの回答結果と掲載設定を結合して返す
 */
surveysRouter.get(
  '/',
  vValidator('query', GetSurveysRequestSchema),
  async (c) => {
    const {
      limit,
      offset,
      answerStatus,
      publishStatus,
      recentMonths,
      orderBy,
    } = c.req.valid('query')

    // 認証ユーザーを取得
    const user = c.get('user')
    const userId = user?.userId ? parseInt(user.userId, 10) : undefined

    try {
      const result = await surveysService.getAllSurveys(
        limit,
        offset,
        answerStatus,
        publishStatus,
        recentMonths,
        orderBy,
        userId
      )
      return c.json(result)
    } catch {
      throw new HTTPException(500, { message: 'アンケート一覧の取得に失敗しました' })
    }
  }
)

/**
 * アンケート詳細取得
 * GET /api/surveys/:publishId
 *
 * アクセス制御:
 * - 回答結果テーブルで回答者が自分のレコードが存在する場合のみ
 */
surveysRouter.get('/:publishId', async (c) => {
  const publishId = c.req.param('publishId')
  const user = c.get('user')

  try {
    // 回答結果で回答者が自分のレコードが存在するかチェック
    const isRespondent = await answersService.isRespondentForPublish(publishId, user.userId)
    if (!isRespondent) {
      throw new HTTPException(403, { message: 'このアンケートへのアクセス権限がありません' })
    }

    const result = await surveysService.getSurveyById(publishId)
    return c.json(result)
  } catch (error) {
    if (error instanceof HTTPException) throw error
    throw new HTTPException(500, { message: 'アンケート詳細の取得に失敗しました' })
  }
})

// アンケート回答用スキーマ（publishId はパスパラメータから取得）
const SubmitBodySchema = v.object({
  answers: SubmitAnswerRequestSchema.entries.answers,
  aiGenerated: v.optional(SubmitAnswerRequestSchema.entries.aiGenerated),
})

/**
 * アンケート回答提出
 * POST /api/surveys/:publishId/submit
 */
surveysRouter.post(
  '/:publishId/submit',
  vValidator('json', SubmitBodySchema),
  async (c) => {
    const publishId = c.req.param('publishId')
    const { answers, aiGenerated } = c.req.valid('json')
    const user = c.get('user')

    if (!user) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    try {
      const userId = parseInt(user.userId, 10)
      const result = await surveysService.submitAnswer(publishId, answers, aiGenerated, userId)
      return c.json(result)
    } catch {
      throw new HTTPException(500, { message: 'アンケート回答の提出に失敗しました' })
    }
  }
)

// アンケート保存用スキーマ
const SaveBodySchema = v.object({
  answers: SaveSurveyRequestSchema.entries.answers,
  aiGenerated: v.optional(SaveSurveyRequestSchema.entries.aiGenerated),
})

/**
 * アンケート保存（途中保存）
 * POST /api/surveys/:publishId/save
 */
surveysRouter.post(
  '/:publishId/save',
  vValidator('json', SaveBodySchema),
  async (c) => {
    const publishId = c.req.param('publishId')
    const { answers, aiGenerated } = c.req.valid('json')
    const user = c.get('user')

    if (!user) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    try {
      const userId = parseInt(user.userId, 10)
      const result = await surveysService.saveSurvey(publishId, answers, aiGenerated, userId)
      return c.json(result)
    } catch {
      throw new HTTPException(500, { message: 'アンケートの保存に失敗しました' })
    }
  }
)

// AI生成用スキーマ
const AIGenerateBodySchema = v.object({
  userPrompt: v.string(),
  agentId: v.optional(v.string(), ''),
})

/**
 * AI生成（サポーター向け・非ストリーミング）
 * POST /api/surveys/:answerId/ai
 *
 * 注: ユーザー向けAI生成はストリーミング対応のため、
 * GET /api/surveys/:answerId/ai/user (SSE) として streaming.ts で実装
 */
surveysRouter.post(
  '/:answerId/ai',
  vValidator('json', AIGenerateBodySchema),
  async (c) => {
    const answerId = c.req.param('answerId')
    const { userPrompt, agentId } = c.req.valid('json')
    const user = c.get('user')

    if (!user) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    // 所有者チェック（IDOR対策）
    const answer = await answersService.getAnswerById(answerId)
    if (!answersService.canAccessAnswer(answer, user.userId)) {
      throw new HTTPException(403, { message: 'この回答へのアクセス権限がありません' })
    }

    if (!userPrompt) {
      return c.json({ success: true, message: '' })
    }

    try {
      const sessionId = `answer_${answerId}_${user.userId}_supporter`

      // AI回答を生成（非ストリーミング）
      const aiMessage = aiService
        ? await aiService.askAgent(userPrompt, agentId || '', sessionId)
        : ''

      // Pleasanterに保存（サポーター用）
      await surveysService.updateAnswerAISupporter(answerId, aiMessage)

      return c.json({
        success: true,
        message: aiMessage,
      })
    } catch (error) {
      if (error instanceof HTTPException) throw error
      throw new HTTPException(500, { message: 'AI生成に失敗しました' })
    }
  }
)

// 面談実施用スキーマ（userId/userCodeはJWT認証から取得するためbodyに含めない）
const InterviewBodySchema = v.object({
  interviewMemo: v.string(),
  nextAction: v.string(),
  interviewMethod: v.string(),
})

/**
 * 面談実施
 * POST /api/surveys/:answerId/interview
 */
surveysRouter.post(
  '/:answerId/interview',
  vValidator('json', InterviewBodySchema),
  async (c) => {
    const answerId = c.req.param('answerId')
    const { interviewMemo, nextAction, interviewMethod } = c.req.valid('json')
    const user = c.get('user')

    if (!user) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    try {
      // アクセス権限チェック
      const answer = await answersService.getAnswerById(answerId)
      if (!answersService.canAccessAnswer(answer, user.userId)) {
        throw new HTTPException(403, { message: 'この回答へのアクセス権限がありません' })
      }

      // 面談者IDはJWT認証ユーザーを使用（body.userIdによる偽装を防止）
      const result = await surveysService.submitInterview(
        answerId,
        user.userId,
        interviewMemo,
        nextAction,
        interviewMethod
      )
      return c.json(result)
    } catch (error) {
      if (error instanceof HTTPException) throw error
      throw new HTTPException(500, { message: '面談実施に失敗しました' })
    }
  }
)
