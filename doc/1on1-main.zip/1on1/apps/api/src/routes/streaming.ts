/**
 * SSEストリーミングルート
 *
 * AI生成のストリーミングエンドポイント
 */

import { Hono } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import { surveysService, answersService } from '../services'
import * as aiService from '../infrastructure/ai_agent'

type Variables = {
  user: AuthUser
}

export const streamingRouter = new Hono<{ Variables: Variables }>()

/**
 * AI生成エンドポイント（ユーザー向け・SSEストリーミング）
 * POST /api/surveys/:answerId/ai/user
 */
streamingRouter.post(
  '/api/surveys/:answerId/ai/user',
  authMiddleware,
  async (c) => {
    const answerId = c.req.param('answerId')
    // bodyからパラメータを取得（snake_case対応）
    const body = await c.req.json().catch(() => ({}))
    const userPrompt = body.user_prompt || body.userPrompt || ''
    const agentId = body.agent_id || body.agentId || ''

    // ミドルウェアで設定されたユーザー情報を取得
    const user = c.get('user')
    const userId = user?.userId
    if (!userId) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    // 所有者チェック（IDOR対策）
    const answer = await answersService.getAnswerById(answerId)
    if (!answersService.canAccessAnswer(answer, userId)) {
      throw new HTTPException(403, { message: 'この回答へのアクセス権限がありません' })
    }

    // SSEレスポンスのヘッダー設定
    c.header('Content-Type', 'text/event-stream')
    c.header('Cache-Control', 'no-cache')
    c.header('Connection', 'keep-alive')

    const { readable, writable } = new TransformStream()
    const writer = writable.getWriter()
    const encoder = new TextEncoder()

    // 非同期処理でストリーミング
    ;(async () => {
      try {
        if (!userPrompt) {
          await writer.write(
            encoder.encode(
              `event: complete\ndata: ${JSON.stringify({ code: '200', status: 'success', message: '' })}\n\n`
            )
          )
          await writer.close()
          return
        }

        // 初期化イベント
        await writer.write(
          encoder.encode(`event: init\ndata: ${JSON.stringify({ status: 'initialized' })}\n\n`)
        )

        const sessionId = `answer_${answerId}_${userId}_user`

        // AI回答をストリーミングで返す
        let aiMessage = ''

        for await (const chunk of aiService.askAgentStream(userPrompt, agentId, sessionId)) {
          aiMessage += chunk
          await writer.write(
            encoder.encode(`event: ai_chunk\ndata: ${JSON.stringify({ chunk })}\n\n`)
          )
        }

        // 保存開始イベント
        await writer.write(
          encoder.encode(`event: saving\ndata: ${JSON.stringify({ status: 'saving' })}\n\n`)
        )

        // Pleasanterに保存
        await surveysService.updateAnswerAIUser(answerId, aiMessage)

        // 完了イベント
        await writer.write(
          encoder.encode(
            `event: complete\ndata: ${JSON.stringify({ code: '200', status: 'success', message: aiMessage })}\n\n`
          )
        )
      } catch {
        try {
          await writer.write(
            encoder.encode(`event: error\ndata: ${JSON.stringify({ error: 'AI生成中にエラーが発生しました' })}\n\n`)
          )
        } catch {
          // ストリームが既に閉じている場合は無視
        }
      } finally {
        try {
          await writer.close()
        } catch {
          // ストリームが既に閉じている場合は無視
        }
      }
    })()

    return new Response(readable)
  }
)

/**
 * AI生成エンドポイント（サポーター向け・非ストリーミング）
 * POST /api/surveys/:answerId/ai/supporter
 */
streamingRouter.post(
  '/api/surveys/:answerId/ai/supporter',
  authMiddleware,
  async (c) => {
    const answerId = c.req.param('answerId')
    // bodyからパラメータを取得（snake_case対応）
    const body = await c.req.json().catch(() => ({}))
    const userPrompt = body.user_prompt || body.userPrompt || ''
    const agentId = body.agent_id || body.agentId || ''

    // ミドルウェアで設定されたユーザー情報を取得
    const user = c.get('user')
    const userId = user?.userId
    if (!userId) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    // 所有者チェック（IDOR対策）
    const answer = await answersService.getAnswerById(answerId)
    if (!answersService.canAccessAnswer(answer, userId)) {
      throw new HTTPException(403, { message: 'この回答へのアクセス権限がありません' })
    }

    try {
      if (!userPrompt) {
        return c.json({ code: '200', status: 'success', message: '' })
      }

      const sessionId = `answer_${answerId}_${userId}_supporter`

      // AI回答を取得（非ストリーミング）
      let aiMessage = ''
      for await (const chunk of aiService.askAgentStream(userPrompt, agentId, sessionId)) {
        aiMessage += chunk
      }

      // Pleasanterに保存
      await surveysService.updateAnswerAISupporter(answerId, aiMessage)

      return c.json({ code: '200', status: 'success', message: aiMessage })
    } catch {
      return c.json(
        { code: '500', status: 'error', message: 'AI生成中にエラーが発生しました' },
        500
      )
    }
  }
)
