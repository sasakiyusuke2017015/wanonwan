/**
 * ユーザールート
 *
 * GET    /api/users                  - ユーザー一覧取得
 * GET    /api/users/subordinates     - 配下一覧取得
 * GET    /api/users/:id              - ユーザー詳細取得
 * PUT    /api/users/:id              - ユーザー情報更新
 * POST   /api/users/change-password  - パスワード変更
 */

import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import { HTTPException } from 'hono/http-exception'
import * as v from 'valibot'
import { authMiddleware, type AuthUser } from '../middleware/auth'
import { UserSchema, ChangePasswordRequestSchema } from '@1on1/domain/validators'
import { usersService, answersService } from '../services'
import { ServiceError, SERVICE_ERROR_STATUS_MAP } from '../services/errors'
import type { LoggerVariables } from '../middleware/requestLogger'

type Variables = LoggerVariables & {
  user: AuthUser
}

export const usersRouter = new Hono<{ Variables: Variables }>()

// 全ルートに認証を適用
usersRouter.use('*', authMiddleware)

/**
 * ユーザー一覧取得
 * GET /api/users
 */
usersRouter.get('/', async (c) => {
  try {
    const users = await usersService.getAllUsers()
    return c.json({
      data: users,
      count: users.length,
    })
  } catch {
    throw new HTTPException(500, { message: 'ユーザー一覧の取得に失敗しました' })
  }
})

/**
 * 配下一覧取得
 * GET /api/users/subordinates
 *
 * 自分が面談候補に含まれている回答の回答者（＝配下）を取得
 */
usersRouter.get('/subordinates', async (c) => {
  const user = c.get('user')

  if (!user?.userId) {
    throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
  }

  try {
    const subordinates = await answersService.getSubordinates(user.userId)
    return c.json({
      data: subordinates,
      count: subordinates.length,
    })
  } catch {
    throw new HTTPException(500, { message: '配下一覧の取得に失敗しました' })
  }
})

/**
 * ユーザー詳細取得
 * GET /api/users/:id
 */
usersRouter.get('/:id', async (c) => {
  const userId = c.req.param('id')

  try {
    const user = await usersService.getUserById(userId)
    return c.json(user)
  } catch (error) {
    if (error instanceof ServiceError) {
      return c.json({ message: error.message }, SERVICE_ERROR_STATUS_MAP[error.code])
    }
    throw new HTTPException(500, { message: 'ユーザー詳細の取得に失敗しました' })
  }
})

// ユーザー更新用スキーマ
const UpdateUserBodySchema = v.partial(UserSchema)

/**
 * ユーザー情報更新
 * PUT /api/users/:id
 */
usersRouter.put(
  '/:id',
  vValidator('json', UpdateUserBodySchema),
  async (c) => {
    const userId = c.req.param('id')
    const data = c.req.valid('json')
    const user = c.get('user')

    // 自分のユーザー情報のみ更新可能
    if (user.userId !== userId) {
      throw new HTTPException(403, { message: '他のユーザーの情報を更新する権限がありません' })
    }

    try {
      const result = await usersService.updateUser(userId, data)
      return c.json(result)
    } catch (error) {
      if (error instanceof ServiceError) {
        return c.json({ message: error.message }, SERVICE_ERROR_STATUS_MAP[error.code])
      }
      throw new HTTPException(500, { message: 'ユーザー情報の更新に失敗しました' })
    }
  }
)

/**
 * パスワード変更
 * POST /api/users/change-password
 */
usersRouter.post(
  '/change-password',
  vValidator('json', ChangePasswordRequestSchema),
  async (c) => {
    const { current_password, new_password, confirm_password } = c.req.valid('json')
    const user = c.get('user')

    if (!user?.userId) {
      throw new HTTPException(401, { message: 'ユーザー認証が必要です' })
    }

    const appLogger = c.get('appLogger')

    try {
      const result = await usersService.changePassword(
        user.userId,
        current_password,
        new_password,
        confirm_password,
        appLogger
      )
      return c.json(result)
    } catch (error) {
      if (error instanceof ServiceError) {
        return c.json({ message: error.message }, SERVICE_ERROR_STATUS_MAP[error.code])
      }
      appLogger.error({ err: error, operation: 'change_password' }, 'unexpected error')
      throw new HTTPException(500, { message: 'パスワードの変更に失敗しました' })
    }
  }
)
