/**
 * AI Agent連携サービス
 *
 * 1on1-AI-Agentサービスまたは直接OpenAIと通信してAIアドバイスを生成します。
 * 元のPython版: apps/api/app/integrations/ai_agent/
 */

import OpenAI from 'openai'

/**
 * AI Agent設定
 */
interface AIAgentConfig {
  useAIAgent: boolean
  aiAgentUrl?: string
  openaiApiKey?: string
  aiModel?: string
}

/**
 * AI Agent リクエスト
 */
interface AIAgentRequest {
  message: string
  select_agents: string
  session_id?: string
}

/**
 * AI Agent レスポンス
 */
interface AIAgentResponse {
  message: string
  selected_agent: string
}

/**
 * 環境変数から設定を取得
 */
function getAIAgentConfig(): AIAgentConfig {
  const useAIAgentStr = process.env.USE_AI_AGENT
  if (!useAIAgentStr) {
    throw new Error('USE_AI_AGENT environment variable is not set')
  }

  const useAIAgent = useAIAgentStr.toLowerCase() === 'true' ||
                     useAIAgentStr === '1' ||
                     useAIAgentStr.toLowerCase() === 'yes'

  // Fail Fast 原則: AI_AGENT を使用する場合は AI_AGENT_URL が必須
  if (useAIAgent) {
    const aiAgentUrl = process.env.AI_AGENT_URL
    if (!aiAgentUrl) {
      throw new Error('AI_AGENT_URL environment variable is not set (required when USE_AI_AGENT=True)')
    }
    return {
      useAIAgent,
      aiAgentUrl,
      openaiApiKey: process.env.OPENAI_API_KEY,
      aiModel: process.env.AI_MODEL,
    }
  }

  // AI Agent を使用しない場合は OpenAI API Key が必須
  const openaiApiKey = process.env.OPENAI_API_KEY
  if (!openaiApiKey) {
    throw new Error('OPENAI_API_KEY environment variable is not set')
  }

  const aiModel = process.env.AI_MODEL
  if (!aiModel) {
    throw new Error('AI_MODEL environment variable is not set')
  }

  return {
    useAIAgent,
    openaiApiKey,
    aiModel,
  }
}

// グローバル設定
const config = getAIAgentConfig()

// OpenAI クライアント（必要に応じて初期化）
let openaiClient: OpenAI | null = null
if (config.openaiApiKey) {
  openaiClient = new OpenAI({
    apiKey: config.openaiApiKey,
  })
}

/**
 * AI Agent API を呼び出す
 */
async function callAIAgent(
  prompt: string,
  selectAgents: string,
  sessionId?: string
): Promise<string> {
  if (!config.aiAgentUrl) {
    throw new Error('AI_AGENT_URL is not configured')
  }

  try {
    const payload: AIAgentRequest = {
      message: prompt,
      select_agents: selectAgents,
    }

    if (sessionId) {
      payload.session_id = sessionId
    }

    const response = await fetch(config.aiAgentUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`HTTP error from AI-Agent: ${response.status} - ${errorText}`)
    }

    const data = (await response.json()) as AIAgentResponse
    const message = data.message
    const selectedAgent = data.selected_agent

    return `${selectedAgent}が選択されました\n${message}`
  } catch (error) {
    throw error
  }
}

/**
 * OpenAI Chat Completion をストリーミング形式で呼び出す
 */
async function* askChatStream(
  prompt: string,
  persona: string = '',
  model: string = config.aiModel!
): AsyncGenerator<string, void, unknown> {
  if (!openaiClient) {
    throw new Error('OpenAI client is not initialized')
  }

  const stream = await openaiClient.chat.completions.create({
    model,
    messages: [
      { role: 'system', content: persona },
      { role: 'user', content: prompt },
    ],
    stream: true,
  })

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content
    if (content) {
      yield content
    }
  }
}

/**
 * AI-Agentまたは直接OpenAIを使用してアドバイスを取得（非ストリーミング版）
 *
 * @param prompt - ユーザーへの質問やプロンプト
 * @param selectAgents - 使用するエージェント選択（JSON文字列または空文字列）
 * @param sessionId - セッションID（会話の継続性のため）
 * @returns AIエージェントからの応答文字列
 */
export async function askAgent(
  prompt: string,
  selectAgents: string = 'auto',
  sessionId?: string
): Promise<string> {
  // selectAgentsが空の場合はデフォルトの'auto'を使用
  const agents = selectAgents || 'auto'

  let parsedAgents: string
  try {
    parsedAgents = JSON.parse(agents)
  } catch {
    parsedAgents = agents
  }

  if (config.useAIAgent) {
    // AI Agent使用時は失敗したらフォールバックせずエラーを投げる
    return await callAIAgent(prompt, parsedAgents, sessionId)
  } else {
    // ストリーミングレスポンスを文字列にまとめる
    let result = ''
    for await (const chunk of askChatStream(prompt)) {
      result += chunk
    }
    return result
  }
}

/**
 * AI-Agentまたは直接OpenAIを使用してアドバイスを取得（ストリーミング版）
 *
 * @param prompt - ユーザーへの質問やプロンプト
 * @param selectAgents - 使用するエージェント選択（JSON文字列または空文字列）
 * @param sessionId - セッションID（会話の継続性のため）
 * @yields AIエージェントからの応答文字列（チャンク）
 */
export async function* askAgentStream(
  prompt: string,
  selectAgents: string = 'auto',
  sessionId?: string
): AsyncGenerator<string, void, unknown> {
  // selectAgentsが空の場合はデフォルトの'auto'を使用
  const agents = selectAgents || 'auto'

  let parsedAgents: string
  try {
    parsedAgents = JSON.parse(agents)
  } catch {
    parsedAgents = agents
  }

  if (config.useAIAgent) {
    // AI-Agentはストリーミング未対応のため、結果を一度に返す
    // 失敗時はフォールバックせずエラーを投げる
    const result = await callAIAgent(prompt, parsedAgents, sessionId)
    yield result
  } else {
    for await (const chunk of askChatStream(prompt)) {
      yield chunk
    }
  }
}
