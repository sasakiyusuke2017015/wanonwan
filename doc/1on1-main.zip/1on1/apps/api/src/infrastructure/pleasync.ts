/**
 * Pleasanter 統合データアクセス層
 *
 * @pleasync/client (Rust) を初期化し、サービス層に提供する。
 */

import fs from 'fs'
import path from 'path'
import { createPleasync } from '@pleasync/client'
import { env } from '../config/env.js'

// ============================================================
// 環境変数チェック（Fail Fast）
// ============================================================

const PLEASANTER_URL = process.env.PLEASANTER_URL
if (!PLEASANTER_URL) throw new Error('PLEASANTER_URL is not set')

const PLEASANTER_API_KEY = process.env.PLEASANTER_API_KEY
if (!PLEASANTER_API_KEY) throw new Error('PLEASANTER_API_KEY is not set')

const PLEASANTER_API_VERSION = process.env.PLEASANTER_API_VERSION
if (!PLEASANTER_API_VERSION) throw new Error('PLEASANTER_API_VERSION is not set')

const PG_HOST = process.env.PG_HOST
if (!PG_HOST) throw new Error('PG_HOST is not set')

const PG_PORT = process.env.PG_PORT
if (!PG_PORT) throw new Error('PG_PORT is not set')

const PG_USER = process.env.PG_USER
if (!PG_USER) throw new Error('PG_USER is not set')

const PG_PASSWORD = process.env.PG_PASSWORD
if (!PG_PASSWORD) throw new Error('PG_PASSWORD is not set')

const PG_DATABASE = process.env.PG_DATABASE
if (!PG_DATABASE) throw new Error('PG_DATABASE is not set')

// ============================================================
// site_package パスの解決
// ============================================================

function findSitePackagePath(): string {
  let dir = process.cwd()
  for (let i = 0; i < 5; i++) {
    const candidate = path.join(dir, 'infra', 'pleasanter', `site_package_${env.SITE_CONFIG_MODE}.json`)
    if (fs.existsSync(candidate)) return candidate
    dir = path.dirname(dir)
  }
  throw new Error(`site_package_${env.SITE_CONFIG_MODE}.json が見つかりません`)
}

// ============================================================
// エクスポート
// ============================================================

/** Pleasync インスタンス（DB + REST + スキーマ統合） */
export const pleasync = createPleasync({
  baseUrl: PLEASANTER_URL,
  apiKey: PLEASANTER_API_KEY,
  apiVersion: PLEASANTER_API_VERSION,
  pgHost: PG_HOST,
  pgPort: parseInt(PG_PORT, 10),
  pgUser: PG_USER,
  pgPassword: PG_PASSWORD,
  pgDatabase: PG_DATABASE,
  sitePackagePath: findSitePackagePath(),
})
