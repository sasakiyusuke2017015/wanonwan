/**
 * Hono API Server
 *
 * TypeScript統一バックエンド（REST API）
 */

import { serve } from '@hono/node-server'
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { requestId } from 'hono/request-id'
import { HTTPException } from 'hono/http-exception'
import { env } from './config/env'
import { logger, createAccessLogger } from './config/logger'
import { standardRateLimiter, authRateLimiter } from './middleware/rate-limit'
import { appLoggerMiddleware } from './middleware/requestLogger'
import {
  healthRouter,
  streamingRouter,
  authRouter,
  answersRouter,
  surveysRouter,
  usersRouter,
  dashboardRouter,
  jobsRouter,
  publicRouter,
  devRouter,
  schedulesRouter,
} from './routes'

/**
 * 機密情報をマスクするヘルパー
 */
const SENSITIVE_KEYS = ['password', 'token', 'secret', 'apiKey', 'api_key', 'authorization']

function maskSensitiveData(data: Record<string, unknown>): Record<string, unknown> {
  const masked: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(data)) {
    if (SENSITIVE_KEYS.some(k => key.toLowerCase().includes(k.toLowerCase()))) {
      masked[key] = '***MASKED***'
    } else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      masked[key] = maskSensitiveData(value as Record<string, unknown>)
    } else {
      masked[key] = value
    }
  }
  return masked
}

/**
 * Hono アプリケーション初期化
 */
const app = new Hono()

/**
 * ミドルウェア設定
 */
app.use('*', requestId())
app.use('*', appLoggerMiddleware)

// pinoベースのリクエストログ
app.use('*', async (c, next) => {
  const start = Date.now()

  // リクエストパラメータを取得（ログ用）
  const query = c.req.query()
  let body: unknown = undefined
  // POSTなどでbodyがある場合のみ取得（GETはスキップ）
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    try {
      body = await c.req.json()
      // bodyを再設定（一度読むと消費されるため）
      // Note: Honoはbodyを内部でキャッシュするため、再読み込み可能
    } catch {
      // JSONでない場合は無視
    }
  }

  await next()
  const duration = Date.now() - start

  // アクセスログ出力（log_type: "access" + request_id 付き）
  const rid = c.get('requestId')
  const accessLogger = createAccessLogger(rid)

  const logData: Record<string, unknown> = {
    method: c.req.method,
    path: c.req.path,
    status: c.res.status,
    duration,
  }

  // クエリパラメータがあれば追加
  if (Object.keys(query).length > 0) {
    logData.query = query
  }

  // ボディがあれば追加（機密情報はマスク）
  if (body) {
    const maskedBody = maskSensitiveData(body as Record<string, unknown>)
    logData.body = maskedBody
  }

  accessLogger.info(logData, `${c.req.method} ${c.req.path} ${c.res.status} ${duration}ms`)
})
app.use(
  '*',
  cors({
    origin: env.CORS_ORIGINS,
    credentials: true,
  })
)

// レート制限（全体）
app.use('/api/*', standardRateLimiter)

// 認証エンドポイント用の厳格なレート制限
app.use('/api/auth/*', authRateLimiter)

/**
 * ルートマウント
 */
// ヘルスチェック・ドキュメント
app.route('/', healthRouter)

// SSE ストリーミング
app.route('/', streamingRouter)

// 認証 API
app.route('/api/auth', authRouter)

// 回答 API
app.route('/api/answers', answersRouter)

// アンケート API
app.route('/api/surveys', surveysRouter)

// ユーザー API
app.route('/api/users', usersRouter)

// ダッシュボード API
app.route('/api/dashboard', dashboardRouter)

// ジョブ API（バッチ処理）
app.route('/api/jobs', jobsRouter)

// スケジュール API
app.route('/api/schedules', schedulesRouter)

// 公開 API（認証不要）
app.route('/api/public', publicRouter)

// 開発用 API（ログ出力など）
app.route('/api/dev', devRouter)

/**
 * 404 Not Found
 */
app.notFound((c) => {
  return c.json(
    {
      code: '404',
      status: 'error',
      message: 'Not Found',
    },
    404
  )
})

/**
 * エラーハンドラー
 */
app.onError((err, c) => {
  // HTTPException（Hono の標準エラー）の場合
  if (err instanceof HTTPException) {
    return err.getResponse()
  }

  // その他のエラー: pinoで構造化ログ出力
  logger.error({
    err,
    method: c.req.method,
    path: c.req.path,
    requestId: c.get('requestId'),
  }, 'Unhandled error')

  return c.json(
    {
      code: '500',
      status: 'error',
      message: 'Internal Server Error',
      detail: env.NODE_ENV === 'development' ? err.message : undefined,
    },
    500
  )
})

/**
 * サーバー起動
 */
const port = env.PORT
const host = env.HOST

logger.info({ host, port, env: env.NODE_ENV }, 'Hono API Server starting')

serve({
  fetch: app.fetch,
  port,
  hostname: host,
})

export default app
