# 1on1面談支援システム プロジェクト概要

## 🎯 プロジェクトの目的

**1on1面談の効果的な実施をサポートする統合システム**

従来の手動による面談準備やフィードバック作成の負担を軽減し、AI技術を活用して質の高い1on1面談を実現するためのデジタルプラットフォームです。

## 🚀 主要機能

### 📋 アンケート管理システム
- **作成・配布**: 柔軟な質問設定と対象者管理
- **回答収集**: リアルタイム進捗管理と回答率追跡
- **認証機能**: セキュアなユーザー認証による安全な回答環境

### 🤖 AI フィードバック生成
- **ChatGPT連携**: アンケート回答に基づく自動フィードバック
- **二段階フィードバック**: ユーザー向け・サポーター向け個別生成

### ⚙️ 自動化処理
- **スケジュール管理**: アンケートの自動開始・終了
- **進捗監視**: 回答率の自動計算・更新
- **定期実行**: Cronベースの無人運用

## 🏗️ アーキテクチャ

### システム構成
```
       ┌─────────────┐
       │   nginx     │ ← リバースプロキシ・SSL終端
       │  (80/443)   │
       └─────────────┘
              │
              ▼
┌─────────────────────────────────┐
│     FastAPI Gateway (8080)      │
├─────────┬─────────┬─────────────┤
│ Survey  │ ChatGPT │ Job         │
│ Module  │ Module  │ Module      │
└─────────┴─────────┴─────────────┘
     │         │         │
     │         ▼         ▼
     │   ┌──────────┐ ┌─────────┐
     │   │ OpenAI   │ │ Cron    │
     │   │ API      │ │ Jobs    │
     │   └──────────┘ └─────────┘
     ▼
┌─────────────┐
│ Pleasanter  │
│ API         │
└─────────────┘
```

### 設計パターン
- **モジュラー・モノリス**: 単一アプリ内での機能分離
- **将来のマイクロサービス化**: 各モジュールの独立化可能
- **API ファースト**: RESTful な設計思想

## 💻 技術スタック

### バックエンド
- **Python 3.11**: メイン開発言語
- **FastAPI**: 高性能Webフレームワーク
- **Pydantic**: データバリデーション
- **HTTPX**: 非同期HTTP通信

### AI・API連携
- **OpenAI API**: ChatGPT v3.5/4.0対応
- **Pleasanter API**: データ永続化・マスタ管理

### インフラ・運用
- **Docker**: コンテナ化環境
- **Docker Compose**: マルチコンテナ管理
- **nginx**: リバースプロキシ・SSL/TLS終端処理
- **Cron**: 定期実行ジョブ

### 開発環境
- **VS Code Dev Container**: 統一開発環境
- **Debugpy**: Pythonデバッグ機能
- **Hot Reload**: 開発効率化

## 📁 プロジェクト構造

```
mono-app/
├── app/                    # メインアプリケーション
│   ├── main.py            # FastAPIエントリーポイント
│   ├── config.py          # 設定管理
│   ├── site_config.yml    # サイト固有設定
│   └── modules/           # 機能モジュール
│       ├── survey/        # アンケート管理
│       ├── chatgpt/       # AI連携
│       ├── job/           # バッチ処理
│       └── pleasanter/    # データAPI
├── common/                # 共通ライブラリ
│   ├── logging_utils.py   # ログ管理
│   ├── date_utils.py      # 日時処理
│   └── http_helpers.py    # HTTP通信
├── nginx/                 # nginxリバースプロキシ設定（本番環境用）
│   ├── Dockerfile         # nginx用Dockerイメージ
│   └── nginx.prod.conf    # 本番環境用設定（HTTPS）
├── jobs/                  # 定期実行ジョブ
├── .devcontainer/         # 開発コンテナ設定
└── docker-compose.yml     # Docker Compose設定（profiles構成）
```

## 🛠️ 開発・運用環境

### 開発環境セットアップ

**VS Code Dev Container（推奨）:**
```bash
# 1. 環境変数設定
cp .env.sample .env

# 2. VS Code で "Reopen in Container" を選択
# → 自動で dev profile の環境が起動

# 3. 自動で以下が利用可能
# ・ホットリロード（ポート: PORT）
# ・デバッグ環境（ポート: DEBUG_PORT）
# ・Swagger UI（/docs）
```

**コマンドライン起動:**
```bash
# 環境変数設定
cp .env.sample .env

# 開発環境起動
docker compose --profile dev up --build

# アクセス先
# - API: http://localhost:8080
# - Swagger UI: http://localhost:8080/docs
# - デバッグポート: 環境変数 DEBUG_PORT で指定
```

### 本番環境デプロイ

**基本的な起動:**
```bash
# 1. 本番用環境変数設定
cp .env.sample .env

# 2. SSL証明書設定（下記の「SSL/HTTPS設定」セクション参照）

# 3. Docker Compose 起動（prod profile）
docker compose --profile prod up --build -d

# 4. 自動で以下が起動
# ・nginx-prod: リバースプロキシ（ポート: 80, 443）
# ・gateway-prod: APIゲートウェイ（内部ポート: 8080）
# ・daily-job: 定期ジョブコンテナ

# 5. 停止
docker compose --profile prod down
```

**環境の分離:**
```bash
# 開発環境と本番環境は完全に分離されています
# プロファイルによって異なるサービスが起動します

# 開発環境（dev profile）:
#   - gateway-dev (ポート8080、FastAPI直接アクセス)

# 本番環境（prod profile）:
#   - nginx-prod (HTTPS, ポート443 / HTTP→HTTPSリダイレクト, ポート80)
#   - gateway-prod (内部ポート8080)
#   - daily-job (定期ジョブ)
```

**環境ごとの特徴:**
- **開発環境**: シンプルで高速。FastAPIに直接アクセス、デバッグとホットリロードが快適
- **本番環境**: セキュア。nginx経由でSSL/TLS終端処理、セキュリティヘッダー自動付与


## 📊 主要エンドポイント

| エンドポイント | 機能 | 認証 |
|---------------|------|------|
| `GET /v1/surveys` | アンケート一覧 | 要 |
| `GET /v1/public-surveys` | 公開アンケート一覧 | 不要 |
| `GET /v1/survey/{id}` | アンケート詳細 | 条件付き |
| `POST /v1/answer` | 回答登録 | 条件付き |
| `POST /chatgpt/chat` | AIチャット | 不要 |
| `GET /job/start-surveys` | アンケート一括開始 | 不要 |
| `GET /job/finish-surveys` | アンケート一括終了 | 不要 |

## 🔧 設定・カスタマイズ

### 環境変数
| 変数名 | 説明 | 必須 |
|--------|------|------|
| `OPENAI_API_KEY` | ChatGPT API キー | ✓ |
| `PLEASANTER_API_URL` | Pleasanter API URL | ✓ |
| `PLEASANTER_API_KEY` | Pleasanter API キー | ✓ |
| `LOG_LEVEL` | ログレベル（DEBUG/INFO） | ✓ |

### データモデル設定
- **site_config.yml**: テーブル構造・フィールドマッピング
- **モード切替**: prototype/test/production

## 🔒 SSL/HTTPS設定（本番環境）

### 概要

本番環境では、nginxがリバースプロキシとしてSSL/TLS終端処理を行います。

**特徴:**
- ✅ HTTP（ポート80）からHTTPS（ポート443）への自動リダイレクト
- ✅ Let's Encryptによる無料SSL証明書の自動更新対応
- ✅ モダンなセキュリティヘッダー設定
- ✅ TLS 1.2/1.3 対応

### SSL証明書の取得（Let's Encrypt）

**1. Certbot用ディレクトリ作成:**
```bash
mkdir -p certbot/conf certbot/www
```

**2. 証明書取得（初回のみ）:**
```bash
# Certbotコンテナを使用してSSL証明書を取得
docker run -it --rm \
  -v ./certbot/conf:/etc/letsencrypt \
  -v ./certbot/www:/var/www/certbot \
  certbot/certbot certonly --webroot \
  -w /var/www/certbot \
  -d your-domain.com \
  --email your-email@example.com \
  --agree-tos \
  --no-eff-email
```

**3. nginx設定ファイル更新:**
```bash
# nginx/nginx.prod.conf の以下の行を実際のドメインに変更
# ssl_certificate /etc/letsencrypt/live/your-domain/fullchain.pem;
# ssl_certificate_key /etc/letsencrypt/live/your-domain/privkey.pem;

# 例:
# ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
# ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;
```

**4. 本番環境起動:**
```bash
docker compose --profile prod up --build -d
```

### SSL証明書の自動更新

**証明書更新スクリプト（月1回実行推奨）:**
```bash
# renew-cert.sh
docker run -it --rm \
  -v ./certbot/conf:/etc/letsencrypt \
  -v ./certbot/www:/var/www/certbot \
  certbot/certbot renew

# nginx再起動
docker compose --profile prod restart nginx-prod
```

**Cron設定（自動更新）:**
```bash
# crontabに追加
0 3 1 * * /path/to/renew-cert.sh
```

### ポート構成

| 環境 | 外部ポート | 内部ポート | プロトコル | 備考 |
|------|-----------|-----------|----------|------|
| 開発 | 8080 | - | HTTP | FastAPI直接アクセス |
| 本番 | 80 | - | HTTP | 443へリダイレクトのみ |
| 本番 | 443 | 8080 | HTTPS | SSL終端後、内部はHTTP |

### セキュリティ設定

nginx本番環境では以下のセキュリティヘッダーを自動設定:
- `Strict-Transport-Security`: HTTPS強制
- `X-Frame-Options`: クリックジャッキング対策
- `X-Content-Type-Options`: MIMEスニッフィング対策
- `X-XSS-Protection`: XSS対策

## 📈 今後の展開

### 短期目標
- [ ] テストスイート実装（pytest）
- [ ] CI/CD パイプライン構築
- [ ] パフォーマンス最適化

### 中期目標
- [ ] フロントエンド開発（React/Vue.js）
- [ ] リアルタイム通知機能
- [ ] 詳細分析ダッシュボード

### 長期目標
- [ ] マイクロサービス化
- [ ] クラウドネイティブ対応
- [ ] 多言語対応

## 🎨 特徴・メリット

✨ **AI活用による効率化**: 手動フィードバック作成時間を大幅短縮

🔒 **柔軟な認証システム**: 必要に応じた認証要否設定

⚡ **自動化による運用負荷軽減**: スケジュール管理の完全自動化

🔧 **拡張性の高い設計**: 将来的なスケールアウト対応

📊 **リアルタイム進捗管理**: 回答状況の即座把握

## 🔌 Claude Code MCP連携

MCP設定の詳細は[プロジェクトルートのREADME](../../README.md#-claude-code-mcp連携)を参照してください。

**API開発で活用できるMCPサーバー**:
- `1on1-api`: FastAPIのエンドポイントを直接呼び出し
- `1on1-ui-storybook`: UIコンポーネント情報を参照

---

*このシステムにより、1on1面談の準備から実施、フォローアップまでの全プロセスを効率化し、より質の高いコミュニケーションを実現します。*