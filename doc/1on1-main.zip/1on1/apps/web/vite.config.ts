import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { visualizer } from 'rollup-plugin-visualizer'
import path from 'path'

export default defineConfig(({ mode }) => {
  // VITE_ プレフィックス付き環境変数を読み込み（.envファイル + process.env）
  const fileEnv = loadEnv(mode, process.cwd(), 'VITE_')
  const env = { ...fileEnv, ...process.env }

  // 開発環境のみプロキシ設定を使用（本番はNginxで処理）
  const isDev = mode === 'development'

  // API内部ホスト（Docker: api-dev サービス名、ローカル: localhost）
  const apiHost = env.VITE_API_INTERNAL_HOST || 'localhost'

  return {
    plugins: [
      react(),
      // ビルド分析レポート（pnpm build 後に stats.html を生成）
      mode === 'production' &&
        visualizer({
          filename: 'stats.html',
          gzipSize: true,
          brotliSize: true,
        }),
    ].filter(Boolean),

    resolve: {
      alias: [
        // @ui-catalog/core サブパス（package.json exports に対応）
        { find: '@ui-catalog/core/atoms', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/atoms') },
        { find: '@ui-catalog/core/molecules', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/molecules') },
        { find: '@ui-catalog/core/organisms', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/organisms') },
        { find: '@ui-catalog/core/templates', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/templates') },
        { find: '@ui-catalog/core/hooks/router', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/hooks/router') },
        { find: '@ui-catalog/core/hooks/ui', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/hooks/ui') },
        { find: '@ui-catalog/core/hooks', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/hooks') },
        { find: '@ui-catalog/core/tokens', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/tokens') },
        { find: '@ui-catalog/core/constants', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/constants') },
        { find: '@ui-catalog/core/types', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/types') },
        { find: '@ui-catalog/core/utils', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/utils') },
        { find: '@ui-catalog/core/styles', replacement: path.resolve(__dirname, '../../packages/ui-catalog/core/styles') },
        { find: '@ui-catalog/core/infra/devtools', replacement: path.resolve(__dirname, '../../packages/ui-catalog/infra/devtools') },
        { find: '@ui-catalog/core/infra/version', replacement: path.resolve(__dirname, '../../packages/ui-catalog/infra/version') },
        { find: '@ui-catalog/core/infra/theme', replacement: path.resolve(__dirname, '../../packages/ui-catalog/infra/theme') },
        { find: '@ui-catalog/core/infra', replacement: path.resolve(__dirname, '../../packages/ui-catalog/infra') },
        { find: '@ui-catalog/core/extensions/1on1', replacement: path.resolve(__dirname, '../../packages/ui-catalog/extensions/1on1') },
        { find: '@ui-catalog/core/extensions/shared', replacement: path.resolve(__dirname, '../../packages/ui-catalog/extensions/shared') },
        { find: '@ui-catalog/core/extensions', replacement: path.resolve(__dirname, '../../packages/ui-catalog/extensions') },
        { find: '@ui-catalog/core', replacement: path.resolve(__dirname, '../../packages/ui-catalog') },
        // 具体的なパスを先にマッチさせる（@より@1on1/*が先）
        { find: '@1on1/layouts', replacement: path.resolve(__dirname, './src/layouts') },
        { find: '@1on1/domain', replacement: path.resolve(__dirname, '../../libs/domain') },
        { find: '@', replacement: path.resolve(__dirname, './src') },
      ],
      // packages/ui-catalog からの外部依存を apps/web の node_modules で解決
      dedupe: [
        'react',
        'react-dom',
        'framer-motion',
        'clsx',
        'tailwind-merge',
        'recharts',
        '@dnd-kit/core',
        '@dnd-kit/sortable',
        '@dnd-kit/utilities',
        '@tanstack/react-virtual',
        'jotai',
        'react-router-dom',
        'date-fns',
      ],
    },

    server: {
      port: 3000,
      watch: {
        // モノレポの外部パッケージも監視対象に含める
        ignored: ['!**/packages/ui-catalog/**'],
      },
      proxy: {
        '/api': {
          target: `http://${apiHost}:8000`,
          changeOrigin: true,
        },
      },
    },

    optimizeDeps: {
      // @ui-catalog/core を事前バンドルから除外してHMRを有効化
      exclude: ['@ui-catalog/core'],
    },

    build: {
      outDir: 'dist',
      sourcemap: isDev ? 'inline' : false,
      // esbuild minify（高速、terserの95%の圧縮率）
      minify: 'esbuild',
      // コンソール文を本番ビルドから除去
      esbuild: {
        drop: mode === 'production' ? ['console', 'debugger'] : [],
      },
      rollupOptions: {
        output: {
          manualChunks: {
            // React コア
            'vendor-react': ['react', 'react-dom', 'react-router-dom'],
            // UIライブラリ
            'vendor-ui': ['framer-motion', 'recharts', '@dnd-kit/core', '@dnd-kit/sortable'],
            // データ管理
            'vendor-data': ['@tanstack/react-query', 'jotai', 'valibot'],
            // ユーティリティ
            'vendor-utils': ['date-fns', 'clsx', 'tailwind-merge'],
          },
        },
      },
    },
  }
})
