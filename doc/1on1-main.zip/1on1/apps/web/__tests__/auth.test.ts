/**
 * 認証ヘルパー関数のテスト
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest'
import { setAuthTokens, getAuthToken, clearAuthTokens, AUTH_COOKIE_NAMES } from '../src/lib/auth'

describe('Auth Helper Functions', () => {
  beforeEach(() => {
    // テスト前にCookieをクリア
    document.cookie.split(';').forEach((c) => {
      document.cookie = c
        .replace(/^ +/, '')
        .replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/')
    })
  })

  afterEach(() => {
    // テスト後にCookieをクリア
    document.cookie.split(';').forEach((c) => {
      document.cookie = c
        .replace(/^ +/, '')
        .replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/')
    })
  })

  describe('setAuthTokens', () => {
    it('should set access token cookie', () => {
      const accessToken = 'test-access-token'
      const refreshToken = 'test-refresh-token'

      setAuthTokens(accessToken, refreshToken)

      const savedAccessToken = getAuthToken('ACCESS_TOKEN')
      expect(savedAccessToken).toBe(accessToken)
    })

    it('should set refresh token cookie', () => {
      const accessToken = 'test-access-token'
      const refreshToken = 'test-refresh-token'

      setAuthTokens(accessToken, refreshToken)

      const savedRefreshToken = getAuthToken('REFRESH_TOKEN')
      expect(savedRefreshToken).toBe(refreshToken)
    })
  })

  describe('getAuthToken', () => {
    it('should return null when token does not exist', () => {
      const token = getAuthToken('ACCESS_TOKEN')
      expect(token).toBeNull()
    })

    it('should return token when it exists', () => {
      const accessToken = 'test-access-token'
      const refreshToken = 'test-refresh-token'

      setAuthTokens(accessToken, refreshToken)

      const savedToken = getAuthToken('ACCESS_TOKEN')
      expect(savedToken).toBe(accessToken)
    })
  })

  describe('clearAuthTokens', () => {
    it('should clear all auth tokens', () => {
      const accessToken = 'test-access-token'
      const refreshToken = 'test-refresh-token'

      setAuthTokens(accessToken, refreshToken)

      // トークンが保存されていることを確認
      expect(getAuthToken('ACCESS_TOKEN')).toBe(accessToken)
      expect(getAuthToken('REFRESH_TOKEN')).toBe(refreshToken)

      // クリア
      clearAuthTokens()

      // トークンが削除されていることを確認
      expect(getAuthToken('ACCESS_TOKEN')).toBeNull()
      expect(getAuthToken('REFRESH_TOKEN')).toBeNull()
    })
  })

  describe('AUTH_COOKIE_NAMES', () => {
    it('should have correct cookie names', () => {
      expect(AUTH_COOKIE_NAMES.ACCESS_TOKEN).toBe('access_token')
      expect(AUTH_COOKIE_NAMES.REFRESH_TOKEN).toBe('refresh_token')
    })
  })
})
