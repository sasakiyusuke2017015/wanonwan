import { defineConfig } from 'vitest/config'
import { storybookTest } from '@storybook/addon-vitest/vitest-plugin'
import { playwright } from '@vitest/browser-playwright'
import react from '@vitejs/plugin-react'
import path from 'path'

const alias = [
  { find: '@ui-catalog/core', replacement: path.resolve(__dirname, '../../packages/ui-catalog') },
  { find: '@1on1/layouts', replacement: path.resolve(__dirname, './src/layouts') },
  { find: '@1on1/domain', replacement: path.resolve(__dirname, '../../libs/domain') },
  { find: '@', replacement: path.resolve(__dirname, './src') },
]

// packages/ui-catalog からの外部依存を apps/web の node_modules で解決
const dedupe = [
  'react',
  'react-dom',
  'framer-motion',
  'clsx',
  'tailwind-merge',
]

export default defineConfig({
  plugins: [react()],
  test: {
    projects: [
      // 既存の単体テスト
      {
        test: {
          name: 'unit',
          environment: 'jsdom',
          globals: true,
          setupFiles: ['./src/__tests__/setup.ts'],
          testTimeout: 30000,
          hookTimeout: 30000,
          pool: 'forks',
          fileParallelism: false,
          maxWorkers: 1,
          include: ['src/**/*.test.{ts,tsx}'],
          exclude: [
            '**/node_modules/**',
            '**/dist/**',
            '**/e2e/**',
            '**/*.spec.ts',
            '**/*.e2e.ts',
            '**/GradientOverlay.test.tsx',
          ],
        },
        resolve: { alias, dedupe },
      },
      // Storybook テスト
      {
        extends: './vite.config.ts',
        plugins: [
          storybookTest({
            configDir: '.storybook',
          }),
        ],
        test: {
          name: 'storybook',
          browser: {
            enabled: true,
            provider: playwright({ launch: { args: ['--no-sandbox'] } }),
            instances: [{ browser: 'chromium' }],
            headless: true,
          },
          setupFiles: ['.storybook/vitest.setup.ts'],
        },
        resolve: { alias, dedupe },
      },
    ],
  },
  resolve: { alias, dedupe },
})
