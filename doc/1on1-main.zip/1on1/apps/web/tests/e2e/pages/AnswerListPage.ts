import { expect } from '@playwright/test'
import { BasePage } from './BasePage'

/**
 * 回答一覧ページ
 */
export class AnswerListPage extends BasePage {
  /**
   * 回答一覧に遷移
   */
  async goto(): Promise<void> {
    await this.page.goto('/answers')
    await this.waitForPageLoad()
  }

  /**
   * ページが表示されていることを確認
   */
  async expectToBeVisible(): Promise<void> {
    await this.expectHeaderText('回答一覧')
  }

  /**
   * テーブルが表示されていることを確認
   */
  async expectTableVisible(): Promise<void> {
    await expect(this.page.locator('table').first()).toBeVisible({ timeout: 5000 })
  }

  /**
   * テーブルの行数を取得
   */
  async getRowCount(): Promise<number> {
    const rows = this.page.locator('table tbody tr')
    return await rows.count()
  }

  /**
   * 最初の行をクリック
   */
  async clickFirstRow(): Promise<void> {
    await this.page.locator('table tbody tr').first().click()
  }

  /**
   * ユーザーメニューを開く
   */
  async openUserMenu(): Promise<void> {
    // ヘッダー内のユーザー名ボタン（DropdownMenuのトリガー）をクリック
    // DropdownMenuはbutton要素でユーザー名を含む
    const userMenuButton = this.page.locator('header button').filter({ hasText: /.*/ }).last()
    await userMenuButton.click()
    // メニューが開くのを待つ
    await this.page.waitForTimeout(300)
  }

  /**
   * ログアウトをクリック
   */
  async clickLogout(): Promise<void> {
    await this.openUserMenu()
    // ログアウトメニュー項目をクリック
    await this.page.click('text=ログアウト')
    // ログアウト処理完了とリダイレクトを待つ
    await this.page.waitForURL(/\/login/, { timeout: 10000 })
  }

  /**
   * ログインページにリダイレクトされることを確認
   */
  async expectRedirectToLogin(): Promise<void> {
    await expect(this.page).toHaveURL(/\/login/)
  }
}
