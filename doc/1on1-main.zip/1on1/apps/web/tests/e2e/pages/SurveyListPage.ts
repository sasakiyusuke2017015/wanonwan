import { expect } from '@playwright/test'
import { BasePage } from './BasePage'

/**
 * アンケート一覧ページ
 */
export class SurveyListPage extends BasePage {
  /**
   * アンケート一覧に遷移
   */
  async goto(): Promise<void> {
    await this.page.goto('/surveys')
    await this.waitForPageLoad()
  }

  /**
   * ページが表示されていることを確認
   */
  async expectToBeVisible(): Promise<void> {
    await this.expectHeaderText('アンケート一覧')
  }

  /**
   * 開催中のアンケートセクションが表示されていることを確認
   */
  async expectActiveSection(): Promise<void> {
    await expect(this.page.locator('text=開催中のアンケート').first()).toBeVisible()
  }

  /**
   * 最初のアンケートリンクをクリック
   * @returns アンケートIDまたはnull（アンケートがない場合）
   */
  async clickFirstSurvey(): Promise<string | null> {
    const surveyLink = this.page.locator('a[href*="/surveys/"]').first()
    const isVisible = await surveyLink.isVisible({ timeout: 3000 }).catch(() => false)

    if (!isVisible) {
      return null
    }

    const href = await surveyLink.getAttribute('href')
    const surveyId = href?.match(/\/surveys\/(\d+)/)?.[1] || null

    await surveyLink.click()
    return surveyId
  }

  /**
   * 指定したアンケートをクリック
   */
  async clickSurveyById(surveyId: string): Promise<void> {
    await this.page.click(`a[href*="/surveys/${surveyId}"]`)
    await this.waitForNavigation(/\/surveys\/\d+/)
  }
}
