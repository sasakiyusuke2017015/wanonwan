import { expect } from '@playwright/test'
import { BasePage } from './BasePage'

/**
 * アンケート詳細ページ（回答・確認・送信完了）
 */
export class SurveyDetailPage extends BasePage {
  // セレクタ
  private readonly confirmButton = 'button:has-text("確認画面へ")'
  private readonly submitButton = 'button:has-text("送信")'
  private readonly backButton = 'button:has-text("戻る")'

  /**
   * アンケート詳細ページに遷移（編集モード）
   */
  async goto(surveyId: string): Promise<void> {
    await this.page.goto(`/surveys/${surveyId}?mode=edit`)
    await this.waitForPageLoad()
  }

  /**
   * アンケート回答ページが表示されていることを確認
   */
  async expectEditMode(): Promise<void> {
    await this.expectHeaderText('アンケート回答')
  }

  /**
   * アンケート確認ページが表示されていることを確認
   */
  async expectPreviewMode(): Promise<void> {
    await this.expectHeaderText('アンケート確認')
  }

  /**
   * 送信完了ページが表示されていることを確認
   */
  async expectSuccessMode(): Promise<void> {
    await expect(this.page).toHaveURL(/mode=success/, { timeout: 10000 })
  }

  /**
   * ラジオボタンで回答を選択
   */
  async selectRadioOption(questionIndex: number, optionIndex: number): Promise<void> {
    // 質問グループを取得してn番目のラジオボタンを選択
    const radioButtons = this.page.locator('input[type="radio"]')
    const targetRadio = radioButtons.nth(questionIndex * 5 + optionIndex) // 5選択肢想定
    await targetRadio.click()
  }

  /**
   * テキストエリアに回答を入力
   */
  async fillTextarea(placeholder: string, text: string): Promise<void> {
    await this.page.fill(`textarea[placeholder*="${placeholder}"]`, text)
  }

  /**
   * 全ての必須ラジオボタンを選択（最初の選択肢を選ぶ）
   */
  async fillAllRadioQuestions(): Promise<void> {
    // 未選択のラジオボタングループを見つけて最初の選択肢を選ぶ
    const radioGroups = this.page.locator('[role="radiogroup"], fieldset')
    const count = await radioGroups.count()

    for (let i = 0; i < count; i++) {
      const group = radioGroups.nth(i)
      const firstRadio = group.locator('input[type="radio"]').first()
      const isVisible = await firstRadio.isVisible().catch(() => false)
      if (isVisible) {
        const isChecked = await firstRadio.isChecked()
        if (!isChecked) {
          await firstRadio.click()
        }
      }
    }
  }

  /**
   * 全てのラジオボタンを選択（3番目=普通を選ぶ）
   */
  async fillAllRadioQuestionsWithMiddle(): Promise<void> {
    const radioGroups = this.page.locator('[role="radiogroup"]')
    const count = await radioGroups.count()

    for (let i = 0; i < count; i++) {
      const group = radioGroups.nth(i)
      // 3番目（中央）のオプションを選択
      const middleRadio = group.locator('input[type="radio"]').nth(2)
      const isVisible = await middleRadio.isVisible().catch(() => false)
      if (isVisible) {
        await middleRadio.click()
      }
    }
  }

  /**
   * 確認画面へボタンをクリック
   */
  async clickConfirm(): Promise<void> {
    await this.page.click(this.confirmButton)
    await this.page.waitForURL(/mode=preview/, { timeout: 10000 })
  }

  /**
   * 送信ボタンをクリック
   */
  async clickSubmit(): Promise<void> {
    await this.page.click(this.submitButton)
  }

  /**
   * 戻るボタンをクリック
   */
  async clickBack(): Promise<void> {
    await this.page.click(this.backButton)
  }

  /**
   * AI分析中のステップインジケーターが表示されていることを確認
   */
  async expectAiAnalyzingStep(): Promise<void> {
    // ステップインジケーターの「AI分析中」が in_progress 状態であることを確認
    await expect(this.page.locator('text=AI分析中').first()).toBeVisible({ timeout: 5000 })
  }

  /**
   * 完了ステップが表示されていることを確認
   */
  async expectCompletedStep(): Promise<void> {
    await expect(this.page.locator('text=完了').first()).toBeVisible({ timeout: 30000 })
  }

  /**
   * 送信完了メッセージが表示されていることを確認
   */
  async expectSuccessMessage(): Promise<void> {
    await expect(
      this.page.locator('text=送信完了').first()
    ).toBeVisible({ timeout: 30000 })
  }

  /**
   * バリデーションエラーが表示されていることを確認
   */
  async expectValidationError(): Promise<void> {
    // 赤いエラーメッセージまたはエラー表示を確認
    await expect(
      this.page.locator('.text-red-500, .text-destructive, [role="alert"]').first()
    ).toBeVisible({ timeout: 5000 })
  }

  /**
   * 確認画面へボタンが無効化されていることを確認
   */
  async expectConfirmButtonDisabled(): Promise<void> {
    await expect(this.page.locator(this.confirmButton)).toBeDisabled()
  }
}
