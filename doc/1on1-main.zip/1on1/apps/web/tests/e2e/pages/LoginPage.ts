import { expect } from '@playwright/test'
import { BasePage } from './BasePage'

/**
 * ログインページ
 */
export class LoginPage extends BasePage {
  // セレクタ
  private readonly usernameInput = 'input[name="username"]'
  private readonly passwordInput = 'input[name="password"]'
  private readonly submitButton = 'button[type="submit"]'
  private readonly errorMessage = '.bg-red-50'

  /**
   * ログインページに遷移
   */
  async goto(): Promise<void> {
    await this.page.goto('/login')
    await this.waitForPageLoad()
  }

  /**
   * ユーザー名を入力
   */
  async fillUsername(username: string): Promise<void> {
    await this.page.fill(this.usernameInput, username)
  }

  /**
   * パスワードを入力
   */
  async fillPassword(password: string): Promise<void> {
    await this.page.fill(this.passwordInput, password)
  }

  /**
   * ログインボタンをクリック
   */
  async submit(): Promise<void> {
    await this.page.click(this.submitButton)
  }

  /**
   * ログイン実行（成功時）
   */
  async login(username: string, password: string): Promise<void> {
    await this.fillUsername(username)
    await this.fillPassword(password)

    await Promise.all([
      this.page.waitForURL(/\/(dashboard|answers|home)/, { timeout: 15000 }),
      this.submit(),
    ])
  }

  /**
   * ログイン実行（失敗を想定）
   */
  async loginExpectFailure(username: string, password: string): Promise<void> {
    await this.fillUsername(username)
    await this.fillPassword(password)
    await this.submit()
  }

  /**
   * エラーメッセージが表示されることを確認
   */
  async expectErrorMessage(): Promise<void> {
    await expect(this.page.locator(this.errorMessage).first()).toBeVisible({
      timeout: 5000,
    })
  }

  /**
   * ログインページが表示されていることを確認
   */
  async expectToBeOnLoginPage(): Promise<void> {
    await expect(this.page).toHaveURL(/\/login/)
  }
}
