import { Page, Locator, expect } from '@playwright/test'

/**
 * ベースページクラス
 * 全ページ共通の機能を提供
 */
export abstract class BasePage {
  constructor(protected readonly page: Page) {}

  /**
   * ページが完全に読み込まれるまで待機
   */
  async waitForPageLoad(): Promise<void> {
    await this.page.waitForLoadState('networkidle')
  }

  /**
   * 指定したURLパターンに遷移するまで待機
   */
  async waitForNavigation(urlPattern: RegExp, timeout = 15000): Promise<void> {
    await this.page.waitForURL(urlPattern, { timeout })
  }

  /**
   * ヘッダーのテキストを確認
   */
  async expectHeaderText(text: string): Promise<void> {
    await expect(this.page.locator('header')).toContainText(text)
  }

  /**
   * 要素が表示されるまで待機して返す
   */
  async waitForElement(selector: string, timeout = 5000): Promise<Locator> {
    const element = this.page.locator(selector)
    await expect(element).toBeVisible({ timeout })
    return element
  }

  /**
   * ボタンをクリック
   */
  async clickButton(text: string): Promise<void> {
    await this.page.getByRole('button', { name: text }).click()
  }

  /**
   * リンクをクリック
   */
  async clickLink(text: string): Promise<void> {
    await this.page.getByRole('link', { name: text }).click()
  }

  /**
   * 現在のURLを取得
   */
  get currentUrl(): string {
    return this.page.url()
  }
}
