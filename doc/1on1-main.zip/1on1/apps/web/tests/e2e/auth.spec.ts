import { test, expect } from '@playwright/test'
import { login, TEST_EMAIL, TEST_PASSWORD } from './helpers'
import { LoginPage, AnswerListPage } from './pages'

test.describe('認証フロー', () => {
  test('未認証時はログインページにリダイレクトされる', async ({ page }) => {
    await page.goto('/answers')
    await expect(page).toHaveURL(/\/login/)
  })

  test('ログイン成功後に回答一覧に遷移', async ({ page }) => {
    const loginPage = new LoginPage(page)
    await loginPage.goto()
    await loginPage.login(TEST_EMAIL, TEST_PASSWORD)

    // 回答一覧ページが表示されることを確認
    await expect(page.locator('header')).toContainText('回答一覧')
  })

  test('無効な認証情報でログイン失敗', async ({ page }) => {
    const loginPage = new LoginPage(page)
    await loginPage.goto()
    await loginPage.loginExpectFailure('invalid@example.com', 'wrongpassword')
    await loginPage.expectErrorMessage()
  })

  test('ログアウト後はログインページにリダイレクトされる', async ({ page }) => {
    // まずログイン
    await login(page)

    // 回答一覧ページが表示されることを確認
    const answerListPage = new AnswerListPage(page)
    await answerListPage.expectToBeVisible()

    // ログアウト
    await answerListPage.clickLogout()

    // ログインページにリダイレクトされることを確認
    await answerListPage.expectRedirectToLogin()
  })

  test('ログアウト後に保護されたページにアクセスできない', async ({ page }) => {
    // まずログイン
    await login(page)

    // ログアウト
    const answerListPage = new AnswerListPage(page)
    await answerListPage.clickLogout()

    // 保護されたページに直接アクセス
    await page.goto('/answers')

    // ログインページにリダイレクトされることを確認
    await expect(page).toHaveURL(/\/login/)
  })
})
