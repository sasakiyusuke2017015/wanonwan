import { test, expect } from '@playwright/test'
import { login } from './helpers'

test.describe('アンケート機能', () => {
  test.beforeEach(async ({ page }) => {
    await login(page)
  })

  test('アンケート一覧が表示される', async ({ page }) => {
    await page.goto('/surveys')
    await page.waitForLoadState('networkidle')

    // ヘッダーにページタイトルを確認
    await expect(page.locator('header')).toContainText('アンケート一覧')

    // セクションタイトルが表示されることを確認
    await expect(page.locator('text=開催中のアンケート').first()).toBeVisible()
  })

  test('アンケート詳細ページに遷移できる', async ({ page }) => {
    await page.goto('/surveys')
    await page.waitForLoadState('networkidle')

    // アンケートリンクを探す
    const surveyLink = page.locator('a[href*="/surveys/"]').first()
    const isVisible = await surveyLink.isVisible({ timeout: 3000 }).catch(() => false)

    if (!isVisible) {
      test.skip()
      return
    }

    await surveyLink.click()

    // URLがsurveys/[id]形式になることを確認
    await expect(page).toHaveURL(/\/surveys\//, { timeout: 5000 })
  })
})
