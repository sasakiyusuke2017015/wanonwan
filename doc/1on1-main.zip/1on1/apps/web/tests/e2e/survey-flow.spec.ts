import { test, expect } from '@playwright/test'
import { login, TEST_SURVEY_ID } from './helpers'
import { SurveyDetailPage, SurveyListPage } from './pages'

test.describe('アンケート回答フルフロー', () => {
  test.beforeEach(async ({ page }) => {
    await login(page)
  })

  test('アンケート回答 → 確認 → 送信 → AI分析中 → 完了の全フロー', async ({ page }) => {
    const surveyDetailPage = new SurveyDetailPage(page)
    let surveyId = TEST_SURVEY_ID

    // TEST_SURVEY_IDが未設定の場合、一覧から最初のアンケートを選択
    if (!surveyId) {
      const surveyListPage = new SurveyListPage(page)
      await surveyListPage.goto()

      const foundId = await surveyListPage.clickFirstSurvey()
      if (!foundId) {
        test.skip(true, '利用可能なアンケートがありません')
        return
      }
      surveyId = foundId
    }

    // 1. 編集モードでアンケートを開く
    await surveyDetailPage.goto(surveyId)
    await surveyDetailPage.expectEditMode()

    // 2. 全ての質問に回答（中央の選択肢を選ぶ）
    await surveyDetailPage.fillAllRadioQuestionsWithMiddle()

    // 3. 確認画面へ遷移
    await surveyDetailPage.clickConfirm()
    await surveyDetailPage.expectPreviewMode()

    // 4. 送信
    await surveyDetailPage.clickSubmit()

    // 5. 成功画面に遷移することを確認
    await surveyDetailPage.expectSuccessMode()

    // 6. AI分析中のステップが表示されることを確認（ストリーミング中）
    // 注: AI分析がスキップされる場合もあるため、成功画面の表示を優先確認
    await surveyDetailPage.expectSuccessMessage()
  })

  test('確認画面から編集画面に戻れる', async ({ page }) => {
    const surveyDetailPage = new SurveyDetailPage(page)
    let surveyId = TEST_SURVEY_ID

    if (!surveyId) {
      const surveyListPage = new SurveyListPage(page)
      await surveyListPage.goto()

      const foundId = await surveyListPage.clickFirstSurvey()
      if (!foundId) {
        test.skip(true, '利用可能なアンケートがありません')
        return
      }
      surveyId = foundId
    }

    // 編集モードで開く
    await surveyDetailPage.goto(surveyId)
    await surveyDetailPage.expectEditMode()

    // 回答して確認画面へ
    await surveyDetailPage.fillAllRadioQuestionsWithMiddle()
    await surveyDetailPage.clickConfirm()
    await surveyDetailPage.expectPreviewMode()

    // 戻るボタンで編集画面に戻る
    await surveyDetailPage.clickBack()
    await surveyDetailPage.expectEditMode()

    // 回答が保持されていることを確認（戻った後も入力値が消えていない）
    const checkedRadios = page.locator('input[type="radio"]:checked')
    const checkedCount = await checkedRadios.count()
    expect(checkedCount).toBeGreaterThan(0)
  })

  test('未回答で確認画面へ進もうとするとエラーが表示される', async ({ page }) => {
    const surveyDetailPage = new SurveyDetailPage(page)
    let surveyId = TEST_SURVEY_ID

    if (!surveyId) {
      const surveyListPage = new SurveyListPage(page)
      await surveyListPage.goto()

      const foundId = await surveyListPage.clickFirstSurvey()
      if (!foundId) {
        test.skip(true, '利用可能なアンケートがありません')
        return
      }
      surveyId = foundId
    }

    // 編集モードで開く
    await surveyDetailPage.goto(surveyId)
    await surveyDetailPage.expectEditMode()

    // 回答せずに確認画面へボタンをクリック
    await page.click('button:has-text("確認画面へ")')

    // バリデーションエラーまたはボタンが無効のまま
    // 注: 実装によってはエラーメッセージが表示されるか、ボタンが無効化されている
    const hasError = await page.locator('.text-red-500, .text-destructive, [role="alert"]').first().isVisible().catch(() => false)
    const stillOnEditPage = await page.url().includes('mode=edit') || !page.url().includes('mode=preview')

    // エラーが表示されているか、まだ編集画面にいるかのどちらか
    expect(hasError || stillOnEditPage).toBe(true)
  })
})

test.describe('アンケート一覧からの遷移', () => {
  test.beforeEach(async ({ page }) => {
    await login(page)
  })

  test('アンケート一覧から詳細ページに遷移できる', async ({ page }) => {
    const surveyListPage = new SurveyListPage(page)
    await surveyListPage.goto()
    await surveyListPage.expectToBeVisible()
    await surveyListPage.expectActiveSection()

    const surveyId = await surveyListPage.clickFirstSurvey()
    if (!surveyId) {
      test.skip(true, '利用可能なアンケートがありません')
      return
    }

    // 詳細ページに遷移していることを確認
    await expect(page).toHaveURL(/\/surveys\/\d+/, { timeout: 5000 })
  })
})
