import { Page } from '@playwright/test'
import { LoginPage } from './pages'

// 環境変数のFail Fast チェック（将来の使用のため保持）
function _getRequiredEnv(name: string): string {
  const value = process.env[name]
  if (!value) {
    throw new Error(`Required environment variable ${name} is not set`)
  }
  return value
}

/**
 * テストユーザーの役職タイプ
 */
export type TestUserRole = 'employee' | 'section_head' | 'department_head' | 'admin'

/**
 * テストユーザー情報
 */
export interface TestUser {
  email: string
  password: string
  role: TestUserRole
  name: string
}

// 共通パスワード（全テストユーザー共通）
const COMMON_PASSWORD = process.env.TEST_PASSWORD || '123123123'

/**
 * 役職別テストユーザー
 * Pleasanter に登録済みのテストユーザー情報
 */
export const TEST_USERS: Record<TestUserRole, TestUser> = {
  employee: {
    email: process.env.TEST_EMAIL_EMPLOYEE || 'sdt.1@sms-datatech.co.jp',
    password: COMMON_PASSWORD,
    role: 'employee',
    name: 'テスト 一郎',
  },
  section_head: {
    email: process.env.TEST_EMAIL_SECTION_HEAD || 'sdt.2@sms-datatech.co.jp',
    password: COMMON_PASSWORD,
    role: 'section_head',
    name: 'テスト 二郎',
  },
  department_head: {
    email: process.env.TEST_EMAIL_DEPARTMENT_HEAD || 'sdt.3@sms-datatech.co.jp',
    password: COMMON_PASSWORD,
    role: 'department_head',
    name: 'テスト 三郎',
  },
  admin: {
    email: process.env.TEST_EMAIL_ADMIN || 'sdt.4@sms-datatech.co.jp',
    password: COMMON_PASSWORD,
    role: 'admin',
    name: 'テスト 四郎',
  },
}

// デフォルトのテスト認証情報（一般社員）
export const TEST_EMAIL = TEST_USERS.employee.email
export const TEST_PASSWORD = COMMON_PASSWORD

// テスト用アンケートID（環境変数で指定可能）
export const TEST_SURVEY_ID = process.env.TEST_SURVEY_ID || ''

/**
 * 指定した役職のテストユーザーでログイン
 * @param page Playwright Page
 * @param role ログインする役職（デフォルト: employee）
 */
export async function login(page: Page, role: TestUserRole = 'employee'): Promise<void> {
  const user = TEST_USERS[role]
  const loginPage = new LoginPage(page)
  await loginPage.goto()
  await loginPage.login(user.email, user.password)
}

/**
 * 指定したテストユーザー情報でログイン
 * @param page Playwright Page
 * @param user テストユーザー情報
 */
export async function loginAs(page: Page, user: TestUser): Promise<void> {
  const loginPage = new LoginPage(page)
  await loginPage.goto()
  await loginPage.login(user.email, user.password)
}
