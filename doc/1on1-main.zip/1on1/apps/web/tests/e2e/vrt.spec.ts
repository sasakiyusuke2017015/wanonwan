import { test, expect, Page } from '@playwright/test'

/**
 * Visual Regression Tests (VRT)
 * - ページ単位のスクリーンショット比較
 * - 機能テスト(E2E)とは分離して管理
 */

// 環境変数のFail Fast チェック（認証が必要なテスト用）
function getRequiredEnv(name: string): string {
  const value = process.env[name]
  if (!value) {
    throw new Error(`Required environment variable ${name} is not set`)
  }
  return value
}

// ログインヘルパー（VRT専用）
async function login(page: Page): Promise<void> {
  const testEmail = getRequiredEnv('TEST_EMAIL')
  const testPassword = getRequiredEnv('TEST_PASSWORD')

  await page.goto('/login')
  await page.waitForLoadState('networkidle')
  await page.waitForSelector('input[name="username"]', { timeout: 10000 })
  await page.fill('input[name="username"]', testEmail)
  await page.fill('input[name="password"]', testPassword)

  await Promise.all([
    page.waitForURL(/\/(dashboard|answers|home)/, { timeout: 15000 }),
    page.click('button[type="submit"]'),
  ])
}

test.describe('Visual Regression Tests - 未認証', () => {
  test('ログインページ', async ({ page }) => {
    await page.goto('/login')
    await page.waitForLoadState('networkidle')
    await expect(page).toHaveScreenshot('login.png')
  })
})

test.describe('Visual Regression Tests - 認証後', () => {
  test.beforeEach(async ({ page }) => {
    await login(page)
  })

  test('ダッシュボード', async ({ page }) => {
    await page.goto('/dashboard')
    await page.waitForLoadState('networkidle')
    await expect(page).toHaveScreenshot('dashboard.png')
  })

  test('アンケート一覧', async ({ page }) => {
    await page.goto('/surveys')
    await page.waitForLoadState('networkidle')
    await expect(page).toHaveScreenshot('surveys.png')
  })

  test('回答一覧', async ({ page }) => {
    await page.goto('/answers')
    await page.waitForLoadState('networkidle')
    await expect(page).toHaveScreenshot('answers.png', { timeout: 15000 })
  })
})
