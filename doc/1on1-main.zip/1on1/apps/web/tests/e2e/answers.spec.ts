import { test, expect } from '@playwright/test'
import { login } from './helpers'

test.describe('回答管理機能', () => {
  test.beforeEach(async ({ page }) => {
    await login(page)
  })

  test('回答一覧が表示される', async ({ page }) => {
    await page.goto('/answers')
    await page.waitForLoadState('networkidle')

    // ヘッダーにページタイトルを確認
    await expect(page.locator('header')).toContainText('回答一覧')

    // テーブルローディングが完了するまで待機
    await expect(page.locator('[data-component="loading-zone"][data-variant="table"]')).toBeHidden({
      timeout: 30000,
    })

    // テーブルが表示されるまで待機
    await expect(page.locator('table').first()).toBeVisible({
      timeout: 5000,
    })
  })
})
