// src/pages/Login/types.ts

import type { LoginButtonState } from '@ui-catalog/core/organisms';

/**
 * ログインページのモード
 */
export type LoginPageMode = 'login' | 'password-reset' | 'confirmation';

/**
 * ログインフォームの状態
 */
export interface LoginFormState {
  username: string;
  password: string;
  error: string;
  loading: boolean;
  showPassword: boolean;
  rememberMe: boolean;
  loginButtonState: LoginButtonState;
}

/**
 * ログインレイアウトのProps
 */
export interface LoginLayoutProps {
  // モード
  mode: LoginPageMode;

  // ログインフォーム状態
  username: string;
  password: string;
  error: string;
  loading: boolean;
  showPassword: boolean;
  rememberMe: boolean;
  loginButtonState: LoginButtonState;

  // パスワードリセット状態
  employeeId: string;

  // ログインイベントハンドラー
  onUsernameChange: (value: string) => void;
  onPasswordChange: (value: string) => void;
  onShowPasswordToggle: () => void;
  onRememberMeChange: (checked: boolean) => void;
  onLoginSubmit: (e: React.FormEvent<HTMLFormElement>) => void;

  // パスワードリセットイベントハンドラー
  onEmployeeIdChange: (value: string) => void;
  onPasswordResetSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
}

/**
 * ログイン結果
 */
export interface LoginResult {
  success: boolean;
  error?: string;
}

/**
 * パスワードリセットAPI レスポンス
 */
export interface PasswordResetResponse {
  success: boolean;
  message?: string;
  error?: string;
}
