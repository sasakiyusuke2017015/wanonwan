// src/pages/Login/index.tsx

import { useState, useEffect, useMemo, FormEvent, useCallback } from 'react';

// Jotai は使わず localStorage を直接操作（atomWithStorage の上書き問題を回避）
import { useLocation, useSearchParams } from 'react-router-dom';

import { type LoginButtonState } from '@ui-catalog/core/organisms';
import { ROUTES } from '@/constants/routes';
import { useAuth } from '@/adapters/AuthContext';

import {
  getAndClearAuthErrorMessage,
  getFirstAllowedPath,
  requestPasswordReset,
} from './api';
import LoginLayout from './layout';

import type { LoginPageMode } from './types';

/**
 * ログイン/パスワードリセットページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 *
 * mode パラメータで画面を切り替え
 * - (なし): ログイン画面（デフォルト）
 * - password-reset: パスワードリセット入力画面
 * - confirmation: パスワードリセット完了画面
 */
export default function Login() {

  // ログインフォーム状態（初期値はlocalStorageから直接読み込み）
  const [username, setUsername] = useState(() => {
    const stored = localStorage.getItem('rememberedUsername');
    const rememberMeStored = localStorage.getItem('rememberMe');
    // rememberMe は 'true' または true（JSON）の両方に対応
    const isRemembered = rememberMeStored === 'true' || rememberMeStored === true.toString();
    if (isRemembered && stored) {
      try { return JSON.parse(stored); } catch { return ''; }
    }
    return '';
  });
  const [password, setPassword] = useState(() => {
    const stored = localStorage.getItem('rememberedPassword');
    const rememberMeStored = localStorage.getItem('rememberMe');
    const isRemembered = rememberMeStored === 'true' || rememberMeStored === true.toString();
    if (isRemembered && stored) {
      try { return JSON.parse(stored); } catch { return ''; }
    }
    return '';
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(() => {
    const stored = localStorage.getItem('rememberMe');
    return stored === 'true' || stored === true.toString();
  });
  const [loginButtonState, setLoginButtonState] = useState<LoginButtonState>('ready');

  // パスワードリセット状態
  const [employeeId, setEmployeeId] = useState('');

  const { login } = useAuth();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  // リダイレクト元のパス（セッション切れ時など）
  const redirectFrom = location.state?.from?.pathname;

  // URLパラメータからモードを取得（デフォルトはlogin）
  const mode: LoginPageMode = useMemo(() => {
    const modeParam = searchParams.get('mode');
    if (modeParam === 'password-reset') return 'password-reset';
    if (modeParam === 'confirmation') return 'confirmation';
    return 'login';
  }, [searchParams]);

  // ページタイトルを設定
  useEffect(() => {
    if (mode === 'confirmation') {
      document.title = 'パスワードリセット完了';
    } else if (mode === 'password-reset') {
      document.title = 'パスワードリセット';
    } else {
      document.title = ROUTES.LOGIN.label;
    }
  }, [mode]);

  // 保存されたログイン情報の読み込み（ログインモード時のみ）
  useEffect(() => {
    if (mode !== 'login') return;

    // セッション切れメッセージを確認
    const authErrorMessage = getAndClearAuthErrorMessage();
    if (authErrorMessage) {
      setError(authErrorMessage);
    }

    // 注意: ログイン情報の初期読み込みは useState の初期化関数で行う
    // useEffect では Jotai atom の非同期読み込みタイミングの問題で空値で上書きされるため
  }, [mode]);

  // ログイン情報を保存/クリア（localStorageに直接書き込み）
  const saveCredentials = useCallback((user: string, pass: string, remember: boolean) => {
    if (remember) {
      localStorage.setItem('rememberedUsername', JSON.stringify(user));
      localStorage.setItem('rememberedPassword', JSON.stringify(pass));
      localStorage.setItem('rememberMe', JSON.stringify(true));
    } else {
      localStorage.setItem('rememberedUsername', JSON.stringify(''));
      localStorage.setItem('rememberedPassword', JSON.stringify(''));
      localStorage.setItem('rememberMe', JSON.stringify(false));
    }
  }, []);

  // ログインフォーム送信
  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // ブラウザのパスワード保存検出のため、送信時は type="password" に戻す
    setShowPassword(false);
    setError('');
    setLoading(true);
    setLoginButtonState('authenticating');

    // Loading開始時刻を記録
    const loadingStartTime = Date.now();
    const MIN_LOADING_DURATION = 1000; // 最低1秒間Loading表示

    try {
      const result = await login(username, password);
      if (result.success) {
        // ログイン成功アニメーションを開始
        setLoginButtonState('authenticated');

        // ログイン成功時の記憶機能処理
        saveCredentials(username, password, rememberMe);

        // 最低Loading時間を確保
        const elapsedTime = Date.now() - loadingStartTime;
        const remainingTime = Math.max(0, MIN_LOADING_DURATION - elapsedTime);

        // ログイン結果からユーザー情報を取得してリダイレクト先を決定
        const loggedInUser = result.user;
        // パスワード変更が必要な場合は変更画面へ誘導
        const targetPath = result.requirePasswordChange
          ? '/change-password'
          : getFirstAllowedPath(loggedInUser, redirectFrom);

        setTimeout(() => {
          setLoading(false);
          // アニメーション後にフルページリロードで遷移（ブラウザのパスワード保存を発動させる）
          setTimeout(() => {
            window.location.href = targetPath;
          }, 1000);
        }, remainingTime);
      } else {
        // エラー時は最低Loading時間を確保してメッセージ表示
        const errorMessage = result.error || 'ログインに失敗しました';
        const elapsedTime = Date.now() - loadingStartTime;
        const remainingTime = Math.max(0, MIN_LOADING_DURATION - elapsedTime);

        setTimeout(() => {
          setLoading(false);
          setLoginButtonState('ready');
          setError(errorMessage);
        }, remainingTime);
      }
    } catch {
      // エラー時も最低Loading時間を確保
      const elapsedTime = Date.now() - loadingStartTime;
      const remainingTime = Math.max(0, MIN_LOADING_DURATION - elapsedTime);

      setTimeout(() => {
        setLoading(false);
        setLoginButtonState('ready');
        setError('認証中にエラーが発生しました');
      }, remainingTime);
    }
  };

  // パスワードリセットフォーム送信
  const handlePasswordResetSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    try {
      const result = await requestPasswordReset(employeeId);

      if (result.success) {
        // 確認画面へ遷移（クエリパラメータを変更）
        setSearchParams({ mode: 'confirmation' });
      } else {
        window.alert(result.error || 'パスワードリセットに失敗しました。');
      }
    } catch (error) {
      window.console.error('Password reset error:', error);
      window.alert('パスワードリセットに失敗しました。');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LoginLayout
      mode={mode}
      username={username}
      password={password}
      error={error}
      loading={loading}
      showPassword={showPassword}
      rememberMe={rememberMe}
      loginButtonState={loginButtonState}
      employeeId={employeeId}
      onUsernameChange={setUsername}
      onPasswordChange={setPassword}
      onShowPasswordToggle={() => setShowPassword(!showPassword)}
      onRememberMeChange={setRememberMe}
      onLoginSubmit={handleLoginSubmit}
      onEmployeeIdChange={setEmployeeId}
      onPasswordResetSubmit={handlePasswordResetSubmit}
    />
  );
}
