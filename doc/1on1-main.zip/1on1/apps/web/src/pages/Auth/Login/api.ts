// src/pages/Login/api.ts

import { ROUTES, NAV_ROUTE_KEYS } from '@/constants/routes';
import { filterPermissions } from '@/utils/permissions';

import type { PasswordResetResponse } from './types';

/**
 * 認証エラーメッセージを取得・クリア
 */
export const getAndClearAuthErrorMessage = (): string | null => {
  const authErrorMessage = sessionStorage.getItem('auth_error_message');
  if (authErrorMessage) {
    sessionStorage.removeItem('auth_error_message');
    return authErrorMessage;
  }
  return null;
};

/**
 * 認可されたナビゲーションの一番上のパスを取得
 * LeftPaneと同じ順序でチェック
 * @param user ユーザー情報
 * @param redirectFrom リダイレクト元パス（権限があればこちらを優先）
 * @returns 認可されたパス（なければ '/'）
 */
export const getFirstAllowedPath = (
  user: Record<string, unknown> | null | undefined,
  redirectFrom?: string | null
): string => {
  const { allowedLinks } = filterPermissions(user);

  // リダイレクト元パスが許可されていればそちらを優先
  if (redirectFrom && allowedLinks.includes(redirectFrom)) {
    return redirectFrom;
  }

  for (const key of NAV_ROUTE_KEYS) {
    const route = ROUTES[key];
    if (allowedLinks.includes(route.path)) {
      return route.path;
    }
  }

  // 認可されたリンクがない場合はルートに戻る
  return '/';
};

/**
 * パスワードリセットリクエストを送信
 * @param employeeId メンバー番号
 */
export const requestPasswordReset = async (
  _employeeId: string
): Promise<PasswordResetResponse> => {
  // TODO: 実際のAPI呼び出しを実装

  // 仮の遅延処理（実際はAPI呼び出し）
  await new Promise((resolve) => setTimeout(resolve, 1000));

  return {
    success: true,
    message: 'パスワードリセットのメールを送信しました',
  };
};
