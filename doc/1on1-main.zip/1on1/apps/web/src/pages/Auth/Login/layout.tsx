// src/pages/Login/layout.tsx

import { Checkbox, Media } from '@ui-catalog/core/atoms';
import { Banner, Input, InternalLink } from '@ui-catalog/core/molecules';
import { AuthFormCard, LoginButton } from '@ui-catalog/core/organisms';

import type { LoginLayoutProps } from './types';

/**
 * ログイン/パスワードリセットページレイアウト
 * 2カラムレイアウト（左: ブランディング、右: フォーム）
 * modeパラメータで表示内容を切り替え
 */
const LoginLayout = ({
  mode,
  username,
  password,
  error,
  loading,
  showPassword,
  rememberMe,
  loginButtonState,
  employeeId: _employeeId,
  onUsernameChange,
  onPasswordChange,
  onShowPasswordToggle,
  onRememberMeChange,
  onLoginSubmit,
  onEmployeeIdChange: _onEmployeeIdChange,
  onPasswordResetSubmit: _onPasswordResetSubmit,
}: LoginLayoutProps) => {
  const isPasswordResetMode = mode === 'password-reset';
  const isConfirmationMode = mode === 'confirmation';

  // 左側のタイトル・サブテキスト
  const getLeftContent = () => {
    if (isConfirmationMode) {
      return {
        title: 'メールを確認してください',
        subtitle: 'リセット手順をお送りしました',
      };
    }
    if (isPasswordResetMode) {
      return {
        title: 'パスワードをお忘れですか？',
        subtitle: 'メンバー番号を入力してリセット',
      };
    }
    return {
      title: '1on1へようこそ',
      subtitle: '効果的な1on1ミーティングを実現',
    };
  };

  const leftContent = getLeftContent();

  // ログインフォーム
  const loginForm = (
    <>
      <div>
        <h2 className="text-fluid-2xl font-bold text-slate-800">ログイン</h2>
        <p className="mt-2 text-fluid-sm text-slate-500">
          アカウント情報を入力してください
        </p>
      </div>

      <form className="space-y-4 sm:space-y-6" onSubmit={onLoginSubmit}>
        <input type="hidden" name="remember" value="true" />
        <div className="space-y-4">
          <Input
            id="username"
            name="username"
            type="text"
            autoComplete="username"
            required
            placeholder="ユーザー名"
            value={username}
            onChange={(e) => onUsernameChange(e.target.value)}
            disabled={loading}
            size="large"
          />
          <Input
            id="password"
            name="password"
            type={showPassword ? 'text' : 'password'}
            autoComplete="current-password"
            required
            placeholder="パスワード"
            value={password}
            onChange={(e) => onPasswordChange(e.target.value)}
            disabled={loading}
            size="large"
            icon={showPassword ? 'eye-slashed' : 'eye'}
            iconPosition="right"
            onIconClick={onShowPasswordToggle}
          />
        </div>

        <div className="flex items-center justify-between">
          <Checkbox
            id="remember-me"
            name="remember-me"
            checked={rememberMe}
            onChange={(e) => onRememberMeChange(e.target.checked)}
            label="ログイン情報を記憶"
            size="large"
          />
          <InternalLink
            href="/login?mode=password-reset"
            showIcon={false}
            disableScale
          >
            パスワードを忘れた場合
          </InternalLink>
        </div>

        {error && (
          <Banner
            variant="error"
            message={
              error.split(/(ss-kikaku@sms-datatech\.co\.jp)/).map((part, i) =>
                part === 'ss-kikaku@sms-datatech.co.jp' ? (
                  <a key={i} href="mailto:ss-kikaku@sms-datatech.co.jp" className="underline hover:text-red-600">
                    {part}
                  </a>
                ) : part
              )
            }
          />
        )}

        <LoginButton
          type="submit"
          state={loginButtonState}
          variant="primary"
          fullWidth={true}
          disabled={loading}
          loading={loading}
          loadingText="認証中..."
        >
          {loginButtonState === 'authenticated'
            ? '認証完了'
            : 'ログイン'}
        </LoginButton>
      </form>
    </>
  );

  // パスワードリセット案内画面
  const passwordResetForm = (
    <>
      <div>
        <h2 className="text-fluid-2xl font-bold text-slate-800">パスワードをお忘れですか？</h2>
        <p className="mt-4 text-fluid-base leading-relaxed text-slate-600">
          パスワードのリセットは管理者が行います。
          <br />
          下記メールアドレスへご連絡ください。
        </p>
      </div>

      <div className="rounded-md bg-blue-50 p-6 text-center">
        <p className="text-fluid-sm text-slate-600 mb-2">お問い合わせ先</p>
        <a
          href="mailto:ss-kikaku@sms-datatech.co.jp"
          className="text-fluid-base font-medium text-blue-600 hover:text-blue-800 underline"
        >
          ss-kikaku@sms-datatech.co.jp
        </a>
      </div>

      <div className="text-center">
        <InternalLink href="/login" showIcon={false} disableScale>
          ログイン画面へ戻る
        </InternalLink>
      </div>
    </>
  );

  // 右側コンテンツの選択
  const getRightContent = () => {
    if (isPasswordResetMode || isConfirmationMode) return passwordResetForm;
    return loginForm;
  };

  // password-resetはindigo、それ以外はteal
  const getThemeClasses = () => {
    if (isPasswordResetMode) {
      return {
        gradient: 'bg-gradient-to-br from-indigo-600 to-indigo-700',
        subtitle: 'text-indigo-200',
        footer: 'text-indigo-300',
      };
    }
    return {
      gradient: 'bg-gradient-to-br from-teal-500 to-teal-600',
      subtitle: 'text-teal-100',
      footer: 'text-teal-200',
    };
  };
  const themeClasses = getThemeClasses();

  return (
    <div className="flex min-h-screen">

      {/* デスクトップ: 左側ブランディングパネル */}
      <div className={`hidden md:flex md:w-1/2 flex-col justify-between ${themeClasses.gradient} p-12`}>
        <div>
          <Media
            src="/images/logo_login.png"
            alt="ロゴ"
            height={40}
          />
        </div>
        <div className="flex flex-col items-center justify-center flex-1">
          <Media
            src="/images/character_1on1_stand_1.jpg"
            alt="キャラクター"
            height={240}
            className="rounded-2xl shadow-lg mb-8"
          />
          <h1 className="text-fluid-2xl font-bold text-white">{leftContent.title}</h1>
          <p className={`${themeClasses.subtitle} mt-2`}>{leftContent.subtitle}</p>
        </div>
      </div>

      {/* デスクトップ: 右側フォーム */}
      <div className="hidden md:flex w-full md:w-1/2 flex-col justify-between bg-white px-4 py-12 sm:px-6 lg:px-4">
        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-lg space-y-8">
            {getRightContent()}
          </div>
        </div>
        <div className="text-fluid-sm text-black text-right">
          © 2026 SMS DataTech
        </div>
      </div>

      {/* モバイル: グラデーション背景 + カード型フォーム */}
      <div className={`md:hidden flex flex-col min-h-screen w-full ${themeClasses.gradient}`}>
        {/* ヘッダー: ロゴ + キャラクター + タイトル */}
        <div className="flex flex-col items-center px-6 pt-8 pb-4">
          <Media
            src="/images/logo_login.png"
            alt="ロゴ"
            height={32}
            className="mb-4"
          />
          <Media
            src="/images/character_1on1_stand_1.jpg"
            alt="キャラクター"
            height={120}
            className="rounded-xl shadow-lg mb-4"
          />
          <h1 className="text-fluid-xl font-bold text-white">{leftContent.title}</h1>
          <p className={`${themeClasses.subtitle} mt-1 text-fluid-sm`}>{leftContent.subtitle}</p>
        </div>

        {/* フォームカード */}
        <AuthFormCard>
          {getRightContent()}
        </AuthFormCard>
      </div>
    </div>
  );
};

export default LoginLayout;
