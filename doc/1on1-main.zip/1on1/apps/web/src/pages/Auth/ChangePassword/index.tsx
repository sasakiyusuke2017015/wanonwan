// src/pages/ChangePassword/index.tsx

import { useState, FormEvent } from 'react';

import { useNavigate } from 'react-router-dom';

import { Media } from '@ui-catalog/core/atoms';
import { Banner, Button, Input } from '@ui-catalog/core/molecules';
import { AlertDialog } from '@ui-catalog/core/organisms';
import { PasswordValidation } from '@ui-catalog/core/organisms';
import { AuthFormCard } from '@ui-catalog/core/organisms';

import { getErrorMessage } from '@/constants/httpStatus';
import { useAuth } from '@/adapters/AuthContext';

/**
 * 初回パスワード変更ページ
 *
 * 初期パスワードでログインしたユーザーに対して
 * パスワード変更を強制するページ
 */
export default function ChangePasswordPage() {
  const { changePassword: changePasswordFn } = useAuth();
  const navigate = useNavigate();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);

  // バリデーション
  const validateForm = (): boolean => {
    if (!currentPassword) {
      setError(getErrorMessage('password', 'current_password_required'));
      return false;
    }
    if (!newPassword) {
      setError(getErrorMessage('password', 'new_password_required'));
      return false;
    }
    if (newPassword.length < 8) {
      setError(getErrorMessage('validation', 'password_too_short'));
      return false;
    }
    if (newPassword.length > 30) {
      setError(getErrorMessage('validation', 'password_too_long'));
      return false;
    }
    if (newPassword !== confirmPassword) {
      setError(getErrorMessage('password', 'password_confirm_mismatch'));
      return false;
    }
    if (currentPassword === newPassword) {
      setError(getErrorMessage('password', 'password_same_as_current'));
      return false;
    }
    return true;
  };

  // フォーム送信
  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');

    if (!validateForm()) {
      return;
    }

    if (!changePasswordFn) {
      setError(getErrorMessage('password', 'auth_not_found'));
      return;
    }

    setLoading(true);

    try {
      const result = await changePasswordFn(currentPassword, newPassword, confirmPassword);

      if (!result.success) {
        setError(result.error || getErrorMessage('password', 'change_failed'));
        return;
      }

      setShowSuccessAlert(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : getErrorMessage('password', 'change_failed')
      );
    } finally {
      setLoading(false);
    }
  };

  const formContent = (
    <>
      <form className="space-y-4 sm:space-y-6" onSubmit={handleSubmit}>
        <div className="space-y-3 sm:space-y-4">
          {/* エラーメッセージ */}
          {error && (
            <Banner variant="error" message={error} />
          )}

          {/* 現在のパスワード（初期パスワード） */}
          <div>
            <label
              htmlFor="current-password"
              className="mb-1 block text-fluid-sm font-medium text-gray-700"
            >
              現在のパスワード（初期パスワード）
            </label>
            <Input
              id="current-password"
              type={showCurrentPassword ? 'text' : 'password'}
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="現在のパスワードを入力"
              disabled={loading}
              size="large"
              icon={showCurrentPassword ? 'eye-slashed' : 'eye'}
              iconPosition="right"
              onIconClick={() => setShowCurrentPassword(!showCurrentPassword)}
            />
          </div>

          {/* 新しいパスワード */}
          <div>
            <label
              htmlFor="new-password"
              className="mb-1 block text-fluid-sm font-medium text-gray-700"
            >
              新しいパスワード
            </label>
            <Input
              id="new-password"
              type={showNewPassword ? 'text' : 'password'}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="8～30文字で入力"
              disabled={loading}
              size="large"
              icon={showNewPassword ? 'eye-slashed' : 'eye'}
              iconPosition="right"
              onIconClick={() => setShowNewPassword(!showNewPassword)}
            />
          </div>

          {/* 新しいパスワード（確認） */}
          <div>
            <label
              htmlFor="confirm-password"
              className="mb-1 block text-fluid-sm font-medium text-gray-700"
            >
              新しいパスワード（確認）
            </label>
            <Input
              id="confirm-password"
              type={showConfirmPassword ? 'text' : 'password'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="新しいパスワードを再入力"
              disabled={loading}
              size="large"
              icon={showConfirmPassword ? 'eye-slashed' : 'eye'}
              iconPosition="right"
              onIconClick={() => setShowConfirmPassword(!showConfirmPassword)}
            />
          </div>

          {/* パスワードバリデーション表示 */}
          <PasswordValidation
            password={newPassword}
            confirmPassword={confirmPassword}
            showValidation={newPassword.length > 0}
          />
        </div>

        <div className="w-full">
          <Button
            type="submit"
            variant="primary"
            disabled={loading}
          >
            {loading ? '変更中...' : 'パスワードを変更する'}
          </Button>
        </div>
      </form>
    </>
  );

  return (
    <div className="flex min-h-screen">
      {/* デスクトップ: 左側ブランディングパネル */}
      <div className="hidden md:flex md:w-1/2 flex-col justify-between bg-gradient-to-br from-amber-500 to-amber-600 p-12">
        <div>
          <Media
            src="/images/logo_login.png"
            alt="ロゴ"
            height={40}
          />
        </div>
        <div className="flex flex-col items-center justify-center flex-1">
          <Media
            src="/images/character_1on1_stand_1.jpg"
            alt="キャラクター"
            height={240}
            className="rounded-2xl shadow-lg mb-8"
          />
          <h1 className="text-fluid-2xl font-bold text-white">パスワードを変更してください</h1>
          <p className="text-amber-100 mt-2">セキュリティのため初回ログイン時に変更が必要です</p>
        </div>
      </div>

      {/* デスクトップ: 右側フォーム */}
      <div className="hidden md:flex w-full md:w-1/2 flex-col justify-between bg-white px-4 py-12 sm:px-6 lg:px-4">
        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-lg space-y-8">
            {formContent}
          </div>
        </div>
        <div className="text-fluid-sm text-black text-right">
          &copy; 2026 SMS DataTech
        </div>
      </div>

      {/* モバイル: グラデーション背景 + カード型フォーム */}
      <div className="md:hidden flex flex-col min-h-screen w-full bg-gradient-to-br from-amber-500 to-amber-600">
        {/* ヘッダー: ロゴ + キャラクター + タイトル */}
        <div className="flex flex-col items-center px-6 pt-8 pb-4">
          <Media
            src="/images/logo_login.png"
            alt="ロゴ"
            height={32}
            className="mb-4"
          />
          <Media
            src="/images/character_1on1_stand_1.jpg"
            alt="キャラクター"
            height={120}
            className="rounded-xl shadow-lg mb-4"
          />
          <h1 className="text-fluid-xl font-bold text-white">パスワードを変更してください</h1>
          <p className="text-amber-100 mt-1 text-fluid-sm">セキュリティのため初回ログイン時に変更が必要です</p>
        </div>

        {/* フォームカード */}
        <AuthFormCard marginClassName="mx-3 mb-3" paddingClassName="px-4 py-4">
          {formContent}
        </AuthFormCard>
      </div>

      {/* 成功アラート */}
      <AlertDialog
        isOpen={showSuccessAlert}
        onClose={() => {
          setShowSuccessAlert(false);
          // ログイン画面へ遷移（新しいパスワードでログインし直す）
          navigate('/login', { replace: true });
        }}
        title="パスワード変更完了"
        message="パスワードが変更されました。新しいパスワードでログインしてください。"
        type="success"
      />
    </div>
  );
}
