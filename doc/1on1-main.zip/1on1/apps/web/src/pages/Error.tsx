// src/pages/ErrorPage.jsx
import { useEffect, useState, useRef } from 'react';

import { useLocation } from 'react-router-dom';

import { Icon } from '@ui-catalog/core/atoms';
import { BackButton } from '@ui-catalog/core/molecules';

import { ROUTES } from '@/constants/routes';
import { STORAGE_KEYS } from '@/constants/storage';
import { useNavigateBack } from '@/hooks';
import { sendErrorReport, type ErrorReport } from '@/lib/api/errorReporting';

export default function ErrorPage() {
  const location = useLocation();
  const handleBack = useNavigateBack(ROUTES.ERROR.path);
  const [errorState, setErrorState] = useState<Record<string, unknown>>({});
  const hasInitialized = useRef(false);

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.ERROR.label;
  }, []);

  // エラー情報を取得(location.stateまたはsessionStorageから)- StrictMode対応
  useEffect(() => {
    if (hasInitialized.current) {
      return;
    }

    hasInitialized.current = true;

    let initialErrorState = location.state || {};

    // sessionStorageからエラー情報を取得(window.location.hrefでの遷移時用)
    if (!initialErrorState.message) {
      const storedError = window.sessionStorage.getItem(
        STORAGE_KEYS.ERROR_STATE
      );

      if (storedError) {
        try {
          const parsedError = JSON.parse(storedError);
          initialErrorState = parsedError;
        } catch (e) {
          console.error('Failed to parse error state:', e);
        }
      }
    }

    setErrorState(initialErrorState);

    // エラー情報を設定した後にsessionStorageを削除(一度だけ)
    if (initialErrorState.message) {
      window.sessionStorage.removeItem(STORAGE_KEYS.ERROR_STATE);
    }

    // エラー収集APIを呼び出し
    if (initialErrorState.errorId) {
      const reportError = async () => {
        try {
          const errorReport: ErrorReport = {
            errorId: String(initialErrorState.errorId),
            message: String(
              initialErrorState.message || 'エラーが発生しました'
            ),
            details: String(
              initialErrorState.details || 'エラーページで詳細情報を表示中'
            ),
            code: initialErrorState.code?.toString() || 'ERROR_PAGE_VIEW',
            url: String(initialErrorState.from || window.location.href),
            timestamp: new Date().toISOString(),
          };

          await sendErrorReport(errorReport);
        } catch (reportError) {
          console.error(
            'Failed to send error report from ErrorPage:',
            reportError
          );
        }
      };

      reportError();
    }
  }, [location.state]);

  // URLが存在しないページの場合(404エラー)
  const is404 = !errorState.message && location.pathname !== '/error';

  // 権限エラーの場合
  const isAccessDenied = errorState.code === 'ACCESS_DENIED';

  const message = is404
    ? 'ページが見つかりません'
    : isAccessDenied
      ? 'アクセス権限がありません'
      : errorState.message || '予期しないエラーが発生しました';

  // details を安全に表示する関数
  const formatDetails = (detailsData: unknown): string => {
    if (!detailsData)
      return 'システムエラーが発生しました。しばらく時間をおいて再度お試しください。';

    // 文字列の場合はそのまま返す
    if (typeof detailsData === 'string') return detailsData;

    // 配列の場合
    if (Array.isArray(detailsData)) {
      return detailsData
        .map((item) => {
          if (typeof item === 'string') return item;
          if (typeof item === 'object') {
            // FastAPI validation error format: {type, loc, msg, input}
            return item.msg || JSON.stringify(item);
          }
          return String(item);
        })
        .join('\n');
    }

    // オブジェクトの場合
    if (typeof detailsData === 'object') {
      return JSON.stringify(detailsData, null, 2);
    }

    return String(detailsData);
  };

  const details = is404
    ? `お探しのページ「${location.pathname}」は存在しません。URLをご確認ください。`
    : isAccessDenied
      ? 'このページにアクセスする権限がありません。必要な権限についてはシステム管理者にお問い合わせください。'
      : formatDetails(errorState.details);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 px-4">
      <div className="w-full max-w-2xl">
        <div className="overflow-hidden rounded-2xl bg-white shadow-2xl">
          {/* メインエラー表示エリア */}
          <div className="p-8">
            {/* エラーアイコン */}
            <div className="mb-2 flex justify-center">
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-red-100">
                <Icon
                  name={'info-triangle'}
                  size={48}
                  className="text-red-600"
                />
              </div>
            </div>

            {/* エラーメッセージ */}
            <h1 className="mb-2 text-center text-fluid-3xl font-bold text-gray-900">
              エラーが発生しました
            </h1>

            <div className="mb-8 rounded-xl border-2 border-red-200 bg-red-50 p-6">
              <p className="mb-3 text-fluid-lg font-bold text-red-800">
                {message as string}
              </p>
              <p className="whitespace-pre-wrap text-red-700">
                {details as string}
              </p>
            </div>

            {/* エラーコード・ID・時刻 */}
            {(errorState.code || is404) && (
              <div className="mb-8 text-center">
                <div className="inline-block rounded-lg bg-gray-100 px-6 py-3 space-y-1">
                  <p className="font-mono text-fluid-lg text-gray-700">
                    エラーコード:{' '}
                    <span className="font-bold text-red-600">
                      {(errorState.code as string) || '404'}
                    </span>
                  </p>
                  {Boolean(errorState.errorId) && (
                    <p className="font-mono text-fluid-sm text-gray-600">
                      ID:{' '}
                      <span className="font-bold">{String(errorState.errorId)}</span>
                    </p>
                  )}
                  <p className="font-mono text-fluid-sm text-gray-600">
                    発生時刻:{' '}
                    <span className="font-bold">
                      {new Date().toLocaleString('ja-JP')}
                    </span>
                  </p>
                </div>
              </div>
            )}

            {/* アクションボタン */}
            <div className="mb-8 flex justify-center">
              <BackButton
                variant="outline"
                size="large"
                className="w-full"
                onClick={handleBack}
                label="HOMEに戻る"
                icon={'home'}
              />
            </div>

            {/* サポート情報 */}
            <div className="mb-2 border-t-2 border-gray-200 pt-6 text-left">
              <p className="text-gray-600">
                問題が解決しない場合は、
                <span className="font-bold text-red-600">エラーコード</span>
                を添えて システム管理者にお問い合わせください。
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
