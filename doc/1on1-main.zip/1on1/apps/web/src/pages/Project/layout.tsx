// src/pages/Project/layout.tsx
import { useState } from 'react';

import { Icon } from '@ui-catalog/core/atoms';
import { Button, DevelopmentBanner } from '@ui-catalog/core/molecules';
import { EmptyState } from '@ui-catalog/core/organisms';

import { cn } from '@ui-catalog/core/utils';

import { type Project, type FileSystemItem } from './types';

interface ProjectLayoutProps {
  projects: Project[];
  selectedProject: Project | null;
  fileTree: FileSystemItem[];
  loading: boolean;
  onSelectProject: (projectId: string) => void;
  onSelectItem: (item: FileSystemItem) => void;
  onCreateFolder: () => void;
  onUploadFile: () => void;
}

// プロジェクトカラーのプリセット
const projectColors: Record<string, string> = {
  blue: 'bg-blue-500',
  green: 'bg-green-500',
  purple: 'bg-purple-500',
  orange: 'bg-orange-500',
  pink: 'bg-pink-500',
  teal: 'bg-teal-500',
};

/**
 * フォルダツリーアイテムコンポーネント
 */
function TreeItem({
  item,
  level = 0,
  onSelect,
}: {
  item: FileSystemItem;
  level?: number;
  onSelect: (item: FileSystemItem) => void;
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const hasChildren = item.type === 'folder' && item.children && item.children.length > 0;

  return (
    <div>
      <button
        onClick={() => {
          if (item.type === 'folder') {
            setIsExpanded(!isExpanded);
          }
          onSelect(item);
        }}
        className={cn(
          'w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-lg transition-colors text-left',
          'focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-1'
        )}
        style={{ paddingLeft: `${level * 16 + 12}px` }}
      >
        {/* 展開/折りたたみアイコン */}
        {item.type === 'folder' && (
          <Icon
            name="chevron-right"
            size={12}
            className={cn(
              'text-gray-400 transition-transform',
              isExpanded && 'rotate-90'
            )}
          />
        )}
        {item.type === 'file' && <span className="w-3" />}

        {/* アイコン */}
        <Icon
          name={item.type === 'folder' ? 'folder' : 'file'}
          size={16}
          hover="auto"
          className={item.type === 'folder' ? 'text-yellow-500' : 'text-gray-400'}
        />

        {/* 名前 */}
        <span className="text-gray-700 truncate">{item.name}</span>
      </button>

      {/* 子要素 */}
      {hasChildren && isExpanded && (
        <div>
          {item.children!.map((child) => (
            <TreeItem
              key={child.id}
              item={child}
              level={level + 1}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * プロジェクト管理ページ用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
export default function ProjectLayout({
  projects,
  selectedProject,
  fileTree,
  loading,
  onSelectProject,
  onSelectItem,
  onCreateFolder,
  onUploadFile,
}: ProjectLayoutProps) {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <Icon preset="gears" size={48} stroke="#6B7280" />
        <div className="text-gray-500">プロジェクトを読み込み中...</div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <div className="mb-6">
        <DevelopmentBanner
          message="この機能は現在開発中です。フォルダ/ファイル管理機能を実装予定です。"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* 左側: プロジェクト一覧 */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-fluid-lg font-medium text-gray-800">プロジェクト</h2>
              <Button variant="outline" size="small">
                + 新規
              </Button>
            </div>
            <div className="space-y-2">
              {projects.map((project) => {
                const colorClass = projectColors[project.color] ?? projectColors.blue;
                return (
                  <button
                    key={project.id}
                    onClick={() => onSelectProject(project.id)}
                    className={cn(
                      'w-full flex items-center gap-3 p-3 rounded-lg transition-colors text-left',
                      selectedProject?.id === project.id
                        ? 'bg-teal-50 border border-teal-200'
                        : 'hover:bg-gray-50'
                    )}
                  >
                    <div className={cn('w-3 h-3 rounded-full', colorClass)} />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-800 truncate">
                        {project.name}
                      </div>
                      <div className="text-fluid-xs text-gray-500">
                        {project.fileCount} ファイル
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* 右側: ファイルツリー & プレビュー */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            {/* ツールバー */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <div className="flex items-center gap-2">
                {selectedProject && (
                  <>
                    <span className="font-medium text-gray-800">
                      {selectedProject.name}
                    </span>
                    <span className="text-gray-400">/</span>
                  </>
                )}
                <span className="text-gray-500">ファイル</span>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="default"
                  size="small"
                  leftIcon="folder"
                  onClick={onCreateFolder}
                >
                  新規フォルダ
                </Button>
                <Button
                  variant="primary"
                  size="small"
                  leftIcon="sync-push"
                  onClick={onUploadFile}
                >
                  アップロード
                </Button>
              </div>
            </div>

            {/* ファイルツリー */}
            <div className="p-4 min-h-[400px]">
              {fileTree.length > 0 ? (
                <div className="space-y-1">
                  {fileTree.map((item) => (
                    <TreeItem
                      key={item.id}
                      item={item}
                      onSelect={onSelectItem}
                    />
                  ))}
                </div>
              ) : (
                <div className="h-64">
                  <EmptyState
                    icon={<Icon name="folder" size={48} />}
                    title="ファイルがありません"
                    description="新規フォルダを作成するか、ファイルをアップロードしてください"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
