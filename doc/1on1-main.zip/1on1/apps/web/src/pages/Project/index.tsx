// src/pages/Project/index.tsx
import { useEffect, useMemo, useState, useCallback } from 'react';

import AppLayout from '@1on1/layouts/templates/AppLayout';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';

import ProjectLayout from './layout';
import { type Project, type FileSystemItem } from './types';

// デモ用プロジェクトデータ
const DEMO_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    name: '営業部資料',
    description: '営業部の共有資料フォルダ',
    color: 'blue',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-03-01'),
    memberCount: 12,
    fileCount: 45,
  },
  {
    id: 'proj-2',
    name: '開発ドキュメント',
    description: '開発チームのドキュメント',
    color: 'green',
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-03-10'),
    memberCount: 8,
    fileCount: 123,
  },
  {
    id: 'proj-3',
    name: '人事関連',
    description: '人事部の共有フォルダ',
    color: 'purple',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-02-28'),
    memberCount: 5,
    fileCount: 34,
  },
];

// デモ用ファイルツリー
const DEMO_FILE_TREE: FileSystemItem[] = [
  {
    id: 'folder-1',
    name: '2024年度',
    type: 'folder',
    parentId: null,
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-03-01'),
    children: [
      {
        id: 'folder-1-1',
        name: '第1四半期',
        type: 'folder',
        parentId: 'folder-1',
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-03-01'),
        children: [
          {
            id: 'file-1',
            name: '売上報告.xlsx',
            type: 'file',
            parentId: 'folder-1-1',
            createdAt: new Date('2024-01-15'),
            updatedAt: new Date('2024-01-15'),
            size: 245000,
            mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          },
          {
            id: 'file-2',
            name: '会議議事録.docx',
            type: 'file',
            parentId: 'folder-1-1',
            createdAt: new Date('2024-02-01'),
            updatedAt: new Date('2024-02-01'),
            size: 52000,
            mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          },
        ],
      },
      {
        id: 'folder-1-2',
        name: '第2四半期',
        type: 'folder',
        parentId: 'folder-1',
        createdAt: new Date('2024-04-01'),
        updatedAt: new Date('2024-04-01'),
        children: [],
      },
    ],
  },
  {
    id: 'folder-2',
    name: 'テンプレート',
    type: 'folder',
    parentId: null,
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
    children: [
      {
        id: 'file-3',
        name: '報告書テンプレート.docx',
        type: 'file',
        parentId: 'folder-2',
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01'),
        size: 35000,
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      },
    ],
  },
  {
    id: 'file-4',
    name: 'README.md',
    type: 'file',
    parentId: null,
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
    size: 1500,
    mimeType: 'text/markdown',
  },
];

/**
 * プロジェクト管理ページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function Project() {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.PROJECT.label;
  }, []);

  // 初期データ読み込み（デモ用）
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
      // 最初のプロジェクトを選択
      if (DEMO_PROJECTS.length > 0) {
        setSelectedProjectId(DEMO_PROJECTS[0].id);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  // 選択中のプロジェクト
  const selectedProject = useMemo(() => {
    return DEMO_PROJECTS.find((p) => p.id === selectedProjectId) || null;
  }, [selectedProjectId]);

  // プロジェクト選択
  const handleSelectProject = useCallback((projectId: string) => {
    setSelectedProjectId(projectId);
    // TODO: プロジェクト選択処理
  }, []);

  // ファイル/フォルダ選択
  const handleSelectItem = useCallback((_item: FileSystemItem) => {
    // TODO: アイテム選択処理
  }, []);

  // 新規フォルダ作成
  const handleCreateFolder = useCallback(() => {
    // TODO: フォルダ作成処理
    // TODO: フォルダ作成モーダルを表示
  }, []);

  // ファイルアップロード
  const handleUploadFile = useCallback(() => {
    // TODO: ファイルアップロード処理
    // TODO: ファイルアップロードダイアログを表示
  }, []);

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.PROJECT.path), []);

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={false}
      mainContent={
        <ProjectLayout
          projects={DEMO_PROJECTS}
          selectedProject={selectedProject}
          fileTree={DEMO_FILE_TREE}
          loading={loading}
          onSelectProject={handleSelectProject}
          onSelectItem={handleSelectItem}
          onCreateFolder={handleCreateFolder}
          onUploadFile={handleUploadFile}
        />
      }
    />
  );
}
