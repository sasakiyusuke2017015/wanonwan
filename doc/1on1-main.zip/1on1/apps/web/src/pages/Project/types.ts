// src/pages/Project/types.ts

/**
 * フォルダ/ファイルアイテムの型
 */
export interface FileSystemItem {
  id: string;
  name: string;
  type: 'folder' | 'file';
  parentId: string | null;
  createdAt: Date;
  updatedAt: Date;
  size?: number;  // ファイルサイズ（バイト）
  mimeType?: string;  // MIMEタイプ
  children?: FileSystemItem[];  // フォルダの場合の子要素
}

/**
 * プロジェクトの型
 */
export interface Project {
  id: string;
  name: string;
  description?: string;
  color: string;
  icon?: string;
  createdAt: Date;
  updatedAt: Date;
  memberCount: number;
  fileCount: number;
}

/**
 * API用フォルダ/ファイルデータ型
 */
export interface FileSystemItemData {
  id: string;
  name: string;
  type: 'folder' | 'file';
  parent_id: string | null;
  created_at: string;
  updated_at: string;
  size?: number;
  mime_type?: string;
}

/**
 * API用プロジェクトデータ型
 */
export interface ProjectData {
  id: string;
  name: string;
  description?: string;
  color: string;
  icon?: string;
  created_at: string;
  updated_at: string;
  member_count: number;
  file_count: number;
}
