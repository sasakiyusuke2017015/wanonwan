// src/pages/Dashboard/Layout.tsx
import { Badge, NumberTicker } from '@ui-catalog/core/atoms';
import { AdjustmentBanner, Banner } from '@ui-catalog/core/molecules';
import { LoadingZone, InteractiveTable, TrendChart } from '@ui-catalog/core/organisms';
import { type TableRowAnimationVariant } from '@/constants';
import { CONSTANTS } from '@/constants/schemas';
import { useThemeConfig } from '@/hooks';

import type {
  DisplayCompanySummary,
  DepartmentSummaryItem,
  AlertItem,
  DisplayTrendData,
} from './types';

// レイアウトスタイル定義（テーマ非依存の静的スタイル）
export const layoutStyles = {
  pageContainer: 'min-h-screen bg-gray-50',
  mainContent: 'container mx-auto px-2 py-4 sm:px-4 sm:py-6',
  section: {
    container: 'bg-white p-3 sm:p-6 rounded-lg shadow-md',
    title: 'text-fluid-xl font-bold text-gray-800 mb-2 flex items-center',
  },
  summaryGrid: {
    container: 'grid md:grid-cols-5 gap-3 sm:gap-6',
    responseRate: 'bg-green-50 p-3 sm:p-6 rounded-lg',
  },
  badge: {
    container: 'flex items-center bg-white/70 px-4 py-2 rounded-lg',
    label: 'text-fluid-sm font-medium mr-3',
  },
  table: {
    gridContainer: 'grid md:grid-cols-2 gap-4 mb-6 sm:gap-8 sm:mb-8',
    sectionWrapper: 'h-full',
  },
  loading: {
    container: 'flex justify-center items-center h-32',
    text: 'text-gray-500',
  },
  error: {
    container: 'mb-2 bg-red-50 border border-red-200 rounded-lg p-4',
    icon: 'h-5 w-5 text-red-400',
    title: 'text-fluid-sm font-medium text-red-800',
    message: 'mt-2 text-fluid-sm text-red-700',
  },
};

// テーブルカラム定義
const departmentColumns = [
  { accessor: 'department', label: '部署', proportion: '20%' },
  {
    accessor: CONSTANTS.ASSESSMENT_ITEM['満足度'].key,
    label: CONSTANTS.ASSESSMENT_ITEM['満足度'].shortLabel,
    proportion: '16%',
  },
  {
    accessor: CONSTANTS.ASSESSMENT_ITEM['業務負荷'].key,
    label: CONSTANTS.ASSESSMENT_ITEM['業務負荷'].shortLabel,
    proportion: '16%',
  },
  {
    accessor: CONSTANTS.ASSESSMENT_ITEM['職場環境'].key,
    label: CONSTANTS.ASSESSMENT_ITEM['職場環境'].shortLabel,
    proportion: '16%',
  },
  {
    accessor: CONSTANTS.ASSESSMENT_ITEM['人間関係'].key,
    label: CONSTANTS.ASSESSMENT_ITEM['人間関係'].shortLabel,
    proportion: '16%',
  },
  {
    accessor: CONSTANTS.ASSESSMENT_ITEM['ストレス'].key,
    label: CONSTANTS.ASSESSMENT_ITEM['ストレス'].shortLabel,
    proportion: '16%',
  },
];

const alertColumns = [
  { accessor: 'name', label: 'メンバー名', proportion: '20%' },
  { accessor: 'department', label: '部署', proportion: '15%' },
  { accessor: 'issue', label: '異常項目', proportion: '20%' },
  { accessor: 'duration', label: '連続期間', proportion: '15%' },
  { accessor: 'status', label: '対応状況', proportion: '15%' },
];

// 型定義
interface ColumnType {
  accessor: string;
  label: string;
  proportion?: string | number;
  [key: string]: unknown;
}

interface RowDataType {
  [key: string]: unknown;
}

interface StyleMapping {
  mapping?: Record<string, string>;
  conditions?: Array<{
    operator?: string;
    value?: number;
    style?: string;
    field?: string;
    values?: string[];
  }>;
  [key: string]: unknown;
}

interface RowStylesType {
  conditions?: Array<{
    field: string;
    values: string[];
    style: string;
  }>;
  default?: string;
}

interface CellStylesType {
  department?: Record<string, StyleMapping>;
  alert?: Record<string, StyleMapping>;
  rowStyles?: {
    alert?: RowStylesType;
    [key: string]: RowStylesType | undefined;
  };
  [key: string]:
    | Record<string, StyleMapping>
    | { [key: string]: RowStylesType | undefined }
    | undefined;
}

// セルスタイル定義
const cellStyles: CellStylesType = {
  department: {
    stress: {
      conditions: [
        {
          operator: '<',
          value: 2.0,
          style:
            'bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold rounded-md px-2 py-1',
        },
      ],
    },
  },
  alert: {
    status: {
      mapping: {
        未対応:
          'bg-gradient-to-r from-red-500 to-red-600 text-white text-center rounded-full px-3 py-1 text-fluid-sm font-medium',
        対応中:
          'bg-gradient-to-r from-amber-400 to-orange-500 text-white text-center rounded-full px-3 py-1 text-fluid-sm font-medium',
        対応済:
          'bg-gradient-to-r from-emerald-500 to-green-600 text-white text-center rounded-full px-3 py-1 text-fluid-sm font-medium',
      },
    },
    issue: {
      mapping: {
        ストレス高: 'text-red-600 font-semibold',
        業務負荷高: 'text-red-600 font-semibold',
        満足度低下: 'text-amber-600 font-semibold',
      },
    },
  },
  rowStyles: {
    alert: {
      conditions: [
        {
          field: 'status',
          values: ['未対応', '対応中'],
          style:
            'bg-gradient-to-r from-red-50 to-orange-50 hover:from-red-100 hover:to-orange-100 transition-all duration-200',
        },
      ],
      default: 'hover:bg-gray-50 transition-all duration-200',
    },
  },
};

// スタイル関数
const getCellStyle = (
  row: RowDataType,
  column: ColumnType | Record<string, unknown>,
  tableType: string = 'department'
) => {
  const col = column as ColumnType;
  const tableStyles = cellStyles[tableType] as
    | Record<string, StyleMapping>
    | undefined;
  const styles = tableStyles?.[col.accessor];

  if (!styles) return '';

  // マッピングタイプのスタイル
  if (styles.mapping) {
    const cellValue = row[col.accessor];
    return styles.mapping[String(cellValue)] || '';
  }

  // 条件タイプのスタイル
  if (styles.conditions) {
    for (const condition of styles.conditions) {
      const value = row[col.accessor];
      if (
        condition.operator === '<' &&
        typeof value === 'number' &&
        typeof condition.value === 'number' &&
        value < condition.value
      ) {
        return condition.style || '';
      }
    }
  }

  return '';
};

const getRowStyle = (row: RowDataType, tableType: string = 'alert') => {
  const rowStyles = cellStyles.rowStyles?.[tableType];

  if (!rowStyles) return '';

  // 条件チェック
  if (rowStyles.conditions) {
    for (const condition of rowStyles.conditions) {
      if (condition.values.includes(String(row[condition.field]))) {
        return condition.style;
      }
    }
  }

  return rowStyles.default || '';
};

/**
 * ダッシュボード用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
interface DashboardLayoutProps {
  loading: boolean;
  error: string | null;
  companySummary: DisplayCompanySummary | null;
  departmentData: {
    departments: DepartmentSummaryItem[];
  };
  alerts: {
    alerts: AlertItem[];
  };
  trendDataEnhanced: DisplayTrendData | null;
  enableTableRowAnimation?: boolean;
  tableRowAnimationVariant?: TableRowAnimationVariant;
}

export default function DashboardLayout({
  loading,
  error,
  companySummary,
  departmentData,
  alerts,
  trendDataEnhanced,
  enableTableRowAnimation = true,
  tableRowAnimationVariant = 'slideDown',
}: DashboardLayoutProps) {
  const { colors, shapes } = useThemeConfig('Dashboard');

  // エラーコンテンツ
  const errorContent = error && (
    <Banner
      variant="error"
      title="データの取得に失敗しました"
      message="エラーページへリダイレクトしています..."
      className="mb-2"
    />
  );

  // 全社サマリーコンテンツ
  const summaryContent = (
    <section className="mb-8">
      <div className={layoutStyles.section.container}>
        <h2 className={layoutStyles.section.title}>
          <span
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold mr-3 bg-theme-accent-bg"
          >1</span>
          全社サマリー
        </h2>
        <div className={layoutStyles.summaryGrid.container}>
          <div className={layoutStyles.summaryGrid.responseRate}>
            <h3 className="mb-3 text-fluid-sm font-semibold text-gray-700">回答率</h3>
            <div className="flex items-baseline">
              <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-fluid-3xl font-bold text-transparent">
                {loading ? '...' : (
                  <NumberTicker
                    value={companySummary?.responseRate || 0}
                    suffix="%"
                    delay={0.2}
                  />
                )}
              </span>
              <span className="ml-2 text-fluid-sm text-gray-600">
                {loading
                  ? ''
                  : `(${companySummary?.respondedEmployees || 0}名/${companySummary?.totalEmployees || 0}名)`}
              </span>
            </div>
          </div>
          <div
            className="md:col-span-4 p-6 rounded-lg bg-theme-secondary-bg"
          >
            <h3 className="mb-4 text-fluid-sm font-semibold text-gray-700">
              全社平均値
            </h3>
            <div className="flex flex-wrap items-center gap-4">
              <div className={layoutStyles.badge.container}>
                <span className={layoutStyles.badge.label}>
                  {CONSTANTS.ASSESSMENT_ITEM['満足度'].label}:
                </span>
                <Badge
                  value={
                    loading
                      ? '...'
                      : companySummary?.averageMetrics?.satisfaction?.toFixed(
                          1
                        ) || '0.0'
                  }
                  appearance="metric"
                  styleVariant="gradient"
                  color="blue"
                />
              </div>
              <div className={layoutStyles.badge.container}>
                <span className={layoutStyles.badge.label}>
                  {CONSTANTS.ASSESSMENT_ITEM['業務負荷'].label}:
                </span>
                <Badge
                  value={
                    loading
                      ? '...'
                      : companySummary?.averageMetrics?.workload?.toFixed(1) ||
                        '0.0'
                  }
                  appearance="metric"
                  styleVariant="gradient"
                  color="green"
                />
              </div>
              <div className={layoutStyles.badge.container}>
                <span className={layoutStyles.badge.label}>
                  {CONSTANTS.ASSESSMENT_ITEM['職場環境'].label}:
                </span>
                <Badge
                  value={
                    loading
                      ? '...'
                      : companySummary?.averageMetrics?.environment?.toFixed(
                          1
                        ) || '0.0'
                  }
                  appearance="metric"
                  styleVariant="gradient"
                  color="blue"
                />
              </div>
              <div className={layoutStyles.badge.container}>
                <span className={layoutStyles.badge.label}>
                  {CONSTANTS.ASSESSMENT_ITEM['人間関係'].label}:
                </span>
                <Badge
                  value={
                    loading
                      ? '...'
                      : companySummary?.averageMetrics?.relationship?.toFixed(
                          1
                        ) || '0.0'
                  }
                  appearance="metric"
                  styleVariant="gradient"
                  color="blue"
                />
              </div>
              <div className={layoutStyles.badge.container}>
                <span className={layoutStyles.badge.label}>
                  {CONSTANTS.ASSESSMENT_ITEM['ストレス'].label}:
                </span>
                <Badge
                  value={
                    loading
                      ? '...'
                      : `${companySummary?.averageMetrics?.stress?.toFixed(1) || '0.0'} ${companySummary?.averageMetrics?.stress !== undefined && companySummary.averageMetrics.stress < 3 ? '(やや注意)' : ''}`
                  }
                  appearance="metric"
                  styleVariant="gradient"
                  color="orange"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );

  // 部署別サマリーコンテンツ
  const departmentTableContent = (
    <section className="relative">
      {loading && (
        <div className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-white/80 backdrop-blur-sm">
          <div className="flex flex-col items-center">
            <div className="mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-theme-primary-bg"></div>
            <p className="text-gray-600">データを読み込み中...</p>
          </div>
        </div>
      )}
      <div className="h-full rounded-2xl border border-gray-200/50 bg-white/95 p-6 shadow-xl backdrop-blur-sm transition-all duration-300 hover:shadow-2xl">
        <h2 className="mb-2 flex items-center text-fluid-xl font-bold text-gray-800">
          <span className="mr-3 flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-r from-violet-500 to-purple-500 font-bold text-white shadow-lg">
            2
          </span>
          部署別サマリー
        </h2>
        <LoadingZone
          loading={loading}
          variant="simple"
          height="200px"
          message="データを読み込み中..."
          preset="wave"
        >
          <InteractiveTable
            columns={departmentColumns}
            data={departmentData.departments || []}
            cellClassName={(_, __, column, row) =>
              getCellStyle(
                row as RowDataType,
                column as unknown as ColumnType,
                'department'
              )
            }
            tableClassName="w-full"
            enableRowAnimation={enableTableRowAnimation}
            rowAnimationVariant={tableRowAnimationVariant}
            borderRadius={shapes.borderRadius}
            headerBgColor={colors.tableHeaderBgColor}
            headerTextColor={colors.tableHeaderTextColor}
          />
        </LoadingZone>
      </div>
    </section>
  );

  // 異常検知・アラート一覧コンテンツ
  const alertTableContent = (
    <section className="relative">
      {loading && (
        <div className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-white/80 backdrop-blur-sm">
          <div className="flex flex-col items-center">
            <div className="mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-theme-primary-bg"></div>
            <p className="text-gray-600">データを読み込み中...</p>
          </div>
        </div>
      )}
      <div className="h-full rounded-2xl border border-gray-200/50 bg-white/95 p-6 shadow-xl backdrop-blur-sm transition-all duration-300 hover:shadow-2xl">
        <h2 className="mb-2 flex items-center text-fluid-xl font-bold text-gray-800">
          <span className="mr-3 flex h-8 w-8 animate-pulse items-center justify-center rounded-lg bg-gradient-to-r from-red-500 to-rose-500 font-bold text-white shadow-lg">
            3
          </span>
          異常検知・アラート一覧
        </h2>
        <LoadingZone
          loading={loading}
          variant="simple"
          height="200px"
          message="データを読み込み中..."
          preset="wave"
        >
          <InteractiveTable
            columns={alertColumns}
            data={alerts.alerts || []}
            cellClassName={(_, __, column, row) =>
              getCellStyle(
                row as RowDataType,
                column as unknown as ColumnType,
                'alert'
              )
            }
            rowClassName={(_, row) => getRowStyle(row as RowDataType, 'alert')}
            tableClassName="w-full"
            enableRowAnimation={enableTableRowAnimation}
            rowAnimationVariant={tableRowAnimationVariant}
            borderRadius={shapes.borderRadius}
            headerBgColor={colors.tableHeaderBgColor}
            headerTextColor={colors.tableHeaderTextColor}
          />
        </LoadingZone>
      </div>
    </section>
  );

  // トレンド分析コンテンツ
  const trendContent = (
    <section>
      <div className="rounded-2xl border border-gray-200/50 bg-white/95 p-6 shadow-xl backdrop-blur-sm transition-all duration-300 hover:shadow-2xl">
        <h2 className="mb-2 flex items-center text-fluid-xl font-bold text-gray-800">
          <span className="mr-3 flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-r from-indigo-500 to-blue-500 font-bold text-white shadow-lg">
            4
          </span>
          推移・トレンド分析(過去6ヶ月)
        </h2>
        <div className="rounded-xl bg-gradient-to-br from-gray-50 to-blue-50/30 p-4">
          <LoadingZone
            loading={loading}
            variant="simple"
            height="350px"
            message="データを読み込み中..."
            preset="clock"
          >
            <div className="space-y-4">
              <TrendChart
                data={{
                  labels: trendDataEnhanced?.labels?.slice(-6) || [],
                  datasets:
                    trendDataEnhanced?.datasets?.map((dataset) => ({
                      ...dataset,
                      data: dataset.data?.slice(-6) || [],
                    })) || [],
                }}
                height={250}
                className="w-full"
              />
            </div>
          </LoadingZone>
        </div>
      </div>
    </section>
  );

  return (
    <div className={layoutStyles.pageContainer}>
      <div className={layoutStyles.mainContent}>
        {/* 調整中バナー */}
        <div className="mb-6">
          <AdjustmentBanner message="このページは現在調整中です。" />
        </div>

        {/* エラー表示 */}
        {errorContent}

        {/* 全社サマリー */}
        {summaryContent}

        {/* テーブル(部署別・アラート) */}
        <div className="mb-8 grid gap-8 md:grid-cols-2">
          {departmentTableContent}
          {alertTableContent}
        </div>

        {/* トレンド分析 */}
        {trendContent}
      </div>
    </div>
  );
}
