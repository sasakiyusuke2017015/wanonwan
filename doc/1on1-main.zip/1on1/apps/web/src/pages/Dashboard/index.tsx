// src/pages/Dashboard/index.tsx
import { useEffect, useMemo } from 'react';

import { useAtomValue } from 'jotai';

import { Button } from '@ui-catalog/core/molecules';
import { AlertDialog } from '@ui-catalog/core/organisms';
import AppLayout from '@1on1/layouts/templates/AppLayout';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { useAlert } from '@ui-catalog/core/hooks/ui';
import { useUserInfo } from '@/hooks';
import { uiTableRowAnimationVariantAtom } from '../../state';

import { useDashboardTransformTanStack as useDashboardTransform } from './hooks.tanstack';
import DashboardLayout from './layout';

/**
 * ダッシュボードページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function Dashboard() {
  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.DASHBOARD.label;
  }, []);

  const { userCode } = useUserInfo();
  const { alertState, showAlert, closeAlert } = useAlert();

  // アニメーション設定を取得（variant が 'none' 以外なら有効）
  const tableRowAnimationVariant = useAtomValue(uiTableRowAnimationVariantAtom);
  const enableTableRowAnimation = tableRowAnimationVariant !== 'none';
  const {
    data: transformedData,
    loading,
    error,
  } = useDashboardTransform(userCode);

  // データ取得
  const companySummary = transformedData?.companySummary || null;
  const departmentData = transformedData?.departmentData || { departments: [] };
  const alerts = transformedData?.alerts || { alerts: [] };
  const trendDataEnhanced = transformedData?.trendDataEnhanced || null;

  // イベントハンドラー
  const handleBack = () => {
    window.history.back();
  };

  const handleBulkDelete = () => {
    showAlert('一括削除機能は準備中です。', {
      title: '一括削除',
      type: 'info',
    });
  };

  const handleImport = () => {
    showAlert('インポート機能は準備中です。', {
      title: 'インポート',
      type: 'info',
    });
  };

  const handleExport = () => {
    showAlert('エクスポート機能は準備中です。', {
      title: 'エクスポート',
      type: 'info',
    });
  };

  // フッターボタンコンテンツ
  const footerButtonsContent = (
    <div id="MainCommandsContainer">
      <div id="MainCommands" className="flex justify-center gap-2">
        <Button
          id="GoBack"
          variant="secondary"
          size="small"
          onClick={handleBack}
        >
          戻る
        </Button>
        <Button
          id="BulkDelete"
          variant="danger"
          size="small"
          onClick={handleBulkDelete}
        >
          一括削除
        </Button>
        <Button
          id="Import"
          variant="primary"
          size="small"
          onClick={handleImport}
        >
          インポート
        </Button>
        <Button
          id="Export"
          variant="primary"
          size="small"
          onClick={handleExport}
        >
          エクスポート
        </Button>
      </div>
    </div>
  );

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.DASHBOARD.path), []);

  return (
    <>
      <AppLayout
        breadcrumbItems={breadcrumbs}
        footerContent={footerButtonsContent}
        mainContent={
          <DashboardLayout
            loading={loading}
            error={error}
            companySummary={companySummary}
            departmentData={departmentData}
            alerts={alerts}
            trendDataEnhanced={trendDataEnhanced}
            enableTableRowAnimation={enableTableRowAnimation}
            tableRowAnimationVariant={tableRowAnimationVariant}
          />
        }
      />
      <AlertDialog {...alertState} onClose={closeAlert} />
    </>
  );
}
