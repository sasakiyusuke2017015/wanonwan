/**
 * ダッシュボードページ専用フック (React Query版)
 */
import { useMemo } from 'react';

import { useQuery } from '@tanstack/react-query';

import { apiGet } from '@/lib/api';

import type {
  DisplayCompanySummary,
  DisplayTrendData,
  DepartmentSummaryItem,
  AlertItem,
  PeriodOption,
} from './types';

interface TransformedDashboardData {
  companySummary: DisplayCompanySummary | null;
  departmentData: { departments: DepartmentSummaryItem[] };
  alerts: { alerts: AlertItem[] };
  trendDataEnhanced: DisplayTrendData | null;
  periodOptions: PeriodOption[];
  currentPeriod: string | null;
}

// ダッシュボード統計レスポンス型
interface DashboardStatsResponse {
  回答率?: number;
  総回答数?: number;
  総ユーザー数?: number;
  最新アンケート?: {
    開始?: string;
    タイトル?: string;
  };
}

/**
 * ダッシュボードデータ変換フック (React Query版)
 *
 * REST /api/dashboard/stats エンドポイントを使用
 */
export const useDashboardTransformTanStack = (_userCode: string | undefined) => {
  // React Query でデータ取得
  const { data: rawData, isLoading, error } = useQuery({
    queryKey: ['dashboard', 'stats'],
    queryFn: () => apiGet<DashboardStatsResponse>('/dashboard/stats'),
    staleTime: 5 * 60 * 1000, // 5分間キャッシュ
    gcTime: 24 * 60 * 60 * 1000, // 1日間保持
    retry: 3,
  });

  // データ変換
  const transformedData = useMemo((): TransformedDashboardData | null => {
    if (!rawData) return null;

    // APIレスポンスをフロント表示用に変換
    const companySummary: DisplayCompanySummary = {
      responseRate: rawData.回答率 ?? 0,
      respondedEmployees: rawData.総回答数 ?? 0,
      totalEmployees: rawData.総ユーザー数 ?? 0,
      averageMetrics: {
        satisfaction: 0, // TODO: サービス層で計算が必要
        workload: 0,
        environment: 0,
        relationship: 0,
        stress: 0,
      },
    };

    // トレンドデータは別途 getChartData で取得する必要があるため空
    const trendDataEnhanced: DisplayTrendData | null = null;

    // 部署別データ、アラートは現在のサービスでは未実装
    const departmentData: { departments: DepartmentSummaryItem[] } = { departments: [] };
    const alerts: { alerts: AlertItem[] } = { alerts: [] };

    // 期間オプション（最新アンケートから生成）
    const periodOptions: PeriodOption[] = rawData.最新アンケート
      ? [
          {
            value: rawData.最新アンケート.開始 ?? '',
            label: rawData.最新アンケート.タイトル ?? '最新アンケート',
          },
        ]
      : [];

    const currentPeriod = rawData.最新アンケート?.開始 ?? null;

    return {
      companySummary,
      departmentData,
      alerts,
      trendDataEnhanced,
      periodOptions,
      currentPeriod,
    };
  }, [rawData]);

  return {
    data: transformedData,
    loading: isLoading,
    error: error ? String(error) : null,
  };
};
