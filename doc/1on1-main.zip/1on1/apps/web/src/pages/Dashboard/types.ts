/**
 * ダッシュボードページの型定義
 */

/**
 * 期間選択オプション
 */
export interface PeriodOption {
  value: string;
  label: string;
}

/**
 * ヘッダー情報
 */
export interface Header {
  periodOptions?: PeriodOption[];
  currentPeriod?: string;
}

/**
 * 平均指標データ
 */
export interface AverageMetrics {
  satisfaction?: number;
  workload?: number;
  environment?: number;
  relationship?: number;
  stress?: number;
}

/**
 * 会社全体のサマリー
 */
export interface CompanySummary {
  responseRate?: number;
  respondedEmployees?: number;
  totalEmployees?: number;
  averageMetrics?: AverageMetrics;
}

/**
 * 部署別サマリーの1項目
 */
export interface DepartmentSummaryItem {
  department?: string;
  satisfaction?: number;
  workload?: number;
  environment?: number;
  relationship?: number;
  stress?: number;
  [key: string]: string | number | undefined;
}

/**
 * アラート情報の1項目
 */
export interface AlertItem {
  name?: string;
  department?: string;
  issue?: string;
  duration?: string;
  status?: string;
  [key: string]: string | number | undefined;
}

/**
 * トレンドグラフのデータセット1つ
 */
export interface TrendDataset {
  label?: string;
  data?: number[];
  color?: string;
}

/**
 * トレンドデータ
 */
export interface TrendData {
  labels?: string[];
  datasets?: TrendDataset[];
}

/**
 * ダッシュボードAPIから返されるデータ全体
 */
export interface DashboardSummary {
  header?: Header;
  companySummary?: CompanySummary;
  departmentSummary?: DepartmentSummaryItem[];
  alerts?: AlertItem[];
  trendData?: TrendData;
  [key: string]: unknown;
}

/**
 * 画面表示用: 平均指標データ（必須フィールド版）
 */
export interface DisplayAverageMetrics {
  satisfaction: number;
  workload: number;
  environment: number;
  relationship: number;
  stress: number;
}

/**
 * 画面表示用: 会社全体のサマリー（必須フィールド版）
 */
export interface DisplayCompanySummary {
  responseRate: number;
  respondedEmployees: number;
  totalEmployees: number;
  averageMetrics: DisplayAverageMetrics;
}

/**
 * 画面表示用: トレンドグラフのデータセット1つ（必須フィールド版）
 */
export interface DisplayTrendDataset {
  label: string;
  data: number[];
  borderColor?: string;
  backgroundColor?: string;
  tension?: number;
  fill?: boolean;
  [key: string]: unknown;
}

/**
 * 画面表示用: トレンドデータ（必須フィールド版）
 */
export interface DisplayTrendData {
  labels: string[];
  datasets: DisplayTrendDataset[];
}
