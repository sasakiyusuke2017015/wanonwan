import { useEffect } from 'react';

import { Link } from 'react-router-dom';

import { ROUTES } from '@/constants/routes';

export default function AboutPage() {

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.ABOUT.label;
  }, []);
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-2xl rounded-lg bg-white p-8 shadow-lg">
        <h1 className="mb-4 text-fluid-2xl font-bold">About</h1>
        <p className="mb-4">
          このアプリケーションはVite + React +
          Storybookを使って開発されています。
          アトミックデザインの原則に基づいてコンポーネントを設計しています。
        </p>
        <Link
          to="/"
          className="inline-block rounded px-4 py-2 font-medium text-white transition-opacity hover:opacity-90 bg-theme-accent-bg"
        >
          HOMEに戻る
        </Link>
      </div>
    </div>
  );
}
