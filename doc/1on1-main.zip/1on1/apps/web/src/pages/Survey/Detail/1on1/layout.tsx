// src/pages/SurveyDetail/layout.tsx
import { useMemo } from 'react';

import { FormField } from '@ui-catalog/core/molecules';
import { LoadingZone } from '@ui-catalog/core/organisms';

import type { Question as QuestionType, SurveyAnswers, SurveyDetailData } from './types';

interface SurveyDetailLayoutProps {
  surveyData: SurveyDetailData | null;
  loading: boolean;
  isEditMode: boolean;
  answers: SurveyAnswers;
  onAnswerChange: (questionId: number, value: string) => void;
  validationErrors?: Record<string, string>;
}

/**
 * アンケート詳細用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
export default function SurveyDetailLayout({
  surveyData,
  loading,
  isEditMode,
  answers,
  onAnswerChange,
  validationErrors = {},
}: SurveyDetailLayoutProps) {
  const sortedQuestions = useMemo(() => {
    if (!surveyData?.アンケート内容JSON) return [];
    return [...surveyData.アンケート内容JSON].sort((a, b) => a.ソート順 - b.ソート順);
  }, [surveyData]);

  const renderInput = (question: QuestionType) => {
    const questionKey = `question_${question.質問ID}`;
    const currentValue = answers[questionKey] || '';
    const options = question.選択肢.filter((opt: string) => opt !== '');
    const disabledClass = !isEditMode ? 'cursor-not-allowed bg-gray-100 text-gray-500' : '';

    switch (question.回答形式) {
      case 'ラジオボタン':
        return (
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2 lg:grid-cols-3">
            {options.map((opt) => {
              const isSelected = currentValue === opt;
              return (
                <label
                  key={opt}
                  className={`flex cursor-pointer items-center gap-2 rounded px-3 py-2 transition-colors ${
                    isSelected ? 'bg-blue-500 text-white' : 'hover:bg-blue-50'
                  } ${!isEditMode ? 'cursor-not-allowed opacity-50' : ''}`}
                >
                  <input
                    type="radio"
                    name={questionKey}
                    value={opt}
                    checked={isSelected}
                    onChange={() => onAnswerChange(question.質問ID, opt)}
                    disabled={!isEditMode}
                    className="h-4 w-4"
                  />
                  <span className={`text-sm ${isSelected ? 'font-medium text-white' : 'text-gray-700'}`}>{opt}</span>
                </label>
              );
            })}
          </div>
        );

      case 'チェックボックス': {
        const checkedValues = currentValue ? currentValue.split(',') : [];
        return (
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2 lg:grid-cols-3">
            {options.map((opt) => {
              const isChecked = checkedValues.includes(opt);
              return (
                <label
                  key={opt}
                  className={`flex cursor-pointer items-center gap-2 rounded px-3 py-2 transition-colors ${
                    isChecked ? 'bg-blue-500 text-white' : 'hover:bg-blue-50'
                  } ${!isEditMode ? 'cursor-not-allowed opacity-50' : ''}`}
                >
                  <input
                    type="checkbox"
                    value={opt}
                    checked={isChecked}
                    onChange={(e) => {
                      const next = e.target.checked
                        ? [...checkedValues, opt]
                        : checkedValues.filter((v) => v !== opt);
                      onAnswerChange(question.質問ID, next.join(','));
                    }}
                    disabled={!isEditMode}
                    className="h-4 w-4"
                  />
                  <span className={`text-sm ${isChecked ? 'font-medium text-white' : 'text-gray-700'}`}>{opt}</span>
                </label>
              );
            })}
          </div>
        );
      }

      case 'セレクトボックス':
        return (
          <select
            name={questionKey}
            value={currentValue}
            onChange={(e) => onAnswerChange(question.質問ID, e.target.value)}
            disabled={!isEditMode}
            className={`w-full rounded border border-gray-300 px-3 py-2 text-sm text-gray-700 ${disabledClass}`}
          >
            <option value="">選択してください</option>
            {options.map((opt) => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
        );

      case 'テキストエリア':
        return (
          <textarea
            name={questionKey}
            value={currentValue}
            onChange={(e) => onAnswerChange(question.質問ID, e.target.value)}
            disabled={!isEditMode}
            rows={6}
            placeholder="回答を入力してください"
            className={`w-full rounded border-2 border-gray-300 px-3 py-2 text-sm text-gray-700 placeholder:text-gray-400 ${disabledClass}`}
          />
        );

      case '電話番号':
        return (
          <>
            <input
              type="tel"
              name={questionKey}
              value={currentValue}
              onChange={(e) => onAnswerChange(question.質問ID, e.target.value.replace(/[^\d-]/g, ''))}
              disabled={!isEditMode}
              placeholder="例: 03-1234-5678 または 090-1234-5678"
              className={`w-full rounded border border-gray-300 px-3 py-2 text-sm text-gray-700 placeholder:text-gray-400 ${disabledClass}`}
            />
            <p className="mt-1 text-xs text-gray-500">ハイフン（-）を含めて入力してください</p>
          </>
        );

      case '郵便番号':
        return (
          <>
            <input
              type="text"
              name={questionKey}
              value={currentValue}
              onChange={(e) => onAnswerChange(question.質問ID, e.target.value.replace(/[^\d-]/g, ''))}
              disabled={!isEditMode}
              placeholder="例: 123-4567 または 1234567"
              maxLength={8}
              className={`w-full rounded border border-gray-300 px-3 py-2 text-sm text-gray-700 placeholder:text-gray-400 ${disabledClass}`}
            />
            <p className="mt-1 text-xs text-gray-500">7桁の数字で入力してください（ハイフンあり・なし両方可）</p>
          </>
        );

      default:
        return (
          <input
            type="text"
            name={questionKey}
            value={currentValue}
            onChange={(e) => onAnswerChange(question.質問ID, e.target.value)}
            disabled={!isEditMode}
            placeholder="回答を入力してください"
            className={`w-full rounded border-2 border-gray-300 px-3 py-2 text-sm text-gray-700 placeholder:text-gray-400 ${disabledClass}`}
          />
        );
    }
  };

  return (
    <div className="container mx-auto">
      <LoadingZone
        loading={loading}
        variant="card"
        preset="orbit"
        height="400px"
      >
        {surveyData && (
          <section className="rounded border bg-white shadow">
            <div className="container mx-auto p-3">
              <div className="mb-6">
                {sortedQuestions.map((question, index) => (
                  <FormField
                    key={question.質問ID}
                    variant="question"
                    label={`${index + 1}. ${question.タイトル}`}
                    description={question.タイトル備考 || undefined}
                    required={question.必須回答}
                    error={validationErrors[`question_${question.質問ID}`]}
                  >
                    {renderInput(question)}
                  </FormField>
                ))}
              </div>
            </div>
          </section>
        )}
      </LoadingZone>
    </div>
  );
}
