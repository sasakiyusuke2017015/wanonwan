// src/pages/SurveyDetail/index.tsx
import { useCallback, useEffect, useMemo, useState } from 'react';

import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from 'react-router-dom';

import { Icon } from '@ui-catalog/core/atoms';
// TODO: Badgeを一時的に非表示
// import { Badge } from '@ui-catalog/core/atoms';
import { BackButton, Button, QACardList, StepIndicator } from '@ui-catalog/core/molecules';
import { AlertDialog, ConfirmDialog } from '@ui-catalog/core/organisms';
import { type Tab } from '@1on1/layouts/organisms/AppSubHeader';
import AppLayout from '@1on1/layouts/templates/AppLayout';

import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { useStreamingApi } from '@/hooks/api/useStreaming';
import { useAlert, useConfirm } from '@ui-catalog/core/hooks/ui';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiPost } from '@/lib/api';

/** 送信成功後にアニメーション表示するためのsessionStorageキー */
const COMPLETED_SURVEY_ID_KEY = 'completedSurveyId';

import SurveyDetailLayout from './layout';

import type { SurveyAnswers, SurveyDetailData, AnswerItem, QuestionWithAnswer } from './types';

/**
 * アンケート詳細ページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function SurveyDetail() {
  const navigate = useNavigate();
  const { id: publishId } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();
  const queryClient = useQueryClient();
  const { alertState, showAlert, closeAlert } = useAlert();
  const { confirmState, showConfirm, handleConfirm, handleCancel } = useConfirm();

  // location.stateからsurveyDataを取得し、stateで保持（mode変更時に失われないように）
  const [cachedSurveyData] = useState<SurveyDetailData | null>(() => {
    const state = location.state as { surveyData?: SurveyDetailData } | null;
    return state?.surveyData ?? null;
  });

  // URLパラメータからモードを取得（デフォルトはedit）
  const mode = useMemo(() => {
    const modeParam = searchParams.get('mode');
    if (modeParam === 'preview') return 'preview';  // 送信前確認
    if (modeParam === 'review') return 'review';    // 送信済み振り返り
    if (modeParam === 'success') return 'success';
    if (modeParam === 'error') return 'error';
    return 'edit';
  }, [searchParams]);

  const isEditMode = mode === 'edit';
  const isPreviewMode = mode === 'preview';  // 送信前確認
  const isReviewMode = mode === 'review';    // 送信済み振り返り
  const isSuccessMode = mode === 'success';
  const isErrorMode = mode === 'error';

  // モード変更時（編集・確認・送信・振り返り画面）にスクロールを天井に戻す（easeIn）
  useEffect(() => {
    if (isEditMode || isPreviewMode || isSuccessMode || isReviewMode) {
      const el = document.querySelector('[data-component="app-main"]') ?? document.documentElement;
      const start = el.scrollTop;
      if (start === 0) return;
      const duration = 400;
      const startTime = performance.now();
      const easeIn = (t: number) => t * t;

      const animate = (now: number) => {
        const elapsed = Math.min((now - startTime) / duration, 1);
        el.scrollTop = start * (1 - easeIn(elapsed));
        if (elapsed < 1) requestAnimationFrame(animate);
      };
      requestAnimationFrame(animate);
    }
  }, [isEditMode, isPreviewMode, isSuccessMode, isReviewMode]);

  // エラー詳細（location.stateから取得）
  const errorDetails = useMemo(() => {
    const state = location.state as { errorDetails?: string } | null;
    return state?.errorDetails || null;
  }, [location.state]);

  // 一覧から渡されたデータのみ使用（APIエンドポイント不要）
  const surveyData = cachedSurveyData as SurveyDetailData | null;

  // ローディング状態（キャッシュデータがない場合は即座にリダイレクト）
  const loading = false;

  // アンケート回答送信用（React Query mutation）
  const submitSurveyMutation = useMutation({
    mutationFn: (data: { publishId: string; answers: AnswerItem[] }) =>
      apiPost<{ success: boolean; answerId?: number }>(`/surveys/${data.publishId}/submit`, { answers: data.answers }),
  });

  // AIコメント生成用ストリーミングAPI
  // AI生成はオプショナル：エラー時もアンケート送信は成功扱い
  const {
    stream: generateAiComment,
    isStreaming,
    streamingText,
    data: streamingResponse,
  } = useStreamingApi<{ code: string; status: string; message: string }>();

  // フォーム回答状態（レビューページから戻ってきた場合は復元）
  const [answers, setAnswers] = useState<SurveyAnswers>(() => {
    const state = location.state as { answers?: SurveyAnswers } | null;
    return state?.answers || {};
  });

  // バリデーションエラー状態
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});


  // ページタイトルを状態に応じて設定
  const pageTitle = useMemo(() => {
    if (isSuccessMode) return '送信完了';
    if (isErrorMode) return '送信エラー';
    if (isEditMode) return 'アンケート回答';
    if (isPreviewMode) return 'アンケート確認';
    if (isReviewMode) return 'アンケート振り返り';
    return 'アンケート';
  }, [isSuccessMode, isErrorMode, isEditMode, isPreviewMode, isReviewMode]);

  useEffect(() => {
    document.title = pageTitle;
  }, [pageTitle]);

  // キャッシュデータがない場合（直接URLアクセス）は一覧にリダイレクト
  useEffect(() => {
    if (!cachedSurveyData && !isSuccessMode && !isErrorMode) {
      navigate('/surveys');
    }
  }, [cachedSurveyData, isSuccessMode, isErrorMode, navigate]);

  // preview モードでリロードされた場合（回答データがない場合）は一覧にリダイレクト
  useEffect(() => {
    if (isPreviewMode && !loading && Object.keys(answers).length === 0) {
      navigate('/surveys');
    }
  }, [isPreviewMode, loading, answers, navigate]);

  // review モードでリロードされた場合（キャッシュデータがない場合）は一覧にリダイレクト
  useEffect(() => {
    if (isReviewMode && !loading && !cachedSurveyData?.アンケート内容JSON) {
      navigate('/surveys');
    }
  }, [isReviewMode, loading, cachedSurveyData, navigate]);


  const handleAnswerChange = useCallback((questionId: number, value: string) => {
    const questionKey = `question_${questionId}`;
    setAnswers((prev) => ({
      ...prev,
      [questionKey]: value,
    }));

    // 入力時にエラーをクリア
    setValidationErrors((prev) => {
      if (!prev[questionKey]) return prev;
      const newErrors = { ...prev };
      delete newErrors[questionKey];
      return newErrors;
    });

    // 必須項目の場合、空欄チェック
    if (surveyData?.アンケート内容JSON) {
      const question = surveyData.アンケート内容JSON.find((q) => q.質問ID === questionId);
      if (question?.必須回答 && (!value || value.trim() === '')) {
        setValidationErrors((prev) => ({
          ...prev,
          [questionKey]: 'この項目は必須です',
        }));
      }
    }
  }, [surveyData]);

  const validateAnswers = (): boolean => {
    if (!surveyData?.アンケート内容JSON) return true;

    const errors: Record<string, string> = {};
    const requiredQuestions = surveyData.アンケート内容JSON.filter((q) => q.必須回答);

    for (const question of requiredQuestions) {
      const questionKey = `question_${question.質問ID}`;
      const answer = answers[questionKey];
      if (!answer || answer.trim() === '') {
        errors[questionKey] = 'この項目は必須です';
      }
    }

    setValidationErrors(errors);

    if (Object.keys(errors).length > 0) {
      showAlert('必須項目に入力してください。', {
        title: '入力エラー',
        type: 'warning',
      });
      return false;
    }
    return true;
  };

  const handleSubmit = () => {
    if (!publishId) return;

    // バリデーション
    if (!validateAnswers()) {
      return;
    }

    // プレビューモードに遷移（ページ遷移なし）
    setSearchParams({ mode: 'preview' });
  };

  // プレビューモードから編集に戻る
  const handleBackToEdit = () => {
    setSearchParams({ mode: 'edit' });
  };

  // フロントでプロンプトを構築（生成プロンプト + 回答内容）
  const buildUserPrompt = (answerItems: AnswerItem[]): string => {
    if (!surveyData?.ユーザー用生成プロンプト) return '';
    const answersText = 'アンケート内容：' + JSON.stringify(answerItems);
    return `${surveyData.ユーザー用生成プロンプト}\n${answersText}`;
  };

  // サポーター向けプロンプトを構築
  const buildSupporterPrompt = (answerItems: AnswerItem[]): string => {
    if (!surveyData?.サポーター用生成プロンプト) return '';
    const answersText = 'アンケート内容：' + JSON.stringify(answerItems);
    return `${surveyData.サポーター用生成プロンプト}\n${answersText}`;
  };

  // 送信確定ボタン
  const handleConfirmSubmit = () => {
    if (!publishId || !answers || !surveyData) return;

    showConfirm('アンケートを送信してもよろしいですか？', {
      title: '送信確認',
      type: 'info',
      confirmText: '送信する',
      cancelText: 'キャンセル',
      onConfirm: () => {
        // answersを API形式に変換
        const answerItems: AnswerItem[] = surveyData.アンケート内容JSON.map((question) => {
          const answer = answers[`question_${question.質問ID}`] || '';
          return {
            question_id: String(question.質問ID),
            question: question.タイトル,
            answer,
          };
        });

        // プロンプトを構築（生成プロンプトがあればAI生成を実行）
        const userPrompt = buildUserPrompt(answerItems);
        const supporterPrompt = buildSupporterPrompt(answerItems);

        // 即座にsuccess画面へ遷移（API送信完了を待たない）
        setSearchParams({ mode: 'success' });

        // 移動アニメーション用にIDを保存
        sessionStorage.setItem(COMPLETED_SURVEY_ID_KEY, publishId);

        // バックグラウンドで回答を送信
        submitSurveyMutation.mutate(
          {
            publishId,
            answers: answerItems,
          },
          {
            onSuccess: (response) => {
              const answerId = response.answerId;

              // キャッシュ無効化（一覧に戻った時に再取得）
              queryClient.invalidateQueries({ queryKey: ['surveys', 'list'] });
              queryClient.invalidateQueries({ queryKey: ['answers'] });

              // ユーザー向けAI生成（画面に表示、ストリーミング）
              if (userPrompt && answerId) {
                generateAiComment(
                  { user_prompt: userPrompt, agent_id: '' },
                  `/surveys/${answerId}/ai/user`
                ).catch((err) => {
                  console.error('AI生成エラー:', err.message);
                  showAlert(`AI分析に失敗しました: ${err.message}`, {
                    title: 'AI分析エラー',
                    type: 'error',
                  });
                  setSearchParams({ mode: 'error' });
                });

                // サポーター向けAI生成（バックグラウンドで実行）
                if (supporterPrompt) {
                  apiPost(`/surveys/${answerId}/ai/supporter`, {
                    user_prompt: supporterPrompt,
                    agent_id: '',
                  }).catch((err) => {
                    console.error('サポーター向けAI生成エラー:', err.message);
                  });
                }
              }
            },
            onError: (error) => {
              console.error('アンケート送信エラー:', error);
              showAlert('アンケートの送信に失敗しました。', {
                title: '送信エラー',
                type: 'error',
              });
              setSearchParams({ mode: 'error' });
            },
          }
        );
      },
    });
  };

  // 印刷ボタン
  const handlePrint = () => {
    window.print();
  };

  // SubHeaderCenter: アンケートタイトルと説明文
  const subHeaderCenter = useMemo(() => {
    if (!surveyData) return null;

    if (isSuccessMode) {
      return (
        <div className="flex flex-col items-center text-center">
          <h2 className="text-fluid-xl font-bold text-gray-800">{surveyData.タイトル}</h2>
          <p className="mt-1 text-fluid-sm text-gray-600">アンケートの送信が完了しました</p>
        </div>
      );
    }

    if (isErrorMode) {
      return (
        <div className="flex flex-col items-center text-center">
          <h2 className="text-fluid-xl font-bold text-gray-800">{surveyData.タイトル}</h2>
          <p className="mt-1 text-fluid-sm text-gray-600">アンケートの送信に失敗しました</p>
        </div>
      );
    }

    if (isPreviewMode) {
      return (
        <div className="flex flex-col items-center text-center">
          <h2 className="text-fluid-xl font-bold text-gray-800">{surveyData.タイトル}</h2>
          <p className="mt-1 text-fluid-sm text-gray-600">入力内容をご確認ください</p>
        </div>
      );
    }

    if (isReviewMode) {
      return (
        <div className="flex flex-col items-center text-center">
          <h2 className="text-fluid-xl font-bold text-gray-800">{surveyData.タイトル}</h2>
          <p className="mt-1 text-fluid-sm text-gray-600">過去の回答内容を確認できます</p>
        </div>
      );
    }

    return (
      <div className="flex flex-col items-center text-center">
        <h2 className="text-fluid-xl font-bold text-gray-800">{surveyData.タイトル}</h2>
        <p className="mt-1 text-fluid-sm text-gray-600">
          あなたの現在の状況や気持ちについて、率直に回答してください
        </p>
      </div>
    );
  }, [surveyData, isSuccessMode, isErrorMode, isPreviewMode, isReviewMode]);

  const subHeaderRight = useMemo(() => {
    // TODO: Badgeを一時的に非表示
    // const modeConfig = {
    //   preview: { text: '送信前確認', color: 'blue' as const },
    //   review: { text: '振り返り', color: 'gray' as const },
    //   edit: { text: '入力', color: 'green' as const },
    //   success: { text: '送信完了', color: 'green' as const },
    //   error: { text: 'エラー', color: 'red' as const },
    // };

    // const config = modeConfig[mode];

    // return (
    //   <Badge
    //     value={config.text}
    //     appearance="status"
    //     variant="solid"
    //     color={config.color}
    //     size="medium"
    //   />
    // );
    return null;
  }, [mode]);

  // SubHeaderのタブ定義
  const subHeaderTabs: Tab[] = useMemo(() => [{
    key: 'main',
    label: 'メイン',
    content: (
      <div className="flex items-center justify-between">
        <div className="flex-1"></div>
        <div className="flex justify-center">{subHeaderCenter}</div>
        <div className="flex flex-1 justify-end">{subHeaderRight}</div>
      </div>
    ),
  }], [subHeaderCenter, subHeaderRight]);

  // Footerコンテンツ
  const footerContent = useMemo(() => {
    // 送信成功画面
    if (isSuccessMode) {
      const isAnalyzing = isStreaming || submitSurveyMutation.isPending;
      return (
        <div id="MainCommandsContainer">
          <div id="MainCommands" className="flex justify-center gap-2">
            <BackButton onClick={() => navigate('/surveys')} label="戻る（一覧）" disabled={isAnalyzing} />
            <Button
              size="small"
              onClick={handlePrint}
              leftIcon={'file'}
              disabled={isAnalyzing}
            >
              回答を印刷
            </Button>
          </div>
        </div>
      );
    }

    // エラー画面ではフッター非表示
    if (isErrorMode) {
      return null;
    }

    // 送信前確認モード
    if (isPreviewMode) {
      return (
        <div id="MainCommandsContainer">
          <div id="MainCommands" className="flex justify-center gap-2">
            <BackButton onClick={handleBackToEdit} label="戻る（修正）" />
            <Button
              variant="primary"
              size="small"
              leftIcon={'comment-check'}
              onClick={handleConfirmSubmit}
            >
              送信確定
            </Button>
          </div>
        </div>
      );
    }

    if (isEditMode) {
      return (
        <div id="MainCommandsContainer">
          <div id="MainCommands" className="flex justify-center gap-2">
            <BackButton onClick={() => navigate('/surveys')} />
            <Button
              variant="primary"
              size="small"
              onClick={handleSubmit}
              leftIcon={'arrow-up-right'}
            >
              確認画面へ
            </Button>
          </div>
        </div>
      );
    }

    // 振り返りモード（送信済み結果の閲覧）
    if (isReviewMode) {
      return (
        <div id="MainCommandsContainer">
          <div id="MainCommands" className="flex justify-center gap-2">
            <BackButton onClick={() => navigate('/surveys')} label="戻る（一覧）" />
            <Button
              size="small"
              onClick={handlePrint}
              leftIcon={'file'}
            >
              回答を印刷
            </Button>
          </div>
        </div>
      );
    }

    return null;
  }, [isSuccessMode, isErrorMode, isEditMode, isPreviewMode, isReviewMode, handleBackToEdit, handleConfirmSubmit, handleSubmit, handlePrint, navigate]);

  // 送信前確認用のデータ形式に変換（ソート順でソート）
  const previewData = useMemo(() => {
    if (!surveyData?.アンケート内容JSON || !answers) return [];

    return [...surveyData.アンケート内容JSON]
      .sort((a, b) => (a.ソート順 || 0) - (b.ソート順 || 0))
      .map((question) => {
        const answer = answers[`question_${question.質問ID}`] || '';
        return {
          question: question.タイトル,
          answer,
        };
      });
  }, [surveyData, answers]);

  // review モード用のデータ（回答済みデータ）
  // SurveyListから渡されるアンケート内容JSONは { question_id, question, answer } 形式
  const reviewData = useMemo(() => {
    if (!cachedSurveyData?.アンケート内容JSON) return [];
    const items = cachedSurveyData.アンケート内容JSON as unknown as QuestionWithAnswer[];
    return items.map((q) => ({
      question: q.question,
      answer: q.answer,
    }));
  }, [cachedSurveyData]);

  // review モード用のAIコメント（ユーザー向け・サポーター向け）
  const reviewAiComment = useMemo(() => {
    return cachedSurveyData?.ユーザー用生成回答 || undefined;
  }, [cachedSurveyData]);

  // パンくずリストの生成（モードに応じてラベルを変更）
  const breadcrumbs = useMemo(() => {
    let breadcrumbLabel: string;
    if (isEditMode) {
      breadcrumbLabel = 'アンケート記載';
    } else if (isPreviewMode) {
      breadcrumbLabel = 'アンケート確認';
    } else if (isSuccessMode) {
      breadcrumbLabel = 'アンケート送信';
    } else if (isReviewMode) {
      breadcrumbLabel = 'アンケート振り返り';
    } else {
      breadcrumbLabel = surveyData?.タイトル || 'アンケート詳細';
    }
    return getBreadcrumbs(ROUTES.SURVEY_DETAIL.path, {
      id: publishId || '',
      title: breadcrumbLabel,
    });
  }, [publishId, surveyData?.タイトル, mode, isEditMode, isPreviewMode, isSuccessMode, isReviewMode]);

  // メインコンテンツの決定
  const mainContent = useMemo(() => {
    // 送信成功画面（ストリーミング中も表示）
    if (isSuccessMode) {
      const aiMessage = streamingText || streamingResponse?.message || '';

      return (
        <div className="p-4">
          {/* ステップインジケーター */}
          <div className="mb-6">
            <StepIndicator
              steps={[
                { label: '回答記入', status: 'completed' },
                { label: '送信確認', status: 'completed' },
                { label: 'AI分析', status: isStreaming || submitSurveyMutation.isPending ? 'in_progress' : 'completed', loadingIcon: 'loading-heartbeat' },
                { label: '完了', status: isStreaming || submitSurveyMutation.isPending ? 'pending' : 'completed' },
              ]}
              completedColor="green"
              activeColor="blue"
            />
          </div>

          <div className="flex flex-col items-center justify-center p-8">
            {isStreaming || submitSurveyMutation.isPending ? (
              <>
                {/* AI分析中（API送信中・ストリーミング中） */}
                <div className="mb-6">
                  <Icon
                    preset="dna"
                    size={80}
                    stroke="blue"
                    strokeWidth={1.5}
                  />
                </div>
                <h3 className="mb-3 text-fluid-2xl font-bold text-gray-800">
                  AIが回答を分析中...
                </h3>
                <p className="mb-4 text-gray-600">
                  しばらくお待ちください
                </p>
                <p className="mb-6 text-fluid-sm text-gray-500">
                  分析中にページを閉じると回答の送信が完了しないことがあります
                </p>
              </>
            ) : (
              <>
                {/* 送信完了・AI分析完了 */}
                <div className="mb-6">
                  <Icon
                    name={'comment-check'}
                    size={80}
                    stroke="green"
                    strokeWidth={1.5}
                  />
                </div>
                <h3 className="mb-3 text-fluid-2xl font-bold text-gray-800">
                  送信完了しました！
                </h3>
                <p className="mb-6 text-gray-600">
                  入力いただいたデータは管理職に共有されます。
                </p>
              </>
            )}
          </div>

          {/* AIコメント表示（QACardListコンポーネントを共有） */}
          {aiMessage && (
            <div className="mt-4">
              <QACardList
                items={[]}
                aiComment={aiMessage}
                aiCommentStreaming={isStreaming}
              />
            </div>
          )}
        </div>
      );
    }

    // エラー画面
    if (isErrorMode) {
      return (
        <div className="flex flex-col items-center justify-center p-8">
          {/* エラーアイコン */}
          <div className="mb-6">
            <Icon
              name={'info-triangle'}
              size={80}
              stroke="red"
              strokeWidth={1.5}
            />
          </div>

          {/* タイトル */}
          <h3 className="mb-3 text-fluid-2xl font-bold text-gray-800">
            送信に失敗しました
          </h3>

          {/* エラーメッセージ */}
          <p className="mb-6 text-gray-600">
            アンケートの送信中にエラーが発生しました。
          </p>

          {/* エラー詳細 */}
          {errorDetails && (
            <div className="mb-6 w-full rounded-lg border border-red-200 bg-red-50 p-4">
              <h5 className="mb-2 text-fluid-lg font-semibold text-red-800">
                エラー詳細:
              </h5>
              <p className="whitespace-pre-wrap text-red-700">{errorDetails}</p>
            </div>
          )}

          {/* アクションボタン */}
          <div className="flex justify-center gap-3">
            <Button
              variant="primary"
              size="medium"
              onClick={() => setSearchParams({ mode: 'preview' })}
              leftIcon={'arrow-u-turn'}
            >
              確認画面に戻る
            </Button>
            <Button
              variant="secondary"
              size="medium"
              onClick={() => navigate('/surveys')}
              leftIcon={'arrow-u-turn'}
            >
              戻る（一覧）
            </Button>
          </div>
        </div>
      );
    }

    // 送信前確認画面
    if (isPreviewMode) {
      return (
        <div className="p-4">
          {/* ステップインジケーター */}
          <div className="mb-6">
            <StepIndicator
              steps={[
                { label: '回答記入', status: 'completed' },
                { label: '送信確認', status: 'in_progress', loadingIcon: 'loading-orbit' },
                { label: 'AI分析', status: 'pending' },
                { label: '完了', status: 'pending' },
              ]}
              completedColor="green"
              activeColor="blue"
            />
          </div>

          <QACardList items={previewData} variant="blue" />
        </div>
      );
    }

    // 振り返り画面（送信済み結果の閲覧）
    if (isReviewMode) {
      return (
        <div className={`p-4 ${reviewAiComment ? 'flex flex-col gap-4 lg:flex-row' : ''}`}>
          {/* 左: Q&Aリスト */}
          <div className={reviewAiComment ? 'w-full lg:w-1/2 min-w-0' : 'w-full'}>
            <QACardList
              items={reviewData}
              variant="green"
              infoMessage="これは過去に回答したアンケートの内容です（読み取り専用）"
            />
          </div>
          {/* 右: AIコメント */}
          {reviewAiComment && (
            <div className="w-full lg:w-1/2 min-w-0">
              <div className="sticky top-4 rounded-xl bg-gradient-to-r from-purple-50 to-indigo-50 p-4 shadow-sm border border-purple-200">
                <div className="flex items-center gap-2 mb-3">
                  <Icon name={'diamond'} size={20} stroke="purple" hover="auto" />
                  <span className="font-semibold text-purple-700">AIからのコメント</span>
                </div>
                <div className="bg-white rounded-lg p-3 border border-purple-100">
                  <p className="text-gray-700 whitespace-pre-wrap">{reviewAiComment}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // 入力画面
    return (
      <SurveyDetailLayout
        surveyData={surveyData}
        loading={loading}
        isEditMode={isEditMode}
        answers={answers}
        onAnswerChange={handleAnswerChange}
        validationErrors={validationErrors}
      />
    );
  }, [
    isSuccessMode,
    isErrorMode,
    isPreviewMode,
    isReviewMode,
    streamingText,
    streamingResponse,
    isStreaming,
    errorDetails,
    previewData,
    reviewData,
    reviewAiComment,
    surveyData,
    loading,
    isEditMode,
    answers,
    handleAnswerChange,
    validationErrors,
    setSearchParams,
    navigate,
  ]);

  return (
    <>
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={true}
        subHeaderTabs={subHeaderTabs}
        subHeaderLoading={loading}
        footerContent={footerContent}
        mainContent={mainContent}
      />
      <AlertDialog {...alertState} onClose={closeAlert} />
      <ConfirmDialog
        {...confirmState}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    </>
  );
}
