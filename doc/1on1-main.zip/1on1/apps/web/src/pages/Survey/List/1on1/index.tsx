// src/pages/SurveyList/index.tsx
import { useEffect, useMemo, useState } from 'react';

import { useAtomValue } from 'jotai';
import { useNavigate } from 'react-router-dom';

/** 送信成功後にアニメーション表示するためのsessionStorageキー */
const COMPLETED_SURVEY_ID_KEY = 'completedSurveyId';

import { StatisticPanel, type StatusDefinition } from '@ui-catalog/core/organisms';
import { type Tab } from '@1on1/layouts/organisms/AppSubHeader';
import AppLayout from '@1on1/layouts/templates/AppLayout';
import { formatDate } from '@1on1/domain/utils';
import { isPublishActive, isPublishCompleted } from '@/utils/status';
import { CONSTANTS } from '@/constants/schemas';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { useErrorHandler } from '@/hooks';
import { uiCardAnimationVariantAtom } from '@/state';

import { useSurveyListActiveTanStack, useSurveyListAnsweredTanStack } from './hooks.tanstack';
import SurveyListLayout, { Survey } from './layout';
import { SURVEY_STATUS_CONFIG } from './surveyCard';
import type { SurveyListParams } from './types';

// アンケート一覧用のステータス定義
const surveyStatusDef: Record<string, StatusDefinition> = {
  開催中: { value: 1, color: 'blue', label: '開催中', shortLabel: '開催中' },
  期限超過: { value: 2, color: 'red', label: '期限超過', shortLabel: '期限超過' },
  回答済: { value: 3, color: 'gray', label: '回答済', shortLabel: '回答済' },
};

/**
 * アンケート一覧ページ(コンテナコンポーネント)
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function SurveyList() {
  const navigate = useNavigate();
  const { handleError } = useErrorHandler();

  // アニメーション設定を取得（variant が 'none' 以外なら有効）
  const cardAnimationVariant = useAtomValue(uiCardAnimationVariantAtom);
  const enableCardAnimation = cardAnimationVariant !== 'none';

  // 回答完了したアンケートID（移動アニメーション用）
  const [completedSurveyId, setCompletedSurveyId] = useState<string | null>(null);

  // ページタイトルを設定 & 完了IDを取得
  useEffect(() => {
    document.title = ROUTES.SURVEYS.label;

    // sessionStorageから完了したアンケートIDを取得
    const id = sessionStorage.getItem(COMPLETED_SURVEY_ID_KEY);
    if (id) {
      setCompletedSurveyId(id);
      // 一度取得したらクリア
      sessionStorage.removeItem(COMPLETED_SURVEY_ID_KEY);
    }
  }, []);

  // APIパラメータ(キャッシュキー用)- useMemoでメモ化して無限ループを防止
  const activeParams = useMemo<SurveyListParams>(() => ({
    answerStatus: [CONSTANTS.ANSWER_STATUS['アンケート未回答'].value],
    publishStatus: [CONSTANTS.PUBLICATION_STATUS['実施中'].value, CONSTANTS.PUBLICATION_STATUS['完了'].value],
    orderBy: { 完了: 'desc', 開始: 'desc' },
  }), []);

  // APIからデータ取得(開催中・期限超過用：未回答) - TanStack Query版
  const {
    data: rawData,
    loading,
    refreshing,
    error,
    isOffline,
  } = useSurveyListActiveTanStack(activeParams);

  // 回答済みデータ用パラメータ - useMemoでメモ化
  const answeredParams = useMemo<SurveyListParams>(() => ({
    answerStatus: [CONSTANTS.ANSWER_STATUS['アンケート回答済'].value],
    publishStatus: [CONSTANTS.PUBLICATION_STATUS['実施中'].value, CONSTANTS.PUBLICATION_STATUS['完了'].value],
    orderBy: { 完了: 'asc', 開始: 'asc' },
  }), []);

  // 回答済みデータの取得 - TanStack Query版
  const {
    data: answeredRawData,
    loading: answeredLoading,
    refreshing: answeredRefreshing,
    error: answeredError,
  } = useSurveyListAnsweredTanStack(answeredParams);

  // エラーハンドリング(オフライン時はエラー表示しない)
  useEffect(() => {
    if (error && !loading && !isOffline) {
      handleError({
        message: 'アンケート一覧の取得に失敗しました',
        details: String(error),
        code: 'SURVEY_LIST_FETCH_ERROR',
      });
    }
  }, [error, loading, isOffline, handleError]);

  useEffect(() => {
    if (answeredError && !answeredLoading && !isOffline) {
      handleError({
        message: '回答済みアンケート一覧の取得に失敗しました',
        details: String(answeredError),
        code: 'ANSWERED_SURVEY_LIST_FETCH_ERROR',
      });
    }
  }, [answeredError, answeredLoading, isOffline, handleError]);

  // データをステータス別に振り分け
  const { activeSurveys, answeredSurveys, statistics } = useMemo(() => {
    const active: Survey[] = [];
    const overdue: Survey[] = [];
    const answered: Survey[] = [];

    // 開催中・期限超過データの処理
    // Fail Fast: APIは必ず { data: [...], total: number } 形式を返す
    if (rawData?.data) {
      const now = new Date();

      rawData.data.forEach((survey) => {
          const completionDate = new Date(survey.完了);
          const isOverdue = completionDate < now;
          // 掲載状況が「実施中」または「完了」なら表示対象
          const isDisplayTarget = isPublishActive(survey.掲載状況) || isPublishCompleted(survey.掲載状況);

          if (isDisplayTarget && isOverdue) {
            // 期限超過(実施中だが期限切れ)→ 開催中セクションに表示
            const surveyItem: Survey = {
              publishId: String(survey.掲載ID),
              title: survey.タイトル,
              description: survey.掲載内容,
              period: `${formatDate(survey.開始)} ～ ${formatDate(survey.完了)}`,
              ...SURVEY_STATUS_CONFIG.期限超過,
              rawData: survey,
            };
            active.push(surveyItem); // 開催中セクションに表示
            overdue.push(surveyItem); // 統計用にも追加
          } else if (isDisplayTarget) {
            // 開催中
            const surveyItem: Survey = {
              publishId: String(survey.掲載ID),
              title: survey.タイトル,
              description: survey.掲載内容,
              period: `${formatDate(survey.開始)} ～ ${formatDate(survey.完了)}`,
              ...SURVEY_STATUS_CONFIG.開催中,
              rawData: survey,
            };
            active.push(surveyItem);
          }
        });
    }

    // 回答済みデータの処理
    // Fail Fast: APIは必ず { data: [...], total: number } 形式を返す
    if (answeredRawData?.data) {
      answeredRawData.data.forEach((survey) => {
          const surveyItem: Survey = {
            publishId: String(survey.掲載ID),
            title: survey.タイトル,
            description: survey.掲載内容,
            period: `${formatDate(survey.開始)} ～ ${formatDate(survey.完了)}`,
            ...SURVEY_STATUS_CONFIG.回答済み,
            rawData: survey,
          };
          answered.push(surveyItem);
        });
    }

    return {
      activeSurveys: active,
      answeredSurveys: answered,
      statistics: {
        active: active.length - overdue.length, // 開催中のみ(期限超過を除く)
        overdue: overdue.length,
        answered: answered.length,
        total: active.length + answered.length, // 期限超過は active に含まれているため除外
      },
    };
  }, [rawData, answeredRawData]);

  // イベントハンドラー
  const handleSurveyClick = (survey: Survey) => {
    // 回答済みの場合は振り返りモード、それ以外は編集モード
    const mode = survey.status === '回答済み' ? 'review' : 'edit';
    navigate(`/surveys/${survey.publishId}?mode=${mode}`, {
      state: { surveyData: survey.rawData },
    });
  };

  // フッターボタンコンテンツ(現在は空)
  const footerButtonsContent = null;

  // サブヘッダーコンテンツ
  const subHeaderLeft = useMemo(() => (
    <StatisticPanel
      items={[
        { statusDef: surveyStatusDef.開催中, value: statistics.active },
        { statusDef: surveyStatusDef.期限超過, value: statistics.overdue },
        { statusDef: surveyStatusDef.回答済, value: statistics.answered },
      ]}
      totalLabel="全"
      totalValue={statistics.total}
      totalUnit="件"
      unit="件"
      emptyMessage="該当データなし"
    />
  ), [statistics]);

  // SubHeaderのタブ定義
  const subHeaderTabs: Tab[] = useMemo(() => [{
    key: 'main',
    label: 'メイン',
    content: subHeaderLeft,
  }], [subHeaderLeft]);

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.SURVEYS.path), []);

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={true}
      subHeaderTabs={subHeaderTabs}
      subHeaderLoading={loading || refreshing || answeredLoading || answeredRefreshing}
      footerContent={footerButtonsContent}
      mainContent={
        <SurveyListLayout
          loading={loading}
          answeredLoading={answeredLoading}
          activeSurveys={activeSurveys}
          answeredSurveys={answeredSurveys}
          overdueCount={statistics.overdue}
          onSurveyClick={handleSurveyClick}
          enableCardAnimation={enableCardAnimation}
          cardAnimationVariant={cardAnimationVariant}
          completedSurveyId={completedSurveyId}
        />
      }
    />
  );
}
