// src/pages/SurveyList/layout.tsx
import { AnimatePresence, motion } from 'framer-motion';

import { Banner, SurveyCard } from '@ui-catalog/core/molecules';
import { CardGrid, LoadingZone, BlurFade, ToggleableSection } from '@ui-catalog/core/organisms';
import { type CardAnimationVariant, type IconName } from '@/constants';
import { useThemeConfig } from '@/hooks';

import { type SurveyData } from './types';

export type Survey = {
  publishId: string;
  title: string;
  description?: string;
  period: string;
  status: string;
  statusColor: 'blue' | 'green' | 'red' | 'yellow' | 'gray' | 'orange';
  headerColor: string;
  buttonVariant: 'primary' | 'danger' | 'outline';
  buttonText: string;
  buttonIcon?: IconName;
  rawData?: SurveyData;
};

interface SurveyListLayoutProps {
  loading: boolean;
  answeredLoading: boolean;
  activeSurveys: Survey[];
  answeredSurveys: Survey[];
  overdueCount: number;
  onSurveyClick: (survey: Survey) => void;
  enableCardAnimation?: boolean;
  cardAnimationVariant?: CardAnimationVariant;
  /** 回答完了したアンケートID（移動アニメーション用） */
  completedSurveyId?: string | null;
}

/**
 * アンケート一覧用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
export default function SurveyListLayout({
  loading,
  answeredLoading,
  activeSurveys,
  answeredSurveys,
  overdueCount,
  onSurveyClick,
  enableCardAnimation: _enableCardAnimation = true,
  cardAnimationVariant = 'slideRight',
  completedSurveyId,
}: SurveyListLayoutProps) {
  const { colors, shapes } = useThemeConfig('SurveyList');

  return (
    <div className="container mx-auto">
      {/* 期限超過アラートバナー（BlurFadeでアニメーション） */}
      {overdueCount > 0 && (
        <BlurFade delay={0.1} inView>
          <div className="mb-4">
            <Banner
              variant="error"
              message={`回答期限を過ぎたアンケートが${overdueCount}件あります。早めに回答してください。`}
            />
          </div>
        </BlurFade>
      )}

      {/* 開催中アンケート（期限超過も含む） */}
      <ToggleableSection
        title="開催中のアンケート"
        borderColor={colors.accentBorderColor}
        defaultOpen={true}
        cardRadius={shapes.cardRadius}
      >
        <LoadingZone
          variant="simple"
          preset="hourglass"
          loading={loading}
        >
          {activeSurveys.length > 0 ? (
            <CardGrid
              animated={false}
              enableAnimation={false}
              animationVariant={cardAnimationVariant}
              cols={3}
            >
              <AnimatePresence mode="popLayout">
                {activeSurveys.map((survey, index) => (
                  <motion.div
                    key={survey.publishId}
                    layoutId={`survey-card-${survey.publishId}`}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, y: 50 }}
                    transition={{
                      type: 'spring',
                      stiffness: 300,
                      damping: 30,
                      delay: completedSurveyId === survey.publishId ? 0 : 0.1 + index * 0.05,
                    }}
                  >
                    <CardGrid.Item>
                      <SurveyCard
                        id={survey.publishId}
                        title={survey.title}
                        description={survey.description}
                        period={survey.period}
                        status={survey.status}
                        statusColor={survey.statusColor}
                        headerColor={survey.headerColor}
                        buttonVariant={survey.buttonVariant}
                        buttonText={survey.buttonText}
                        buttonIcon={survey.buttonIcon}
                        onClick={() => onSurveyClick(survey)}
                      />
                    </CardGrid.Item>
                  </motion.div>
                ))}
              </AnimatePresence>
            </CardGrid>
          ) : (
            <p className="text-gray-500">開催中のアンケートはありません</p>
          )}
        </LoadingZone>
      </ToggleableSection>

      {/* 回答済みセクション */}
      <ToggleableSection
        title="過去に回答済みのアンケート"
        borderColor="border-gray-600"
        defaultOpen={true}
        cardRadius={shapes.cardRadius}
      >
        <LoadingZone
          variant="simple"
          preset="hourglass"
          loading={loading || answeredLoading}
        >
          {answeredSurveys.length > 0 ? (
            <CardGrid
              animated={false}
              enableAnimation={false}
              animationVariant={cardAnimationVariant}
              cols={3}
            >
              <AnimatePresence mode="popLayout">
                {answeredSurveys.map((survey, index) => {
                  const isNewlyCompleted = completedSurveyId === survey.publishId;
                  return (
                    <motion.div
                      key={survey.publishId}
                      layoutId={`survey-card-${survey.publishId}`}
                      initial={isNewlyCompleted ? { opacity: 0, scale: 0.9, y: -50 } : { opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{
                        type: 'spring',
                        stiffness: 300,
                        damping: 30,
                        delay: isNewlyCompleted ? 0.2 : 0.1 + index * 0.05,
                      }}
                    >
                      <CardGrid.Item>
                        <SurveyCard
                          id={survey.publishId}
                          title={survey.title}
                          description={survey.description}
                          period={survey.period}
                          status={survey.status}
                          statusColor={survey.statusColor}
                          headerColor={survey.headerColor}
                          buttonVariant={survey.buttonVariant}
                          buttonText={survey.buttonText}
                          buttonIcon={survey.buttonIcon}
                          onClick={() => onSurveyClick(survey)}
                        />
                      </CardGrid.Item>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </CardGrid>
          ) : (
            <p className="text-gray-500">回答済みのアンケートはありません</p>
          )}
        </LoadingZone>
      </ToggleableSection>
    </div>
  );
}
