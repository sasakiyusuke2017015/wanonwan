/**
 * Survey設定定義
 * アンケートのステータスごとの表示設定を一元管理
 */


import type { Survey } from './layout';

/**
 * Surveyステータスごとの設定型
 */
type SurveyStatusConfig = Omit<Survey, 'id' | 'publishId' | 'title' | 'period'>;

/**
 * Survey ステータス設定
 * 各ステータスに応じたデザインとボタン設定を定義
 */
export const SURVEY_STATUS_CONFIG: Record<
  '開催中' | '期限超過' | '回答済み',
  SurveyStatusConfig
> = {
  開催中: {
    status: '開催中',
    statusColor: 'blue',
    headerColor: 'bg-blue-600',
    buttonVariant: 'primary',
    buttonText: '回答する',
    buttonIcon: 'comment-check',
  },
  期限超過: {
    status: '期限超過',
    statusColor: 'red',
    headerColor: 'bg-red-500',
    buttonVariant: 'danger',
    buttonText: '回答する',
    buttonIcon: 'comment-check',
  },
  回答済み: {
    status: '回答済み',
    statusColor: 'gray',
    headerColor: 'bg-blue-600',
    buttonVariant: 'outline',
    buttonText: '振り返る',
    buttonIcon: 'eye',
  },
} as const;
