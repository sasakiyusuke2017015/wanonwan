// src/pages/SurveyList/types.ts

export interface SurveyListParams {
  answerStatus?: number[];
  publishStatus?: number[];
  recentMonths?: number;
  orderBy?: Record<string, 'asc' | 'desc'>;
}

/**
 * アンケート内容のJSON構造
 */
export interface SurveyQuestionAnswer {
  question_id: string;
  question: string;
  answer: string;
}

/**
 * 個別のアンケートデータ
 */
export interface SurveyData {
  掲載ID: number;
  掲載状況: number;
  掲載内容?: string;
  内容: string;
  開始: string;
  完了: string;
  バッチ開始月: string;
  タイトル: string;
  アンケートID: number;
  回答ID?: number;
  回答状況: number;
  回答者?: string;
  アンケート内容JSON?: SurveyQuestionAnswer[];
  ユーザー用生成回答?: string;
  ユーザー用生成プロンプト?: string;
  サポーター用生成回答?: string;
  サポーター用生成プロンプト?: string;
}

/**
 * アンケート一覧APIレスポンス
 *
 * Fail Fast: APIは必ずこの形式を返す。不正な形式はエラーとする。
 */
export interface SurveyListResponse {
  data: SurveyData[];
  total: number;
}
