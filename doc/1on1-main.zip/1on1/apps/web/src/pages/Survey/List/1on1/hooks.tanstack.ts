/**
 * アンケート一覧ページ専用フック（React Query版）
 */
import { useQuery } from '@tanstack/react-query';

import { APP_CONFIG } from '@/constants/app';

import { apiGet } from '@/lib/api';

import type { SurveyListParams, SurveyListResponse } from './types';

/**
 * SurveyListParams → APIクエリパラメータを構築
 */
const buildSurveyQueryParams = (params: SurveyListParams): Record<string, unknown> => {
  return {
    limit: 100,
    offset: 0,
    answerStatus: params.answerStatus?.[0]?.toString(),
    publishStatus: params.publishStatus?.[0]?.toString(),
    recentMonths: params.recentMonths ?? APP_CONFIG.RECENT_MONTHS,
    orderBy: params.orderBy ? JSON.stringify(params.orderBy) : undefined,
  };
};

/**
 * アンケート一覧データ取得フック（React Query版）
 * 開催中・期限超過データを取得
 */
export const useSurveyListActiveTanStack = (params: SurveyListParams) => {
  const queryParams = buildSurveyQueryParams(params);

  const { data, isLoading, isFetching, error } = useQuery({
    queryKey: ['surveys', 'list', 'active', queryParams],
    queryFn: () => apiGet<SurveyListResponse>('/surveys', queryParams),
    staleTime: 5 * 60 * 1000, // 5分間キャッシュ
    gcTime: 24 * 60 * 60 * 1000, // 1日間保持
    retry: 3,
  });

  return {
    data,
    loading: isLoading,
    refreshing: isFetching && !isLoading,
    error,
    isOffline: false,
  };
};

/**
 * 回答済みアンケート一覧データ取得フック（React Query版）
 */
export const useSurveyListAnsweredTanStack = (params: SurveyListParams) => {
  const queryParams = buildSurveyQueryParams(params);

  const { data, isLoading, isFetching, error } = useQuery({
    queryKey: ['surveys', 'list', 'answered', queryParams],
    queryFn: () => apiGet<SurveyListResponse>('/surveys', queryParams),
    staleTime: 5 * 60 * 1000, // 5分間キャッシュ
    gcTime: 24 * 60 * 60 * 1000, // 1日間保持
    retry: 3,
  });

  return {
    data,
    loading: isLoading,
    refreshing: isFetching && !isLoading,
    error,
  };
};
