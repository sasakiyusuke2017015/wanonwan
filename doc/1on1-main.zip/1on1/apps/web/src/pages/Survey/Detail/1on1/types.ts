/**
 * Survey Input ページの型定義
 */

/**
 * 質問データの型
 */
export interface Question {
  質問ID: number;
  タイトル: string;
  タイトル備考: string;
  質問内容: string;
  内容備考: string;
  回答形式:
    | 'ラジオボタン'
    | 'セレクトボックス'
    | 'チェックボックス'
    | 'テキストボックス'
    | 'テキストエリア'
    | '電話番号'
    | '郵便番号';
  選択肢: string[];
  ソート順: number;
  必須回答: boolean;
  追加記入欄あり: boolean;
}

/**
 * 回答済み質問データの型（API送信後のレスポンス形式）
 */
export interface QuestionWithAnswer {
  question_id: string;
  question: string;
  answer: string;
}

/**
 * アンケート詳細データの型
 */
export interface SurveyDetailData {
  タイトル: string;
  アンケート内容JSON: Question[];
  // AI関連
  ユーザー用生成プロンプト?: string;
  サポーター用生成プロンプト?: string;
  ユーザー用生成回答?: string;
  サポーター用生成回答?: string;
}

/**
 * フォーム回答データの型
 */
export interface SurveyAnswers {
  [questionId: string]: string;
}

/**
 * 送信用回答アイテムの型
 */
export interface AnswerItem {
  question_id: string;
  question: string;
  answer: string;
}

