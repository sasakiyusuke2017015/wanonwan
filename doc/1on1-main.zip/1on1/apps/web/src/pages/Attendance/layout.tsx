// src/pages/Attendance/layout.tsx
import { format } from 'date-fns';
import { ja } from 'date-fns/locale/ja';

import { Icon } from '@ui-catalog/core/atoms';
import { Button, DatePicker, DevelopmentBanner } from '@ui-catalog/core/molecules';
import { InteractiveTable } from '@ui-catalog/core/organisms';
import { type TableRowAnimationVariant } from '@/constants';
import { useThemeConfig } from '@/hooks';
import { cn } from '@ui-catalog/core/utils';

import { type AttendanceRecord, type AttendanceSummary, type AttendanceStatus, type AttendanceTableRow } from './types';

interface AttendanceLayoutProps {
  currentRecord: AttendanceRecord | null;
  monthlyRecords: AttendanceRecord[];
  tableData: AttendanceTableRow[];
  summary: AttendanceSummary;
  loading: boolean;
  currentTime: Date;
  selectedMonth: string;
  onMonthChange: (value: string) => void;
  onClockIn: () => void;
  onClockOut: () => void;
  onBreakStart: () => void;
  onBreakEnd: () => void;
  enableTableRowAnimation?: boolean;
  tableRowAnimationVariant?: TableRowAnimationVariant;
}

// ステータスラベルと色の定義
const statusConfig: Record<AttendanceStatus, { label: string; color: string; bgColor: string }> = {
  not_started: { label: '未出勤', color: 'text-gray-600', bgColor: 'bg-gray-100' },
  working: { label: '勤務中', color: 'text-green-600', bgColor: 'bg-green-100' },
  on_break: { label: '休憩中', color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
  completed: { label: '退勤済', color: 'text-blue-600', bgColor: 'bg-blue-100' },
  absent: { label: '欠勤', color: 'text-red-600', bgColor: 'bg-red-100' },
  holiday: { label: '休日', color: 'text-purple-600', bgColor: 'bg-purple-100' },
  paid_leave: { label: '有給', color: 'text-teal-600', bgColor: 'bg-teal-100' },
};

// テーブル列定義
const tableColumns = [
  { accessor: 'date', label: '日付', proportion: '8%', dataAlign: 'center' as const },
  { accessor: 'dayOfWeek', label: '曜日', proportion: '6%', dataAlign: 'center' as const },
  { accessor: 'clockIn', label: '出勤', proportion: '10%', dataAlign: 'center' as const },
  { accessor: 'clockOut', label: '退勤', proportion: '10%', dataAlign: 'center' as const },
  { accessor: 'breakTime', label: '休憩', proportion: '10%', dataAlign: 'center' as const },
  { accessor: 'workHours', label: '勤務時間', proportion: '12%', dataAlign: 'center' as const },
  { accessor: 'statusLabel', label: '状態', proportion: '12%', dataAlign: 'center' as const },
  { accessor: 'note', label: '備考', proportion: '32%', dataAlign: 'left' as const },
];

// セルスタイル関数
const getCellClassName = (
  _rowIndex: number,
  _colIndex: number,
  column: { accessor: string },
  row: Record<string, unknown>
): string => {
  const classes: string[] = [];

  // 週末は背景色を変更
  if (row.isWeekend) {
    classes.push('bg-gray-50');
  }

  // 曜日の色分け
  if (column.accessor === 'dayOfWeek') {
    if (row.dayOfWeek === '日') {
      classes.push('text-red-500 font-medium');
    } else if (row.dayOfWeek === '土') {
      classes.push('text-blue-500 font-medium');
    }
  }

  // 状態の色分け
  if (column.accessor === 'statusLabel') {
    const status = row.status as AttendanceStatus;
    const config = statusConfig[status];
    if (config) {
      classes.push(config.color, 'font-medium');
    }
  }

  // 備考が「残業」の場合
  if (column.accessor === 'note' && row.note === '残業') {
    classes.push('text-orange-600 font-medium');
  }

  return classes.join(' ');
};

/**
 * 勤怠管理ページ用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
export default function AttendanceLayout({
  currentRecord,
  tableData,
  summary,
  loading,
  currentTime,
  selectedMonth,
  onMonthChange,
  onClockIn,
  onClockOut,
  onBreakStart,
  onBreakEnd,
  enableTableRowAnimation = true,
  tableRowAnimationVariant = 'slideDown',
}: AttendanceLayoutProps) {
  const { colors, shapes } = useThemeConfig('Attendance');

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <Icon preset="atom" size={48} />
        <div className="text-gray-500">勤怠データを読み込み中...</div>
      </div>
    );
  }

  const status = currentRecord?.status || 'not_started';
  const statusInfo = statusConfig[status];

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <div className="mb-6">
        <DevelopmentBanner
          message="この機能は現在開発中です。KingOfTimeのような勤怠管理機能を実装予定です。"
        />
      </div>

      {/* 上部: 打刻パネルとサマリー */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* 打刻パネル */}
        <div className="lg:col-span-2">
          <div
            className="bg-white shadow-sm border border-gray-200 p-6"
            style={{ borderRadius: shapes.borderRadius }}
          >
            {/* 現在時刻 */}
            <div className="text-center mb-6">
              <div className="text-fluid-5xl font-bold text-gray-800 font-mono">
                {format(currentTime, 'HH:mm:ss')}
              </div>
              <div className="text-fluid-base text-gray-500 mt-2">
                {format(currentTime, 'yyyy年M月d日（E）', { locale: ja })}
              </div>
            </div>

            {/* ステータス表示 */}
            <div className="flex justify-center mb-6">
              <span
                className={cn(
                  'px-4 py-2 text-fluid-base font-medium',
                  statusInfo.bgColor,
                  statusInfo.color
                )}
                style={{ borderRadius: shapes.badgeRadius }}
              >
                {statusInfo.label}
              </span>
            </div>

            {/* 打刻ボタン */}
            <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto">
              <Button
                onClick={onClockIn}
                disabled={status !== 'not_started'}
                variant={status === 'not_started' ? 'primary' : 'secondary'}
                size="large"
                className={cn(
                  'py-3 font-bold',
                  status === 'not_started' && 'bg-green-500 hover:bg-green-600 border-green-500'
                )}
              >
                <Icon name={'arrow-in'} size={20} className="mr-2" hover="auto" />
                出勤
              </Button>
              <Button
                onClick={onClockOut}
                disabled={status !== 'working' && status !== 'on_break'}
                variant={(status === 'working' || status === 'on_break') ? 'primary' : 'secondary'}
                size="large"
                className={cn(
                  'py-3 font-bold',
                  (status === 'working' || status === 'on_break') && 'bg-red-500 hover:bg-red-600 border-red-500'
                )}
              >
                <Icon name={'door-out'} size={20} className="mr-2" hover="auto" />
                退勤
              </Button>
              <Button
                onClick={onBreakStart}
                disabled={status !== 'working'}
                variant={status === 'working' ? 'primary' : 'secondary'}
                size="large"
                className={cn(
                  'py-3 font-bold',
                  status === 'working' && 'bg-yellow-500 hover:bg-yellow-600 border-yellow-500'
                )}
              >
                <Icon name={'clock'} size={20} className="mr-2" hover="auto" />
                休憩開始
              </Button>
              <Button
                onClick={onBreakEnd}
                disabled={status !== 'on_break'}
                variant={status === 'on_break' ? 'primary' : 'secondary'}
                size="large"
                className={cn(
                  'py-3 font-bold',
                  status === 'on_break' && 'bg-blue-500 hover:bg-blue-600 border-blue-500'
                )}
              >
                <Icon name={'check-circle'} size={20} className="mr-2" hover="auto" />
                休憩終了
              </Button>
            </div>

            {/* 本日の記録 */}
            {currentRecord && (
              <div className="mt-6 pt-4 border-t border-gray-200">
                <h3 className="text-fluid-sm font-medium text-gray-500 mb-3">本日の記録</h3>
                <div className="grid grid-cols-4 gap-3 text-center">
                  <div className="bg-gray-50 p-2" style={{ borderRadius: shapes.buttonRadius }}>
                    <div className="text-fluid-xs text-gray-400">出勤</div>
                    <div className="text-fluid-lg font-mono font-medium">
                      {currentRecord.clockIn ? format(currentRecord.clockIn, 'HH:mm') : '--:--'}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-2" style={{ borderRadius: shapes.buttonRadius }}>
                    <div className="text-fluid-xs text-gray-400">退勤</div>
                    <div className="text-fluid-lg font-mono font-medium">
                      {currentRecord.clockOut ? format(currentRecord.clockOut, 'HH:mm') : '--:--'}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-2" style={{ borderRadius: shapes.buttonRadius }}>
                    <div className="text-fluid-xs text-gray-400">休憩開始</div>
                    <div className="text-fluid-lg font-mono font-medium">
                      {currentRecord.breakStart ? format(currentRecord.breakStart, 'HH:mm') : '--:--'}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-2" style={{ borderRadius: shapes.buttonRadius }}>
                    <div className="text-fluid-xs text-gray-400">休憩終了</div>
                    <div className="text-fluid-lg font-mono font-medium">
                      {currentRecord.breakEnd ? format(currentRecord.breakEnd, 'HH:mm') : '--:--'}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* サマリー */}
        <div className="space-y-4">
          {/* 月間サマリー */}
          <div
            className="bg-white shadow-sm border border-gray-200 p-5"
            style={{ borderRadius: shapes.borderRadius }}
          >
            <h3 className="text-fluid-base font-medium text-gray-800 mb-3 flex items-center">
              <Icon name={'calendar'} size={18} className="mr-2 text-gray-500" hover="auto" />
              今月のサマリー
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-fluid-sm text-gray-600">出勤日数</span>
                <span className="font-medium">
                  {summary.actualWorkDays} / {summary.totalWorkDays} 日
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-fluid-sm text-gray-600">総勤務時間</span>
                <span className="font-medium">{summary.totalWorkHours} 時間</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-fluid-sm text-gray-600">残業時間</span>
                <span className="font-medium text-orange-600">{summary.overtimeHours} 時間</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-fluid-sm text-gray-600">有給残日数</span>
                <span className="font-medium text-teal-600">
                  {summary.paidLeaveRemaining} 日
                </span>
              </div>
            </div>
          </div>

          {/* クイックアクション */}
          <div
            className="bg-white shadow-sm border border-gray-200 p-5"
            style={{ borderRadius: shapes.borderRadius }}
          >
            <h3 className="text-fluid-base font-medium text-gray-800 mb-3 flex items-center">
              <Icon name={'sliders'} size={18} className="mr-2 text-gray-500" hover="auto" />
              クイックアクション
            </h3>
            <div className="space-y-2">
              <Button variant="secondary" size="small" leftIcon="calendar">
                有給申請
              </Button>
              <Button variant="secondary" size="small" leftIcon="file">
                勤怠修正申請
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* 下部: 勤怠履歴テーブル */}
      <div
        className="bg-white shadow-sm border border-gray-200 p-5"
        style={{ borderRadius: shapes.borderRadius }}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-fluid-base font-medium text-gray-800 flex items-center">
            <Icon name={'list'} size={18} className="mr-2 text-gray-500" hover="auto" />
            勤怠履歴
          </h3>
          <DatePicker
            value={selectedMonth}
            onChange={onMonthChange}
            pickerMode="month"
            navigationMode="month"
            variant="dark"
            size="small"
            recentMonths={24}
          />
        </div>
        <InteractiveTable
          columns={tableColumns}
          data={tableData}
          cellClassName={getCellClassName}
          tableClassName="w-full"
          enableRowAnimation={enableTableRowAnimation}
          rowAnimationVariant={tableRowAnimationVariant}
          borderRadius={shapes.borderRadius}
          headerBgColor={colors.tableHeaderBgColor}
          headerTextColor={colors.tableHeaderTextColor}
        />
      </div>
    </div>
  );
}
