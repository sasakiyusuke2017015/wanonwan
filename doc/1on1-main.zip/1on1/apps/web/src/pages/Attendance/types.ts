// src/pages/Attendance/types.ts

/**
 * 打刻記録の型
 */
export interface AttendanceRecord {
  id: string;
  date: Date;
  clockIn?: Date;
  clockOut?: Date;
  breakStart?: Date;
  breakEnd?: Date;
  status: AttendanceStatus;
  note?: string;
}

/**
 * 勤怠ステータス
 */
export type AttendanceStatus =
  | 'not_started'  // 未出勤
  | 'working'      // 勤務中
  | 'on_break'     // 休憩中
  | 'completed'    // 退勤済
  | 'absent'       // 欠勤
  | 'holiday'      // 休日
  | 'paid_leave';  // 有給休暇

/**
 * 月間勤怠サマリー
 */
export interface AttendanceSummary {
  totalWorkDays: number;
  actualWorkDays: number;
  totalWorkHours: number;
  overtimeHours: number;
  paidLeaveUsed: number;
  paidLeaveRemaining: number;
}

/**
 * テーブル表示用の勤怠データ
 * InteractiveTableのTableRowData型と互換性を持たせるためインデックスシグネチャを追加
 */
export interface AttendanceTableRow {
  [key: string]: string | boolean | AttendanceStatus;
  id: string;
  date: string;           // 日付表示用 (例: "12/1")
  dayOfWeek: string;      // 曜日 (例: "月")
  clockIn: string;        // 出勤時刻 (例: "09:00" or "--:--")
  clockOut: string;       // 退勤時刻 (例: "18:00" or "--:--")
  breakTime: string;      // 休憩時間 (例: "1:00" or "--:--")
  workHours: string;      // 勤務時間 (例: "8:00" or "--:--")
  status: AttendanceStatus;
  statusLabel: string;    // 状態ラベル (例: "退勤済")
  note: string;           // 備考
  isWeekend: boolean;     // 週末かどうか
  isToday: boolean;       // 今日かどうか
}

/**
 * API用勤怠データ型
 */
export interface AttendanceData {
  id: string;
  date: string;
  clock_in?: string;
  clock_out?: string;
  break_start?: string;
  break_end?: string;
  status: AttendanceStatus;
  note?: string;
}
