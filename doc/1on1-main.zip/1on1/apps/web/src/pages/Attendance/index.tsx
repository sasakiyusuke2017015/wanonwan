// src/pages/Attendance/index.tsx
import { useEffect, useMemo, useState, useCallback } from 'react';

import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay, isAfter } from 'date-fns';
import { useAtomValue } from 'jotai';

import AppLayout from '@1on1/layouts/templates/AppLayout';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { uiTableRowAnimationVariantAtom } from '../../state';

import AttendanceLayout from './layout';
import { type AttendanceRecord, type AttendanceSummary, type AttendanceTableRow, type AttendanceStatus } from './types';

// ステータスラベル
const STATUS_LABELS: Record<AttendanceStatus, string> = {
  not_started: '未出勤',
  working: '勤務中',
  on_break: '休憩中',
  completed: '退勤済',
  absent: '欠勤',
  holiday: '休日',
  paid_leave: '有給',
};

// 曜日ラベル
const DAY_OF_WEEK = ['日', '月', '火', '水', '木', '金', '土'];

// デモ用サマリーデータ
const DEMO_SUMMARY: AttendanceSummary = {
  totalWorkDays: 20,
  actualWorkDays: 15,
  totalWorkHours: 120,
  overtimeHours: 8,
  paidLeaveUsed: 2,
  paidLeaveRemaining: 12,
};

// デモ用月間勤怠記録を生成（指定月の月初から月末まで）
const createDemoMonthlyRecords = (targetMonth: Date): AttendanceRecord[] => {
  const today = new Date();
  const records: AttendanceRecord[] = [];

  // 指定月の1日から月末日までのデータを生成
  const monthStart = startOfMonth(targetMonth);
  const monthEnd = endOfMonth(targetMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // 乱数シードを月ごとに固定（同じ月は同じデータになるように）
  const seedBase = targetMonth.getFullYear() * 100 + targetMonth.getMonth();

  days.forEach((date, index) => {
    const dayOfWeek = getDay(date);
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const isFutureDate = isAfter(date, today);
    const isCurrentDay = isSameDay(date, today);

    // 今日と未来の日付は別途管理
    if (isCurrentDay || isFutureDate) {
      if (isWeekend) {
        records.push({
          id: `record-${index}`,
          date,
          status: 'holiday',
        });
      } else {
        records.push({
          id: `record-${index}`,
          date,
          status: 'not_started',
        });
      }
      return;
    }

    if (isWeekend) {
      // 週末は休日
      records.push({
        id: `record-${index}`,
        date,
        status: 'holiday',
      });
    } else {
      // 平日はランダムな勤怠データ（シードベースの疑似乱数）
      const pseudoRandom = ((seedBase * 31 + index * 17) % 100) / 100;

      if (pseudoRandom < 0.1) {
        // 10%の確率で有給
        records.push({
          id: `record-${index}`,
          date,
          status: 'paid_leave',
          note: '私用のため',
        });
      } else {
        // 通常勤務
        const clockInHour = 8 + (index % 2); // 8-9時
        const clockInMin = (index * 7) % 60;
        const clockOutHour = 17 + (index % 3); // 17-19時
        const clockOutMin = (index * 11) % 60;

        const clockIn = new Date(date);
        clockIn.setHours(clockInHour, clockInMin, 0);

        const clockOut = new Date(date);
        clockOut.setHours(clockOutHour, clockOutMin, 0);

        const breakStart = new Date(date);
        breakStart.setHours(12, 0, 0);

        const breakEnd = new Date(date);
        breakEnd.setHours(13, 0, 0);

        const isOvertime = clockOutHour >= 19;

        records.push({
          id: `record-${index}`,
          date,
          clockIn,
          clockOut,
          breakStart,
          breakEnd,
          status: 'completed',
          note: isOvertime ? '残業' : '',
        });
      }
    }
  });

  return records;
};

// AttendanceRecord を テーブル表示用に変換
const transformToTableRows = (records: AttendanceRecord[], today: Date): AttendanceTableRow[] => {
  return records.map((record) => {
    const dayOfWeek = getDay(record.date);
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const isToday = isSameDay(record.date, today);

    // 勤務時間を計算
    let workHours = '--:--';
    let breakTime = '--:--';

    if (record.clockIn && record.clockOut) {
      const totalMinutes = (record.clockOut.getTime() - record.clockIn.getTime()) / (1000 * 60);
      let breakMinutes = 0;

      if (record.breakStart && record.breakEnd) {
        breakMinutes = (record.breakEnd.getTime() - record.breakStart.getTime()) / (1000 * 60);
        const breakHrs = Math.floor(breakMinutes / 60);
        const breakMins = Math.floor(breakMinutes % 60);
        breakTime = `${breakHrs}:${breakMins.toString().padStart(2, '0')}`;
      }

      const workMinutes = totalMinutes - breakMinutes;
      const workHrs = Math.floor(workMinutes / 60);
      const workMins = Math.floor(workMinutes % 60);
      workHours = `${workHrs}:${workMins.toString().padStart(2, '0')}`;
    }

    return {
      id: record.id,
      date: format(record.date, 'M/d'),
      dayOfWeek: DAY_OF_WEEK[dayOfWeek],
      clockIn: record.clockIn ? format(record.clockIn, 'HH:mm') : '--:--',
      clockOut: record.clockOut ? format(record.clockOut, 'HH:mm') : '--:--',
      breakTime,
      workHours,
      status: record.status,
      statusLabel: STATUS_LABELS[record.status],
      note: record.note || '',
      isWeekend,
      isToday,
    };
  });
};

/**
 * 勤怠管理ページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function Attendance() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedMonth, setSelectedMonth] = useState(() => format(new Date(), 'yyyy-MM'));
  const [currentRecord, setCurrentRecord] = useState<AttendanceRecord | null>(() => ({
    id: 'today',
    date: new Date(),
    status: 'not_started',
  }));
  const [loading, setLoading] = useState(true);

  // アニメーション設定を取得（variant が 'none' 以外なら有効）
  const tableRowAnimationVariant = useAtomValue(uiTableRowAnimationVariantAtom);
  const enableTableRowAnimation = tableRowAnimationVariant !== 'none';

  // 選択月からDateオブジェクトを生成
  const selectedMonthDate = useMemo(() => {
    const [year, month] = selectedMonth.split('-').map(Number);
    return new Date(year, month - 1, 1);
  }, [selectedMonth]);

  // 選択月の勤怠記録を生成
  const monthlyRecords = useMemo(() => {
    return createDemoMonthlyRecords(selectedMonthDate);
  }, [selectedMonthDate]);

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.ATTENDANCE.label;
  }, []);

  // 現在時刻の更新
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 初期データ読み込み（デモ用）
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  // テーブル表示用データに変換（currentRecordを今日の行にマージ）
  const tableData = useMemo(() => {
    const rows = transformToTableRows(monthlyRecords, currentTime);

    // currentRecordがある場合、今日の行を上書き
    if (currentRecord) {
      const todayIndex = rows.findIndex((row) => row.isToday);
      if (todayIndex !== -1) {
        const dayOfWeek = getDay(currentRecord.date);
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

        // 勤務時間を計算
        let workHours = '--:--';
        let breakTime = '--:--';

        if (currentRecord.clockIn && currentRecord.clockOut) {
          const totalMinutes = (currentRecord.clockOut.getTime() - currentRecord.clockIn.getTime()) / (1000 * 60);
          let breakMinutes = 0;

          if (currentRecord.breakStart && currentRecord.breakEnd) {
            breakMinutes = (currentRecord.breakEnd.getTime() - currentRecord.breakStart.getTime()) / (1000 * 60);
            const breakHrs = Math.floor(breakMinutes / 60);
            const breakMins = Math.floor(breakMinutes % 60);
            breakTime = `${breakHrs}:${breakMins.toString().padStart(2, '0')}`;
          }

          const workMinutes = totalMinutes - breakMinutes;
          const workHrs = Math.floor(workMinutes / 60);
          const workMins = Math.floor(workMinutes % 60);
          workHours = `${workHrs}:${workMins.toString().padStart(2, '0')}`;
        }

        rows[todayIndex] = {
          id: currentRecord.id,
          date: format(currentRecord.date, 'M/d'),
          dayOfWeek: DAY_OF_WEEK[dayOfWeek],
          clockIn: currentRecord.clockIn ? format(currentRecord.clockIn, 'HH:mm') : '--:--',
          clockOut: currentRecord.clockOut ? format(currentRecord.clockOut, 'HH:mm') : '--:--',
          breakTime,
          workHours,
          status: currentRecord.status,
          statusLabel: STATUS_LABELS[currentRecord.status],
          note: currentRecord.note || '',
          isWeekend,
          isToday: true,
        };
      }
    }

    return rows;
  }, [monthlyRecords, currentTime, currentRecord]);

  // 出勤
  const handleClockIn = useCallback(() => {
    setCurrentRecord((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        clockIn: new Date(),
        status: 'working',
      };
    });
    // TODO: 出勤処理
  }, []);

  // 退勤
  const handleClockOut = useCallback(() => {
    setCurrentRecord((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        clockOut: new Date(),
        status: 'completed',
      };
    });
    // TODO: 退勤処理
  }, []);

  // 休憩開始
  const handleBreakStart = useCallback(() => {
    setCurrentRecord((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        breakStart: new Date(),
        status: 'on_break',
      };
    });
    // TODO: 休憩開始処理
  }, []);

  // 休憩終了
  const handleBreakEnd = useCallback(() => {
    setCurrentRecord((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        breakEnd: new Date(),
        status: 'working',
      };
    });
    // TODO: 休憩終了処理
  }, []);

  // 月変更
  const handleMonthChange = useCallback((value: string) => {
    setSelectedMonth(value);
    // ローディング表示（擬似的）
    setLoading(true);
    setTimeout(() => setLoading(false), 300);
  }, []);

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.ATTENDANCE.path), []);

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={false}
      mainContent={
        <AttendanceLayout
          currentRecord={currentRecord}
          monthlyRecords={monthlyRecords}
          tableData={tableData}
          summary={DEMO_SUMMARY}
          loading={loading}
          currentTime={currentTime}
          selectedMonth={selectedMonth}
          onMonthChange={handleMonthChange}
          onClockIn={handleClockIn}
          onClockOut={handleClockOut}
          onBreakStart={handleBreakStart}
          onBreakEnd={handleBreakEnd}
          enableTableRowAnimation={enableTableRowAnimation}
          tableRowAnimationVariant={tableRowAnimationVariant}
        />
      }
    />
  );
}
