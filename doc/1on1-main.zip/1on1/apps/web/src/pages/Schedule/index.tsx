import { useEffect, useMemo, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Provider } from 'jotai'
import type { CalendarEvent as UICatalogEvent, ViewMode } from '@ui-catalog/core/types'
import { CalendarPage } from '@ui-catalog/core/templates'
import AppLayout from '@1on1/layouts/templates/AppLayout'
import { getBreadcrumbs, ROUTES } from '@/constants/routes'
import { useSchedules } from '@/hooks/api/useSchedules'

// ========================================
// 定数
// ========================================

const VALID_VIEWS: readonly ViewMode[] = ['day', 'week', 'month', 'agenda']

// ========================================
// メインコンポーネント
// ========================================

export default function Schedule() {
  return (
    <Provider>
      <ScheduleInner />
    </Provider>
  )
}

function ScheduleInner() {
  const { view } = useParams<{ view: string }>()
  const navigate = useNavigate()

  // URL → viewMode
  const currentView: ViewMode = VALID_VIEWS.includes(view as ViewMode) ? (view as ViewMode) : 'day'

  // viewMode → URL（CalendarHeader の ViewSwitch 経由）
  const handleViewModeChange = useCallback(
    (mode: ViewMode) => {
      navigate(`/schedule/${mode}`, { replace: true })
    },
    [navigate]
  )

  useEffect(() => {
    document.title = ROUTES.SCHEDULE.label
  }, [])

  const {
    data: schedules,
    loading,
    error,
    operationError,
    createSchedule,
    updateSchedule,
    deleteSchedule,
    clearOperationError,
  } = useSchedules()

  const events = useMemo(() => schedules || [], [schedules])

  const handlePersistEvent = useCallback(
    async (event: UICatalogEvent) => {
      const isExistingRecord = event.id && /^\d+$/.test(event.id)
      if (isExistingRecord) {
        await updateSchedule(event)
      } else {
        const { id: _, ...eventWithoutId } = event
        await createSchedule(eventWithoutId)
      }
    },
    [createSchedule, updateSchedule]
  )

  const handleRemoveEvent = useCallback(
    async (id: string) => {
      await deleteSchedule(id)
    },
    [deleteSchedule]
  )

  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.SCHEDULE.path), [])

  if (loading) {
    return (
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={false}
        mainContent={
          <div className="flex h-full items-center justify-center">
            <div className="text-gray-500">スケジュールを読み込み中...</div>
          </div>
        }
      />
    )
  }

  if (error) {
    return (
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={false}
        mainContent={
          <div className="flex h-full items-center justify-center">
            <div className="text-center">
              <div className="mb-4 text-red-600">{error}</div>
              <button
                onClick={() => window.location.reload()}
                className="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              >
                再読み込み
              </button>
            </div>
          </div>
        }
      />
    )
  }

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={false}
      noPadding
      mainContent={
        <div className="relative h-full">
          {operationError && (
            <div className="absolute right-4 top-4 z-50 flex items-center gap-2 rounded-lg bg-red-50 border border-red-200 px-4 py-3 shadow-lg">
              <span className="text-sm text-red-700">{operationError}</span>
              <button
                onClick={clearOperationError}
                className="ml-2 text-red-400 hover:text-red-600"
              >
                ✕
              </button>
            </div>
          )}
          <CalendarPage
            events={events}
            persistEvent={handlePersistEvent}
            removeEvent={handleRemoveEvent}
            initialViewMode={currentView}
            onViewModeChange={handleViewModeChange}
          />
        </div>
      }
    />
  )
}
