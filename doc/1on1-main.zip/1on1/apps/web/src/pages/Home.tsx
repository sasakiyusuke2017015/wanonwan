/**
 * ホーム画面
 * カード定義とメインコンポーネントを統合
 */
import { useEffect, useMemo } from 'react';

import { AdjustmentBanner, ExternalLink, InternalLink } from '@ui-catalog/core/molecules';
import { ContentBlock } from '@ui-catalog/core/organisms';
import AppLayout from '@1on1/layouts/templates/AppLayout';
import { useAuth } from '@/adapters/AuthContext';
import { type IconName } from '@/constants';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { resolveUrlTemplate } from '@1on1/domain/utils';
import { useUserInfo } from '@/hooks';
import { filterPermissions } from '@/utils/permissions';

// カード関連の型定義
interface CardLink {
  id: string;
  to: string;
  text: string;
  className: string;
}

interface CardExternalLink {
  id: string;
  href: string;
  text: string;
  className: string;
}

interface Card {
  id: string;
  title: string;
  titleColor: string;
  iconType?: 'none' | 'icon' | 'media';
  logoSrc?: string;
  logoAlt?: string;
  iconName?: IconName;
  links?: CardLink[];
  externalLinks?: CardExternalLink[];
}

/**
 * ホーム画面カード定義（完全に静的なデータ）
 * 動的なパラメータ（userId等）はテンプレート化（:userId形式）
 */
const HOME_CARDS: Card[] = [
  {
    id: 'card-1on1',
    title: import.meta.env.VITE_APP_NAME,
    titleColor: 'text-indigo-700',
    iconType: 'media',
    logoSrc: '/images/favicon_1on1.svg',
    logoAlt: 'Test Logo',
    links: [
      {
        id: 'link-dashboard',
        to: ROUTES.DASHBOARD.path,
        text: '全社ダッシュボード',
        className: 'bg-neutral-600 hover:bg-neutral-700',
      },
      {
        id: 'link-employees',
        to: ROUTES.ANSWERS.path,
        text: '配下メンバー一覧',
        className: 'bg-teal-600 hover:bg-teal-700',
      },
      {
        id: 'link-surveys',
        to: ROUTES.SURVEYS.path,
        text: 'アンケート一覧',
        className: 'bg-purple-600 hover:bg-purple-700',
      },
    ],
  },
  {
    id: 'card-external',
    title: 'Link',
    titleColor: 'text-green-700',
    iconType: 'icon',
    iconName: 'arrow-up-right',
    externalLinks: [
      {
        id: 'link-dev-server',
        href: 'http://192.168.10.64:5173/',
        text: '開発サーバー',
        className: 'bg-indigo-600 hover:bg-indigo-700',
      },
      {
        id: 'link-prod-server',
        href: 'https://192.168.10.63/',
        text: '本番サーバー',
        className: 'bg-purple-600 hover:bg-purple-700',
      },
      {
        id: 'link-gitea',
        href: 'http://192.168.10.66:3000/',
        text: 'Gitea',
        className: 'bg-slate-600 hover:bg-slate-700',
      },
      {
        id: 'link-dify',
        href: 'http://192.168.10.66/apps',
        text: 'Dify',
        className: 'bg-blue-700 hover:bg-blue-800',
      },
      {
        id: 'link-storybook',
        href: 'http://192.168.10.64:6006/',
        text: 'Storybook',
        className: 'bg-pink-600 hover:bg-pink-700',
      },
      {
        id: 'link-fastapi-1on1',
        href: 'http://192.168.10.64:4000/docs#',
        text: 'FastAPI(1on1)',
        className: 'bg-sky-600 hover:bg-sky-700',
      },
      {
        id: 'link-fastapi-ai-agent',
        href: 'http://192.168.10.64:8090/docs#',
        text: 'FastAPI(AI-agent)',
        className: 'bg-sky-600 hover:bg-sky-700',
      },
      {
        id: 'link-pleasanter',
        href: 'http://192.168.10.64/items/1/index',
        text: 'Pleasanter',
        className: 'bg-orange-600 hover:bg-orange-700',
      },
      {
        id: 'link-wordpress',
        href: 'http://192.168.10.63/?page_id=63',
        text: 'WordPress',
        className: 'bg-emerald-600 hover:bg-emerald-700',
      },
    ],
  },
  {
    id: 'card-develop',
    title: 'Develop',
    titleColor: 'text-rose-700',
    iconType: 'icon',
    iconName: 'keyboard',
    links: [
      {
        id: 'link-error',
        to: ROUTES.ERROR.path,
        text: 'エラー画面',
        className: 'bg-red-600 hover:bg-red-700',
      },
      {
        id: 'link-about',
        to: ROUTES.ABOUT.path,
        text: 'このアプリについて',
        className: 'bg-lime-600 hover:bg-lime-700',
      },
    ],
  },
];

export default function HomePage() {
  // ページタイトルを設定
  useEffect(() => {
    document.title = import.meta.env.VITE_APP_NAME || ROUTES.HOME.label;
  }, []);

  // ユーザー情報取得
  const { userId, user } = useUserInfo();
  const { user: authUser } = useAuth();

  // ユーザー情報の統合
  const userInfo = authUser || user;

  // 権限情報の処理
  const { allowedLinks } = filterPermissions(userInfo);

  // カード管理ロジック
  const filteredCards = useMemo(() => {
    return (
      HOME_CARDS.map((card) => ({
        ...card,
        // 内部リンクのフィルタリングとURL置換（permissions.yml の allowedLinks で制御）
        links: card.links
          ?.filter((link) => {
            return allowedLinks.includes(link.id);
          })
          .map((link) => ({
            ...link,
            to: resolveUrlTemplate(link.to, { userId }),
          })),
        // 外部リンクのフィルタリング（permissions.yml の allowedLinks で制御）
        externalLinks: card.externalLinks?.filter((link) =>
          allowedLinks.includes(link.id)
        ),
      }))
        // カード表示の自動判定：カード内に許可されたリンクが1つでもあれば表示
        .filter((card) => {
          const hasLinks = card.links && card.links.length > 0;
          const hasExternalLinks =
            card.externalLinks && card.externalLinks.length > 0;
          return hasLinks || hasExternalLinks;
        })
    );
  }, [allowedLinks, userId]);

  const mainContent = (
    <>
      <div className="mx-auto max-w-7xl mb-6">
        <AdjustmentBanner message="このページは現在調整中です。" />
      </div>
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 rounded-2xl border border-gray-200/50 bg-gradient-to-br from-gray-50 to-blue-50 px-4 py-8 shadow-xl backdrop-blur-sm md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
        {filteredCards.map((card) => (
          <ContentBlock
            key={card.id}
            id={card.id}
            title={card.title}
            titleColor={card.titleColor}
            titleAlign="center"
            iconType={card.iconType}
            iconName={card.iconName}
            logoSrc={card.logoSrc}
            logoAlt={card.logoAlt}
          >
            {/* 内部リンクの場合 */}
            {card.links &&
              card.links.map((link) => (
                <InternalLink
                  key={link.id}
                  href={link.to}
                  className={`block w-full px-4 py-2 ${link.className} rounded text-center font-medium text-white`}
                >
                  {link.text}
                </InternalLink>
              ))}

            {/* 外部リンクの場合 */}
            {card.externalLinks &&
              card.externalLinks.map((link) => (
                <ExternalLink
                  key={link.id}
                  href={link.href}
                  className={link.className}
                >
                  {link.text}
                </ExternalLink>
              ))}
          </ContentBlock>
        ))}
      </div>
    </>
  );

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.HOME.path), []);

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      footerContent={null}
      mainContent={mainContent}
    />
  );
}
