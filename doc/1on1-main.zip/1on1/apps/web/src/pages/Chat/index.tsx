// src/pages/Chat/index.tsx
import { useEffect, useMemo, useState, useCallback } from 'react';

import AppLayout from '@1on1/layouts/templates/AppLayout';
import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { useDemoData } from '@/hooks/api/useDemoData';

import ChatLayout from './layout';
import {
  type ChatChannel,
  type ChatMessage,
  type ChatChannelData,
  type ChatMessageData,
} from './types';

// APIデータをチャンネル型に変換
const transformToChannels = (data: ChatChannelData[]): ChatChannel[] => {
  return data.map((item) => ({
    id: item.id,
    name: item.name,
    description: item.description,
    isPrivate: item.is_private,
    memberCount: item.member_count,
    unreadCount: item.unread_count,
    lastMessage: item.last_message,
    lastMessageAt: item.last_message_at ? new Date(item.last_message_at) : undefined,
  }));
};

// APIデータをメッセージ型に変換
const transformToMessages = (data: ChatMessageData[]): ChatMessage[] => {
  return data.map((item) => ({
    id: String(item.id),
    channelId: item.channel_id,
    userId: item.user_id,
    userName: item.user_name,
    userAvatar: item.user_avatar,
    content: item.content,
    timestamp: new Date(item.timestamp),
    isEdited: item.is_edited,
    reactions: item.reactions,
  }));
};

// デモ用チャンネルデータ
const DEMO_CHANNELS: ChatChannelData[] = [
  {
    id: 'general',
    name: '全体',
    description: '全メンバー向けの一般チャンネル',
    is_private: false,
    member_count: 150,
    unread_count: 3,
    last_message: 'お疲れ様です！',
    last_message_at: new Date().toISOString(),
  },
  {
    id: 'random',
    name: '雑談',
    description: '雑談用チャンネル',
    is_private: false,
    member_count: 120,
    unread_count: 0,
    last_message: '週末どこか行きますか？',
    last_message_at: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'dev-team',
    name: '開発チーム',
    description: '開発チーム専用',
    is_private: true,
    member_count: 15,
    unread_count: 5,
    last_message: 'PRレビューお願いします',
    last_message_at: new Date(Date.now() - 1800000).toISOString(),
  },
];

// デモ用メッセージデータ
const createDemoMessages = (): Record<string, ChatMessageData[]> => {
  const now = new Date();
  return {
    general: [
      {
        id: 1,
        channel_id: 'general',
        user_id: 'user1',
        user_name: '田中太郎',
        content: 'おはようございます！今日もよろしくお願いします。',
        timestamp: new Date(now.getTime() - 3600000 * 2).toISOString(),
        is_edited: false,
        reactions: [{ emoji: '👍', count: 3, users: ['user2', 'user3', 'user4'] }],
      },
      {
        id: 2,
        channel_id: 'general',
        user_id: 'user2',
        user_name: '山田花子',
        content: 'おはようございます！今日の会議は14時からですね。',
        timestamp: new Date(now.getTime() - 3600000).toISOString(),
        is_edited: false,
      },
    ],
    'dev-team': [
      {
        id: 10,
        channel_id: 'dev-team',
        user_id: 'user3',
        user_name: '佐藤健一',
        content: '新しいPRを作成しました。レビューお願いします！',
        timestamp: new Date(now.getTime() - 7200000).toISOString(),
        is_edited: false,
      },
    ],
  };
};

// チャンネルに対応するメッセージを取得
const getDemoMessages = (channelId: string): ChatMessageData[] => {
  const messagesMap = createDemoMessages();
  return messagesMap[channelId] || [
    {
      id: 100,
      channel_id: channelId,
      user_id: 'system',
      user_name: 'システム',
      content: 'このチャンネルにはまだメッセージがありません。',
      timestamp: new Date().toISOString(),
      is_edited: false,
    },
  ];
};

/**
 * チャットページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function Chat() {
  const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.CHAT.label;
  }, []);

  // チャンネル一覧取得（デモデータ）
  const {
    data: channelsData,
    loading: channelsLoading,
  } = useDemoData<ChatChannelData[]>(DEMO_CHANNELS, {
    delay: 300,
    debugLabel: 'Chat Channels デモデータ',
  });

  // チャンネルデータを変換
  const channels: ChatChannel[] = useMemo(() => {
    if (!channelsData) return [];
    return transformToChannels(channelsData);
  }, [channelsData]);

  // 初期チャンネル選択
  useEffect(() => {
    if (channels.length > 0 && !selectedChannelId) {
      setSelectedChannelId(channels[0].id);
    }
  }, [channels, selectedChannelId]);

  // チャンネル選択時にメッセージ取得（デモデータ）
  useEffect(() => {
    if (!selectedChannelId) return;

    setMessagesLoading(true);
    // デモ用の遅延
    const timer = setTimeout(() => {
      const demoMessages = getDemoMessages(selectedChannelId);
      setMessages(transformToMessages(demoMessages));
      setMessagesLoading(false);
    }, 200);

    return () => clearTimeout(timer);
  }, [selectedChannelId]);

  // イベントハンドラー
  const handleSelectChannel = useCallback((channelId: string) => {
    setSelectedChannelId(channelId);
  }, []);

  const handleSendMessage = useCallback((content: string) => {
    // TODO: 実際のAPI呼び出しを実装
    const newMessage: ChatMessage = {
      id: `temp-${Date.now()}`,
      channelId: selectedChannelId || '',
      userId: 'current-user',
      userName: '自分',
      content,
      timestamp: new Date(),
      isEdited: false,
    };
    setMessages((prev) => [...prev, newMessage]);
    // TODO: メッセージ送信処理
  }, [selectedChannelId]);

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.CHAT.path), []);

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={false}
      mainContent={
        <ChatLayout
          channels={channels}
          messages={messages}
          loading={channelsLoading || messagesLoading}
          selectedChannelId={selectedChannelId}
          onSelectChannel={handleSelectChannel}
          onSendMessage={handleSendMessage}
        />
      }
    />
  );
}
