// src/pages/Chat/layout.tsx
import { useState, useRef, useEffect } from 'react';

import { Icon } from '@ui-catalog/core/atoms';
import { DevelopmentBanner } from '@ui-catalog/core/molecules';

import { useThemeConfig } from '@/hooks';

import { type ChatChannel, type ChatMessage } from './types';

interface ChatLayoutProps {
  channels: ChatChannel[];
  messages: ChatMessage[];
  loading: boolean;
  selectedChannelId: string | null;
  onSelectChannel: (channelId: string) => void;
  onSendMessage: (content: string) => void;
}

/**
 * チャットページ用レイアウトコンポーネント（Slackライク）
 */
export default function ChatLayout({
  channels,
  messages,
  loading,
  selectedChannelId,
  onSelectChannel,
  onSendMessage,
}: ChatLayoutProps) {
  const { shapes } = useThemeConfig('Chat');
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 新しいメッセージが追加されたらスクロール
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSendMessage(inputValue.trim());
      setInputValue('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const selectedChannel = channels.find((ch) => ch.id === selectedChannelId);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const isToday = date.toDateString() === today.toDateString();
    if (isToday) return '今日';

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) return '昨日';

    return date.toLocaleDateString('ja-JP', { month: 'long', day: 'numeric' });
  };

  // メッセージを日付でグループ化
  const groupedMessages = messages.reduce<Record<string, ChatMessage[]>>((groups, message) => {
    const dateKey = message.timestamp.toDateString();
    if (!groups[dateKey]) {
      groups[dateKey] = [];
    }
    groups[dateKey].push(message);
    return groups;
  }, {});

  return (
    <div className="p-4 bg-gray-50 min-h-full">
      <div className="mb-4">
        <DevelopmentBanner
          message="この機能は現在開発中です。Slackライクなチャット機能を実装予定です。"
        />
      </div>
      <div className="flex h-[calc(100vh-250px)] min-h-[500px] bg-white" style={{ borderRadius: shapes.borderRadius }}>
      {/* サイドバー: チャンネル一覧 */}
      <div className="w-64 flex-shrink-0 border-r border-gray-200 bg-gray-50 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h2 className="font-bold text-gray-800">チャンネル</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => onSelectChannel(channel.id)}
              className={`w-full px-4 py-2 text-left flex items-center gap-2 hover:bg-gray-100 transition-colors ${
                selectedChannelId === channel.id ? 'bg-gray-200' : ''
              }`}
            >
              <span className="text-gray-500">
                {channel.isPrivate ? (
                  <Icon name="lock" size={16} hover="auto" />
                ) : (
                  <span className="text-fluid-lg">#</span>
                )}
              </span>
              <span className="flex-1 truncate text-fluid-sm font-medium text-gray-700">
                {channel.name}
              </span>
              {channel.unreadCount && channel.unreadCount > 0 && (
                <span
                  className="px-2 py-0.5 text-fluid-xs text-white rounded-full bg-theme-primary-bg"
                >
                  {channel.unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* メインエリア */}
      <div className="flex-1 flex flex-col">
        {/* ヘッダー */}
        <div className="px-4 py-3 border-b border-gray-200 bg-white flex items-center gap-3">
          {selectedChannel ? (
            <>
              <span className="text-gray-500">
                {selectedChannel.isPrivate ? (
                  <Icon name="lock" size={18} hover="auto" />
                ) : (
                  <span className="text-fluid-xl">#</span>
                )}
              </span>
              <div>
                <h3 className="font-bold text-gray-800">{selectedChannel.name}</h3>
                {selectedChannel.description && (
                  <p className="text-fluid-xs text-gray-500">{selectedChannel.description}</p>
                )}
              </div>
              <span className="ml-auto text-fluid-xs text-gray-400">
                {selectedChannel.memberCount}人のメンバー
              </span>
            </>
          ) : (
            <h3 className="font-bold text-gray-400">チャンネルを選択してください</h3>
          )}
        </div>

        {/* メッセージエリア */}
        <div className="flex-1 overflow-y-auto px-4 py-2 bg-white">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full gap-4">
              <Icon preset="radar" size={48} />
              <div className="text-gray-500">メッセージを読み込み中...</div>
            </div>
          ) : !selectedChannelId ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-gray-400">左のリストからチャンネルを選択してください</div>
            </div>
          ) : (
            <>
              {Object.entries(groupedMessages).map(([dateKey, dayMessages]) => (
                <div key={dateKey}>
                  {/* 日付区切り */}
                  <div className="flex items-center my-4">
                    <div className="flex-1 border-t border-gray-200" />
                    <span className="px-3 text-fluid-xs text-gray-500">
                      {formatDate(new Date(dateKey))}
                    </span>
                    <div className="flex-1 border-t border-gray-200" />
                  </div>

                  {/* メッセージ */}
                  {dayMessages.map((message) => (
                    <div key={message.id} className="flex gap-3 py-2 hover:bg-gray-50 px-2 rounded">
                      {/* アバター */}
                      <div
                        className="w-9 h-9 rounded flex-shrink-0 flex items-center justify-center text-white font-bold text-fluid-sm bg-theme-primary-bg"
                      >
                        {message.userName.charAt(0)}
                      </div>

                      {/* メッセージ本文 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2">
                          <span className="font-bold text-gray-900 text-fluid-sm">
                            {message.userName}
                          </span>
                          <span className="text-fluid-xs text-gray-400">
                            {formatTime(message.timestamp)}
                          </span>
                          {message.isEdited && (
                            <span className="text-fluid-xs text-gray-400">(編集済み)</span>
                          )}
                        </div>
                        <p className="text-fluid-sm text-gray-700 whitespace-pre-wrap break-words">
                          {message.content}
                        </p>

                        {/* リアクション */}
                        {message.reactions && message.reactions.length > 0 && (
                          <div className="flex gap-1 mt-1">
                            {message.reactions.map((reaction, idx) => (
                              <span
                                key={idx}
                                className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 rounded-full text-fluid-xs hover:bg-gray-200 cursor-pointer"
                              >
                                <span>{reaction.emoji}</span>
                                <span className="text-gray-600">{reaction.count}</span>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* 入力エリア */}
        {selectedChannelId && (
          <div className="p-4 border-t border-gray-200 bg-white">
            <form onSubmit={handleSubmit}>
              <div
                className="flex items-end gap-2 border border-gray-300 rounded-lg p-2 focus-within:border-gray-400 transition-colors"
                style={{ borderRadius: shapes.borderRadius }}
              >
                <textarea
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`#${selectedChannel?.name ?? ''} にメッセージを送信`}
                  className="flex-1 resize-none outline-none text-fluid-sm max-h-32 min-h-[40px]"
                  rows={1}
                />
                <button
                  type="submit"
                  disabled={!inputValue.trim()}
                  className="p-2 text-white rounded transition-opacity disabled:opacity-50 bg-theme-primary-bg"
                >
                  <Icon name="arrow-up-right" size={18} stroke="white" hover="auto" />
                </button>
              </div>
              <p className="mt-1 text-fluid-xs text-gray-400">
                Enter で送信、Shift + Enter で改行
              </p>
            </form>
          </div>
        )}
      </div>
      </div>
    </div>
  );
}
