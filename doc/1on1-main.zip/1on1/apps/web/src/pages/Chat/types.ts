// src/pages/Chat/types.ts

/**
 * チャットメッセージの型定義
 */
export interface ChatMessage {
  id: string;
  channelId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  timestamp: Date;
  isEdited?: boolean;
  reactions?: MessageReaction[];
}

/**
 * メッセージリアクション
 */
export interface MessageReaction {
  emoji: string;
  count: number;
  users: string[];
}

/**
 * チャンネルの型定義
 */
export interface ChatChannel {
  id: string;
  name: string;
  description?: string;
  isPrivate: boolean;
  memberCount: number;
  unreadCount?: number;
  lastMessage?: string;
  lastMessageAt?: Date;
}

/**
 * チャットAPIレスポンス
 */
export interface ChatMessagesResponse {
  code: string;
  status: string;
  data: ChatMessageData[];
}

export interface ChatChannelsResponse {
  code: string;
  status: string;
  data: ChatChannelData[];
}

/**
 * APIから取得するメッセージデータ
 */
export interface ChatMessageData {
  id: number;
  channel_id: string;
  user_id: string;
  user_name: string;
  user_avatar?: string;
  content: string;
  timestamp: string;
  is_edited: boolean;
  reactions?: {
    emoji: string;
    count: number;
    users: string[];
  }[];
}

/**
 * APIから取得するチャンネルデータ
 */
export interface ChatChannelData {
  id: string;
  name: string;
  description?: string;
  is_private: boolean;
  member_count: number;
  unread_count?: number;
  last_message?: string;
  last_message_at?: string;
}
