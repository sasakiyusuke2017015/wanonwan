/**
 * 回答詳細ページの型定義
 */

import type { EvaluationData } from '@1on1/domain/validators/common'

export type { EvaluationData }

/**
 * 回答結果データ
 * 特定期間におけるメンバーの回答・面談・評価データ
 */
export interface AnswerResult {
  回答状況?: string;
  評価結果?: EvaluationData;
  健康状態?: string | { Value?: string; value?: string } | null;
  回答日?: string | null;
  面談日?: string | null;
  回答者?: string;
  開始?: string;
  コメント?: string;
  追加面談候補者名?: string;
  追加面談候補者役職?: string;
  面談候補?: string; // ["userId1", "userId2"] 形式のJSON文字列
  面談メモ?: string;
  面談内容閲覧者?: string; // ["userId1", "userId2"] 形式のJSON文字列
  面談者?: string; // 面談者の名前（APIで名前に解決済み）
  次回までのアクション?: string;
  回答ID?: string;
  面談方式?: string;
  [key: string]: unknown;
}

export interface MemoData {
  user_id: string;
  user_code: string;
  interview_memo: string;
  next_action: string;
  interview_method: string;
  [key: string]: unknown;
}

export interface UpdateResult {
  success: boolean;
  message: string;
}

export interface EmployeeDetailResponse {
  名前?: string;
  ユーザーID?: string;
  ユーザーコード?: string;
  所属本部?: string;
  所属部?: string;
  所属課?: string;
  部署?: string;
  役職?: string;
  サポーター?: string;
  トレーナー?: string;
  回答結果?: AnswerResult[];
  [key: string]: unknown;
}

/**
 * メンバー情報（画面表示用）
 */
export interface EmployeeInfo {
  name: string;
  id: string;
  department: string;
  position: string;
  supporter: string;
  trainer: string;
  interviewDate: string;
  interviewer: {
    name: string;
    position: string;
  };
}

/**
 * 最新の評価情報
 */
export interface LatestEvaluation {
  date: string;
  scores: {
    jobSatisfaction: { current: number };
    workload: { current: number };
    workEnvironment: { current: number };
    relationships: { current: number };
    stress: { current: number };
  };
  comment: string;
}

/**
 * トレンドデータ
 */
export interface TrendData {
  months: string[];
  jobSatisfaction: number[];
  stress: number[];
  workload: number[];
  workEnvironment: number[];
  relationships: number[];
}

/**
 * 面談メモ情報
 */
export interface InterviewMemo {
  content: string;
}

/**
 * 回答詳細データ（変換済み・画面表示用）
 */
export interface EmployeeDetailData {
  employeeInfo: EmployeeInfo;
  latestEvaluation: LatestEvaluation | null;
  trendData: TrendData;
  aiActionSuggestions: unknown[];
  answerHistory: AnswerResult[];
  interviewMemo: InterviewMemo;
}
