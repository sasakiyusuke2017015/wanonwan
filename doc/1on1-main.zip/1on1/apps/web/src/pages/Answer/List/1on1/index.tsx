// src/pages/EmployeeList/index.tsx
import { useEffect, useState, useMemo, useCallback, useRef } from 'react';

import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useNavigate } from 'react-router-dom';


import { Button, ResetButton, FilterField } from '@ui-catalog/core/molecules';
import { AlertDialog, ConfirmDialog, SortableToggleList, StatisticPanel } from '@ui-catalog/core/organisms';
import { type Tab, createTabLayout } from '@1on1/layouts/organisms/AppSubHeader';
import AppLayout from '@1on1/layouts/templates/AppLayout';

import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { CONSTANTS } from '@/constants/schemas';
import { useDevice } from '@ui-catalog/core/hooks';
import { useErrorHandler, useUserInfo, useThemeConfig } from '@/hooks';
import { useAlert } from '@ui-catalog/core/hooks/ui';
import {
  displayDateAtom,
  visibleColumnsAtom,
  columnOrderAtom,
  addAnswerTabAtom,
  closeAllAnswerTabsAtom,
  viewModeAtom,
  uiTableRowAnimationVariantAtom,
  uiCardAnimationVariantAtom,
} from '@/state';

import { useAnswerListTanStack, useAnswerStatistics, useFilterValues, useFilteredAnswerData, useAnswerColumns } from './hooks.tanstack';
import AnswerListLayout from './layout';
import { ANSWER_TABLE_COLUMNS, FILTER_CONFIGS, getInitialFilterValues } from './tableColumns';

/**
 * 配下メンバー一覧ページ（コンテナコンポーネント）
 * データ取得・状態管理・ビジネスロジックを担当
 */
export default function AnswerList() {
  // 定数定義を取得
  const answerStatusDef = CONSTANTS.ANSWER_STATUS;

  // 現在のユーザー情報を取得（面談メモ閲覧制御用）
  const { userId: currentUserId } = useUserInfo();

  // ページタイトルを設定
  useEffect(() => {
    document.title = ROUTES.ANSWERS.label;
  }, []);

  const navigate = useNavigate();
  const { handleError } = useErrorHandler();
  const { alertState, showAlert, closeAlert } = useAlert();
  const [displayDate, setDisplayDate] = useAtom(displayDateAtom);
  const { shapes: shapeConfig } = useThemeConfig('AnswerList');

  // アニメーション設定を取得（variant が 'none' 以外なら有効）
  const tableRowAnimationVariant = useAtomValue(uiTableRowAnimationVariantAtom);
  const cardAnimationVariant = useAtomValue(uiCardAnimationVariantAtom);
  const enableTableRowAnimation = tableRowAnimationVariant !== 'none';
  const enableCardAnimation = cardAnimationVariant !== 'none';

  // 回答詳細タブを追加・全削除するatom
  const addAnswerTab = useSetAtom(addAnswerTabAtom);
  const closeAllAnswerTabs = useSetAtom(closeAllAnswerTabsAtom);

  // 表示モード（テーブル/カード）
  const [viewMode, setViewMode] = useAtom(viewModeAtom);
  const { isMobileOrTablet } = useDevice();
  // 実際の表示モード（モバイル/タブレットでは強制的にカード表示）
  const effectiveViewMode = isMobileOrTablet ? 'card' : viewMode;

  // データ取得（TanStack Query版）
  // useAnswerListTanStack は直接 AnswerDisplayData[] を返す
  // currentUserId を渡して面談メモの閲覧制御を行う
  const {
    data: answerData,
    allData,
    loading,
    refreshing,
    error,
    isOffline,
    dataUpdatedAt,
    refetch,
  } = useAnswerListTanStack(displayDate, currentUserId);

  // フィルター値の管理
  const { filterValues, handleFilterChange, handleResetFilters } = useFilterValues();

  // アンケート選択状態
  const [selectedSurvey, setSelectedSurvey] = useState<string>('');

  // アンケートタイトル一覧を抽出（重複排除）
  const surveyTitles = useMemo(() => {
    if (!answerData) return [];
    const titles = new Set<string>();
    for (const answer of answerData) {
      if (answer.アンケートタイトル) {
        titles.add(answer.アンケートタイトル);
      }
    }
    return Array.from(titles).sort();
  }, [answerData]);

  // バッチ開始月一覧を抽出（DatePickerハイライト用 — フィルタ前の全データから計算）
  // 回答状況に応じて色分け
  const highlightedMonths = useMemo(() => {
    if (!allData) return [];
    // 月ごとに未回答・未実施があるかを集計
    const monthStatus = new Map<string, { hasUnanswered: boolean; hasUninterviewed: boolean }>();
    for (const answer of allData) {
      if (!answer.バッチ開始月) continue;
      const month = answer.バッチ開始月;
      const status = monthStatus.get(month) || { hasUnanswered: false, hasUninterviewed: false };
      // 未回答チェック（回答状況がアンケート回答済でない）
      if (answer.回答状況 !== 'アンケート回答済' && answer.回答状況 !== '完了') {
        status.hasUnanswered = true;
      }
      // 未完了チェック（回答状況が完了でない）
      if (answer.回答状況 !== '完了') {
        status.hasUninterviewed = true;
      }
      monthStatus.set(month, status);
    }
    // 月ごとに色配列を生成
    return Array.from(monthStatus.entries()).map(([month, status]) => {
      const colors: string[] = [];
      if (status.hasUnanswered) colors.push(String((answerStatusDef.アンケート未回答 as Record<string, unknown>).color ?? 'gray'));
      if (status.hasUninterviewed) colors.push(String((answerStatusDef.アンケート回答済 as Record<string, unknown>).color ?? 'gray'));
      return { month, colors };
    });
  }, [allData, answerStatusDef]);

  // フィルター適用（アンケート選択 + その他フィルター）
  const filteredByFilterValues = useFilteredAnswerData(answerData, filterValues);
  const filteredAnswerData = useMemo(() => {
    if (!selectedSurvey) return filteredByFilterValues;
    return filteredByFilterValues.filter(
      (answer) => answer.アンケートタイトル === selectedSurvey
    );
  }, [filteredByFilterValues, selectedSurvey]);

  // 統計計算（フィルター後のデータを使用）
  const statistics = useAnswerStatistics(filteredAnswerData);

  // 全カラムをトグル対象として管理
  const allColumns = useMemo(() => ANSWER_TABLE_COLUMNS, []);

  // デフォルトの列順序
  const defaultColumnOrder = useMemo(
    () => allColumns.map((col) => col.accessor),
    [allColumns]
  );

  // デフォルトで表示する列（visible: true のもの）
  const defaultVisibleColumns = useMemo(
    () => allColumns.filter((col) => col.visible).map((col) => col.accessor),
    [allColumns]
  );

  // トグル表示順序の管理（Jotaiで永続化）
  const [storedColumnOrder, setStoredColumnOrder] = useAtom(columnOrderAtom);

  // 空配列の場合はデフォルト順序を使用、新しい列があれば末尾に追加
  const columnDisplayOrder = useMemo(() => {
    if (storedColumnOrder.length === 0) {
      return defaultColumnOrder;
    }
    // 保存された値が有効かチェック
    const validSaved = storedColumnOrder.filter((accessor) => defaultColumnOrder.includes(accessor));
    // 新しく追加された列があれば末尾に追加
    const newAccessors = defaultColumnOrder.filter((accessor) => !validSaved.includes(accessor));
    return validSaved.length > 0 ? [...validSaved, ...newAccessors] : defaultColumnOrder;
  }, [storedColumnOrder, defaultColumnOrder]);

  const setColumnDisplayOrder = setStoredColumnOrder;

  // 現在ドラッグ中の列
  const [draggingColumn, setDraggingColumn] = useState<string | null>(null);

  // 列幅リセット用キー
  const [columnWidthsResetKey, setColumnWidthsResetKey] = useState(0);

  // 選択行（チェックボックスで選択された行のインデックス）
  const [selectedRows, setSelectedRows] = useState<number[]>([]);

  // 前回のフィルター済みデータを保持（フィルター変更時の選択維持用）
  const prevFilteredDataRef = useRef<typeof filteredAnswerData>([]);

  // フィルター変更時に選択を維持（フィルター後も存在するデータのみ）
  useEffect(() => {
    // 前回のデータから選択中のユーザーIDを取得
    const selectedUserIds = selectedRows
      .map(index => prevFilteredDataRef.current[index]?.ユーザーID)
      .filter((id): id is string => Boolean(id));

    // 新しいデータで同じIDを持つ行のインデックスを取得
    if (selectedUserIds.length > 0) {
      const newSelectedRows = filteredAnswerData
        .map((row, index) => selectedUserIds.includes(row.ユーザーID) ? index : -1)
        .filter(index => index !== -1);
      setSelectedRows(newSelectedRows);
    }

    // 現在のデータを保持
    prevFilteredDataRef.current = filteredAnswerData;
  }, [filteredAnswerData]);

  // CSV出力確認ダイアログ
  const [csvConfirmDialog, setCsvConfirmDialog] = useState<{
    isOpen: boolean;
    message: string;
    targetRows: number[];
  }>({ isOpen: false, message: '', targetRows: [] });

  // 表示列の管理（Jotaiで永続化）
  const [storedVisibleColumns, setStoredVisibleColumns] = useAtom(visibleColumnsAtom);

  // 空配列の場合はデフォルト表示列を使用
  const visibleColumnAccessors = useMemo(() => {
    // storedVisibleColumnsから表示中の列を取得
    const visible = storedVisibleColumns.length === 0
      ? defaultVisibleColumns
      : storedVisibleColumns.filter((accessor) => defaultColumnOrder.includes(accessor));

    // columnDisplayOrderの順序に従って並び替え
    return columnDisplayOrder.filter((accessor) => visible.includes(accessor));
  }, [storedVisibleColumns, defaultVisibleColumns, defaultColumnOrder, columnDisplayOrder]);

  const setVisibleColumnAccessors = setStoredVisibleColumns;

  // テーブルカラム定義（visibleColumnAccessorsの順序に従って並び替え）
  const answerColumns = useAnswerColumns(visibleColumnAccessors);

  // イベントハンドラー
  const handleDateChange = useCallback((date: string) => {
    setDisplayDate(date);
  }, [setDisplayDate]);

  // CSV出力ボタンクリック時: 確認ダイアログを表示
  const handleCsvExport = useCallback(() => {
    // 選択行のみを対象
    const targetRows = selectedRows;

    if (targetRows.length === 0) {
      showAlert('出力するデータがありません。', {
        title: 'CSV出力',
        type: 'warning',
      });
      return;
    }

    // 確認ダイアログを表示
    const message = `選択された${targetRows.length}件のデータをCSV出力します。\nよろしいですか？`;

    setCsvConfirmDialog({
      isOpen: true,
      message,
      targetRows,
    });
  }, [selectedRows, showAlert]);

  // CSV出力の実行（確認ダイアログでOKを押した後）
  const executeCsvExport = useCallback(() => {
    const { targetRows } = csvConfirmDialog;

    // 対象行のデータを取得
    const targetData = targetRows
      .sort((a, b) => a - b) // 行番号順にソート
      .map((rowIndex) => filteredAnswerData[rowIndex])
      .filter(Boolean);

    if (targetData.length === 0) {
      showAlert('出力するデータがありません。', {
        title: 'CSV出力',
        type: 'warning',
      });
      setCsvConfirmDialog({ isOpen: false, message: '', targetRows: [] });
      return;
    }

    // ヘッダー行を作成（表示列の順序で）
    const headers = answerColumns.map((col: { label: string }) => col.label);

    // データ行を作成
    const rows = targetData.map((row) => {
      return answerColumns.map((col: { accessor: string }) => {
        const value = row[col.accessor];
        // nullやundefinedは空文字に
        if (value === null || value === undefined) {
          return '';
        }
        // オブジェクト型（LinkData等）の場合はtext or toを取得
        if (typeof value === 'object') {
          if ('text' in value) return String(value.text);
          if ('to' in value) return String(value.to);
          if ('url' in value) return String(value.url);
          return JSON.stringify(value);
        }
        // カンマや改行、ダブルクォートを含む場合はエスケープ
        const strValue = String(value);
        if (strValue.includes(',') || strValue.includes('\n') || strValue.includes('"')) {
          return `"${strValue.replace(/"/g, '""')}"`;
        }
        return strValue;
      });
    });

    // CSVテキストを生成
    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.join(',')),
    ].join('\n');

    // BOM付きUTF-8でBlobを作成（Excelでの文字化け対策）
    const bom = new Uint8Array([0xef, 0xbb, 0xbf]);
    const blob = new Blob([bom, csvContent], { type: 'text/csv;charset=utf-8' });

    // ダウンロード
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `回答一覧_${displayDate.replace(/-/g, '')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // ダイアログを閉じる
    setCsvConfirmDialog({ isOpen: false, message: '', targetRows: [] });

    showAlert(`${targetData.length}件のデータをCSV出力しました。`, {
      title: 'CSV出力',
      type: 'success',
    });
  }, [csvConfirmDialog, filteredAnswerData, answerColumns, displayDate, showAlert]);

  // CSV出力確認ダイアログのキャンセル
  const handleCsvConfirmCancel = useCallback(() => {
    setCsvConfirmDialog({ isOpen: false, message: '', targetRows: [] });
  }, []);

  // 選択したメンバーの詳細を開く
  const handleOpenDetails = useCallback(() => {
    if (selectedRows.length === 0) {
      showAlert('回答者を選択してください。', {
        title: '詳細表示',
        type: 'warning',
      });
      return;
    }

    // 既存のタブを全てクリアして、選択されたメンバーのタブに入れ替える
    closeAllAnswerTabs();

    // 選択されたメンバーをタブとして追加（重複はスキップ）
    const addedUserIds = new Set<string>();
    selectedRows.forEach((rowIndex) => {
      const answer = filteredAnswerData[rowIndex];
      if (answer && !addedUserIds.has(answer.ユーザーID)) {
        addedUserIds.add(answer.ユーザーID);
        addAnswerTab({
          answerId: answer.ユーザーID,
          name: answer.名前?.text || answer.ユーザーID,
        });
      }
    });

    // 回答詳細ページに遷移
    navigate(ROUTES.ANSWER_DETAIL.path);
  }, [selectedRows, filteredAnswerData, closeAllAnswerTabs, addAnswerTab, navigate, showAlert]);

  // メンバー名リンククリック時のハンドラ
  const handleInternalLinkClick = useCallback((
    linkData: { text: string; to: string },
    rowIndex: number,
  ) => {
    const answer = filteredAnswerData[rowIndex];
    if (answer) {
      const batchStartMonth = answer.バッチ開始月;
      addAnswerTab({
        answerId: answer.ユーザーID,
        name: linkData.text,
      });
      // 先に遷移してから日付を設定（現在ページの再フィルタを防ぐ）
      navigate(ROUTES.ANSWER_DETAIL.path);
      if (batchStartMonth) {
        setDisplayDate(batchStartMonth);
      }
    }
  }, [filteredAnswerData, addAnswerTab, navigate, setDisplayDate]);

  // カードクリック時のハンドラ（詳細画面遷移）
  const handleCardClick = useCallback((answerId: string, name: string) => {
    addAnswerTab({
      answerId,
      name,
    });
    navigate(ROUTES.ANSWER_DETAIL.path);
  }, [addAnswerTab, navigate]);

  const handleColumnToggle = useCallback((accessor: string) => {
    setVisibleColumnAccessors((prev) => {
      // editable: false のカラムは常に表示されるので変更しない
      const column = allColumns.find((col) => col.accessor === accessor);
      if (column && !column.toggleable) {
        return prev;
      }

      // キャッシュが空（初回アクセス）の場合はデフォルト表示列をベースにする
      const current = prev.length === 0 ? defaultVisibleColumns : prev;

      if (current.includes(accessor)) {
        return current.filter((a) => a !== accessor);
      } else {
        // columnDisplayOrderの順序に従って正しい位置に挿入
        const newVisible = [...current, accessor];
        return newVisible.sort((a, b) => {
          const indexA = columnDisplayOrder.indexOf(a);
          const indexB = columnDisplayOrder.indexOf(b);
          return indexA - indexB;
        });
      }
    });
  }, [allColumns, columnDisplayOrder, defaultVisibleColumns]);

  const handleResetColumns = useCallback(() => {
    // デフォルト: デフォルト表示列のみ表示、順序もリセット
    const defaultOrder = allColumns.map((col) => col.accessor);
    setColumnDisplayOrder(defaultOrder);
    setVisibleColumnAccessors(defaultVisibleColumns);
    // 列幅もリセット
    setColumnWidthsResetKey((prev) => prev + 1);
  }, [allColumns, defaultVisibleColumns]);

  // SortableToggleListからの順序変更ハンドラー
  const handleOrderChange = useCallback((newOrder: string[]) => {
    setColumnDisplayOrder(newOrder);
  }, []);

  // ドラッグ開始時のハンドラー
  const handleDragStart = useCallback((id: string) => {
    setDraggingColumn(id);
  }, []);

  // ドラッグ終了時のハンドラー
  const handleDragEnd = useCallback(() => {
    setDraggingColumn(null);
  }, []);

  // フィルターが適用されているか判定
  const isFiltersApplied = useMemo(() => {
    const initialValues = getInitialFilterValues();
    return Object.keys(filterValues).some((key) => {
      const current = filterValues[key];
      const initial = initialValues[key];

      if (Array.isArray(current) && Array.isArray(initial)) {
        return JSON.stringify(current) !== JSON.stringify(initial);
      }
      return current !== initial;
    });
  }, [filterValues]);

  // const handleReportExport = () => {
  //   window.alert('レポート出力未実装');
  // };

  // 選択された行のユニークなユーザーID数（重複除去）
  const uniqueSelectedUserCount = useMemo(() => {
    const userIds = new Set<string>();
    selectedRows.forEach((rowIndex) => {
      const answer = filteredAnswerData[rowIndex];
      if (answer?.ユーザーID) {
        userIds.add(answer.ユーザーID);
      }
    });
    return userIds.size;
  }, [selectedRows, filteredAnswerData]);

  // エラーハンドリング（オフライン時はエラー表示しない）
  useEffect(() => {
    if (error && !loading && !isOffline) {
      handleError({
        message: '回答者データの取得に失敗しました',
        details: String(error) || 'データを読み込むことができませんでした。',
        code: 'ANSWER_LIST_ERROR',
        originalError: error,
      });
    }
  }, [error, loading, isOffline, handleError]);

  // フッターボタンコンテンツ
  const footerButtonsContent = (
    <div id="MainCommandsContainer">
      <div id="MainCommands" className="flex justify-center gap-2">
        <Button
          id="OpenDetails"
          size="small"
          variant="primary"
          leftIcon={'employee'}
          onClick={handleOpenDetails}
          disabled={loading || selectedRows.length === 0}
        >
          詳細を開く{uniqueSelectedUserCount > 0 && ` (${uniqueSelectedUserCount})`}
        </Button>
        <Button
          id="Import"
          size="small"
          leftIcon={'file'}
          onClick={handleCsvExport}
          disabled={loading || selectedRows.length === 0}
        >
          CSV出力{selectedRows.length > 0 && ` (${selectedRows.length})`}
        </Button>
        {/* <Button
          id="Export"
          size="small"
          leftIcon={'file'}
          onClick={handleReportExport}
          disabled={loading}
        >
          レポート出力
        </Button> */}
      </div>
    </div>
  );

  // サブヘッダーコンテンツ
  const subHeaderStatistic = useMemo(() => (
    <StatisticPanel
      items={[
        { statusDef: { value: answerStatusDef.アンケート未回答.value, shortLabel: answerStatusDef.アンケート未回答.shortLabel ?? '未回答', color: String((answerStatusDef.アンケート未回答 as Record<string, unknown>).color ?? 'red'), label: 'アンケート未回答' }, value: statistics.unanswered },
        { statusDef: { value: answerStatusDef.アンケート回答済.value, shortLabel: answerStatusDef.アンケート回答済.shortLabel ?? '回答済', color: String((answerStatusDef.アンケート回答済 as Record<string, unknown>).color ?? 'green'), label: 'アンケート回答済' }, value: statistics.scheduled },
        { statusDef: { value: answerStatusDef.完了.value, shortLabel: answerStatusDef.完了.shortLabel ?? '完了', color: String((answerStatusDef.完了 as Record<string, unknown>).color ?? 'gray'), label: '完了' }, value: statistics.interviewed },
      ]}
      totalLabel="全"
      totalValue={statistics.total}
      totalUnit="名"
      emptyMessage="該当データなし"
    />
  ), [answerStatusDef, statistics]);



  // 表示項目がデフォルト状態から変更されているか判定（列順序も含む）
  const isColumnsModified = useMemo(() => {
    const defaultAccessors = allColumns.map((col) => col.accessor);
    // デフォルト表示列と一致しているかチェック
    if (visibleColumnAccessors.length !== defaultVisibleColumns.length) {
      return true;
    }
    // デフォルト表示列が全て含まれているかチェック
    if (!defaultVisibleColumns.every((accessor) => visibleColumnAccessors.includes(accessor))) {
      return true;
    }
    // 列順序がデフォルトと異なるかチェック
    const isOrderChanged = columnDisplayOrder.some(
      (accessor, index) => accessor !== defaultAccessors[index]
    );
    return isOrderChanged;
  }, [allColumns, visibleColumnAccessors, columnDisplayOrder, defaultVisibleColumns]);

  // SubHeaderのタブ定義
  const subHeaderTabs: Tab[] = useMemo(() => {
    const tabs: Tab[] = [
      {
        key: 'filter',
        label: 'フィルタ',
        icon: 'funnel',
        isHighlighted: isFiltersApplied,
        content: createTabLayout(
          <div className="flex flex-wrap gap-4">
            {FILTER_CONFIGS.map((config) => {
              // カード表示時は全フィルタ有効、テーブル表示時は表示列のみ有効
              const isColumnVisible = effectiveViewMode === 'card' || visibleColumnAccessors.includes(config.accessor);
              const filterValue = filterValues[config.accessor];

              if (config.type === 'text') {
                return (
                  <FilterField
                    key={config.accessor}
                    type="text"
                    label={config.label}
                    value={(filterValue as string) || ''}
                    onChange={(value) => handleFilterChange(config.accessor, value)}
                    placeholder={config.placeholder}
                    disabled={!isColumnVisible}
                  />
                );
              }

              if (config.type === 'status' && config.options) {
                return (
                  <FilterField
                    key={config.accessor}
                    type="status"
                    label={config.label}
                    value={(filterValue as string[]) || []}
                    onChange={(value) => handleFilterChange(config.accessor, value)}
                    options={config.options}
                    disabled={!isColumnVisible}
                  />
                );
              }

              if (config.type === 'score') {
                return (
                  <FilterField
                    key={config.accessor}
                    type="score"
                    label={config.label}
                    value={(filterValue as [number, number]) || [config.min || 1, config.max || 5]}
                    onChange={(value) => handleFilterChange(config.accessor, value)}
                    min={config.min}
                    max={config.max}
                    disabled={!isColumnVisible}
                  />
                );
              }

              if (config.type === 'date') {
                return (
                  <FilterField
                    key={config.accessor}
                    type="date"
                    label={config.label}
                    value={(filterValue as string) || ''}
                    onChange={(value) => handleFilterChange(config.accessor, value)}
                    disabled={!isColumnVisible}
                  />
                );
              }

              if (config.type === 'dateRange' && config.options) {
                return (
                  <FilterField
                    key={config.accessor}
                    type="dateRange"
                    label={config.label}
                    value={(filterValue as string) || ''}
                    onChange={(value) => handleFilterChange(config.accessor, value)}
                    options={config.options}
                    disabled={!isColumnVisible}
                  />
                );
              }

              return null;
            })}
          </div>
        ),
        headerRight: <ResetButton onClick={handleResetFilters} />,
      },
    ];

    // テーブル表示時のみ表示項目タブを追加
    if (effectiveViewMode === 'table') {
      tabs.push({
        key: 'columns',
        label: '表示項目',
        icon: 'gear',
        isHighlighted: isColumnsModified,
        content: createTabLayout(
          <SortableToggleList
            items={allColumns.map((col) => ({
              id: col.accessor,
              label: col.label,
              checked: visibleColumnAccessors.includes(col.accessor),
              disabled: !col.toggleable,
            }))}
            order={columnDisplayOrder}
            onOrderChange={handleOrderChange}
            onItemToggle={handleColumnToggle}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
          />
        ),
        headerRight: <ResetButton onClick={handleResetColumns} />,
      });
    }

    // 集計タブは常に表示
    tabs.push({
      key: 'statistics',
      label: '集計',
      icon: 'chart-bar',
      content: createTabLayout(subHeaderStatistic),
    });

    return tabs;
  }, [allColumns, visibleColumnAccessors, columnDisplayOrder, handleColumnToggle, handleResetColumns, handleOrderChange, handleFilterChange, handleResetFilters, isFiltersApplied, filterValues, subHeaderStatistic, isColumnsModified, handleDragStart, handleDragEnd, shapeConfig, effectiveViewMode]);

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.ANSWERS.path), []);

  return (
    <>
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={true}
        subHeaderTabs={subHeaderTabs}
        subHeaderDefaultActiveTabKey="filter"
        subHeaderLoading={loading || refreshing}
        mainOverflowY="hidden"
        footerContent={footerButtonsContent}
        mainContent={
          <AnswerListLayout
            loading={loading}
            refreshing={refreshing}
            answerData={filteredAnswerData}
            answerColumns={answerColumns}
            displayDate={displayDate}
            onDateChange={handleDateChange}
            surveyTitles={surveyTitles}
            selectedSurvey={selectedSurvey}
            onSurveyChange={setSelectedSurvey}
            highlightedMonths={highlightedMonths}
            onRefresh={refetch}
            dataUpdatedAt={dataUpdatedAt}
            enableColumnAnimation={true}
            draggingColumn={draggingColumn}
            columnWidthsResetKey={columnWidthsResetKey}
            selectedRows={selectedRows}
            onSelectionChange={setSelectedRows}
            onInternalLinkClick={handleInternalLinkClick}
            viewMode={viewMode}
            effectiveViewMode={effectiveViewMode}
            showViewModeToggle={!isMobileOrTablet}
            onViewModeChange={setViewMode}
            onCardClick={handleCardClick}
            enableTableRowAnimation={enableTableRowAnimation}
            tableRowAnimationVariant={tableRowAnimationVariant}
            enableCardAnimation={enableCardAnimation}
            cardAnimationVariant={cardAnimationVariant}
          />
        }
      />
      <AlertDialog {...alertState} onClose={closeAlert} />
      <ConfirmDialog
        isOpen={csvConfirmDialog.isOpen}
        title="CSV出力"
        message={csvConfirmDialog.message}
        confirmText="出力"
        cancelText="キャンセル"
        onConfirm={executeCsvExport}
        onCancel={handleCsvConfirmCancel}
      />
    </>
  );
}
