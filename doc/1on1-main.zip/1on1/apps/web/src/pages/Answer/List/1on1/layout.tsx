// src/pages/EmployeeList/Layout.tsx
import { useEffect, useState, useRef } from 'react';

import { DataCountDisplay, DatePicker, ViewModeToggle, Select } from '@ui-catalog/core/molecules';
import type { ViewModeOption } from '@ui-catalog/core/molecules';
import { RefreshButton, InteractiveTable } from '@ui-catalog/core/organisms';
import { APP_CONFIG, LAYOUT_SIZES } from '@/constants/app';
import { type CardAnimationVariant, type TableRowAnimationVariant } from '@/constants';
import { useThemeConfig } from '@/hooks';
import type { ViewMode } from '@/state';

import AnswerCardList from './AnswerCardList';
import type { AnswerDisplayData, ColumnDefinition } from './types';
import type { HighlightedMonth } from '@ui-catalog/core/molecules';

import type { TableRowData } from '@ui-catalog/core/organisms';

interface InternalLinkData {
  text: string;
  to: string;
  answerId?: string;
}

interface EmployeeListLayoutProps {
  /** メンバーデータ */

  answerData: AnswerDisplayData[];

  answerColumns: ColumnDefinition[];
  loading: boolean;
  refreshing?: boolean;
  // 日付選択
  displayDate: string;
  onDateChange: (date: string) => void;
  // アンケート選択
  surveyTitles: string[];
  selectedSurvey: string;
  onSurveyChange: (survey: string) => void;
  // DatePickerハイライト月（バッチ開始月）
  highlightedMonths?: HighlightedMonth[];
  // 更新
  onRefresh?: () => void;
  dataUpdatedAt?: number;
  // 列アニメーション
  enableColumnAnimation?: boolean;
  draggingColumn?: string | null;
  // 列幅リセット用キー
  columnWidthsResetKey?: number;
  // 行選択
  selectedRows?: number[];
  onSelectionChange?: (rows: number[]) => void;
  // 内部リンククリック
  onInternalLinkClick?: (linkData: InternalLinkData, rowIndex: number, colIndex: number) => void;
  // 表示モード
  viewMode: ViewMode;
  effectiveViewMode: ViewMode;
  showViewModeToggle: boolean;
  onViewModeChange: (mode: ViewMode) => void;
  // カードクリック（詳細画面遷移）
  onCardClick?: (answerId: string, name: string) => void;
  // アニメーション設定（Layoutが受け取りコンポーネントに渡す）
  enableTableRowAnimation?: boolean;
  tableRowAnimationVariant?: TableRowAnimationVariant;
  enableCardAnimation?: boolean;
  cardAnimationVariant?: CardAnimationVariant;
}

/**
 * 配下メンバー一覧用レイアウトコンポーネント
 * UIの構築のみを担当（プレゼンテーショナルコンポーネント）
 */
export default function AnswerListLayout({
  answerData,
  answerColumns,
  loading,
  refreshing = false,
  displayDate,
  onDateChange,
  surveyTitles,
  selectedSurvey,
  onSurveyChange,
  highlightedMonths,
  onRefresh,
  dataUpdatedAt,
  enableColumnAnimation = false,
  draggingColumn,
  columnWidthsResetKey = 0,
  selectedRows = [],
  onSelectionChange,
  onInternalLinkClick,
  viewMode,
  effectiveViewMode,
  showViewModeToggle,
  onViewModeChange,
  onCardClick,
  enableTableRowAnimation: _enableTableRowAnimation = true,
  tableRowAnimationVariant = 'slideDown',
  enableCardAnimation = true,
  cardAnimationVariant = 'slideRight',
}: EmployeeListLayoutProps) {
  const { colors, shapes } = useThemeConfig('AnswerList');
  const [datePickerAreaHeight, setDatePickerAreaHeight] = useState<number>(52);
  const datePickerAreaRef = useRef<HTMLDivElement>(null);

  // DatePickerエリアの高さを取得
  useEffect(() => {
    if (!datePickerAreaRef.current) return;

    const updateDatePickerAreaHeight = () => {
      if (datePickerAreaRef.current) {
        const height = datePickerAreaRef.current.offsetHeight;
        setDatePickerAreaHeight(height);
      }
    };

    updateDatePickerAreaHeight();

    // ResizeObserverで高さの変更を監視
    const resizeObserver = new ResizeObserver(updateDatePickerAreaHeight);
    resizeObserver.observe(datePickerAreaRef.current);

    return () => resizeObserver.disconnect();
  }, []);

  // CSS calc()で高さオフセットを構築（JS state連鎖を排除し、ガタつきを防止）
  // var(--subheader-height) はSubHeaderのResizeObserverが設定するCSS変数
  const heightOffsetCss = `${LAYOUT_SIZES.HEADER_HEIGHT}px + var(--subheader-height, 80px) + ${LAYOUT_SIZES.FOOTER_HEIGHT}px + ${datePickerAreaHeight}px`;

  // 表示モード切り替えの選択肢
  const viewModeOptions: ViewModeOption<ViewMode>[] = [
    { value: 'table', label: 'テーブル', icon: 'list' },
    { value: 'card', label: 'カード', icon: 'dashboard' },
  ];

  return (
    <>
      {/* メインコンテンツ */}
        {/* ヘッダー: DatePicker + 件数 + 表示モード切り替え */}
        <div ref={datePickerAreaRef} className="flex flex-wrap justify-between items-center gap-2 px-4 py-2 flex-shrink-0">
          {/* 左側: DatePicker + 件数 + 更新ボタン */}
          <div className="flex items-center gap-3">
            <DatePicker
              pickerMode="month"
              variant="default"
              size="small"
              navigationMode="month"
              value={displayDate}
              onChange={onDateChange}
              recentMonths={APP_CONFIG.RECENT_MONTHS}
              allowClear={true}
              highlightedMonths={highlightedMonths}
            />
            {/* テーブル表示時のみ件数・選択数をここに表示（カード時はCardList内に統合） */}
            {effectiveViewMode === 'table' && <DataCountDisplay totalCount={answerData.length} selectedCount={selectedRows.length} loading={loading} />}
          </div>

          {/* 右側: アンケート選択・表示モード切り替え */}
          <div className="flex items-center gap-4 text-fluid-sm">
            {/* アンケート選択ドロップダウン */}
            {surveyTitles.length > 0 && (
              <Select
                options={surveyTitles.map((title) => ({ value: title, label: title }))}
                value={selectedSurvey || undefined}
                onChange={(value) => onSurveyChange(value ?? '')}
                placeholder="すべてのアンケート"
                allowEmpty={true}
                width="w-[280px]"
              />
            )}
            {showViewModeToggle && (
              <ViewModeToggle
                value={viewMode}
                onChange={onViewModeChange}
                options={viewModeOptions}
              />
            )}
            {onRefresh && (
              <RefreshButton
                onRefresh={onRefresh}
                dataUpdatedAt={dataUpdatedAt}
                loading={loading}
                refreshing={refreshing}
              />
            )}
          </div>
        </div>

        {/* コンテンツ: テーブル or カード */}
        {effectiveViewMode === 'table' ? (
          <InteractiveTable
            columns={answerColumns as unknown as import('@ui-catalog/core/organisms').Column[]}
            data={answerData as unknown as TableRowData[]}
            enableRowHighlight={true}
            enableRowColors={false}
            enableKeyboardNavigation={true}
            loading={loading || refreshing}
            heightPercent={100}
            heightOffsetCss={heightOffsetCss}
            enableSelection={true}
            enableCellSelection={true}
            enableColumnAnimation={enableColumnAnimation}
            draggingColumn={draggingColumn}
            columnWidthsResetKey={columnWidthsResetKey}
            enableRowAnimation={tableRowAnimationVariant !== 'none'}
            rowAnimationVariant={tableRowAnimationVariant}
            borderRadius={shapes.borderRadius}
            headerBgColor={colors.tableHeaderBgColor}
            headerTextColor={colors.tableHeaderTextColor}
            backgroundHeaderBgColor={colors.secondaryBgColor}
            selectedRows={selectedRows}
            onSelectionChange={onSelectionChange}
            onInternalLinkClick={onInternalLinkClick}
            enableVirtualization={true}
          />
        ) : (
          <div
            style={{
              height: `calc(100vh - (${heightOffsetCss}))`,
              maxHeight: `calc(100vh - (${heightOffsetCss}))`,
              overflow: 'hidden',
            }}
          >
            <AnswerCardList
              data={answerData}
              loading={loading || refreshing}
              selectedRows={selectedRows}
              onSelectionChange={onSelectionChange || (() => {})}
              onCardClick={onCardClick || (() => {})}
              enableAnimation={enableCardAnimation}
              animationVariant={cardAnimationVariant}
              headerExtra={<DataCountDisplay totalCount={answerData.length} selectedCount={selectedRows.length} loading={loading} />}
            />
          </div>
        )}
    </>
  );
}
