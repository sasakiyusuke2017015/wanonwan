/**
 * 配下メンバー一覧ページの型定義
 */

import type { EvaluationData } from '@1on1/domain/validators/common'

export type { EvaluationData }

/**
 * 回答結果データ
 * 特定期間におけるメンバーの回答・面談・評価データ
 */
export interface AnswerResult {
  回答状況?: string;
  評価結果?: EvaluationData;
  健康状態?: string | { Value?: string; value?: string } | null;
  回答日?: string | null;
  面談日?: string | null;
  面談方式?: string | null;
  面談メモ?: string | null;
  回答者?: string;
}

/**
 * 回答者基本データ
 * バックエンドから取得する回答者の生データ
 */
export interface Answer {
  ユーザーID: string;
  役職?: string;
  所属本部?: string;
  所属部?: string;
  所属課?: string;
  部署?: string;
  サポーター?: string;
  トレーナー?: string;
  回答結果?: AnswerResult[];
}

/**
 * 回答者名リンクデータ
 */
export interface AnswerNameLinkData {
  text: string;
  to: string;
}

/**
 * 回答者表示データ
 * UI表示用に変換された回答者データ
 */
export interface AnswerDisplayData {
  回答ID: number;
  ユーザーID: string;
  名前: AnswerNameLinkData;
  rowStyleType?: 'red' | 'green' | 'yellow';
  役職: string | null;
  部署: string | null;
  メールアドレス: string | null;
  アンケートタイトル: string | null;
  バッチ開始月: string | null;
  開始: string | null;
  完了: string | null;
  回答状況: string;
  回答日: string | null;
  満足度: number | null;
  業務負荷: number | null;
  職場環境: number | null;
  人間関係: number | null;
  ストレス: number | null;
  健康状態: string | null;
  面談日: string | null;
  面談方式: string | null;
  面談メモ: string | null;
  /** 面談候補（JSON文字列） - 委任機能用 */
  面談候補: string | null;
  /** 動的プロパティアクセス用（CSV出力等） */
  [key: string]: unknown;
}

/**
 * 統計処理用回答者データ
 * 統計計算に必要な最小限のフィールド
 */
export interface ProcessedAnswer {
  回答状況: string;
}

/**
 * 回答者統計データ
 * 回答率・面談率などの統計情報
 */
export interface Statistics {
  total: number;
  answered: number;
  unanswered: number;
  scheduled: number;
  interviewed: number;
  percentage: number;
}

/**
 * 配下メンバー一覧APIレスポンスデータ
 * 配下メンバーの一覧を含むAPIレスポンスの型定義
 */
export interface AnswerListData {
  配下メンバー?: Answer[];
}

export interface AnswerListParams {
  user_code?: string;
  display_date?: string;
  [key: string]: unknown;
}

export interface AnswerListResponse {
  answers: unknown[];
  total: number;
  page: number;
  limit: number;
  [key: string]: unknown;
}

/**
 * カラム定義の型（フィルター設定を含む）
 */
export interface ColumnDefinition {
  accessor: string;
  label: string;
  proportion?: number;
  dataAlign?: 'left' | 'center' | 'right';
  dataFontSize?: string;
  cellType?: 'text' | 'link' | 'internal';
  /** デフォルトで表示するか（true=表示、false=非表示だがトグルで切替可能） */
  visible: boolean;
  /** トグルで表示/非表示を切り替え可能か（false=常に表示、トグル操作不可） */
  toggleable: boolean;
  /** カスタムレンダラー（value型は各render関数内で検証） */
  render?: (value: unknown, row: AnswerDisplayData) => React.ReactNode;
  // フィルター設定
  filter?: import('@ui-catalog/core/types').FilterConfig;
}
