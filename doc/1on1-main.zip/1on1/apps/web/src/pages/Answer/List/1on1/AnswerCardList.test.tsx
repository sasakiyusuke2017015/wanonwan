import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AnswerCardList from './AnswerCardList';
import type { AnswerDisplayData } from './types';

/** テスト用のデフォルトデータ */
const createMockData = (id: string, name: string): AnswerDisplayData => ({
  ユーザーID: id,
  名前: { text: name, to: `/answers/${id}` },
  役職: '課長',
  部署: '営業部',
  メールアドレス: `${id}@example.com`,
  アンケートタイトル: 'Q1アンケート',
  バッチ開始月: '2025-01',
  回答状況: 'アンケート回答済',
  回答日: '2025-01-15',
  満足度: 4.0,
  業務負荷: 3.5,
  職場環境: 4.5,
  人間関係: 3.0,
  ストレス: 2.5,
  健康状態: '良好',
  面談日: '2025-01-20',
  面談方式: null,
  面談メモ: null,
});

const mockData = [
  createMockData('user-001', '山田太郎'),
  createMockData('user-002', '鈴木花子'),
  createMockData('user-003', '佐藤次郎'),
];

const defaultProps = {
  data: mockData,
  selectedRows: [] as number[],
  onSelectionChange: vi.fn(),
  onCardClick: vi.fn(),
  enableAnimation: false,
};

describe('AnswerCardList', () => {
  // ========================================
  // 基本レンダリング
  // ========================================
  describe('基本レンダリング', () => {
    it('全データのカードが表示される', () => {
      render(<AnswerCardList {...defaultProps} />);
      expect(screen.getByText('山田太郎')).toBeInTheDocument();
      expect(screen.getByText('鈴木花子')).toBeInTheDocument();
      expect(screen.getByText('佐藤次郎')).toBeInTheDocument();
    });

    it('ローディング中はメッセージが表示される', () => {
      render(<AnswerCardList {...defaultProps} loading={true} />);
      expect(screen.getByText('データを読み込み中...')).toBeInTheDocument();
    });

    it('データが空の場合はメッセージが表示される', () => {
      render(<AnswerCardList {...defaultProps} data={[]} />);
      expect(screen.getByText('該当する回答者がいません')).toBeInTheDocument();
    });
  });

  // ========================================
  // 全選択ヘッダー
  // ========================================
  describe('全選択ヘッダー', () => {
    it('全選択チェックボックスが表示される', () => {
      const { container } = render(<AnswerCardList {...defaultProps} />);
      // ヘッダー部分にチェックボックスが存在
      const headerCheckbox = container.querySelector('.sticky input[type="checkbox"]');
      expect(headerCheckbox).toBeInTheDocument();
    });

    it('未選択時はチェックボックスが未チェック状態である', () => {
      const { container } = render(<AnswerCardList {...defaultProps} selectedRows={[]} />);
      const headerCheckbox = container.querySelector('.sticky input[type="checkbox"]') as HTMLInputElement;
      expect(headerCheckbox).toBeInTheDocument();
      expect(headerCheckbox.checked).toBe(false);
    });

    it('一部選択時はチェックボックスがチェック状態である', () => {
      const { container } = render(<AnswerCardList {...defaultProps} selectedRows={[0, 1]} />);
      const headerCheckbox = container.querySelector('.sticky input[type="checkbox"]') as HTMLInputElement;
      expect(headerCheckbox).toBeInTheDocument();
      expect(headerCheckbox.checked).toBe(true);
    });

    it('全選択時はチェックボックスがチェック状態である', () => {
      const { container } = render(<AnswerCardList {...defaultProps} selectedRows={[0, 1, 2]} />);
      const headerCheckbox = container.querySelector('.sticky input[type="checkbox"]') as HTMLInputElement;
      expect(headerCheckbox).toBeInTheDocument();
      expect(headerCheckbox.checked).toBe(true);
    });

    it('全選択チェックボックスクリックで全行が選択される', async () => {
      const onSelectionChange = vi.fn();
      const user = userEvent.setup();

      const { container } = render(
        <AnswerCardList {...defaultProps} onSelectionChange={onSelectionChange} />
      );

      const headerCheckbox = container.querySelector('.sticky input[type="checkbox"]') as HTMLInputElement;
      await user.click(headerCheckbox);
      expect(onSelectionChange).toHaveBeenCalledWith([0, 1, 2]);
    });
  });

  // ========================================
  // 個別カード選択
  // ========================================
  describe('個別カード選択', () => {
    it('カードクリックで選択トグルされる', async () => {
      const onSelectionChange = vi.fn();
      const user = userEvent.setup();

      const { container } = render(
        <AnswerCardList {...defaultProps} onSelectionChange={onSelectionChange} />
      );

      // 最初のカードをクリック（カード全体がクリッカブル）
      const cards = container.querySelectorAll('[data-testid="answer-card"]');
      expect(cards.length).toBe(3);
      await user.click(cards[0]);
      expect(onSelectionChange).toHaveBeenCalledWith([0]);
    });

    it('選択済みカードクリックで選択解除される', async () => {
      const onSelectionChange = vi.fn();
      const user = userEvent.setup();

      const { container } = render(
        <AnswerCardList
          {...defaultProps}
          selectedRows={[0, 1]}
          onSelectionChange={onSelectionChange}
        />
      );

      const cards = container.querySelectorAll('[data-testid="answer-card"]');
      await user.click(cards[0]);
      expect(onSelectionChange).toHaveBeenCalledWith([1]);
    });
  });

  // ========================================
  // 選択状態の視覚的フィードバック
  // ========================================
  describe('選択状態の視覚的フィードバック', () => {
    it('選択されたカードにはブランドカラーのボーダーが適用される', () => {
      const { container } = render(
        <AnswerCardList {...defaultProps} selectedRows={[0]} />
      );

      const cards = container.querySelectorAll('[data-testid="answer-card"]');
      // 選択カード: ブランドカラーのボーダー
      expect(cards[0].className).toMatch(/border-blue-500/);
      expect(cards[0].className).toMatch(/border-2/);
      // 非選択カード: ブランドカラーなし
      expect(cards[1].className).not.toMatch(/border-blue-500/);
    });

    it('選択カードには右上インジケーターが表示される', () => {
      const { container } = render(
        <AnswerCardList {...defaultProps} selectedRows={[0]} />
      );

      const cards = container.querySelectorAll('[data-testid="answer-card"]');
      expect(cards[0].querySelector('[data-testid="selection-indicator"]')).toBeInTheDocument();
      expect(cards[1].querySelector('[data-testid="selection-indicator"]')).not.toBeInTheDocument();
    });

    it('カード内にチェックボックス（input[type=checkbox]）が存在しない', () => {
      const { container } = render(
        <AnswerCardList {...defaultProps} selectedRows={[0]} />
      );

      const cards = container.querySelectorAll('[data-testid="answer-card"]');
      // カード内部にはチェックボックスがない（ヘッダーの全選択は除く）
      expect(cards[0].querySelector('input[type="checkbox"]')).not.toBeInTheDocument();
      expect(cards[1].querySelector('input[type="checkbox"]')).not.toBeInTheDocument();
    });
  });

  // ========================================
  // スクロール領域
  // ========================================
  describe('スクロール領域', () => {
    it('カードリスト領域に overflow-y-auto が設定されている', () => {
      const { container } = render(<AnswerCardList {...defaultProps} />);
      const scrollArea = container.querySelector('.overflow-y-auto');
      expect(scrollArea).toBeInTheDocument();
    });

    it('ルート要素に h-full が設定されている', () => {
      const { container } = render(<AnswerCardList {...defaultProps} />);
      const root = container.firstElementChild as HTMLElement;
      expect(root.className).toMatch(/h-full/);
    });

    it('ヘッダーが sticky で固定されている', () => {
      const { container } = render(<AnswerCardList {...defaultProps} />);
      const stickyHeader = container.querySelector('.sticky');
      expect(stickyHeader).toBeInTheDocument();
    });
  });

  // ========================================
  // データ変更時の再描画
  // ========================================
  describe('データ変更時の再描画', () => {
    it('データが減ったとき、カード数が正しく減る', () => {
      const { container, rerender } = render(<AnswerCardList {...defaultProps} />);
      expect(container.querySelectorAll('[data-testid="answer-card"]').length).toBe(3);

      // フィルター適用: 2件に減る
      const filteredData = [mockData[0], mockData[2]];
      rerender(<AnswerCardList {...defaultProps} data={filteredData} />);
      expect(container.querySelectorAll('[data-testid="answer-card"]').length).toBe(2);
    });

    it('データが減ったとき、残ったカードの内容が正しい', () => {
      const { rerender } = render(<AnswerCardList {...defaultProps} />);

      const filteredData = [mockData[0], mockData[2]];
      rerender(<AnswerCardList {...defaultProps} data={filteredData} />);

      expect(screen.getByText('山田太郎')).toBeInTheDocument();
      expect(screen.queryByText('鈴木花子')).not.toBeInTheDocument();
      expect(screen.getByText('佐藤次郎')).toBeInTheDocument();
    });

    it('データが空になったとき、空メッセージが表示される', () => {
      const { rerender } = render(<AnswerCardList {...defaultProps} />);

      rerender(<AnswerCardList {...defaultProps} data={[]} />);
      expect(screen.getByText('該当する回答者がいません')).toBeInTheDocument();
    });
  });
});
