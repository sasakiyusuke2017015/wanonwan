import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AnswerCard from './AnswerCard';
import type { AnswerDisplayData } from './types';

/** テスト用のデフォルトデータ */
const createMockData = (overrides: Partial<AnswerDisplayData> = {}): AnswerDisplayData => ({
  ユーザーID: 'user-001',
  名前: { text: '山田太郎', to: '/answers/user-001' },
  役職: '課長',
  部署: '営業部',
  メールアドレス: 'yamada@example.com',
  アンケートタイトル: 'Q1アンケート',
  バッチ開始月: '2025-01',
  回答状況: 'アンケート回答済',
  回答日: '2025-01-15',
  満足度: 4.0,
  業務負荷: 3.5,
  職場環境: 4.5,
  人間関係: 3.0,
  ストレス: 2.5,
  健康状態: '良好',
  面談日: '2025-01-20',
  面談方式: '対面',
  面談メモ: '特に問題なし',
  ...overrides,
});

const defaultProps = {
  data: createMockData(),
  selected: false,
  onSelectionChange: vi.fn(),
  onClick: vi.fn(),
};

describe('AnswerCard', () => {
  // ========================================
  // 基本レンダリング
  // ========================================
  describe('基本レンダリング', () => {
    it('名前が表示される', () => {
      render(<AnswerCard {...defaultProps} />);
      expect(screen.getByText('山田太郎')).toBeInTheDocument();
    });

    it('部署・役職が表示される', () => {
      render(<AnswerCard {...defaultProps} />);
      expect(screen.getByText(/営業部/)).toBeInTheDocument();
      expect(screen.getByText(/課長/)).toBeInTheDocument();
    });

    it('名前がない場合はユーザーIDが表示される', () => {
      const data = createMockData({ 名前: { text: '', to: '' } });
      render(<AnswerCard {...defaultProps} data={data} />);
      expect(screen.getByText('user-001')).toBeInTheDocument();
    });
  });

  // ========================================
  // 通常状態: 「静かな佇まい」
  // ========================================
  describe('通常状態（非選択）', () => {
    it('淡いボーダーを持つ', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const card = container.firstElementChild as HTMLElement;
      // 通常: 淡いグレーのボーダー（border-gray-100 or border-transparent）
      expect(card.className).toMatch(/border/);
      // 太い選択ボーダーではない
      expect(card.className).not.toMatch(/border-blue-500/);
      expect(card.className).not.toMatch(/border-\[/);
    });

    it('shadow-sm（控えめな影）を持つ', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/shadow-sm/);
    });
  });

  // ========================================
  // ホバー状態: 「反応の予感」
  // ========================================
  describe('ホバー状態', () => {
    it('ホバー時に影が強まるクラスを持つ', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/hover:shadow-md/);
    });

    it('ホバー時に浮き上がるクラスを持つ', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/hover:-translate-y-1/);
    });
  });

  // ========================================
  // 選択状態: 「明確な意思表示」
  // ========================================
  describe('選択状態', () => {
    it('アクセント・ボーダー（ブランドカラー 2px）が適用される', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={true} />);
      const card = container.firstElementChild as HTMLElement;
      // 選択時: ブランドカラーの太い枠線
      expect(card.className).toMatch(/border-blue-500/);
      expect(card.className).toMatch(/border-2/);
    });

    it('背景のトーンが変化する（ブランドカラー低彩度）', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={true} />);
      const card = container.firstElementChild as HTMLElement;
      // 選択時: ブランドカラー 5-10% の背景
      expect(card.className).toMatch(/bg-blue-50/);
    });

    it('右上に選択インジケーター（丸バッジ + チェックマーク）が表示される', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={true} />);
      // 右上のインジケーター要素
      const indicator = container.querySelector('[data-testid="selection-indicator"]');
      expect(indicator).toBeInTheDocument();
    });

    it('非選択時はインジケーターが表示されない', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const indicator = container.querySelector('[data-testid="selection-indicator"]');
      expect(indicator).not.toBeInTheDocument();
    });

    it('チェックボックス（左上の四角い箱）が存在しない', () => {
      const { container } = render(<AnswerCard {...defaultProps} selected={false} />);
      const checkbox = container.querySelector('input[type="checkbox"]');
      expect(checkbox).not.toBeInTheDocument();
    });
  });

  // ========================================
  // アラート行の選択状態
  // ========================================
  describe('アラート行', () => {
    it('アラート行は赤系のボーダーが適用される', () => {
      const data = createMockData({ rowStyleType: 'red' });
      const { container } = render(<AnswerCard {...defaultProps} data={data} selected={false} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/border-red/);
    });

    it('アラート行 + 選択時は赤系の太いボーダーが適用される', () => {
      const data = createMockData({ rowStyleType: 'red' });
      const { container } = render(<AnswerCard {...defaultProps} data={data} selected={true} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/border-red/);
      expect(card.className).toMatch(/border-2/);
    });
  });

  // ========================================
  // カード全体クリック（巨大なボタン）
  // ========================================
  describe('カード全体クリック', () => {
    it('カードクリックで選択がトグルされる', async () => {
      const onSelectionChange = vi.fn();
      const user = userEvent.setup();

      const { container } = render(
        <AnswerCard {...defaultProps} selected={false} onSelectionChange={onSelectionChange} />
      );

      const card = container.firstElementChild as HTMLElement;
      await user.click(card);
      expect(onSelectionChange).toHaveBeenCalledWith(true);
    });

    it('選択済みカードクリックで選択解除される', async () => {
      const onSelectionChange = vi.fn();
      const user = userEvent.setup();

      const { container } = render(
        <AnswerCard {...defaultProps} selected={true} onSelectionChange={onSelectionChange} />
      );

      const card = container.firstElementChild as HTMLElement;
      await user.click(card);
      expect(onSelectionChange).toHaveBeenCalledWith(false);
    });
  });

  // ========================================
  // トランジション
  // ========================================
  describe('トランジション', () => {
    it('transition-all duration-200 クラスを持つ', () => {
      const { container } = render(<AnswerCard {...defaultProps} />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.className).toMatch(/transition-all/);
      expect(card.className).toMatch(/duration-200/);
    });
  });

  // ========================================
  // スコア・ステータス表示（既存機能の保持）
  // ========================================
  describe('スコア表示', () => {
    it('5つの評価項目ラベルが表示される', () => {
      render(<AnswerCard {...defaultProps} />);
      expect(screen.getByText('満足度')).toBeInTheDocument();
      expect(screen.getByText('業務負荷')).toBeInTheDocument();
      expect(screen.getByText('職場環境')).toBeInTheDocument();
      expect(screen.getByText('人間関係')).toBeInTheDocument();
      expect(screen.getByText('ストレス')).toBeInTheDocument();
    });

    it('スコアがnullの場合は「-」が表示される', () => {
      const data = createMockData({ 満足度: null });
      render(<AnswerCard {...defaultProps} data={data} />);
      expect(screen.getAllByText('-').length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('ステータス表示', () => {
    it('回答・面談・健康のステータスラベルが表示される', () => {
      render(<AnswerCard {...defaultProps} />);
      expect(screen.getByText(/回答:/)).toBeInTheDocument();
      expect(screen.getByText(/面談:/)).toBeInTheDocument();
      expect(screen.getByText(/健康:/)).toBeInTheDocument();
    });
  });

  describe('日付表示', () => {
    it('回答日・面談日が表示される', () => {
      render(<AnswerCard {...defaultProps} />);
      expect(screen.getByText(/回答日: 2025-01-15/)).toBeInTheDocument();
      expect(screen.getByText(/面談日: 2025-01-20/)).toBeInTheDocument();
    });
  });

  describe('cardRadius', () => {
    it('カスタム borderRadius が適用される', () => {
      const { container } = render(<AnswerCard {...defaultProps} cardRadius="1rem" />);
      const card = container.firstElementChild as HTMLElement;
      expect(card.style.borderRadius).toBe('1rem');
    });
  });
});
