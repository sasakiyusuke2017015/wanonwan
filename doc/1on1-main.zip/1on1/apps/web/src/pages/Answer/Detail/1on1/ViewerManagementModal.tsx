/**
 * 閲覧者管理モーダル
 *
 * 回答の閲覧権限（面談候補）を管理するモーダル
 * - 左側: 閲覧可能（面談候補にいる人）
 * - 右側: 閲覧不可（自分の配下で、まだ閲覧者に入っていない人）
 *
 * 注意: 自分自身は閲覧者リストから削除できない（閲覧中のバグ防止）
 */
import { FC, useState, useEffect, useCallback, useMemo } from 'react';

import { Icon } from '@ui-catalog/core/atoms';
import { Button } from '@ui-catalog/core/molecules';
import { Modal, Toast, TransferList, type TransferListItem } from '@ui-catalog/core/organisms';

import { useToast } from '@ui-catalog/core/hooks/ui';
import { apiPost, apiDelete } from '@/lib/api';

/** 閲覧者/追加可能な人の型 */
interface ViewerUser {
  ユーザーID: string;
  名前: string;
  役職: string | null;
  部署: string | null;
  /** 自分の配下かどうか（操作可能か） */
  isSubordinate: boolean;
}

export interface ViewerManagementModalProps {
  /** モーダル表示状態 */
  isOpen: boolean;
  /** モーダルを閉じるハンドラ */
  onClose: () => void;
  /** 回答ID */
  answerId: string;
  /** 現在の閲覧者（面談候補）のユーザーID配列 */
  currentViewerIds: string[];
  /** 配下一覧（追加可能な人の候補） */
  subordinates: ViewerUser[];
  /** 現在のユーザーID */
  currentUserId: string;
  /** 現在のユーザー名 */
  currentUserName?: string;
  /** 変更成功時のコールバック */
  onSuccess?: () => void;
}

/** ViewerUser を TransferListItem に変換 */
function toTransferItem(
  user: ViewerUser,
  currentUserId: string,
  currentUserName: string
): TransferListItem {
  const isSelf = user.ユーザーID === currentUserId;
  return {
    id: user.ユーザーID,
    label: isSelf ? `${currentUserName} (自分)` : user.名前,
    subLabel: user.部署 || user.役職
      ? `${user.部署 || ''}${user.役職 ? ` / ${user.役職}` : ''}`
      : undefined,
    disabled: isSelf || !user.isSubordinate,
    disabledReason: isSelf ? '削除不可' : !user.isSubordinate ? '移動不可' : undefined,
  };
}

/**
 * 閲覧者管理モーダル
 */
const ViewerManagementModal: FC<ViewerManagementModalProps> = ({
  isOpen,
  onClose,
  answerId,
  currentViewerIds,
  subordinates,
  currentUserId,
  currentUserName = 'あなた',
  onSuccess,
}) => {
  const { toastState, showToast, closeToast } = useToast();

  // ローディング状態
  const [loading, setLoading] = useState(false);

  // 現在の閲覧者リスト（ローカル状態）
  const [viewers, setViewers] = useState<string[]>([]);
  // 初期状態（変更検出用）
  const [initialViewers, setInitialViewers] = useState<string[]>([]);

  // モーダルが開いたときに初期化
  useEffect(() => {
    if (isOpen) {
      setViewers([...currentViewerIds]);
      setInitialViewers([...currentViewerIds]);
    }
  }, [isOpen, currentViewerIds]);

  // 変更があるかどうか
  const hasChanges = useMemo(() => {
    if (viewers.length !== initialViewers.length) return true;
    const sortedViewers = [...viewers].sort();
    const sortedInitial = [...initialViewers].sort();
    return sortedViewers.some((v, i) => v !== sortedInitial[i]);
  }, [viewers, initialViewers]);

  // 追加されたユーザー
  const addedViewers = useMemo(() => {
    const initialSet = new Set(initialViewers);
    return viewers.filter(id => !initialSet.has(id));
  }, [viewers, initialViewers]);

  // 削除されたユーザー
  const removedViewers = useMemo(() => {
    const currentSet = new Set(viewers);
    return initialViewers.filter(id => !currentSet.has(id));
  }, [viewers, initialViewers]);

  // 全ユーザーマップ（ID → ViewerUser）
  const userMap = useMemo(() => {
    const map = new Map<string, ViewerUser>();
    subordinates.forEach(s => map.set(s.ユーザーID, s));
    // 自分自身を追加（subordinates にいない場合）
    if (!map.has(currentUserId)) {
      map.set(currentUserId, {
        ユーザーID: currentUserId,
        名前: currentUserName,
        役職: null,
        部署: null,
        isSubordinate: false,
      });
    }
    return map;
  }, [subordinates, currentUserId, currentUserName]);

  // 左側（閲覧可能）のアイテム
  const leftItems = useMemo(() => {
    return viewers.map(id => {
      const user = userMap.get(id) || {
        ユーザーID: id,
        名前: `ユーザー ${id}`,
        役職: null,
        部署: null,
        isSubordinate: false,
      };
      return toTransferItem(user, currentUserId, currentUserName);
    });
  }, [viewers, userMap, currentUserId, currentUserName]);

  // 右側（閲覧不可）のアイテム
  const rightItems = useMemo(() => {
    const viewerSet = new Set(viewers);
    return subordinates
      .filter(s => !viewerSet.has(s.ユーザーID) && s.ユーザーID !== currentUserId)
      .map(s => toTransferItem(s, currentUserId, currentUserName));
  }, [viewers, subordinates, currentUserId, currentUserName]);

  // TransferList の onChange
  const handleTransferChange = useCallback((
    newLeftItems: TransferListItem[],
    _newRightItems: TransferListItem[]
  ) => {
    // 左側のアイテムIDを新しい viewers として設定
    // ただし、自分自身は常に含める
    const newViewerIds = newLeftItems.map(item => item.id);
    if (!newViewerIds.includes(currentUserId) && initialViewers.includes(currentUserId)) {
      newViewerIds.unshift(currentUserId);
    }
    setViewers(newViewerIds);
  }, [currentUserId, initialViewers]);

  // 更新ボタン押下時の処理
  const handleSave = useCallback(async () => {
    if (!hasChanges) return;

    setLoading(true);
    try {
      // 追加処理
      for (const userId of addedViewers) {
        await apiPost(`/answers/${answerId}/delegate`, {
          delegateToUserId: userId,
          delegationType: 'this_answer_only',
        });
      }

      // 削除処理
      for (const userId of removedViewers) {
        await apiDelete(`/answers/${answerId}/delegate/${userId}`);
      }

      showToast('閲覧者を更新しました', { type: 'success' });
      setInitialViewers([...viewers]);
      onSuccess?.();
    } catch (err) {
      console.error('閲覧者更新エラー:', err);
      showToast('閲覧者の更新に失敗しました', { type: 'error' });
      // エラー時は元に戻す
      setViewers([...initialViewers]);
    } finally {
      setLoading(false);
    }
  }, [hasChanges, addedViewers, removedViewers, answerId, viewers, initialViewers, showToast, onSuccess]);

  // キャンセル処理
  const handleCancel = useCallback(() => {
    if (hasChanges) {
      setViewers([...initialViewers]);
    }
    onClose();
  }, [hasChanges, initialViewers, onClose]);

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={handleCancel}
        title="閲覧者確認"
        maxWidth="max-w-4xl"
      >
        <div className="space-y-4">
          {/* 説明文 */}
          <p className="text-fluid-sm text-gray-600">
            チェックボックスで選択し、ボタンで閲覧権限を切り替えられます。
            <br />
            <span className="text-fluid-xs text-gray-400">※変更は「更新」ボタンを押すまで反映されません</span>
          </p>

          {/* TransferList */}
          <TransferList
            leftItems={leftItems}
            rightItems={rightItems}
            leftLabel="閲覧可能"
            rightLabel="閲覧不可"
            toRightLabel="無効化 →"
            toLeftLabel="← 有効化"
            leftIcon={<Icon name={'users-group'} size={20} stroke="blue" hover="auto" />}
            rightIcon={<Icon name={'person'} size={20} stroke="gray" hover="auto" />}
            onChange={handleTransferChange}
            loading={loading}
            minHeight="250px"
          />

          {/* フッターボタン */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              type="button"
              variant="secondary"
              size="small"
              onClick={handleCancel}
              disabled={loading}
            >
              キャンセル
            </Button>
            <Button
              type="button"
              variant="primary"
              size="small"
              onClick={handleSave}
              disabled={loading || !hasChanges}
            >
              {loading ? '更新中...' : '更新'}
            </Button>
          </div>
        </div>
      </Modal>

      <Toast {...toastState} onClose={closeToast} />
    </>
  );
};

export default ViewerManagementModal;
