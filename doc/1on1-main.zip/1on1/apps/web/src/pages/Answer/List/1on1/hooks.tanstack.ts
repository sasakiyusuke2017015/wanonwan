/**
 * 配下メンバー一覧ページ専用フック（REST API版）
 */
import { useMemo, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAtom, useSetAtom } from 'jotai';

import { ROUTES } from '@/constants/routes';
import {
  filterValuesAtom,
  textFiltersAtom,
  statusFiltersAtom,
  scoreFiltersAtom,
  dateRangeFiltersAtom,
} from '@/state';
import type { FilterValues } from '@ui-catalog/core/types';
import {
  isDateInRange,
  type DateRange,
  formatDate,
  getMaskedInterviewMemo,
} from '@1on1/domain/utils';
import {
  getAnswerStatusLabel,
  getHealthStatusLabel,
} from '@/utils/status';

import { apiGet } from '@/lib/api';

import { getInitialFilterValues, FILTER_CONFIGS, ANSWER_TABLE_COLUMNS } from './tableColumns';

import type { AnswerDisplayData, ProcessedAnswer, Statistics, ColumnDefinition } from './types';

/**
 * API AnswerListItem型
 * API は数値コードを返す
 * ユーザー情報はユーザーマスタから結合済み
 */
interface AnswerListItem {
  回答ID: number;
  回答状況?: number | string; // 数値コード (Pleasanterは文字列で返す場合あり)
  回答者?: string;
  掲載設定?: string;
  アンケートタイトル?: string; // アンケートマスタから結合
  バッチ開始月?: string; // 掲載設定から結合
  開始?: string; // 掲載設定から結合
  完了?: string; // 掲載設定から結合
  健康状態?: number | string;
  面談方式?: string;
  面談候補?: string; // ["userId1", "userId2"] 形式のJSON文字列（委任機能用）
  回答日?: string;
  面談日?: string;
  評価結果JSON?: string;
  面談メモ?: string;
  面談内容閲覧者?: string; // ["userId1", "userId2"] 形式のJSON文字列
  面談者?: string; // 面談者の名前（APIで解決済み）
  作成日時?: string;
  // ユーザーマスタから結合されたフィールド
  回答者名?: string;
  役職?: string;
  所属本部?: string;
  所属部?: string;
  所属課?: string;
  メールアドレス?: string;
}

/**
 * API レスポンス型
 */
interface AnswersResponse {
  answers: AnswerListItem[];
  total: number;
}

/**
 * 評価結果JSONをパースしてスコア値を取得
 */
interface EvaluationScores {
  満足度: number | null;
  業務負荷: number | null;
  職場環境: number | null;
  人間関係: number | null;
  ストレス: number | null;
}

/**
 * 文字列/数値を数値に安全に変換
 */
function toNumber(value: number | string | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === 'number') return value;
  const parsed = parseInt(value, 10);
  return isNaN(parsed) ? undefined : parsed;
}

/**
 * バッチ開始月を YYYY-MM 形式に正規化
 * Pleasanter保存形式: "YYYY年MM月" → "YYYY-MM"
 */
function normalizeYearMonth(value: string | undefined): string | null {
  if (!value) return null;
  // "YYYY年MM月" 形式をパース
  const match = value.match(/^(\d{4})年(\d{1,2})月$/);
  if (match) {
    const year = match[1];
    const month = match[2].padStart(2, '0');
    return `${year}-${month}`;
  }
  // 既に YYYY-MM 形式の場合はそのまま返す
  if (/^\d{4}-\d{2}$/.test(value)) {
    return value;
  }
  return null;
}

function parseEvaluationJSON(json: string | undefined): EvaluationScores {
  const empty: EvaluationScores = { 満足度: null, 業務負荷: null, 職場環境: null, 人間関係: null, ストレス: null };
  if (!json) return empty;
  try {
    // Pleasanterからの値はPython dict形式（シングルクォート）の場合があるため変換
    const normalized = json.replace(/'/g, '"');
    const parsed = JSON.parse(normalized);
    const toScore = (v: unknown): number | null => {
      if (typeof v === 'number') return Math.round(v);
      return null;
    };
    return {
      満足度: toScore(parsed.満足度),
      業務負荷: toScore(parsed.業務負荷),
      職場環境: toScore(parsed.職場環境),
      人間関係: toScore(parsed.人間関係),
      ストレス: toScore(parsed.ストレス),
    };
  } catch {
    return empty;
  }
}

/**
 * APIレスポンスを表示用データに直接変換
 * 数値コード → ラベル変換を行う
 * ユーザー情報はAPIから結合済みのフィールドを使用
 * @param answers APIからのレスポンス
 * @param currentUserId 現在のログインユーザーID（面談メモ閲覧制御用）
 */
const transformToDisplayData = (
  answers: AnswerListItem[],
  currentUserId?: string
): AnswerDisplayData[] => {
  return answers.map((item) => {
    const scores = parseEvaluationJSON(item.評価結果JSON);
    // 部署表示: 所属部 > 所属課 > 所属本部 の優先順で表示
    const 部署 = item.所属部 || item.所属課 || item.所属本部 || null;

    // 面談メモの表示内容を決定（閲覧権限チェック）
    // 面談者名はAPIで解決済み
    const displayMemo = getMaskedInterviewMemo(
      item.面談メモ,
      item.面談者,
      item.面談内容閲覧者,
      currentUserId
    );

    return {
      回答ID: item.回答ID,
      ユーザーID: item.回答者 || String(item.回答ID),
      名前: {
        text: item.回答者名 || item.回答者 || String(item.回答ID),
        to: ROUTES.ANSWER_DETAIL.path,
      },
      役職: item.役職 || null,
      部署,
      メールアドレス: item.メールアドレス || null,
      アンケートタイトル: item.アンケートタイトル || null,
      バッチ開始月: normalizeYearMonth(item.バッチ開始月),
      開始: formatDate(item.開始),
      完了: formatDate(item.完了),
      回答状況: getAnswerStatusLabel(toNumber(item.回答状況)),
      回答日: formatDate(item.回答日),
      満足度: scores.満足度,
      業務負荷: scores.業務負荷,
      職場環境: scores.職場環境,
      人間関係: scores.人間関係,
      ストレス: scores.ストレス,
      健康状態: getHealthStatusLabel(toNumber(item.健康状態)),
      面談日: formatDate(item.面談日),
      面談方式: item.面談方式 || null,
      面談メモ: displayMemo,
      面談候補: item.面談候補 || null,
    };
  });
};

/**
 * 配下メンバー一覧データ取得フック（REST API版）
 * GET /api/answers エンドポイントを使用
 *
 * 24ヶ月分のデータを一括取得し、displayDate でフロントエンドフィルタリング
 * @param displayDate 表示対象月 (YYYY-MM形式)。指定時はその月のバッチ開始月のみ表示
 * @param currentUserId 現在のログインユーザーID（面談メモ閲覧制御用）
 */
export const useAnswerListTanStack = (displayDate?: string, currentUserId?: string) => {
  const {
    data: rawData,
    isLoading,
    isFetching,
    error,
    dataUpdatedAt,
    refetch,
  } = useQuery({
    queryKey: ['answers', 'list', 'all'],
    queryFn: () => apiGet<AnswersResponse>('/answers', { recentMonths: 24 }),
    staleTime: 5 * 60 * 1000,
    gcTime: 24 * 60 * 60 * 1000,
    retry: 3,
  });

  // APIレスポンスを表示用データに変換
  const allData = useMemo(() => {
    if (!rawData?.answers) return [];
    return transformToDisplayData(rawData.answers, currentUserId);
  }, [rawData, currentUserId]);

  // displayDate（バッチ開始月）でフィルタリング
  const displayData = useMemo(() => {
    if (!displayDate) return allData;
    return allData.filter((item) => item.バッチ開始月 === displayDate);
  }, [allData, displayDate]);

  return {
    data: displayData,
    allData,
    loading: isLoading,
    refreshing: isFetching && !isLoading,
    error,
    isOffline: false,
    dataUpdatedAt,
    refetch,
  };
};

/**
 * 配下メンバー一覧統計計算フック
 * 処理済みメンバーデータから回答率などの統計情報を計算する
 */
export const useAnswerStatistics = (
  processedData: ProcessedAnswer[]
): Statistics => {
  return useMemo(() => {
    const total = processedData.length;

    // 完了: 完了している人数
    const interviewed = processedData.filter(
      (e) => e.回答状況 === '完了'
    ).length;

    // 回答済み: 回答済みだが完了していない人数
    const answered = processedData.filter(
      (e) => e.回答状況 === 'アンケート回答済'
    ).length;

    // 未回答: 未回答の人数
    const unanswered = processedData.filter(
      (e) => e.回答状況 !== 'アンケート回答済' && e.回答状況 !== '完了'
    ).length;

    // 回答済み（面談待ち）
    const scheduled = answered;

    const percentage =
      Math.round(((answered + interviewed) / (total || 1)) * 100) || 0;

    return {
      total,
      answered,
      unanswered,
      scheduled,
      interviewed,
      percentage,
    };
  }, [processedData]);
};

export interface UseFilterValuesReturn {
  filterValues: FilterValues;
  setFilterValues: (value: FilterValues) => void;
  handleFilterChange: (accessor: string, value: string[] | [number, number] | string) => void;
  handleResetFilters: () => void;
}

/**
 * フィルター値をJotai atomで管理するカスタムフック
 * 配下メンバー一覧ページのフィルター状態を永続化
 *
 * 内部では種別別atomを使用し、再レンダリングを最適化
 */
export const useFilterValues = (): UseFilterValuesReturn => {
  // 統合フィルタatom（読み取り用）
  const [storedFilterValues, setStoredFilterValues] = useAtom(filterValuesAtom);

  // 種別別setter（個別更新用 - 再レンダリング最適化）
  const setTextFilters = useSetAtom(textFiltersAtom);
  const setStatusFilters = useSetAtom(statusFiltersAtom);
  const setScoreFilters = useSetAtom(scoreFiltersAtom);
  const setDateRangeFilters = useSetAtom(dateRangeFiltersAtom);

  // 空オブジェクトの場合はデフォルト値を使用
  const filterValues: FilterValues = useMemo(() => {
    return Object.keys(storedFilterValues).length > 0
      ? (storedFilterValues as FilterValues)
      : getInitialFilterValues();
  }, [storedFilterValues]);

  // フィルター値を更新
  const setFilterValues = useCallback(
    (value: FilterValues): void => {
      setStoredFilterValues(value);
    },
    [setStoredFilterValues]
  );

  // 個別フィルターの変更ハンドラー（種別に応じて適切なatomを更新）
  const handleFilterChange = useCallback(
    (accessor: string, value: string[] | [number, number] | string) => {
      if (typeof value === 'string') {
        // テキストまたは日付範囲フィルタ
        // FILTER_CONFIGSで判別するのがベストだが、簡易的に両方更新
        setTextFilters((prev) => ({ ...prev, [accessor]: value }));
        setDateRangeFilters((prev) => ({ ...prev, [accessor]: value }));
      } else if (Array.isArray(value)) {
        if (value.length === 2 && typeof value[0] === 'number') {
          // スコアフィルタ
          setScoreFilters((prev) => ({ ...prev, [accessor]: value as [number, number] }));
        } else {
          // ステータスフィルタ
          setStatusFilters((prev) => ({ ...prev, [accessor]: value as string[] }));
        }
      }
    },
    [setTextFilters, setStatusFilters, setScoreFilters, setDateRangeFilters]
  );

  // フィルターのリセット
  const handleResetFilters = useCallback(() => {
    const initialValues = getInitialFilterValues();

    // 各種別atomを個別にリセット
    const textFilters: Record<string, string> = {};
    const statusFilters: Record<string, string[]> = {};
    const scoreFilters: Record<string, [number, number]> = {};
    const dateRangeFilters: Record<string, string> = {};

    Object.entries(initialValues).forEach(([key, value]) => {
      if (typeof value === 'string') {
        textFilters[key] = value;
        dateRangeFilters[key] = value;
      } else if (Array.isArray(value)) {
        if (value.length === 2 && typeof value[0] === 'number') {
          scoreFilters[key] = value as [number, number];
        } else {
          statusFilters[key] = value as string[];
        }
      }
    });

    setTextFilters(textFilters);
    setStatusFilters(statusFilters);
    setScoreFilters(scoreFilters);
    setDateRangeFilters(dateRangeFilters);
  }, [setTextFilters, setStatusFilters, setScoreFilters, setDateRangeFilters]);

  return {
    filterValues,
    setFilterValues,
    handleFilterChange,
    handleResetFilters,
  };
};

/**
 * フィルター適用済みメンバーデータを返すフック
 * フィルタリングロジックをコンポーネントから分離
 */
export const useFilteredAnswerData = (
  answerData: AnswerDisplayData[] | undefined,
  filterValues: FilterValues
): AnswerDisplayData[] => {
  return useMemo(() => {
    if (!answerData || answerData.length === 0) return [];

    return answerData.filter((answer) => {
      for (const config of FILTER_CONFIGS) {
        const filterValue = filterValues[config.accessor];
        const employeeValue = answer[config.accessor as keyof typeof answer];

        if (!filterValue) continue;

        if (config.type === 'status') {
          const selectedStatuses = filterValue as string[];
          if (selectedStatuses.length > 0 && !selectedStatuses.includes(String(employeeValue))) {
            return false;
          }
        } else if (config.type === 'score') {
          const [min, max] = filterValue as [number, number];
          const score = employeeValue as number | null;
          // min >= 1 の場合、null（未判定）は除外
          if (score === null) {
            if (min >= 1) return false;
          } else if (score < min || score > max) {
            return false;
          }
        } else if (config.type === 'text') {
          const searchText = (filterValue as string).toLowerCase();
          // オブジェクト型（InternalLinkData等）の場合は.textを取得
          const targetValue = typeof employeeValue === 'object' && employeeValue !== null && 'text' in employeeValue
            ? (employeeValue as { text: string }).text
            : employeeValue;
          if (searchText && !String(targetValue || '').toLowerCase().includes(searchText)) {
            return false;
          }
        } else if (config.type === 'date') {
          const searchText = filterValue as string;
          if (searchText && !String(employeeValue || '').includes(searchText)) {
            return false;
          }
        } else if (config.type === 'dateRange') {
          const dateRangeJson = filterValue as string;
          if (dateRangeJson) {
            try {
              const dateRange = JSON.parse(dateRangeJson) as DateRange;
              const dateValue = employeeValue as string | null;
              if (!isDateInRange(dateValue, dateRange)) {
                return false;
              }
            } catch (error) {
              console.warn('Failed to parse date range filter:', error);
            }
          }
        }
      }

      return true;
    });
  }, [answerData, filterValues]);
};

/**
 * テーブルカラム定義フック
 * visibleColumnAccessorsの順序に従って列を並び替える
 * editable: false の列も並び替え可能（トグルは不可）
 * @param visibleColumnAccessors 表示する列のアクセサ配列
 * @param actionColumn オプション: アクション列の設定（末尾に追加）
 */
export const useAnswerColumns = (
  visibleColumnAccessors: string[],
  actionColumn?: ColumnDefinition
): ColumnDefinition[] => {
  return useMemo(() => {
    // visibleColumnAccessorsの順序に従って全ての列を並び替え
    const columns = visibleColumnAccessors
      .map((accessor) =>
        ANSWER_TABLE_COLUMNS.find(
          (col) => col.accessor === accessor
        )
      )
      .filter((col): col is ColumnDefinition => col !== undefined);

    // アクション列がある場合は末尾に追加
    if (actionColumn) {
      columns.push(actionColumn);
    }

    return columns;
  }, [visibleColumnAccessors, actionColumn]);
};
