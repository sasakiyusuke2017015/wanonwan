/**
 * テーブルカラム定義
 * 各テーブルで使用するカラム構成の定義
 */
import { Badge, type BadgeColor } from '@ui-catalog/core/atoms';
import { ScoreBadge } from '@ui-catalog/core/molecules';
import { CONSTANTS } from '@/constants/schemas';
import type { FilterConfig, FilterConfigWithMeta, FilterValues } from '@ui-catalog/core/types';
import { generateDateFilterOptions, isNullish } from '@1on1/domain/utils';

import type { ColumnDefinition } from './types';

/**
 * 配下メンバー一覧テーブルのカラム定義
 */
export const ANSWER_TABLE_COLUMNS: ColumnDefinition[] = [
  {
    accessor: '名前',
    label: '回答者名',
    proportion: 12,
    dataAlign: 'left' as const,
    cellType: 'internal' as const,
    visible: true,
    toggleable: false,
    filter: {
      type: 'text',
      width: 'w-40',
    },
    // データ変換でInternalLinkData形式に変換される
    // { text: 名前, to: '/answers/details', employeeId: ユーザーID }
  },
  {
    accessor: '部署',
    label: '部署',
    proportion: 18,
    dataAlign: 'left' as const,
    dataFontSize: 'text-fluid-xs' as const,
    visible: true,
    toggleable: true,
    filter: {
      type: 'text',
      width: 'w-40',
    },
  },
  {
    accessor: '役職',
    label: '役職',
    proportion: 8,
    dataAlign: 'left' as const,
    dataFontSize: 'text-fluid-xs' as const,
    visible: true,
    toggleable: true,
    filter: {
      type: 'text',
      width: 'w-40',
    },
  },
  {
    accessor: 'アンケートタイトル',
    label: 'アンケート',
    proportion: 16,
    dataAlign: 'left' as const,
    dataFontSize: 'text-fluid-xs' as const,
    visible: false,
    toggleable: true,
    filter: {
      type: 'text',
      width: 'w-40',
    },
  },
  {
    accessor: 'バッチ開始月',
    label: '開始月',
    proportion: 8,
    visible: false,
    toggleable: true,
    filter: {
      type: 'text',
      width: 'w-40',
    },
    render: (value) => {
      if (!value || typeof value !== 'string') return <span className="text-gray-400">-</span>;
      // YYYY-MM → YYYY/MM
      return <span>{value.replace('-', '/')}</span>;
    },
  },
  {
    accessor: '開始',
    label: '開始日',
    proportion: 9,
    visible: false,
    toggleable: true,
    filter: {
      type: 'dateRange',
      options: generateDateFilterOptions().map(opt => ({
        label: opt.label,
        value: opt.value,
      })),
      width: 'w-40',
    },
  },
  {
    accessor: '完了',
    label: '終了日',
    proportion: 9,
    visible: false,
    toggleable: true,
    filter: {
      type: 'dateRange',
      options: generateDateFilterOptions().map(opt => ({
        label: opt.label,
        value: opt.value,
      })),
      width: 'w-40',
    },
  },
  {
    accessor: '回答日',
    label: '回答日',
    proportion: 9,
    visible: true,
    toggleable: true,
    filter: {
      type: 'dateRange',
      options: generateDateFilterOptions().map(opt => ({
        label: opt.label,
        value: opt.value,
      })),
      width: 'w-40',
    },
  },
  {
    accessor: '回答状況',
    label: '回答状況',
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'status',
      options: Object.entries(CONSTANTS.ANSWER_STATUS).map(([key, def]) => ({
        label: (def as { shortLabel: string; color?: string }).shortLabel,
        value: key,
        color: (def as { shortLabel: string; color?: string }).color,
      })),
      width: 'w-40',
    },
    render: (value) => {
      const statusKey = typeof value === 'string' ? value : null;
      const statusDef = statusKey ? (CONSTANTS.ANSWER_STATUS as unknown as Record<string, { value: number; color?: string; label?: string; shortLabel: string }>)[statusKey] : null;

      if (!statusDef) {
        return (
          <Badge
            value={CONSTANTS.ANSWER_STATUS.アンケート未回答.shortLabel}
            styleVariant="solid"
            color="gray"
            size="small"
          />
        );
      }

      return (
        <Badge
          value={statusDef.shortLabel}
          styleVariant="solid"
          color={statusDef.color as BadgeColor}
          size="small"
        />
      );
    },
  },
  {
    accessor: '満足度',
    label: CONSTANTS.ASSESSMENT_ITEM.満足度.label,
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'score',
      min: 0,
      max: 5,
      width: 'w-40',
    },
    render: (value) => {
      if (isNullish(value) || typeof value !== 'number') return <span className="text-gray-400">-</span>;
      return <ScoreBadge score={value} size="small" />;
    },
  },
  {
    accessor: '業務負荷',
    label: CONSTANTS.ASSESSMENT_ITEM.業務負荷.label,
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'score',
      min: 0,
      max: 5,
      width: 'w-40',
    },
    render: (value) => {
      if (isNullish(value) || typeof value !== 'number') return <span className="text-gray-400">-</span>;
      return <ScoreBadge score={value} size="small" />;
    },
  },
  {
    accessor: '職場環境',
    label: CONSTANTS.ASSESSMENT_ITEM.職場環境.label,
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'score',
      min: 0,
      max: 5,
      width: 'w-40',
    },
    render: (value) => {
      if (isNullish(value) || typeof value !== 'number') return <span className="text-gray-400">-</span>;
      return <ScoreBadge score={value} size="small" />;
    },
  },
  {
    accessor: '人間関係',
    label: CONSTANTS.ASSESSMENT_ITEM.人間関係.label,
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'score',
      min: 0,
      max: 5,
      width: 'w-40',
    },
    render: (value) => {
      if (isNullish(value) || typeof value !== 'number') return <span className="text-gray-400">-</span>;
      return <ScoreBadge score={value} size="small" />;
    },
  },
  {
    accessor: 'ストレス',
    label: CONSTANTS.ASSESSMENT_ITEM.ストレス.label,
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'score',
      min: 0,
      max: 5,
      width: 'w-40',
    },
    render: (value) => {
      if (isNullish(value) || typeof value !== 'number') return <span className="text-gray-400">-</span>;
      return <ScoreBadge score={value} size="small" />;
    },
  },
  {
    accessor: '健康状態',
    label: '健康状態',
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'status',
      options: Object.entries(CONSTANTS.HEALTH_STATUS).map(([key, def]) => ({
        label: (def as { shortLabel: string; color?: string }).shortLabel,
        value: key,
        color: (def as { shortLabel: string; color?: string }).color,
      })),
      width: 'w-40',
    },
    render: (value) => {
      // 健康状態の定義を取得
      const healthKey = typeof value === 'string' ? value : null;
      const healthDef = healthKey ? (CONSTANTS.HEALTH_STATUS as unknown as Record<string, { value: number; color?: string; label?: string; shortLabel: string }>)[healthKey] : null;

      if (!healthDef) {
        return (
          <Badge
            value={CONSTANTS.ANSWER_STATUS.アンケート未回答.shortLabel}
            styleVariant="solid"
            color="gray"
            size="small"
          />
        );
      }

      const displayLabel = healthDef.shortLabel || healthKey || '-';
      const displayColor = (healthDef.color || 'gray') as
        | 'blue'
        | 'green'
        | 'red'
        | 'yellow'
        | 'gray'
        | 'orange';

      return (
        <Badge
          value={displayLabel}
          styleVariant="solid"
          color={displayColor}
          size="small"
        />
      );
    },
  },
  {
    accessor: '面談日',
    label: '面談日',
    proportion: 9,
    visible: true,
    toggleable: true,
    filter: {
      type: 'dateRange',
      options: generateDateFilterOptions().map(opt => ({
        label: opt.label,
        value: opt.value,
      })),
      width: 'w-40',
    },
  },
  {
    accessor: '面談方式',
    label: '面談方式',
    proportion: 8,
    visible: true,
    toggleable: true,
    filter: {
      type: 'status',
      options: Object.entries(CONSTANTS.INTERVIEW_METHOD).map(([key, def]) => ({
        label: key,
        value: key,
        color: String((def as Record<string, unknown>).color ?? ''),
      })),
      width: 'w-40',
    },
    render: (value) => {
      if (!value || typeof value !== 'string') {
        return <span className="text-gray-400">-</span>;
      }
      const methodDef = (CONSTANTS.INTERVIEW_METHOD as unknown as Record<string, { value: number; key?: string; color?: string }>)[value];
      const displayColor = (methodDef?.color || 'gray') as
        | 'blue'
        | 'green'
        | 'red'
        | 'yellow'
        | 'gray'
        | 'orange';
      return (
        <Badge
          value={value}
          styleVariant="solid"
          color={displayColor}
          size="small"
        />
      );
    },
  },
  {
    accessor: '面談メモ',
    label: '面談メモ',
    proportion: 18,
    dataAlign: 'left' as const,
    dataFontSize: 'text-fluid-xs' as const,
    visible: false,
    toggleable: true,
    filter: {
      type: 'text',
      width: 'w-40',
    },
    render: (value) => {
      if (!value || typeof value !== 'string') {
        return <span className="text-gray-400">-</span>;
      }
      // 長いテキストは省略表示
      const maxLength = 30;
      const displayText = value.length > maxLength
        ? `${value.slice(0, maxLength)}...`
        : value;
      return <span title={value}>{displayText}</span>;
    },
  },
];

/**
 * フィルター設定（カラム定義から自動生成）
 */
export const FILTER_CONFIGS: FilterConfigWithMeta[] = ANSWER_TABLE_COLUMNS
  .filter((col): col is ColumnDefinition & { filter: FilterConfig } =>
    col.filter !== undefined
  )
  .map((col) => ({
    accessor: col.accessor,
    label: col.label,
    ...col.filter,
  }));

/**
 * フィルター初期値を生成
 */
export function getInitialFilterValues(): FilterValues {
  const initialValues: FilterValues = {};

  FILTER_CONFIGS.forEach((config) => {
    if (config.type === 'status') {
      initialValues[config.accessor] = [];
    } else if (config.type === 'score') {
      initialValues[config.accessor] = [config.min ?? 0, config.max ?? 5];
    } else if (config.type === 'text' || config.type === 'date' || config.type === 'dateRange') {
      initialValues[config.accessor] = '';
    }
  });

  return initialValues;
}
