/**
 * メンバーカードリストコンポーネント
 * メンバーをカード形式で一覧表示
 */
import { FC, ReactNode, memo, useCallback, useMemo } from 'react';

import { Checkbox } from '@ui-catalog/core/atoms';
import { CardGrid } from '@ui-catalog/core/organisms';
import { LoadingZone } from '@ui-catalog/core/organisms';
import { useThemeConfig } from '@/hooks';
import type { CardAnimationVariant } from '@/constants';

import AnswerCard from './AnswerCard';

import type { AnswerDisplayData } from './types';

interface AnswerCardListProps {
  /** 回答者データ配列 */
  data: AnswerDisplayData[];
  /** ローディング状態 */
  loading?: boolean;
  /** 選択された行インデックス */
  selectedRows: number[];
  /** 選択変更ハンドラ */
  onSelectionChange: (rows: number[]) => void;
  /** カードクリックハンドラ（詳細画面遷移） */
  onCardClick: (answerId: string, name: string) => void;
  /** アニメーション有効化 */
  enableAnimation?: boolean;
  /** アニメーションvariant */
  animationVariant?: CardAnimationVariant;
  /** ヘッダー拡張スロット（チェックボックスの横に表示） */
  headerExtra?: ReactNode;
}

/**
 * 回答者カードリストコンポーネント
 */
const AnswerCardList: FC<AnswerCardListProps> = memo(({
  data,
  loading = false,
  selectedRows,
  onSelectionChange,
  onCardClick,
  enableAnimation = true,
  animationVariant = 'slideRight',
  headerExtra,
}) => {
  const { colors } = useThemeConfig('AnswerCardList');
  // データのID構成が変わったらCardGridを再マウント（CSS animation状態をリセット）
  const gridKey = useMemo(() => {
    return data.map((d) => d.ユーザーID).join(',');
  }, [data]);

  // 全選択状態の計算
  const allSelected = useMemo(() => {
    return data.length > 0 && selectedRows.length === data.length;
  }, [data.length, selectedRows.length]);

  const someSelected = useMemo(() => {
    return selectedRows.length > 0 && selectedRows.length < data.length;
  }, [data.length, selectedRows.length]);

  // 全選択/解除ハンドラ
  const handleSelectAll = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      onSelectionChange(data.map((_, index) => index));
    } else {
      onSelectionChange([]);
    }
  }, [data, onSelectionChange]);

  // 個別選択ハンドラ
  const handleRowSelection = useCallback((index: number, selected: boolean) => {
    if (selected) {
      onSelectionChange([...selectedRows, index]);
    } else {
      onSelectionChange(selectedRows.filter((i) => i !== index));
    }
  }, [selectedRows, onSelectionChange]);

  // カードクリックハンドラ（詳細画面遷移）
  const handleCardClick = useCallback((answer: AnswerDisplayData) => {
    onCardClick(answer.ユーザーID, answer.名前?.text || answer.ユーザーID);
  }, [onCardClick]);

  if (loading) {
    return (
      <LoadingZone
        variant="card"
        height="16rem"
        message="データを読み込み中..."
        primaryBgColor={colors.primaryBgColor}
        accentTextColor={colors.accentTextColor}
        preset="cube-glow"
      />
    );
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">
        該当する回答者がいません
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* ヘッダー: 全選択チェックボックス + 件数表示スロット */}
      <div className="sticky top-0 z-10 bg-gray-50 px-4 py-2 border-b border-gray-200 flex items-center gap-3">
        <Checkbox
          checked={allSelected || someSelected}
          onChange={handleSelectAll}
        />
        {headerExtra}
      </div>

      {/* カードリスト */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-4">
        <CardGrid
          key={gridKey}
          animated={enableAnimation}
          enableAnimation={enableAnimation}
          animationVariant={animationVariant}
          cols={4}
          gap={4}
        >
          {data.map((answer, index) => (
            <CardGrid.Item key={answer.ユーザーID}>
              <AnswerCard
                data={answer}
                selected={selectedRows.includes(index)}
                onSelectionChange={(selected) => handleRowSelection(index, selected)}
                onClick={() => handleCardClick(answer)}
              />
            </CardGrid.Item>
          ))}
        </CardGrid>
      </div>
    </div>
  );
});

AnswerCardList.displayName = 'AnswerCardList';

export default AnswerCardList;
