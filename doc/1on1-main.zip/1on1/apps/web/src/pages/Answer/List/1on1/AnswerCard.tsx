/**
 * 回答者カードコンポーネント
 *
 * ui-catalog の MemberCard を使用し、
 * 1on1 固有のデータ変換ロジックをここで持つ
 */
import { FC, memo, useMemo } from 'react'

import {
  MemberCard,
  type MemberCardData,
  type StatusItem,
} from '@ui-catalog/core/molecules'

/** ステータス定義の型（MemberCard用） */
interface MemberStatusDefinition {
  shortLabel?: string
  color?: 'gray' | 'red' | 'orange' | 'yellow' | 'green' | 'blue' | 'purple'
}
import { CONSTANTS } from '@/constants/schemas'

import type { AnswerDisplayData } from './types'

interface AnswerCardProps {
  /** 回答者データ */
  data: AnswerDisplayData
  /** 選択状態 */
  selected: boolean
  /** 選択変更ハンドラ */
  onSelectionChange: (selected: boolean) => void
  /** カードクリックハンドラ（詳細画面遷移） */
  onClick: () => void
  /** カードの角丸 */
  cardRadius?: string
  /** セルの角丸 */
  cellRadius?: string
}

/**
 * CONSTANTS の定義を MemberCard 用に変換
 */
const convertStatusDef = (
  def: Record<string, { shortLabel?: string; color?: string }>
): Record<string, MemberStatusDefinition> => {
  const result: Record<string, MemberStatusDefinition> = {}
  for (const key in def) {
    result[key] = {
      shortLabel: def[key].shortLabel,
      color: (def[key].color || 'gray') as MemberStatusDefinition['color'],
    }
  }
  return result
}

/**
 * AnswerDisplayData を MemberCardData に変換
 */
const toMemberCardData = (data: AnswerDisplayData): MemberCardData => ({
  id: data.ユーザーID,
  name: data.名前?.text || data.ユーザーID,
  subtitle: data.部署 + (data.役職 ? ` / ${data.役職}` : ''),
  scores: [
    { label: '満足度', value: data.満足度 },
    { label: '業務負荷', value: data.業務負荷 },
    { label: '職場環境', value: data.職場環境 },
    { label: '人間関係', value: data.人間関係 },
    { label: 'ストレス', value: data.ストレス },
  ],
  statuses: [
    {
      label: '回答',
      value: data.回答状況,
      definitions: convertStatusDef(CONSTANTS.ANSWER_STATUS),
      defaultLabel: '未',
    },
    {
      label: '健康',
      value: data.健康状態,
      definitions: convertStatusDef(CONSTANTS.HEALTH_STATUS),
      defaultLabel: '不明',
    },
  ] as StatusItem[],
  dates: [
    { label: '回答日', value: data.回答日 },
    { label: '面談日', value: data.面談日 },
  ],
  badges: data.面談方式
    ? [{
        label: '面談方式',
        value: data.面談方式,
        color: (((CONSTANTS.INTERVIEW_METHOD as unknown as Record<string, Record<string, unknown>>)[data.面談方式]?.color as string) || 'gray') as 'blue' | 'green' | 'red' | 'yellow' | 'gray' | 'orange',
      }]
    : undefined,
  memo: data.面談メモ || undefined,
  isAlert: data.rowStyleType === 'red',
})

/**
 * 回答者カードコンポーネント
 */
const AnswerCard: FC<AnswerCardProps> = memo(({
  data,
  selected,
  onSelectionChange,
  onClick: _onClick,
  cardRadius = '0.5rem',
  cellRadius = '0.375rem',
}) => {
  const memberData = useMemo(() => toMemberCardData(data), [data])

  return (
    <MemberCard
      data={memberData}
      selected={selected}
      onSelectionChange={onSelectionChange}
      cardRadius={cardRadius}
      cellRadius={cellRadius}
    />
  )
})

AnswerCard.displayName = 'AnswerCard'

export default AnswerCard
