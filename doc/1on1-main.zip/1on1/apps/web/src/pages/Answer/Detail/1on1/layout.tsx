// src/pages/EmployeeDetail/Layout.tsx
/**
 * 回答詳細用レイアウトコンポーネント（プレゼンテーショナルコンポーネント）
 *
 * 【責任】
 * - UIコンポーネントの配置と構築
 * - セクション構成（メンバー情報、評価、トレンド、メモなど）
 *
 * 【受け取るもの】
 * - 生データ（answerData）
 * - 状態（memo, etc.）
 * - ハンドラー（onChange, onClick, etc.）
 */

import { Icon, TextArea } from '@ui-catalog/core/atoms';
import { Button, DatePicker, QACardList, Select, StarRating } from '@ui-catalog/core/molecules';
import type { HighlightedMonth } from '@ui-catalog/core/molecules';
import { ContentBlock, RadarChart, ToggleableSection, TrendChart } from '@ui-catalog/core/organisms';
import { APP_CONFIG } from '@/constants/app';
import { type IconName } from '@/constants';
import { useDevice } from '@ui-catalog/core/hooks';
import { useThemeConfig } from '@/hooks';
import { cn } from '@ui-catalog/core/utils';

import type { EmployeeDetailData, AnswerResult } from './types';

interface TrendChartData {
  datasets: Array<{
    label: string;
    data: (number | null)[];
    color?: string;
  }>;
  labels: string[];
}

interface EmployeeDetailLayoutProps {
  // データ
  answerData: EmployeeDetailData | null;
  loading: boolean;

  // 日付選択
  displayDate: string;
  onDateChange: (date: string) => void;

  // 面談メモ関連の状態
  memo: string;
  setMemo: (value: string) => void;
  interviewMethod: string;
  setInterviewMethod: (value: string) => void;

  // エラー状態
  memoError: boolean;
  setMemoError: (value: boolean) => void;
  interviewMethodError: boolean;
  setInterviewMethodError: (value: boolean) => void;

  // トレンドチャート
  trendChartPeriod: number;
  setTrendChartPeriod: (value: number) => void;
  getTrendChartData: () => TrendChartData | null;
  onMonthClick?: (month: string) => void;
  currentMonth?: string;

  // ハンドラー
  handleRecordInterview: () => void;
  recording: boolean;

  // アンケート振り返り
  surveyAnswers: Array<Record<string, unknown>>;
  aiComments: {
    userComment: string;
    supporterComment: string;
  };

  // ヘルパー関数
  getPreviousEvaluationData: () => AnswerResult | null;
  getChangeArrow: (current: number, previous: number | undefined) => IconName | '';

  // 派生データ
  isAnswered: boolean;
  isInterviewed: boolean;
  interviewInfo: {
    interviewer: string;
    interviewDate: string;
  };
  interviewMethodOptions: Array<{ value: string; label: string }>;

  /** 自分の回答かどうか（サポーターAI非表示・面談メモ非表示） */
  isOwnAnswer?: boolean;
  /** DatePickerハイライト月 */
  highlightedMonths?: HighlightedMonth[];
  /** 閲覧者確認ボタンクリックハンドラ */
  onViewerManagementClick?: () => void;
  /** 閲覧者確認ボタンを表示するか */
  showViewerManagement?: boolean;
}

export default function AnswerDetailLayout({
  answerData,
  loading,
  displayDate,
  onDateChange,
  memo,
  setMemo,
  interviewMethod,
  setInterviewMethod,
  memoError,
  setMemoError,
  interviewMethodError,
  setInterviewMethodError,
  trendChartPeriod,
  setTrendChartPeriod,
  getTrendChartData,
  onMonthClick,
  currentMonth,
  handleRecordInterview,
  recording,
  surveyAnswers,
  aiComments,
  getPreviousEvaluationData,
  getChangeArrow,
  isAnswered,
  isInterviewed,
  interviewInfo,
  interviewMethodOptions,
  isOwnAnswer = false,
  highlightedMonths,
  onViewerManagementClick,
  showViewerManagement = false,
}: EmployeeDetailLayoutProps) {
  const { colors, shapes } = useThemeConfig('AnswerDetail');
  const { isMobile } = useDevice();

  // 評価項目の表示コンポーネント
  const EvaluationItem = ({
    label,
    current,
    previous,
  }: {
    label: string;
    current: number;
    previous?: number;
  }) => (
    <div className="flex items-center justify-between border-b border-gray-100 py-3 last:border-b-0">
      <div className="flex flex-1 items-center gap-4">
        <span className="min-w-[80px] shrink-0 font-medium text-gray-700">{label}</span>
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <div className="flex items-center gap-2">
            <StarRating rating={current} size={20} showValue={false} />
            <span className="font-medium text-gray-800">
              ({current.toFixed(1)})
            </span>
          </div>
          {previous !== undefined && (() => {
            const diff = current - previous;
            const absDiff = Math.abs(diff);
            const iconName = getChangeArrow(current, previous);

            // アイコンの色を決定
            let iconColor = 'gray';
            if (absDiff >= 1) {
              iconColor = diff > 0 ? 'green' : 'red';
            } else if (absDiff > 0) {
              iconColor = diff > 0 ? 'green' : 'red';
            }

            return (
              <div className="flex items-center gap-2">
                {iconName && (
                  <Icon
                    name={iconName}
                    size={18}
                    stroke={iconColor}
                    strokeWidth={2.5}
                  />
                )}
                <span className="text-fluid-sm text-gray-500">
                  (前回: {previous.toFixed(1)})
                </span>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );

  // 最新評価コンテンツ
  const latestEvaluationContent = (
    <ContentBlock
      variant="section"
      title={
        answerData?.latestEvaluation?.date
          ? `最新評価 (${answerData.latestEvaluation.date})`
          : '最新評価'
      }
      loading={loading}
      loadingPreset="triangle"
      loadingSize={40}
      loadingMessage="最新評価を読み込み中..."
      loadingHeight="100px"
    >
      {isAnswered && answerData?.latestEvaluation?.scores ? (
        (() => {
          const previousData = getPreviousEvaluationData();
          const previousScores = previousData?.評価結果;
          const scores = answerData.latestEvaluation.scores;

          // レーダーチャート用データ
          const radarData = [
            { label: '満足度', value: scores.jobSatisfaction?.current || 0 },
            { label: '業務負荷', value: scores.workload?.current || 0 },
            { label: '職場環境', value: scores.workEnvironment?.current || 0 },
            { label: '人間関係', value: scores.relationships?.current || 0 },
            { label: 'ストレス', value: scores.stress?.current || 0 },
          ];

          return (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {/* 左側: 評価項目リスト */}
              <div className="space-y-0">
                <EvaluationItem
                  label="満足度"
                  current={scores.jobSatisfaction?.current || 0}
                  previous={previousScores?.満足度 ?? undefined}
                />
                <EvaluationItem
                  label="業務負荷"
                  current={scores.workload?.current || 0}
                  previous={previousScores?.業務負荷 ?? undefined}
                />
                <EvaluationItem
                  label="職場環境"
                  current={scores.workEnvironment?.current || 0}
                  previous={previousScores?.職場環境 ?? undefined}
                />
                <EvaluationItem
                  label="人間関係"
                  current={scores.relationships?.current || 0}
                  previous={previousScores?.人間関係 ?? undefined}
                />
                <EvaluationItem
                  label="ストレス"
                  current={scores.stress?.current || 0}
                  previous={previousScores?.ストレス ?? undefined}
                />
                <EvaluationItem
                  label="平均"
                  current={(() => {
                    const allScores = [
                      scores.jobSatisfaction?.current || 0,
                      scores.workload?.current || 0,
                      scores.workEnvironment?.current || 0,
                      scores.relationships?.current || 0,
                      scores.stress?.current || 0,
                    ];
                    const validScores = allScores.filter((s) => s > 0);
                    return validScores.length > 0
                      ? validScores.reduce((a, b) => a + b, 0) / validScores.length
                      : 0;
                  })()}
                  previous={(() => {
                    if (!previousScores) return undefined;
                    const allScores = [
                      previousScores.満足度 || 0,
                      previousScores.業務負荷 || 0,
                      previousScores.職場環境 || 0,
                      previousScores.人間関係 || 0,
                      previousScores.ストレス || 0,
                    ];
                    const validScores = allScores.filter((s) => s > 0);
                    return validScores.length > 0
                      ? validScores.reduce((a, b) => a + b, 0) / validScores.length
                      : undefined;
                  })()}
                />
              </div>
              {/* 右側: レーダーチャート */}
              <div className="flex items-center justify-center">
                <RadarChart
                  data={radarData}
                  maxValue={5}
                  size={280}
                  strokeColor="#10b981"
                  fillColor="#10b981"
                  fillOpacity={0.2}
                />
              </div>
            </div>
          );
        })()
      ) : (
        <p className="text-center text-gray-500">該当期間の回答がありません</p>
      )}
      {answerData?.latestEvaluation?.comment && (
        <div className="mt-6">
          <h4 className="mb-2 font-semibold">コメント</h4>
          <p className="text-gray-700">
            {answerData.latestEvaluation.comment}
          </p>
        </div>
      )}
    </ContentBlock>
  );

  // トレンドチャートコンテンツ
  const trendChartContent = (
    <ContentBlock
      variant="section"
      title="評価推移"
      loading={loading}
      loadingPreset="heartbeat"
      loadingSize={40}
      loadingMessage="推移データを読み込み中..."
      loadingHeight="100px"
    >
      <div className="mb-4">
        <Select
          label="表示期間："
          options={isMobile
            ? [
                { value: '3', label: '過去3ヶ月' },
                { value: '6', label: '過去6ヶ月' },
              ]
            : [
                { value: '3', label: '過去3ヶ月' },
                { value: '6', label: '過去6ヶ月' },
                { value: '12', label: '過去12ヶ月' },
                { value: '0', label: '全期間' },
              ]
          }
          value={String(trendChartPeriod)}
          onChange={(value) => setTrendChartPeriod(Number(value ?? 3))}
          width="w-36"
          allowEmpty={false}
        />
      </div>
      {(() => {
        const trendData = getTrendChartData();
        return trendData ? (
          <TrendChart
            data={trendData}
            height={300}
            onMonthClick={onMonthClick}
            currentMonth={currentMonth}
            showTooltip={false}
          />
        ) : (
          <p className="text-center text-gray-500">該当期間の回答がありません</p>
        );
      })()}
    </ContentBlock>
  );

  // アンケート振り返りコンテンツ（3カラム: QA | ユーザーAI | サポーターAI）
  const surveyReviewContent = (() => {
    if (!isAnswered) {
      return <p className="text-center text-gray-500">該当期間の回答がありません</p>;
    }

    // 自分の回答: サポーターAI非表示、ユーザーAIがあれば50:50
    // 他人の回答: 両方あれば33:33:33
    const showSupporterAi = !isOwnAnswer && !!aiComments.supporterComment;
    const hasUserAi = !!aiComments.userComment;
    const hasAnyVisibleAi = hasUserAi || showSupporterAi;

    // カラム幅の決定（レスポンシブ対応: スマホは縦並び、PCは横並び）
    const qaWidth = !hasAnyVisibleAi ? 'w-full' : (showSupporterAi ? 'w-full lg:w-1/3' : 'w-full lg:w-1/2');
    const aiWidth = showSupporterAi ? 'w-full lg:w-1/3' : 'w-full lg:w-1/2';

    return (
      <div className={hasAnyVisibleAi ? 'flex flex-col gap-4 lg:flex-row' : ''}>
        {/* Q&Aリスト */}
        <div className={`${qaWidth} min-w-0`}>
          <QACardList
            items={surveyAnswers.map((item) => ({
              question: String(item.question || item.タイトル || ''),
              answer: String(item.answer || item.回答内容 || ''),
            }))}
            variant="green"
          />
        </div>
        {/* ユーザー用AIコメント */}
        {hasUserAi && (
          <div className={`${aiWidth} min-w-0`}>
            <div className="sticky top-4 rounded-xl bg-gradient-to-r from-purple-50 to-indigo-50 p-4 shadow-sm border border-purple-200">
              <div className="flex items-center gap-2 mb-3">
                <Icon name={'diamond'} size={20} stroke="purple" hover="auto" />
                <span className="font-semibold text-purple-700">AIからのコメント</span>
              </div>
              <div className="bg-white rounded-lg p-3 border border-purple-100">
                <p className="text-gray-700 whitespace-pre-wrap">{aiComments.userComment}</p>
              </div>
            </div>
          </div>
        )}
        {/* サポーター用AIコメント（自分の回答では非表示） */}
        {showSupporterAi && (
          <div className="w-full lg:w-1/3 min-w-0">
            <div className="sticky top-4 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50 p-4 shadow-sm border border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Icon name={'diamond'} size={20} stroke="blue" hover="auto" />
                <span className="font-semibold text-blue-700">サポーターへのコメント</span>
              </div>
              <div className="bg-white rounded-lg p-3 border border-blue-100">
                <p className="text-gray-700 whitespace-pre-wrap">{aiComments.supporterComment}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  })();

  // 面談メモコンテンツ
  const interviewMemoContent = (
    <ContentBlock
      variant="section"
      loading={loading}
      loadingPreset="interview"
      loadingSize={40}
      loadingMessage="面談メモを読み込み中..."
      loadingHeight="100px"
    >
      {isAnswered ? (
        <div className="space-y-4">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:gap-6">
            <div className="flex items-center">
              <span className="w-20 shrink-0 text-fluid-sm font-medium text-gray-700 sm:w-auto sm:mr-2">
                面談方式：
              </span>
              {isInterviewed || isOwnAnswer ? (
                <span className="border-b-2 border-gray-300 py-1 text-center text-gray-700">
                  {interviewMethodOptions.find(opt => opt.value === interviewMethod)?.label || interviewMethod || '-'}
                </span>
              ) : (
                <div className={cn(interviewMethodError && 'rounded-md ring-2 ring-red-500')}>
                  <Select
                    id="interview-method"
                    options={interviewMethodOptions}
                    value={interviewMethod}
                    onChange={(value) => {
                      setInterviewMethod(value ?? '');
                      setInterviewMethodError(false);
                    }}
                    placeholder="面談方式を選択"
                    disabled={loading}
                    width="w-50"
                    allowEmpty={false}
                  />
                </div>
              )}
            </div>
            <div className="flex flex-col gap-3 sm:ml-auto sm:flex-row sm:items-center sm:gap-6">
              {interviewInfo.interviewDate && (
                <div className="flex items-center">
                  <span className="w-20 shrink-0 text-fluid-sm font-medium text-gray-700 sm:w-auto sm:mr-2">
                    面談日：
                  </span>
                  <span className="border-b-2 border-gray-300 py-1 text-center text-gray-700">
                    {interviewInfo.interviewDate}
                  </span>
                </div>
              )}
              {interviewInfo.interviewer && (
                <div className="flex items-center">
                  <span className="w-20 shrink-0 text-fluid-sm font-medium text-gray-700 sm:w-auto sm:mr-2">
                    面談者：
                  </span>
                  <span className="border-b-2 border-gray-300 py-1 text-center text-gray-700">
                    {interviewInfo.interviewer}
                  </span>
                </div>
              )}
            </div>
          </div>
          <div>
            <TextArea
              id="interview-memo"
              value={memo}
              onChange={(e) => {
                setMemo(e.target.value);
                setMemoError(false);
              }}
              rows={4}
              error={memoError}
              placeholder="面談の内容やメモを入力してください..."
              disabled={loading || isInterviewed || isOwnAnswer}
            />
          </div>
          {!isOwnAnswer && (
            <div className="flex justify-between items-center gap-3">
              {showViewerManagement && (
                <Button
                  variant="secondary"
                  size="small"
                  onClick={onViewerManagementClick}
                >
                  <Icon name={'users-group'} size={16} className="mr-1" hover="auto" />
                  閲覧者確認
                </Button>
              )}
              <div className="flex-1" />
              <Button
                variant="primary"
                size="small"
                onClick={handleRecordInterview}
                disabled={loading || recording || isInterviewed}
              >
                {recording ? '記録中...' : '面談を記録'}
              </Button>
            </div>
          )}
        </div>
      ) : (
        <p className="text-center text-gray-500">該当期間の回答がありません</p>
      )}
    </ContentBlock>
  );

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2">
        <DatePicker
          pickerMode="month"
          variant="default"
          size="small"
          navigationMode="month"
          value={displayDate}
          onChange={onDateChange}
          recentMonths={APP_CONFIG.RECENT_MONTHS}
          highlightedMonths={highlightedMonths}
        />
      </div>

      {/* 自分自身の回答の場合は面談記録セクションを非表示 */}
      {!isOwnAnswer && (
        <ToggleableSection
          title="面談記録"
          borderColor={colors.accentBorderColor}
          defaultOpen={true}
          cardRadius={shapes.cardRadius}
          marginClassName="mb-2 sm:mb-4"
        >
          {interviewMemoContent}
        </ToggleableSection>
      )}

      <ToggleableSection
        title="ヒアリング結果と推移"
        borderColor={colors.accentBorderColor}
        defaultOpen={true}
        cardRadius={shapes.cardRadius}
        marginClassName="mb-2 sm:mb-4"
      >
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {latestEvaluationContent}
          {trendChartContent}
        </div>
      </ToggleableSection>

      <ToggleableSection
        title="アンケート振り返り"
        borderColor={colors.accentBorderColor}
        defaultOpen={true}
        cardRadius={shapes.cardRadius}
        marginClassName="mb-2 sm:mb-4"
      >
        <ContentBlock
          variant="section"
          loading={loading}
          loadingMessage="アンケート振り返りを読み込み中..."
          loadingHeight="100px"
        >
          {surveyReviewContent}
        </ContentBlock>
      </ToggleableSection>

    </>
  );
}
