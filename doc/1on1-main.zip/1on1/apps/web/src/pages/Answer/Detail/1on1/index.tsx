/**
 * 回答詳細ページ（複数タブ対応版）
 * 複数のメンバーをタブ形式で同時に表示
 */
import { useEffect, useState, useCallback, useMemo } from 'react';

import { useAtom, useAtomValue, useSetAtom } from 'jotai';

import { Icon } from '@ui-catalog/core/atoms';
import { BackButton, TabBar } from '@ui-catalog/core/molecules';
import { AlertDialog, ConfirmDialog, Toast, FixedTabBar, LoadingOverlay } from '@ui-catalog/core/organisms';
import AppLayout from '@1on1/layouts/templates/AppLayout';

import { getBreadcrumbs, ROUTES } from '@/constants/routes';
import { CONSTANTS } from '@/constants/schemas';
import type { HighlightedMonth } from '@ui-catalog/core/molecules';
import { useNavigate } from '@/adapters/RouterContext';
import { useAlert, useConfirm, useToast } from '@ui-catalog/core/hooks/ui';
import { useUserInfo } from '@/hooks';
import { useMutation, useQueryClient, useQueries, useQuery } from '@tanstack/react-query';
import { apiGet, apiPost } from '@/lib/api';
import { Button } from '@ui-catalog/core/molecules';
import {
  displayDateAtom,
  openedAnswerTabsAtom,
  activeAnswerIdAtom,
  closeAnswerTabAtom,
  leftPaneOpenAtom,
  answerDetailStateFamily,
  incrementRefreshKeyAtom,
  clearValidationErrorsAtom,
  trendChartPeriodAtom,
} from '@/state';
import { toStatusCode } from '@1on1/domain/utils';
import { getAnswerStatusLabel } from '@/utils/status';
import { formatDate, formatDateForComparison } from '@1on1/domain/utils/date';
import { findAnswerByDisplayDate } from '@/utils/date/filter';

import { useAnswerDetailTanStack } from './hooks.tanstack';
import AnswerDetailLayout from './layout';
import ViewerManagementModal from './ViewerManagementModal';
import type { EmployeeDetailResponse } from './types';

/**
 * 回答詳細ページ（複数タブ対応版）
 */
export default function AnswerDetails() {
  const [displayDate, setDisplayDate] = useAtom(displayDateAtom);
  const openedTabs = useAtomValue(openedAnswerTabsAtom);
  const [activeAnswerId, setActiveAnswerId] = useAtom(activeAnswerIdAtom);
  const closeTab = useSetAtom(closeAnswerTabAtom);
  const isLeftPaneOpen = useAtomValue(leftPaneOpenAtom);
  const navigate = useNavigate();
  const handleBack = useCallback(() => navigate('/answers'), [navigate]);
  const { toastState, showToast, closeToast } = useToast();

  // CSV出力確認ダイアログの状態
  const [csvConfirmDialog, setCsvConfirmDialog] = useState<{
    isOpen: boolean;
    message: string;
  }>({ isOpen: false, message: '' });

  // ページタイトルを設定
  useEffect(() => {
    document.title = '回答詳細';
  }, []);

  // displayDateが空（AnswerListでXクリアされた場合）なら今月を自動セット
  useEffect(() => {
    if (!displayDate) {
      const now = new Date();
      const fallback = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      setDisplayDate(fallback);
    }
  }, [displayDate, setDisplayDate]);

  // 日付変更ハンドラー
  const handleDateChange = useCallback(
    (newDate: string) => {
      setDisplayDate(newDate);
    },
    [setDisplayDate]
  );

  // タブ選択ハンドラー
  const handleSelectTab = useCallback((answerId: string) => {
    setActiveAnswerId(answerId);
  }, [setActiveAnswerId]);

  // タブを閉じるハンドラー
  const handleCloseTab = useCallback((answerId: string) => {
    closeTab(answerId);
  }, [closeTab]);

  // アクティブなタブの情報
  const activeTab = useMemo(
    () => openedTabs.find((tab) => tab.answerId === activeAnswerId),
    [openedTabs, activeAnswerId]
  );

  // TabBar用のタブデータに変換
  const tabItems = useMemo(() => {
    return openedTabs.map((tab) => ({
      id: tab.answerId,
      label: tab.name || tab.answerId,
    }));
  }, [openedTabs]);

  // タブバーコンテンツ
  const tabBarContent = useMemo(() => {
    if (openedTabs.length === 0) return null;
    return (
      <FixedTabBar isLeftPaneOpen={isLeftPaneOpen}>
        <TabBar
          tabs={tabItems}
          activeTabId={activeAnswerId}
          onSelectTab={handleSelectTab}
          onCloseTab={handleCloseTab}
        />
      </FixedTabBar>
    );
  }, [openedTabs, tabItems, activeAnswerId, handleSelectTab, handleCloseTab, isLeftPaneOpen]);

  // 全タブのデータを取得（CSV出力用）
  const allTabsDataQueries = useQueries({
    queries: openedTabs.map((tab) => ({
      queryKey: ['answers', 'detail', tab.answerId],
      queryFn: () => apiGet<EmployeeDetailResponse>(`/answers/${tab.answerId}`),
      enabled: openedTabs.length > 0,
      staleTime: 5 * 60 * 1000,
    })),
  });

  // CSV出力確認ダイアログを表示
  const handleCsvExportClick = useCallback(() => {
    if (openedTabs.length === 0) return;

    const message = `${openedTabs.length}件のデータをCSV出力します。よろしいですか？`;
    setCsvConfirmDialog({ isOpen: true, message });
  }, [openedTabs.length]);

  // CSV出力確認ダイアログのキャンセル
  const handleCsvConfirmCancel = useCallback(() => {
    setCsvConfirmDialog({ isOpen: false, message: '' });
  }, []);

  // CSV出力実行
  const executeCsvExport = useCallback(() => {
    setCsvConfirmDialog({ isOpen: false, message: '' });
    if (openedTabs.length === 0) return;

    // ヘッダー定義
    const headers = [
      '名前',
      '社員番号',
      '部署',
      '役職',
      'サポーター',
      'トレーナー',
      '対象月',
      '回答状況',
      '健康状態',
      '満足度',
      '業務負荷',
      '職場環境',
      '人間関係',
      'ストレス',
      '面談者',
      '面談日',
      '面談方式',
      'コメント',
      '面談メモ',
      '次回アクション',
    ];

    // データ行を作成
    const rows: string[][] = [];

    openedTabs.forEach((tab, index) => {
      const queryResult = allTabsDataQueries[index];
      const rawData = queryResult?.data;

      if (!rawData) return;

      // displayDateに対応する回答を取得
      const answerResult = findAnswerByDisplayDate(rawData.回答結果 || [], displayDate);

      const row = [
        rawData.名前 || '',
        rawData.ユーザーコード || '',
        rawData.部署 || [rawData.所属本部, rawData.所属部, rawData.所属課].filter(Boolean).join(' / ') || '',
        rawData.役職 || '',
        rawData.サポーター || '',
        rawData.トレーナー || '',
        displayDate,
        answerResult ? getAnswerStatusLabel(toStatusCode(answerResult['回答状況'])) : '',
        answerResult?.['健康状態'] ? String(typeof answerResult['健康状態'] === 'object' ? (answerResult['健康状態'] as Record<string, unknown>).Value || '' : answerResult['健康状態']) : '',
        String(answerResult?.評価結果?.満足度 || ''),
        String(answerResult?.評価結果?.業務負荷 || ''),
        String(answerResult?.評価結果?.職場環境 || ''),
        String(answerResult?.評価結果?.人間関係 || ''),
        String(answerResult?.評価結果?.ストレス || ''),
        String(answerResult?.['面談者'] || ''),
        formatDate(answerResult?.['面談日'] as string | null | undefined) || '',
        String(answerResult?.['面談方式'] || ''),
        String(answerResult?.コメント || ''),
        String(answerResult?.['面談メモ'] || ''),
        String(answerResult?.['次回までのアクション'] || ''),
      ];

      // エスケープ処理
      const escapedRow = row.map((value) => {
        if (value.includes(',') || value.includes('\n') || value.includes('"')) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      });

      rows.push(escapedRow);
    });

    if (rows.length === 0) {
      showToast('エクスポートするデータがありません', { type: 'warning' });
      return;
    }

    // CSVテキストを生成
    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');

    // BOM付きUTF-8でBlobを作成（Excelでの文字化け対策）
    const bom = new Uint8Array([0xef, 0xbb, 0xbf]);
    const blob = new Blob([bom, csvContent], { type: 'text/csv;charset=utf-8' });

    // ダウンロード
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `回答詳細_${displayDate.replace(/-/g, '')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast('CSVをダウンロードしました', { type: 'success' });
  }, [openedTabs, allTabsDataQueries, displayDate, showToast]);

  // フッターボタンコンテンツ
  const footerButtonsContent = (
    <div className="flex justify-center gap-2">
      <BackButton onClick={handleBack} />
      {openedTabs.length > 0 && (
        <Button
          type="button"
          variant="default"
          size="small"
          leftIcon={'file'}
          onClick={handleCsvExportClick}
        >
          CSV出力 ({openedTabs.length})
        </Button>
      )}
    </div>
  );

  // パンくずリストの生成
  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.ANSWER_DETAIL.path), []);

  // メインコンテンツ
  const mainContent = useMemo(() => {
    if (openedTabs.length === 0) {
      return (
        <div className="flex h-64 flex-col items-center justify-center text-gray-500">
          <Icon
            name="users-group"
            size={64}
            stroke="currentColor"
            strokeWidth={1.5}
            className="mb-4"
          />
          <p className="text-fluid-lg font-medium">メンバーが選択されていません</p>
          <p className="mt-1 text-fluid-sm">回答一覧からメンバーを選択してください</p>
        </div>
      );
    }

    if (!activeTab) {
      return null;
    }

    return (
      <AnswerDetailPanel
        key={activeTab.answerId}
        answerId={activeTab.answerId}
        displayDate={displayDate}
        onDateChange={handleDateChange}
      />
    );
  }, [openedTabs, activeTab, displayDate, handleDateChange]);

  return (
    <>
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={openedTabs.length > 0}
        subHeaderContent={tabBarContent}
        footerContent={footerButtonsContent}
        mainContent={mainContent}
      />
      <Toast {...toastState} onClose={closeToast} />
      <ConfirmDialog
        isOpen={csvConfirmDialog.isOpen}
        title="CSV出力"
        message={csvConfirmDialog.message}
        confirmText="出力"
        cancelText="キャンセル"
        onConfirm={executeCsvExport}
        onCancel={handleCsvConfirmCancel}
      />
    </>
  );
}

/**
 * 回答詳細パネル（個別メンバー）
 */
function AnswerDetailPanel({
  answerId,
  displayDate,
  onDateChange,
  globalLoading = false,
}: {
  answerId: string;
  displayDate: string;
  onDateChange: (date: string) => void;
  globalLoading?: boolean;
}) {
  const queryClient = useQueryClient();
  const { userId, userName } = useUserInfo();
  const { alertState, showAlert, closeAlert } = useAlert();
  const { confirmState, showConfirm, handleConfirm, handleCancel } = useConfirm();
  const { toastState, showToast, closeToast } = useToast();

  // atomFamily からメンバー固有の状態を取得
  const [answerState, setAnswerState] = useAtom(answerDetailStateFamily(answerId));
  const incrementRefreshKey = useSetAtom(incrementRefreshKeyAtom);
  const clearValidationErrors = useSetAtom(clearValidationErrorsAtom);

  // トレンドチャート表示期間（グローバル設定）
  const [trendChartPeriod, setTrendChartPeriod] = useAtom(trendChartPeriodAtom);

  // トレンドチャートの範囲の終点
  const [trendChartEndDate, setTrendChartEndDate] = useState(displayDate);

  // DatePicker変更時のハンドラ
  const handleDateChange = useCallback(
    (newDate: string) => {
      onDateChange(newDate);
      setTrendChartEndDate(newDate);
    },
    [onDateChange]
  );

  // データ取得（TanStack Query版）
  const { data: answerData, loading } = useAnswerDetailTanStack(
    answerId,
    displayDate,
    answerState.refreshKey
  );

  // 閲覧者管理モーダルの状態
  const [viewerModalOpen, setViewerModalOpen] = useState(false);

  // 配下一覧取得
  const { data: subordinatesData } = useQuery({
    queryKey: ['subordinates'],
    queryFn: () => apiGet<{ data: Array<{ ユーザーID: string; 名前: string; 役職: string | null; 部署: string | null }> }>('/users/subordinates'),
    staleTime: 5 * 60 * 1000, // 5分
  });

  // 現在の閲覧者（面談候補）のユーザーID配列
  const currentViewerIds = useMemo(() => {
    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );
    if (!currentAnswerResult?.面談候補) return [];
    try {
      const parsed = JSON.parse(currentAnswerResult.面談候補);
      return Array.isArray(parsed) ? parsed.map(String) : [];
    } catch {
      return [];
    }
  }, [answerData, displayDate]);

  // 配下一覧（ViewerManagementModal用）
  const subordinates = useMemo(() => {
    return (subordinatesData?.data || []).map(s => ({
      ...s,
      isSubordinate: true,
    }));
  }, [subordinatesData]);

  // 現在の回答ID（displayDateに対応する回答）
  const currentAnswerId = useMemo(() => {
    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );
    return currentAnswerResult?.回答ID ? String(currentAnswerResult.回答ID) : null;
  }, [answerData, displayDate]);

  // 閲覧者管理モーダルを開く
  const handleViewerManagementClick = useCallback(() => {
    setViewerModalOpen(true);
  }, []);

  // 閲覧者変更成功時
  const handleViewerChangeSuccess = useCallback(() => {
    // データを再取得
    incrementRefreshKey(answerId);
    queryClient.invalidateQueries({ queryKey: ['answers'] });
  }, [answerId, incrementRefreshKey, queryClient]);

  // 面談記録用ミューテーション
  const submitInterviewMutation = useMutation({
    mutationFn: (data: {
      answerId: string;
      interviewMemo: string;
      nextAction: string;
      interviewMethod: string;
    }) => {
      const { answerId: id, ...body } = data;
      return apiPost<{ success: boolean }>(`/surveys/${id}/interview`, body);
    },
  });

  // 面談メモの初期化
  useEffect(() => {
    if (!answerData) return;

    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );

    setAnswerState((prev) => ({
      ...prev,
      memo: answerData.interviewMemo?.content || '',
      interviewMethod: currentAnswerResult?.['面談方式'] || '',
    }));
  }, [answerData, displayDate, setAnswerState]);

  // 面談記録処理（確認ダイアログ経由）
  const handleRecordInterview = () => {
    // バリデーション
    let hasError = false;

    if (!answerState.interviewMethod) {
      setAnswerState((prev) => ({ ...prev, interviewMethodError: true }));
      hasError = true;
    }

    if (!answerState.memo.trim()) {
      setAnswerState((prev) => ({ ...prev, memoError: true }));
      hasError = true;
    }

    if (hasError) {
      showAlert('面談方式、面談メモを入力してください。', {
        title: '入力エラー',
        type: 'warning',
      });
      return;
    }

    // 確認ダイアログを表示
    showConfirm('面談を記録してもよろしいですか？', {
      title: '面談記録の確認',
      type: 'info',
      confirmText: '記録する',
      cancelText: 'キャンセル',
      onConfirm: async () => {
        try {
          setAnswerState((prev) => ({ ...prev, recording: true }));

          if (!userId) {
            throw new Error('認証情報が取得できません');
          }

          const currentAnswerResult = findAnswerByDisplayDate(
            answerData?.answerHistory || [],
            displayDate
          );

          if (!currentAnswerResult) {
            throw new Error('該当する回答データが見つかりません');
          }

          const surveyAnswerId = currentAnswerResult['回答ID'];

          await submitInterviewMutation.mutateAsync({
            answerId: String(surveyAnswerId),
            interviewMemo: answerState.memo,
            nextAction: '',
            interviewMethod: answerState.interviewMethod,
          });

          // データ再取得（詳細 + 一覧キャッシュ無効化）
          incrementRefreshKey(answerId);
          queryClient.invalidateQueries({ queryKey: ['answers'] });
          clearValidationErrors(answerId);

          showToast('面談が記録されました', { type: 'success' });
        } catch (err) {
          console.error('面談記録エラー:', err);
          showAlert('面談の記録に失敗しました。', {
            title: 'エラー',
            type: 'error',
          });
        } finally {
          setAnswerState((prev) => ({ ...prev, recording: false }));
        }
      },
    });
  };

  // トレンドチャートデータの準備
  const getTrendChartData = useCallback(() => {
    if (!answerData?.answerHistory) return null;

    const answerHistory = answerData.answerHistory;
    const trendResults: Array<{
      month: string;
      scores: Record<string, unknown>;
    }> = [];

    if (trendChartPeriod === 0) {
      answerHistory.forEach((answerResult: Record<string, unknown>) => {
        if (answerResult['開始']) {
          const targetDisplayDate = formatDateForComparison(String(answerResult['開始']));
          trendResults.push({
            month: targetDisplayDate,
            scores: (answerResult['評価結果'] || {}) as Record<string, unknown>,
          });
        }
      });
      trendResults.sort((a, b) => a.month.localeCompare(b.month));
    } else {
      const endDate = new Date(trendChartEndDate + '-01');
      for (let i = trendChartPeriod - 1; i >= 0; i--) {
        const targetDate = new Date(endDate);
        targetDate.setMonth(targetDate.getMonth() - i);
        const targetDisplayDate = targetDate.toISOString().substring(0, 7);
        const answerResult = findAnswerByDisplayDate(answerHistory, targetDisplayDate);
        if (answerResult) {
          trendResults.push({
            month: targetDisplayDate,
            scores: (answerResult.評価結果 || {}) as Record<string, unknown>,
          });
        }
      }
    }

    const assessmentKeys = Object.keys(CONSTANTS.ASSESSMENT_ITEM).sort(
      (a, b) =>
        (CONSTANTS.ASSESSMENT_ITEM[a]?.order || 0) -
        (CONSTANTS.ASSESSMENT_ITEM[b]?.order || 0)
    );

    return {
      datasets: [
        ...assessmentKeys.map((name) => {
          const item = CONSTANTS.ASSESSMENT_ITEM[name];
          return {
            label: item.label,
            data: trendResults.map((result) => {
              const value = Number(result.scores[name]);
              return isNaN(value) || value === 0 ? null : value;
            }),
            color: item.borderColor,
          };
        }),
        {
          label: '平均',
          data: trendResults.map((result) => {
            const scores = assessmentKeys.map((key) => Number(result.scores[key]) || 0);
            const validScores = scores.filter((s) => s > 0);
            return validScores.length > 0
              ? validScores.reduce((a, b) => a + b, 0) / validScores.length
              : null;
          }),
          color: '#6B7280',
        },
      ],
      labels: trendResults.map((result) => {
        const date = new Date(result.month + '-01');
        return `${date.getFullYear()}/${date.getMonth() + 1}`;
      }),
    };
  }, [answerData, trendChartPeriod, trendChartEndDate]);

  // ステータス取得
  const getEmployeeDetailStatus = useCallback(() => {
    if (!answerData) {
      return {
        answerStatus: '読み込み中...',
        healthStatus: '不明',
        hasData: false,
      };
    }

    const currentAnswerResult = findAnswerByDisplayDate(
      answerData.answerHistory || [],
      displayDate
    );

    if (!currentAnswerResult) {
      return {
        answerStatus: '該当期間データなし',
        healthStatus: '不明',
        hasData: false,
      };
    }

    return {
      answerStatus: getAnswerStatusLabel(toStatusCode(currentAnswerResult['回答状況'])),
      healthStatus: currentAnswerResult['健康状態'],
      hasData: true,
    };
  }, [answerData, displayDate]);

  const status = getEmployeeDetailStatus();
  const isAnswered = status.answerStatus === 'アンケート回答済';
  const isInterviewed = status.answerStatus === '完了';

  // 前回データとの比較
  const getPreviousEvaluationData = useCallback(() => {
    if (!answerData?.answerHistory || answerData.answerHistory.length < 2) {
      return null;
    }

    const currentDate = new Date(displayDate + '-01');
    const previousDate = new Date(currentDate);
    previousDate.setMonth(previousDate.getMonth() - 1);
    const previousDisplayDate = previousDate.toISOString().substring(0, 7);

    return findAnswerByDisplayDate(answerData.answerHistory, previousDisplayDate);
  }, [answerData, displayDate]);

  // 変化矢印（アイコン名を返す）
  const getChangeArrow = useCallback((current: number, previous: number | undefined) => {
    if (!previous) return '';

    const diff = current - previous;
    const absDiff = Math.abs(diff);

    // 1より大きい変化
    if (absDiff > 1) {
      if (diff > 0) return 'trend-up'; // ↑
      if (diff < 0) return 'trend-down'; // ↓
    }

    // 1以下の変化
    if (absDiff > 0) {
      if (diff > 0) return 'trend-up-right'; // ↗
      if (diff < 0) return 'trend-down-right'; // ↘
    }

    // 変化なし
    return 'trend-right'; // →
  }, []);

  // 面談方式の選択肢
  const interviewMethodOptions = useMemo(
    () =>
      Object.keys(CONSTANTS.INTERVIEW_METHOD || {}).map((key) => ({
        value: key,
        label: key,
      })),
    []
  );

  // 現在の面談情報
  const interviewInfo = useMemo(() => {
    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );
    return {
      interviewer: String(currentAnswerResult?.['面談者'] || ''),
      interviewDate: formatDate(currentAnswerResult?.['面談日'] as string | null | undefined) || '',
      interviewMethod: String(currentAnswerResult?.['面談方式'] || ''),
    };
  }, [answerData, displayDate]);

  // 回答内容（アンケート内容JSONをパース）
  const surveyAnswers = useMemo(() => {
    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );
    const jsonStr = currentAnswerResult?.['アンケート内容JSON'];
    if (!jsonStr || typeof jsonStr !== 'string') return [];
    try {
      const parsed = JSON.parse(jsonStr);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [answerData, displayDate]);

  // AI生成回答
  const aiComments = useMemo(() => {
    const currentAnswerResult = findAnswerByDisplayDate(
      answerData?.answerHistory || [],
      displayDate
    );
    return {
      userComment: String(currentAnswerResult?.['ユーザー用生成回答'] || ''),
      supporterComment: String(currentAnswerResult?.['サポーター用生成回答'] || ''),
    };
  }, [answerData, displayDate]);

  const isLoading = loading || globalLoading;

  // 自分の回答かどうか（ログインユーザーID === 閲覧対象ユーザーID）
  const isOwnAnswer = String(userId) === String(answerId);

  // DatePickerハイライト用（未回答→赤、回答済→緑、完了→緑）
  const answerStatusDef = CONSTANTS.ANSWER_STATUS;
  const highlightedMonths: HighlightedMonth[] = useMemo(() => {
    if (!answerData?.answerHistory) return [];
    return answerData.answerHistory
      .filter((answer) => answer['開始'])
      .map((answer) => {
        const month = formatDateForComparison(String(answer['開始']));
        const answerStatus = getAnswerStatusLabel(toStatusCode(answer['回答状況']));
        // 優先度: 未回答→赤、回答済→緑、完了→緑
        if (answerStatus !== '回答済' && answerStatus !== '完了' && answerStatus !== '面談日程調整済') {
          return { month, colors: [String((answerStatusDef.アンケート未回答 as Record<string, unknown>).color ?? 'red')] };
        }
        if (answerStatus !== '完了') {
          return { month, colors: [String((answerStatusDef.アンケート回答済 as Record<string, unknown>).color ?? 'green')] };
        }
        return { month, colors: [String((answerStatusDef.完了 as Record<string, unknown>).color ?? 'gray')] };
      })
      .filter((item) => item.colors.length > 0);
  }, [answerData, answerStatusDef]);

  return (
    <>
      <AnswerDetailLayout
        answerData={answerData}
        loading={isLoading}
        displayDate={displayDate}
        onDateChange={handleDateChange}
        memo={answerState.memo}
        setMemo={(value) => setAnswerState((prev) => ({ ...prev, memo: value }))}
        interviewMethod={answerState.interviewMethod}
        setInterviewMethod={(value) =>
          setAnswerState((prev) => ({ ...prev, interviewMethod: value }))
        }
        memoError={answerState.memoError}
        setMemoError={(value) =>
          setAnswerState((prev) => ({ ...prev, memoError: value }))
        }
        interviewMethodError={answerState.interviewMethodError}
        setInterviewMethodError={(value) =>
          setAnswerState((prev) => ({ ...prev, interviewMethodError: value }))
        }
        trendChartPeriod={trendChartPeriod}
        setTrendChartPeriod={setTrendChartPeriod}
        getTrendChartData={getTrendChartData}
        onMonthClick={onDateChange}
        currentMonth={displayDate}
        handleRecordInterview={handleRecordInterview}
        recording={answerState.recording}
        surveyAnswers={surveyAnswers}
        aiComments={aiComments}
        getPreviousEvaluationData={getPreviousEvaluationData}
        getChangeArrow={getChangeArrow}
        isAnswered={isAnswered}
        isInterviewed={isInterviewed}
        interviewInfo={interviewInfo}
        interviewMethodOptions={interviewMethodOptions}
        isOwnAnswer={isOwnAnswer}
        highlightedMonths={highlightedMonths}
        onViewerManagementClick={handleViewerManagementClick}
        showViewerManagement={true}
      />

      <AlertDialog {...alertState} onClose={closeAlert} />
      <ConfirmDialog {...confirmState} onConfirm={handleConfirm} onCancel={handleCancel} />
      <Toast {...toastState} onClose={closeToast} />
      {answerState.recording && <LoadingOverlay message="面談を記録中..." preset="hourglass" />}

      {/* 閲覧者管理モーダル */}
      {currentAnswerId && (
        <ViewerManagementModal
          isOpen={viewerModalOpen}
          onClose={() => setViewerModalOpen(false)}
          answerId={currentAnswerId}
          currentViewerIds={currentViewerIds}
          subordinates={subordinates}
          currentUserId={userId || ''}
          currentUserName={userName || 'あなた'}
          onSuccess={handleViewerChangeSuccess}
        />
      )}
    </>
  );
}
