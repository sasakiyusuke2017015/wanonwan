/**
 * 回答詳細ページ専用フック（React Query版）
 */
import { useMemo } from 'react';

import { useQuery } from '@tanstack/react-query';

import { formatDateForComparison, getMaskedInterviewMemo } from '@1on1/domain/utils';
import { findAnswerByDisplayDate, getRecentAnswers } from '@/utils/date/filter';
import { debugLog, debugTimeStart, debugTimeEnd } from '@ui-catalog/core/utils';

import { apiGet } from '@/lib/api';
import { useUserInfo } from '@/hooks';

import type { EmployeeDetailResponse, EmployeeDetailData, AnswerResult } from './types';

/**
 * 回答履歴の面談メモを閲覧権限に応じてマスク処理
 */
function maskAnswerHistoryMemos(
  answerHistory: AnswerResult[],
  currentUserId: string | undefined
): AnswerResult[] {
  return answerHistory.map((result) => {
    const maskedMemo = getMaskedInterviewMemo(
      result['面談メモ'],
      result['面談者'],
      result['面談内容閲覧者'],
      currentUserId
    );
    return {
      ...result,
      面談メモ: maskedMemo || '',
    };
  });
}

/**
 * 回答詳細データ変換フック
 * 生の回答詳細データを画面表示用の構造に変換する
 * @param rawData APIからの生データ
 * @param displayDate 表示対象の月
 * @param currentUserId 現在のログインユーザーID（面談メモ閲覧制御用）
 */
const useAnswerDetailTransform = (
  rawData: EmployeeDetailResponse | null | undefined,
  displayDate: string | undefined,
  currentUserId: string | undefined
): EmployeeDetailData | null => {
  return useMemo(() => {
    if (!rawData || !displayDate) return null;

    debugTimeStart('Answer Detail データ変換処理');

    // 面談メモをマスク処理した回答履歴を作成
    const maskedAnswerHistory = maskAnswerHistoryMemos(
      rawData.回答結果 || [],
      currentUserId
    );

    // 詳細画面用データ構造に変換（マスク済みの履歴から検索）
    const currentAnswerResult = findAnswerByDisplayDate(
      maskedAnswerHistory,
      displayDate
    );
    const recentAnswers = getRecentAnswers(
      maskedAnswerHistory,
      displayDate,
      3
    );

    const processedData = {
      employeeInfo: {
        name: rawData.名前 || '不明',
        id: rawData.ユーザーコード || '不明',
        department: (() => {
          const honbu = rawData.所属本部 || '';
          const bu = rawData.所属部 || '';
          const ka = rawData.所属課 || '';

          const parts = [];
          if (honbu) parts.push(honbu);
          if (bu) parts.push(bu);
          if (ka) parts.push(ka);

          if (parts.length > 0) {
            return parts.join(' / ');
          } else {
            return rawData.部署 || '-';
          }
        })(),
        position: rawData.役職 || '不明',
        supporter: rawData.サポーター || '-',
        trainer: rawData.トレーナー || '-',
        interviewDate: currentAnswerResult?.面談日 || '-',
        interviewer: {
          name: currentAnswerResult?.追加面談候補者名 || '未設定',
          position: currentAnswerResult?.追加面談候補者役職 || '未設定',
        },
      },
      latestEvaluation: currentAnswerResult
        ? {
            date: currentAnswerResult.開始 || '未取得',
            scores: {
              jobSatisfaction: {
                current: currentAnswerResult.評価結果?.満足度 || 0,
              },
              workload: {
                current: currentAnswerResult.評価結果?.業務負荷 || 0,
              },
              workEnvironment: {
                current: currentAnswerResult.評価結果?.職場環境 || 0,
              },
              relationships: {
                current: currentAnswerResult.評価結果?.人間関係 || 0,
              },
              stress: { current: currentAnswerResult.評価結果?.ストレス || 0 },
            },
            comment: currentAnswerResult.コメント || '',
          }
        : null,
      trendData: {
        months: recentAnswers.map(
          (result) => formatDateForComparison(result.開始 || '')
        ),
        jobSatisfaction: recentAnswers.map(
          (result) => result.評価結果?.満足度 || 0
        ),
        stress: recentAnswers.map((result) => result.評価結果?.ストレス || 0),
        workload: recentAnswers.map((result) => result.評価結果?.業務負荷 || 0),
        workEnvironment: recentAnswers.map(
          (result) => result.評価結果?.職場環境 || 0
        ),
        relationships: recentAnswers.map(
          (result) => result.評価結果?.人間関係 || 0
        ),
      },
      aiActionSuggestions: [], // 要実装
      answerHistory: maskedAnswerHistory,
      // 面談メモ用の情報も含める（マスク済み）
      interviewMemo: {
        content: currentAnswerResult?.['面談メモ'] || '',
      },
    };

    debugLog(processedData, 'Answer Detail 成形済データ');
    debugTimeEnd('Answer Detail データ変換処理');

    return processedData;
  }, [rawData, displayDate, currentUserId]);
};

/**
 * 回答詳細データ取得フック（React Query版）
 * REST /api/answers/:answerId エンドポイントを使用
 * 面談メモは閲覧権限に応じてマスク処理される
 */
export const useAnswerDetailTanStack = (
  answerId: string | undefined,
  displayDate: string,
  _refreshKey?: number
) => {
  // 現在のユーザーIDを取得（面談メモ閲覧制御用）
  const { userId: currentUserId } = useUserInfo();

  // React Query でデータ取得
  const { data: rawData, isLoading, error } = useQuery({
    queryKey: ['answers', 'detail', answerId, _refreshKey],
    queryFn: () => apiGet<EmployeeDetailResponse>(`/answers/${answerId}`),
    enabled: !!answerId,
    staleTime: 5 * 60 * 1000, // 5分間キャッシュ
    gcTime: 24 * 60 * 60 * 1000, // 1日間保持
    retry: 3,
  });

  // データ変換（面談メモのマスク処理を含む）
  const answerData = useAnswerDetailTransform(rawData, displayDate, currentUserId);

  return {
    data: answerData,
    loading: isLoading,
    error,
  };
};
