/**
 * apps/web 専用フック
 *
 * アプリケーション固有の依存（routes, storage, state等）を持つフック
 */

export { useErrorHandler, createErrorState } from './useErrorHandler'
export { useNavigateBack } from './useNavigateBack'
export { useNavigationItems } from './useNavigationItems'
export type { NavigationItem } from './useNavigationItems'
export { useThemeConfig } from './useThemeConfig'
export { useBackgroundConfig } from './useBackgroundConfig'
export { usePermissions } from './usePermissions'
export type { UsePermissionsReturn } from './usePermissions'
export { useUserInfo } from './useUserInfo'
