/**
 * スケジュールAPI連携フック（TanStack Query 版）
 *
 * 楽観的更新: UI を即時反映 → バックグラウンドで API 呼び出し → 失敗時ロールバック + トースト
 * 既存の回答画面（hooks.tanstack.ts）のキャッシュ戦略に準拠
 */

import { useCallback, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import type { CalendarEvent } from '@ui-catalog/core/types'
import { apiGet, apiPost, apiPut, apiDelete } from '@/lib/api'

// ============================================================
// 型定義
// ============================================================

interface SchedulesResponse {
  schedules: CalendarEvent[]
}

interface ScheduleResponse {
  schedule: CalendarEvent
}

export interface SchedulesState {
  /** スケジュールデータ */
  data: readonly CalendarEvent[] | null
  /** 初回読み込み中 */
  loading: boolean
  /** 初回読み込みエラー */
  error: string | null
  /** 操作エラー（作成/更新/削除の一時的エラー、自動消去） */
  operationError: string | null
  /** データを再取得 */
  refetch: () => Promise<void>
  /** スケジュールを作成 */
  createSchedule: (event: Omit<CalendarEvent, 'id'>) => Promise<CalendarEvent | null>
  /** スケジュールを更新 */
  updateSchedule: (event: CalendarEvent) => Promise<CalendarEvent | null>
  /** スケジュールを削除 */
  deleteSchedule: (eventId: string) => Promise<boolean>
  /** 操作エラーをクリア */
  clearOperationError: () => void
}

export interface UseSchedulesOptions {
  /** 開始日 */
  startDate?: Date
  /** 終了日 */
  endDate?: Date
  /** 自動フェッチを無効化 */
  disableAutoFetch?: boolean
}

// ============================================================
// クエリキー
// ============================================================

const QUERY_KEY = ['schedules'] as const

// ============================================================
// レスポンスの日付を Date オブジェクトに変換
// ============================================================

function hydrateEvent(raw: any): CalendarEvent {
  return {
    ...raw,
    startTime: new Date(raw.startTime),
    endTime: new Date(raw.endTime),
    repeatPeriodStart: raw.repeatPeriodStart ? new Date(raw.repeatPeriodStart) : undefined,
    repeatPeriodEnd: raw.repeatPeriodEnd ? new Date(raw.repeatPeriodEnd) : undefined,
  }
}

// ============================================================
// useSchedules
// ============================================================

export const useSchedules = (options: UseSchedulesOptions = {}): SchedulesState => {
  const { startDate, endDate, disableAutoFetch = false } = options
  const queryClient = useQueryClient()
  const [operationError, setOperationError] = useState<string | null>(null)

  const clearOperationError = useCallback(() => setOperationError(null), [])

  // 操作エラーを設定（5秒後に自動消去）
  const setTemporaryError = useCallback((message: string) => {
    setOperationError(message)
    setTimeout(() => setOperationError(null), 5000)
  }, [])

  // ---------- 一覧取得 ----------
  const params: Record<string, unknown> = {}
  if (startDate) params.startDate = startDate.toISOString()
  if (endDate) params.endDate = endDate.toISOString()

  const {
    data: schedules,
    isLoading,
    error: queryError,
    refetch,
  } = useQuery({
    queryKey: [...QUERY_KEY, params],
    queryFn: async () => {
      const res = await apiGet<SchedulesResponse>('/schedules', params)
      return res.schedules.map(hydrateEvent)
    },
    enabled: !disableAutoFetch,
    staleTime: 5 * 60 * 1000,   // 5分
    gcTime: 24 * 60 * 60 * 1000, // 1日
    retry: 3,
  })

  // ---------- 作成（楽観的更新） ----------
  const createMutation = useMutation({
    mutationFn: async (event: Omit<CalendarEvent, 'id'>) => {
      const res = await apiPost<ScheduleResponse>('/schedules', event)
      return hydrateEvent(res.schedule)
    },
    onMutate: async (newEvent) => {
      await queryClient.cancelQueries({ queryKey: QUERY_KEY })
      const previous = queryClient.getQueryData<CalendarEvent[]>([...QUERY_KEY, params])

      // 楽観的にキャッシュを更新（一時 ID 付き）
      const tempId = `temp-${Date.now()}`
      const tempEvent: CalendarEvent = { ...newEvent, id: tempId } as CalendarEvent
      queryClient.setQueryData<CalendarEvent[]>([...QUERY_KEY, params], (old) =>
        old ? [...old, tempEvent] : [tempEvent]
      )

      return { previous, tempId }
    },
    onSuccess: (created, _newEvent, context) => {
      // temp イベントをサーバーから返ったデータに差し替え（再取得なし = ちらつき防止）
      queryClient.setQueryData<CalendarEvent[]>([...QUERY_KEY, params], (old) =>
        old ? old.map((e) => (e.id === context?.tempId ? created : e)) : [created]
      )
    },
    onError: (_err, _newEvent, context) => {
      if (context?.previous) {
        queryClient.setQueryData([...QUERY_KEY, params], context.previous)
      }
      setTemporaryError('スケジュールの作成に失敗しました')
    },
  })

  // ---------- 更新（楽観的更新） ----------
  const updateMutation = useMutation({
    mutationFn: async (event: CalendarEvent) => {
      const res = await apiPut<ScheduleResponse>(`/schedules/${event.id}`, event)
      return hydrateEvent(res.schedule)
    },
    onMutate: async (updatedEvent) => {
      await queryClient.cancelQueries({ queryKey: QUERY_KEY })
      const previous = queryClient.getQueryData<CalendarEvent[]>([...QUERY_KEY, params])

      // 楽観的に該当イベントを差し替え
      queryClient.setQueryData<CalendarEvent[]>([...QUERY_KEY, params], (old) =>
        old ? old.map((e) => (e.id === updatedEvent.id ? updatedEvent : e)) : [updatedEvent]
      )

      return { previous }
    },
    onSuccess: (updated) => {
      // サーバーから返ったデータで差し替え
      queryClient.setQueryData<CalendarEvent[]>([...QUERY_KEY, params], (old) =>
        old ? old.map((e) => (e.id === updated.id ? updated : e)) : [updated]
      )
    },
    onError: (_err, _updatedEvent, context) => {
      if (context?.previous) {
        queryClient.setQueryData([...QUERY_KEY, params], context.previous)
      }
      setTemporaryError('スケジュールの更新に失敗しました')
    },
  })

  // ---------- 削除（楽観的更新） ----------
  const deleteMutation = useMutation({
    mutationFn: async (eventId: string) => {
      await apiDelete(`/schedules/${eventId}`)
    },
    onMutate: async (eventId) => {
      await queryClient.cancelQueries({ queryKey: QUERY_KEY })
      const previous = queryClient.getQueryData<CalendarEvent[]>([...QUERY_KEY, params])

      queryClient.setQueryData<CalendarEvent[]>([...QUERY_KEY, params], (old) =>
        old ? old.filter((e) => e.id !== eventId) : []
      )

      return { previous }
    },
    onError: (_err, _eventId, context) => {
      if (context?.previous) {
        queryClient.setQueryData([...QUERY_KEY, params], context.previous)
      }
      setTemporaryError('スケジュールの削除に失敗しました')
    },
  })

  // ---------- ラッパー関数 ----------
  const createSchedule = useCallback(
    async (event: Omit<CalendarEvent, 'id'>): Promise<CalendarEvent | null> => {
      try {
        return await createMutation.mutateAsync(event)
      } catch {
        return null
      }
    },
    [createMutation]
  )

  const updateSchedule = useCallback(
    async (event: CalendarEvent): Promise<CalendarEvent | null> => {
      try {
        return await updateMutation.mutateAsync(event)
      } catch {
        return null
      }
    },
    [updateMutation]
  )

  const deleteSchedule = useCallback(
    async (eventId: string): Promise<boolean> => {
      try {
        await deleteMutation.mutateAsync(eventId)
        return true
      } catch {
        return false
      }
    },
    [deleteMutation]
  )

  return {
    data: schedules ?? null,
    loading: isLoading,
    error: queryError ? (queryError instanceof Error ? queryError.message : 'スケジュールの取得に失敗しました') : null,
    operationError,
    refetch: async () => { await refetch() },
    createSchedule,
    updateSchedule,
    deleteSchedule,
    clearOperationError,
  }
}
