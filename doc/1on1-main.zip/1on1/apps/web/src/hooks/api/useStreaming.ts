/**
 * SSEストリーミングAPI用フック
 * Server-Sent Events形式でストリーミングレスポンスを受信する
 */
import { useState, useCallback, useRef } from 'react';

import { getApiUrl } from '@/config/env';
import { getAuthToken } from '@/lib/auth';

// ============================================================
// 型定義
// ============================================================

export interface StreamingState<T, B = unknown> {
  /** ストリーミング実行関数 */
  stream: (body?: B, dynamicEndpoint?: string) => Promise<T | null>;
  /** ストリーミング中か */
  isStreaming: boolean;
  /** ローディング状態（初期化中） */
  loading: boolean;
  /** エラー */
  error: Error | null;
  /** 最終レスポンスデータ */
  data: T | null;
  /** ストリーミング中のテキスト（逐次更新） */
  streamingText: string;
  /** ストリーミングをキャンセル */
  cancel: () => void;
  /** リセット関数 */
  reset: () => void;
}

/** SSE初期化イベントデータ */
export interface SSEInitData {
  [key: string]: unknown;
}

export interface UseStreamingApiOptions<T> {
  /** HTTPメソッド（デフォルト: POST） */
  method?: 'POST' | 'PUT' | 'PATCH';
  /** 初期化完了時コールバック */
  onInit?: (data: SSEInitData) => void;
  /** チャンク受信時コールバック */
  onChunk?: (chunk: string, accumulated: string) => void;
  /** 完了時コールバック */
  onComplete?: (response: T) => void;
  /** エラー時コールバック */
  onError?: (error: Error) => void;
}

// ============================================================
// SSEイベントパーサー
// ============================================================

interface SSEEvent {
  event: string;
  data: string;
}

/**
 * SSEフォーマットのテキストをパースする
 */
const parseSSEEvents = (text: string): SSEEvent[] => {
  const events: SSEEvent[] = [];
  const lines = text.split('\n');

  let currentEvent = '';
  let currentData = '';

  for (const line of lines) {
    if (line.startsWith('event: ')) {
      currentEvent = line.slice(7).trim();
    } else if (line.startsWith('data: ')) {
      currentData = line.slice(6);
    } else if (line === '' && currentData) {
      events.push({
        event: currentEvent || 'message',
        data: currentData,
      });
      currentEvent = '';
      currentData = '';
    }
  }

  return events;
};

// ============================================================
// useStreamingApi - SSEストリーミング用フック
// ============================================================

/**
 * SSEストリーミングAPIフック
 *
 * @example
 * ```typescript
 * const { stream, isStreaming, streamingText, data } = useStreamingApi<Response>({
 *   onChunk: (chunk, accumulated) => console.log('受信:', chunk),
 *   onComplete: (response) => console.log('完了:', response),
 * });
 *
 * // ストリーミング開始
 * await stream({ answers: [...] }, '/api/answers/123/submit/stream');
 * ```
 */
export const useStreamingApi = <T = unknown, B = unknown>(
  endpoint?: string,
  options: UseStreamingApiOptions<T> = {}
): StreamingState<T, B> => {
  const {
    method = 'POST',
    onInit,
    onChunk,
    onComplete,
    onError,
  } = options;

  const [isStreaming, setIsStreaming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [data, setData] = useState<T | null>(null);
  const [streamingText, setStreamingText] = useState('');

  const abortControllerRef = useRef<AbortController | null>(null);

  const reset = useCallback(() => {
    setIsStreaming(false);
    setLoading(false);
    setError(null);
    setData(null);
    setStreamingText('');
  }, []);

  const cancel = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
    setLoading(false);
  }, []);

  const stream = useCallback(
    async (body?: B, dynamicEndpoint?: string): Promise<T | null> => {
      const targetEndpoint = dynamicEndpoint || endpoint;
      if (!targetEndpoint) {
        const err = new Error('Endpoint is required');
        setError(err);
        onError?.(err);
        return null;
      }

      // APIベースURLを取得し、相対パスの場合はベースURLを付与
      const apiBaseUrl = getApiUrl();
      const fullUrl = targetEndpoint.startsWith('http')
        ? targetEndpoint
        : `${apiBaseUrl}${targetEndpoint}`;

      // 既存のストリームをキャンセル
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      abortControllerRef.current = new AbortController();

      setLoading(true);
      setIsStreaming(true);
      setError(null);
      setData(null);
      setStreamingText('');

      try {
        // Cookieからアクセストークンを取得
        const token = getAuthToken('ACCESS_TOKEN');

        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
          Accept: 'text/event-stream',
        };

        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(fullUrl, {
          method,
          headers,
          body: body ? JSON.stringify(body) : undefined,
          signal: abortControllerRef.current.signal,
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        if (!response.body) {
          throw new Error('ReadableStream not supported');
        }

        setLoading(false);

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let accumulatedText = '';
        let finalResponse: T | null = null;

        while (true) {
          const { done, value } = await reader.read();

          if (done) {
            break;
          }

          const text = decoder.decode(value, { stream: true });
          const events = parseSSEEvents(text);

          for (const event of events) {
            try {
              const eventData = JSON.parse(event.data);

              switch (event.event) {
                case 'init':
                  onInit?.(eventData);
                  break;

                case 'ai_chunk':
                  if (eventData.chunk) {
                    accumulatedText += eventData.chunk;
                    setStreamingText(accumulatedText);
                    onChunk?.(eventData.chunk, accumulatedText);
                  }
                  break;

                case 'complete':
                  finalResponse = eventData as T;
                  setData(finalResponse);
                  onComplete?.(finalResponse);
                  break;

                case 'error':
                  throw new Error(eventData.error || 'Unknown error');
              }
            } catch (parseError) {
              // JSONパースエラーは無視（不完全なチャンクの可能性）
              if (event.event === 'error') {
                throw parseError;
              }
            }
          }
        }

        setIsStreaming(false);
        return finalResponse;
      } catch (err) {
        if ((err as Error).name === 'AbortError') {
          // キャンセルされた場合は何もしない
          return null;
        }

        const errorObj = err instanceof Error ? err : new Error('Unknown error');
        setError(errorObj);
        onError?.(errorObj);
        setIsStreaming(false);
        setLoading(false);
        throw errorObj;
      }
    },
    [endpoint, method, onInit, onChunk, onComplete, onError]
  );

  return {
    stream,
    isStreaming,
    loading,
    error,
    data,
    streamingText,
    cancel,
    reset,
  };
};

export default useStreamingApi;
