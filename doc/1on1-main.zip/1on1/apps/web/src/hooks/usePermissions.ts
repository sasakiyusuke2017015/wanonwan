/**
 * 権限管理の統一フック
 * すべての権限判断をこのフックに集約し、一貫したAPIを提供
 */
import { useMemo } from 'react';

import { canAccessAPI as canAccessAPIUtil } from '@1on1/domain/utils';
import { useAuth } from '@/adapters/AuthContext';

import { useUserInfo } from './useUserInfo';
import {
  filterPermissions,
  canViewAnswer as canViewAnswerUtil,
  type AllowedFeatures,
  type AnswerViewTarget,
} from '@/utils/permissions';

export interface UsePermissionsReturn {
  /**
   * 認証状態（loading中はfalse）
   */
  isAuthenticated: boolean;

  /**
   * 認証状態確認中かどうか
   */
  loading: boolean;

  /**
   * ページへのアクセス権限をチェック
   * @param path ページのパス（例: "/home", "/dashboard"）
   * @returns アクセス可能かどうか
   */
  canAccessPage: (path: string) => boolean;

  /**
   * 機能の使用権限をチェック
   * @param feature 機能名（例: "notifications", "export"）
   * @returns 使用可能かどうか
   */
  canUseFeature: (feature: keyof AllowedFeatures) => boolean;

  /**
   * 回答データの閲覧権限をチェック
   * @param target 閲覧対象の情報
   * @returns 閲覧可能かどうか
   */
  canViewAnswer: (target: AnswerViewTarget) => boolean;

  /**
   * APIへのアクセス権限をチェック
   * @param apiPath APIのパス（例: "/api/dashboard/stats"）
   * @returns アクセス可能かどうか
   */
  canAccessAPI: (apiPath: string) => boolean;

  /**
   * 許可されたページパス一覧（ナビゲーションフィルタリング用）
   */
  allowedLinks: string[];

  /**
   * 許可されたAPI一覧
   */
  allowedAPIs: string[];

  /**
   * 許可された機能一覧
   */
  allowedFeatures: AllowedFeatures;
}

/**
 * 権限管理の統一フック
 *
 * 使用例:
 * ```typescript
 * const { canAccessPage, canUseFeature, canViewAnswer } = usePermissions();
 *
 * // ページアクセス
 * if (!canAccessPage('/home')) { ... }
 *
 * // 機能表示
 * {canUseFeature('notifications') && <NotificationBell />}
 *
 * // データ閲覧
 * {canViewAnswer(answerData) && <AnswerDetail />}
 * ```
 */
export const usePermissions = (): UsePermissionsReturn => {
  const { isAuthenticated, loading } = useAuth();
  const { user } = useUserInfo();

  // 権限データを計算（メモ化）
  const permissionData = useMemo(() => filterPermissions(user), [user]);

  // ページアクセス権限チェック（完全一致 or 親パスが許可されていればアクセス可）
  const canAccessPage = useMemo(
    () => (path: string) => {
      if (permissionData.allowedLinks.includes(path)) return true;
      // 親パスチェック: /answers/details → /answers が許可されていればOK
      const parentPath = path.replace(/\/[^/]+$/, '');
      if (parentPath && parentPath !== path) {
        return permissionData.allowedLinks.includes(parentPath);
      }
      return false;
    },
    [permissionData.allowedLinks]
  );

  // 機能使用権限チェック
  const canUseFeature = useMemo(
    () => (feature: keyof AllowedFeatures) => {
      return !!permissionData.allowedFeatures[feature];
    },
    [permissionData.allowedFeatures]
  );

  // 回答データ閲覧権限チェック
  const canViewAnswerFn = useMemo(
    () => (target: AnswerViewTarget) => {
      return canViewAnswerUtil(user, target);
    },
    [user]
  );

  // API アクセス権限チェック
  const canAccessAPI = useMemo(
    () => (apiPath: string) => {
      return canAccessAPIUtil(apiPath, permissionData.allowedAPIs);
    },
    [permissionData.allowedAPIs]
  );

  return {
    // 認証情報
    isAuthenticated,
    loading,
    // 権限チェック関数
    canAccessPage,
    canUseFeature,
    canViewAnswer: canViewAnswerFn,
    canAccessAPI,
    // 生データ
    allowedLinks: permissionData.allowedLinks,
    allowedAPIs: permissionData.allowedAPIs,
    allowedFeatures: permissionData.allowedFeatures,
  };
};
