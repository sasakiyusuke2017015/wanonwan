/**
 * 背景設定を取得するhook
 *
 * @ui-catalog/core/theme の機能を使用
 * ページ全体の背景テクスチャを管理
 */
import { useAtomValue } from 'jotai'

import { getBackgroundConfig, type BackgroundTheme } from '@ui-catalog/core/constants'
import { backgroundThemeAtom } from '@ui-catalog/core/infra/theme'

interface UseBackgroundConfigOptions {
  /** 背景テーマ（未指定時はグローバル設定を使用） */
  backgroundTheme?: BackgroundTheme
}

/**
 * 背景設定を取得するhook
 *
 * @example
 * // グローバル背景設定を使用
 * const background = useBackgroundConfig();
 *
 * @example
 * // 特定の背景テーマで上書き
 * const background = useBackgroundConfig({ backgroundTheme: 'wood' });
 */
export function useBackgroundConfig(options: UseBackgroundConfigOptions = {}) {
  const globalBackgroundTheme = useAtomValue(backgroundThemeAtom)

  const backgroundTheme = options.backgroundTheme ?? globalBackgroundTheme

  return getBackgroundConfig(backgroundTheme)
}
