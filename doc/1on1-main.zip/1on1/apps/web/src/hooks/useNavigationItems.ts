import { useMemo } from 'react';

import { resolveUrlTemplate } from '@1on1/domain/utils';
import { type IconName } from '@ui-catalog/core/constants';
import { ROUTES, NAV_ROUTE_KEYS } from '@/constants/routes';

import { usePermissions } from './usePermissions';
import { useUserInfo } from './useUserInfo';

export interface NavigationItem {
  id: string;
  to: string;
  label: string;
  icon: IconName;
}

/**
 * ナビゲーションアイテムを計算するカスタムフック
 * permissions.yml の allowedPaths に基づいてフィルタリング
 */
export const useNavigationItems = (): NavigationItem[] => {
  const { userId } = useUserInfo();
  const { canAccessPage } = usePermissions();

  const navigationItems = useMemo(() => {
    return NAV_ROUTE_KEYS
      .map((key) => {
        const route = ROUTES[key];
        if (!route.icon) return null;
        return {
          id: `link-${key.toLowerCase().replace(/_/g, '-')}`,
          to: route.path,
          label: route.label,
          icon: route.icon as IconName,
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .filter((item) => {
        // permissions.yml の path で制御（usePermissions で一元管理）
        return canAccessPage(item.to);
      })
      .map((item) => ({
        ...item,
        // URL テンプレートを実際の値に置換
        to: resolveUrlTemplate(item.to, { userId: String(userId) }),
      }));
  }, [canAccessPage, userId]);

  return navigationItems;
};
