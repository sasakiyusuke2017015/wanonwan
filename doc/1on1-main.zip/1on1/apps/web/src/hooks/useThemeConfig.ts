/**
 * テーマ設定を取得するhook
 *
 * @ui-catalog/core/theme の機能を使用
 * コンポーネント名を指定して、解決済みのテーマ設定を取得
 *
 * @example
 * const { colors, shapes } = useThemeConfig('Header');
 * const { colors, shapes } = useThemeConfig('AnswerDetail');
 */
import { useAtomValue } from 'jotai'

import { getThemeConfig } from '@ui-catalog/core/constants'
import {
  colorThemeAtom,
  shapeThemeAtom,
  resolveComponentTheme,
} from '@ui-catalog/core/infra/theme'

import {
  componentThemesAtom,
  type ThemeableComponent,
} from '@/theme/componentThemes'

/**
 * コンポーネントのテーマ設定を取得するhook
 *
 * @param component コンポーネント名（theme/componentThemes.ts に定義）
 * @returns { colors, shapes } テーマ設定
 */
export function useThemeConfig(component: ThemeableComponent) {
  const globalColorTheme = useAtomValue(colorThemeAtom)
  const globalShapeTheme = useAtomValue(shapeThemeAtom)
  const componentThemes = useAtomValue(componentThemesAtom)

  const { colorTheme, shapeTheme } = resolveComponentTheme(
    componentThemes,
    component,
    globalColorTheme,
    globalShapeTheme
  )

  return getThemeConfig(colorTheme, shapeTheme)
}
