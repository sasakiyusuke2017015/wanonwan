'use client';

import { useCallback } from 'react';

import { useNavigate } from '@/adapters/RouterContext';
import { getBreadcrumbs } from '@/constants/routes';

/**
 * パンくずリストの構造から自動的に「戻る先」を判断して遷移するカスタムフック
 *
 * BREADCRUMB_CONFIG で定義されたパンくずリストの最後から2番目の項目（親階層）へ遷移します。
 * パンくずリストが1つしかない場合や定義がない場合は、HOMEページ（'/'）へ遷移します。
 *
 * @param routePattern - 現在のルートパターン（例: ROUTES.ANSWER_DETAIL.path = '/answers/details'）
 * @param params - 動的パラメータ（例: { name: '田中太郎' }）
 * @returns 戻るボタン用のハンドラ関数
 *
 * @example
 * ```tsx
 * // 回答詳細ページ（/answers/details）
 * const handleBack = useNavigateBack(ROUTES.ANSWER_DETAIL.path);
 * // → /answers に戻る
 *
 * // 回答一覧ページ（/answers）
 * const handleBack = useNavigateBack(ROUTES.ANSWERS.path);
 * // → / に戻る
 * ```
 */
export function useNavigateBack(
  routePattern: string,
  params?: Record<string, string>
) {
  const navigate = useNavigate();

  return useCallback(() => {
    const breadcrumbs = getBreadcrumbs(routePattern, params);

    // パンくずリストの最後から2番目の href に戻る（最後は現在のページ）
    // breadcrumbs が2つ以上ある場合：最後から2番目へ
    // breadcrumbs が1つの場合またはない場合：HOMEへ
    const backPath = breadcrumbs.length >= 2
      ? breadcrumbs[breadcrumbs.length - 2].href ?? '/'
      : '/';

    navigate(backPath);
  }, [navigate, routePattern, params]);
}
