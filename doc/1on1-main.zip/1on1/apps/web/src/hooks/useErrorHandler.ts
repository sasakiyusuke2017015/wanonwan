'use client';

/**
 * エラーハンドリングフック
 * アプリケーション全体のエラー処理を統一的に管理
 */
import { useCallback } from 'react';

import { useNavigate } from '@/adapters/RouterContext';

import { STORAGE_KEYS } from '@/constants/storage';

// ============================================================
// 型定義
// ============================================================

interface ErrorState {
  message: string;
  details: string;
  code: string | number;
  from: string;
  errorId: string;
  debugInfo?: DebugInfo;
}

interface DebugInfo {
  timestamp: string;
  userAgent: string;
  viewport: string;
  url: string;
  stackTrace?: string;
  originalError?: {
    name: string;
    message: string;
    stack?: string;
  };
  requestInfo?: RequestInfo;
}

interface RequestInfo {
  url?: string;
  method?: string;
  headers?: Record<string, string>;
  body?: unknown;
}

interface ErrorParams {
  message: string;
  details?: string;
  code?: string | number;
  originalError?: Error | unknown;
  requestInfo?: RequestInfo;
}

// ============================================================
// ユーティリティ関数
// ============================================================

const isDev = (): boolean =>
  import.meta.env.DEV ||
  import.meta.env.MODE === 'development' ||
  ['localhost', '127.0.0.1'].includes(window.location.hostname) ||
  window.location.hostname.startsWith('192.168.');

const generateErrorId = (): string => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `E${timestamp}-${random}`;
};

const collectDebugInfo = (errorParams: ErrorParams): DebugInfo => {
  try {
    const err = errorParams.originalError;
    const isError = err instanceof Error;
    return {
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      url: window.location.href,
      stackTrace: isError ? err.stack : undefined,
      originalError: isError
        ? { name: err.name, message: err.message, stack: err.stack }
        : err
          ? { name: 'Unknown', message: String(err) }
          : undefined,
      requestInfo: errorParams.requestInfo,
    };
  } catch {
    return {
      timestamp: new Date().toISOString(),
      userAgent: 'unknown',
      viewport: 'unknown',
      url: window.location.href,
    };
  }
};

const buildErrorState = (errorParams: ErrorParams): ErrorState => {
  const errorId = generateErrorId();
  return {
    message: errorParams.message,
    details: errorParams.details || 'エラーが発生しました。',
    code: errorParams.code || 'UNKNOWN_ERROR',
    from: window.location.pathname,
    errorId,
    debugInfo: collectDebugInfo(errorParams),
  };
};

const saveErrorState = (errorState: ErrorState): void => {
  try {
    sessionStorage.setItem(STORAGE_KEYS.ERROR_STATE, JSON.stringify(errorState));
  } catch {
    // sessionStorage への保存失敗は無視（エラーハンドリングの本質には影響なし）
  }
};

const logError = (errorState: ErrorState, errorParams: ErrorParams): void => {
  if (isDev()) {
    console.error(`[${errorState.errorId}] ${errorParams.message}`, {
      errorState,
      originalError: errorParams.originalError,
    });
  }
};

const shouldSkipNavigation = (): boolean =>
  localStorage.getItem('FORCE_SKIP_ERROR_PAGE') === 'true';

// ============================================================
// フック
// ============================================================

export const useErrorHandler = (options?: { skipNavigation?: boolean }) => {
  const navigate = useNavigate();
  const { skipNavigation = false } = options || {};

  const handleError = useCallback(
    (errorParams: ErrorParams) => {
      const errorState = buildErrorState(errorParams);

      logError(errorState, errorParams);
      saveErrorState(errorState);

      if (skipNavigation || shouldSkipNavigation()) {
        if (isDev()) {
          console.warn(`エラーページ遷移スキップ: ${errorState.errorId}`);
        }
        return;
      }

      navigate('/error');
    },
    [navigate, skipNavigation]
  );

  return { handleError };
};

// ============================================================
// API用ユーティリティ（Reactフック外で使用）
// ============================================================

export const createErrorState = (errorParams: ErrorParams): ErrorState => {
  const errorState = buildErrorState(errorParams);

  logError(errorState, errorParams);
  saveErrorState(errorState);

  if (shouldSkipNavigation()) {
    if (isDev()) {
      console.warn(`エラーページ遷移スキップ: ${errorState.errorId}`);
    }
  } else {
    setTimeout(() => {
      window.location.href = '/error';
    }, 100);
  }

  return errorState;
};
