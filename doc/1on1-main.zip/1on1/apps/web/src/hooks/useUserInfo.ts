/**
 * ユーザー情報取得フック
 * 認証コンテキストからユーザー情報を取得し、よく使われるフィールドを抽出する
 */
import { useAuth } from '@/adapters/AuthContext';

export const useUserInfo = () => {
  const { user } = useAuth();
  
  const userCode = user?.["ユーザーコード"];
  const userId = user?.["ユーザーID"];
  const userName = user?.["名前"];

  return {
    userCode,
    userId,
    userName,
    user
  };
};