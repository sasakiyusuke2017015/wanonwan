/**
 * 認証アダプター（Vite SPA用）
 *
 * packages/ui-catalog の AuthAdapter インターフェースに準拠
 * Cookieベースの認証状態を管理
 */

import { useState, useEffect, useCallback, useMemo } from 'react'
import type { AuthAdapter, LoginResult, ChangePasswordResult } from '@/adapters'
import type { User } from '@/types'
import { getAuthToken, clearAuthTokens, setAuthTokens } from '@/lib/auth'
import {
  clearBusinessDataFromStorage,
  getLastAuthUserId,
  setLastAuthUserId,
  removeLastAuthUserId,
} from '@/lib/auth/clearUserCache'
import { queryClientRef } from '@/lib/auth/queryClientRef'

/**
 * 認証アダプターを生成するフック
 *
 * packages/ui-catalog の AuthProvider に注入するためのアダプターを返す
 */
export function useAuthAdapter(): AuthAdapter<User> {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  // 初期化時にCookieからトークンを取得、ユーザー情報はlocalStorageから復元
  useEffect(() => {
    const accessToken = getAuthToken('ACCESS_TOKEN')
    if (accessToken) {
      setToken(accessToken)
      // まずlocalStorageから保存済みユーザー情報を復元
      const storedUserInfo = localStorage.getItem('userInfo')
      if (storedUserInfo) {
        try {
          const userData = JSON.parse(storedUserInfo)
          setUser(userData)
        } catch {
          // パース失敗時はJWTからフォールバック
          try {
            const payload = JSON.parse(atob(accessToken.split('.')[1]))
            setUser({
              id: payload.sub || payload.user_id || 0,
              email: payload.email || '',
              name: payload.name || payload.username || '',
              role: payload.role || 'general',
              '名前': payload.name || payload.username || '',
              'ユーザーコード': '',
              'ユーザーID': payload.sub || payload.user_id || '',
              'メールアドレス': payload.email || '',
              '所属本部': '',
              '所属部': '',
              '所属課': '',
              '役職': '',
            })
          } catch {
            setUser(null)
          }
        }
      } else {
        // localStorageにない場合はJWTからデコード（最小限の情報のみ）
        try {
          const payload = JSON.parse(atob(accessToken.split('.')[1]))
          setUser({
            id: payload.sub || payload.user_id || 0,
            email: payload.email || '',
            name: payload.name || payload.username || '',
            role: payload.role || 'general',
            '名前': payload.name || payload.username || '',
            'ユーザーコード': '',
            'ユーザーID': payload.sub || payload.user_id || '',
            'メールアドレス': payload.email || '',
            '所属本部': '',
            '所属部': '',
            '所属課': '',
            '役職': '',
          })
        } catch {
          setUser(null)
        }
      }
    }
    setLoading(false)
  }, [])

  // ログイン関数（REST APIエンドポイントを使用）
  const login = useCallback(async (username: string, password: string): Promise<LoginResult<User>> => {
    try {
      // Viteプロキシ経由で相対パスを使用
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: username, password }),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        // auth.tsからの構造化エラーメッセージをパース
        const rawMessage = errorData.message || errorData.detail || ''
        let errorMessage = 'ログインに失敗しました'
        try {
          const parsed = JSON.parse(rawMessage)
          if (parsed.locked) {
            errorMessage = parsed.error
          } else if (parsed.remainingAttempts !== undefined) {
            errorMessage = `${parsed.error}（残り${parsed.remainingAttempts}回でロック）`
          } else if (parsed.error) {
            errorMessage = parsed.error
          }
        } catch {
          // JSONパース失敗時はそのまま使用
          errorMessage = rawMessage || errorMessage
        }
        return {
          success: false,
          error: errorMessage,
        }
      }

      const data = await response.json()
      const { access_token, refresh_token, user: userData, requirePasswordChange } = data

      // トークンをCookieに保存
      setAuthTokens(access_token, refresh_token)
      setToken(access_token)

      // ユーザー切り替え検知: 前回と異なるユーザーならキャッシュをクリア
      const rawUserId = userData?.id || userData?.userId
      if (!rawUserId) {
        return {
          success: false,
          error: 'ログインレスポンスにユーザーIDが含まれていません',
        }
      }
      const newUserId = String(rawUserId)
      const lastUserId = getLastAuthUserId()
      const userChanged = lastUserId !== null && lastUserId !== newUserId
      if (userChanged) {
        clearBusinessDataFromStorage()
        queryClientRef.current?.clear()
      }
      setLastAuthUserId(newUserId)

      // ユーザー切り替え時はリロードして Jotai メモリキャッシュも初期化
      // Cookie/lastAuthUserId は既にセット済みなので、リロード後に正しいユーザーで復元される
      if (userChanged) {
        window.location.href = '/'
        return { success: true, user: null as unknown as User, requirePasswordChange }
      }

      // ユーザー情報を設定
      // APIレスポンスの role は役職コード（例: "550"）
      const user: User = {
        id: userData?.id || userData?.userId || 0,
        email: userData?.email || username,
        name: userData?.name || userData?.['名前'] || '',
        role: userData?.role || 'general',
        '名前': userData?.['名前'] || userData?.name || '',
        'ユーザーコード': userData?.['ユーザーコード'] || '',
        'ユーザーID': userData?.['ユーザーID'] || String(userData?.userId || ''),
        'メールアドレス': userData?.['メールアドレス'] || userData?.email || '',
        '所属本部': userData?.['所属本部'] || '',
        '所属部': userData?.['所属部'] || '',
        '所属課': userData?.['所属課'] || '',
        '役職': userData?.['役職'] || '',
        '役職コード': userData?.role || userData?.['役職コード'] || '',
      }
      setUser(user)
      // ユーザー情報をlocalStorageに保存（リロード時に復元用）
      localStorage.setItem('userInfo', JSON.stringify(user))

      return { success: true, user, requirePasswordChange }
    } catch (error) {
      console.error('Login error:', error)
      return {
        success: false,
        error: '認証中にエラーが発生しました',
      }
    }
  }, [])

  // ログアウト関数
  const logout = useCallback(async () => {
    setUser(null)
    setToken(null)
    clearAuthTokens()
    // 業務データキャッシュをクリア
    clearBusinessDataFromStorage()
    // ユーザー情報を削除（PRESERVE_KEYSに含まれているため明示的に削除）
    localStorage.removeItem('userInfo')
    removeLastAuthUserId()
    queryClientRef.current?.clear()
    // ログインページにリダイレクト
    window.location.href = '/login'
  }, [])

  // パスワード変更関数（REST APIエンドポイントを使用）
  const changePassword = useCallback(async (
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ): Promise<ChangePasswordResult> => {
    try {
      const accessToken = getAuthToken('ACCESS_TOKEN')
      if (!accessToken) {
        return { success: false, error: '認証情報が見つかりません' }
      }

      const response = await fetch('/api/users/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
          confirm_password: confirmPassword,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        return {
          success: false,
          error: errorData.message || errorData.detail || 'パスワード変更に失敗しました',
        }
      }

      return { success: true }
    } catch (error) {
      console.error('Change password error:', error)
      return {
        success: false,
        error: 'パスワード変更中にエラーが発生しました',
      }
    }
  }, [])

  // 認証ヘッダーを取得
  const getAuthHeaders = useCallback((): Record<string, string> => {
    if (!token) return {}
    return {
      Authorization: `Bearer ${token}`,
    }
  }, [token])

  // トークンの有効性をチェック
  const isAuthenticated = useMemo((): boolean => {
    if (!token) return false
    try {
      const payload = JSON.parse(atob(token.split('.')[1]))
      const expirationTime = payload.exp * 1000
      return Date.now() < expirationTime
    } catch {
      return false
    }
  }, [token])

  return {
    user,
    token,
    loading,
    login,
    logout,
    getAuthHeaders,
    isAuthenticated,
    changePassword,
  }
}
