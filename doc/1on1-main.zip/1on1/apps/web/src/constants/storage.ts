/**
 * ストレージキーの一元管理
 * LocalStorage/SessionStorageで使用するキー名を定義
 *
 * 注意: テーマ関連キーは @ui-catalog/core/theme の THEME_STORAGE_KEYS で管理
 */

export const STORAGE_KEYS = {
  // 認証関連（トークンはCookie管理のためlocalStorage不要）
  USER_INFO: 'userInfo',

  // UI状態（テーマ以外）
  DISPLAY_DATE: 'displayDate',
  LEFT_PANE_OPEN: 'leftPaneOpen',
  ANSWER_LIST_VISIBLE_COLUMNS: 'answerListVisibleColumns',
  ANSWER_LIST_COLUMN_ORDER: 'answerListColumnOrder',
  // フィルター（種別別）
  ANSWER_LIST_TEXT_FILTERS: 'answerListTextFilters',
  ANSWER_LIST_STATUS_FILTERS: 'answerListStatusFilters',
  ANSWER_LIST_SCORE_FILTERS: 'answerListScoreFilters',
  ANSWER_LIST_DATE_RANGE_FILTERS: 'answerListDateRangeFilters',
  ANSWER_LIST_VIEW_MODE: 'answerListViewMode',
  TREND_CHART_PERIOD: 'trendChartPeriod',
  // 回答詳細タブ管理
  ANSWER_DETAIL_OPENED_TABS: 'answerDetailOpenedTabs',
  ANSWER_DETAIL_ACTIVE_ID: 'answerDetailActiveId',

  // エラー管理
  ERROR_STATE: 'errorState',

  // ログイン情報
  REMEMBERED_USERNAME: 'rememberedUsername',
  REMEMBERED_PASSWORD: 'rememberedPassword',
  REMEMBER_ME: 'rememberMe',

  // ユーザー切り替え検知
  LAST_AUTH_USER_ID: 'lastAuthUserId',
} as const;
