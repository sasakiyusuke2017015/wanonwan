/**
 * ロール名の定数定義
 *
 * 使用方法:
 * import { ROLE, RoleName } from '@/constants/roles';
 *
 * const userRole: RoleName = ROLE.ADMIN;
 * if (userRole === ROLE.ADMIN) { ... }
 */

import { CONSTANTS } from './schemas';

/**
 * ロール名定数
 */
export const ROLE = {
  /** 一般メンバー（役職コード～499） */
  EMPLOYEE: 'employee',
  /** 課長（役職コード500-699） */
  SECTION_HEAD: 'section_head',
  /** 部長（役職コード700-899） */
  DEPARTMENT_HEAD: 'department_head',
  /** 本部長（役職コード900-998） */
  DIVISION_HEAD: 'division_head',
  /** 管理者（役職コード999） */
  ADMIN: 'admin',
} as const;

/**
 * ロール名の型定義
 */
export type RoleName = typeof ROLE[keyof typeof ROLE];

/**
 * ロール名の配列（列挙に使用）
 */
export const ROLE_NAMES = Object.values(ROLE) as RoleName[];

/**
 * 役職コードの範囲定数（permissions.yml の roles から取得）
 */
const roles = CONSTANTS.PERMISSIONS.roles;
export const POSITION_CODE = {
  /** 管理者の最大コード（990-999） */
  ADMIN: roles.admin.positionCode.max,
  /** 管理者の最小コード */
  ADMIN_MIN: roles.admin.positionCode.min,
  /** 本部長の範囲 */
  DIVISION_HEAD_MIN: roles.division_head.positionCode.min,
  DIVISION_HEAD_MAX: roles.division_head.positionCode.max,
  /** 部長の範囲 */
  DEPARTMENT_HEAD_MIN: roles.department_head.positionCode.min,
  DEPARTMENT_HEAD_MAX: roles.department_head.positionCode.max,
  /** 課長の範囲 */
  SECTION_HEAD_MIN: roles.section_head.positionCode.min,
  SECTION_HEAD_MAX: roles.section_head.positionCode.max,
  /** 一般メンバーの上限 */
  EMPLOYEE_MAX: roles.employee.positionCode.max,
} as const;

/**
 * アクセスレベルの型定義
 */
export interface AccessLevel {
  min: number;
  max: number;
  description: string;
  canViewSelf: boolean;
  canViewInterviewees: boolean;
  canViewTeam: false | 'section' | 'department' | 'division';
  canViewSubordinates?: number;
}

/**
 * 役職コードベースのデータアクセスレベル定義
 * POSITION_CODE から自動生成されるため、DRY原則に従う
 */
export const ACCESS_LEVELS = {
  /** 一般メンバー（～499）: 自分 + 面談者に設定されている人 */
  self: {
    min: 1,
    max: POSITION_CODE.EMPLOYEE_MAX,
    description: '自分と面談者のデータのみ閲覧可能',
    canViewSelf: true,
    canViewInterviewees: true,
    canViewTeam: false,
  },
  /** 課長（500-699）: 上記 + 同じ課の人（500以下） */
  section: {
    min: POSITION_CODE.SECTION_HEAD_MIN,
    max: POSITION_CODE.SECTION_HEAD_MAX,
    description: '同じ課のメンバー（役職500以下）のデータも閲覧可能',
    canViewSelf: true,
    canViewInterviewees: true,
    canViewTeam: 'section' as const,
    canViewSubordinates: POSITION_CODE.SECTION_HEAD_MIN,
  },
  /** 部長（700-899）: 上記 + 同じ部の人（700以下） */
  department: {
    min: POSITION_CODE.DEPARTMENT_HEAD_MIN,
    max: POSITION_CODE.DEPARTMENT_HEAD_MAX,
    description: '同じ部のメンバー（役職700以下）のデータも閲覧可能',
    canViewSelf: true,
    canViewInterviewees: true,
    canViewTeam: 'department' as const,
    canViewSubordinates: POSITION_CODE.DEPARTMENT_HEAD_MIN,
  },
  /** 本部長（900-999）: 上記 + 同じ本部の人（900以下） */
  division: {
    min: POSITION_CODE.DIVISION_HEAD_MIN,
    max: POSITION_CODE.ADMIN,
    description: '同じ本部のメンバー（役職900以下）のデータも閲覧可能',
    canViewSelf: true,
    canViewInterviewees: true,
    canViewTeam: 'division' as const,
    canViewSubordinates: POSITION_CODE.DIVISION_HEAD_MIN,
  },
} as const satisfies Record<string, AccessLevel>;

/**
 * 役職コードから基本ロールを判定する関数
 * @param positionCode 役職コード
 * @returns ロール名
 */
export function getRoleByPositionCode(positionCode: number | undefined): RoleName {
  if (!positionCode || isNaN(positionCode)) {
    return ROLE.EMPLOYEE; // デフォルト
  }

  // 管理者（990-999）
  if (positionCode >= POSITION_CODE.ADMIN_MIN && positionCode <= POSITION_CODE.ADMIN) {
    return ROLE.ADMIN;
  }

  if (positionCode <= POSITION_CODE.EMPLOYEE_MAX) {
    return ROLE.EMPLOYEE;
  }
  if (positionCode >= POSITION_CODE.SECTION_HEAD_MIN && positionCode <= POSITION_CODE.SECTION_HEAD_MAX) {
    return ROLE.SECTION_HEAD;
  }
  if (positionCode >= POSITION_CODE.DEPARTMENT_HEAD_MIN && positionCode <= POSITION_CODE.DEPARTMENT_HEAD_MAX) {
    return ROLE.DEPARTMENT_HEAD;
  }
  if (positionCode >= POSITION_CODE.DIVISION_HEAD_MIN && positionCode <= POSITION_CODE.DIVISION_HEAD_MAX) {
    return ROLE.DIVISION_HEAD;
  }

  return ROLE.EMPLOYEE; // デフォルト
}

/**
 * 役職コードからアクセスレベルを取得
 * @param positionCode 役職コード
 * @returns アクセスレベル設定（該当なしの場合 null）
 */
export function getAccessLevel(positionCode: number | undefined): AccessLevel | null {
  if (!positionCode) return null;

  // 該当するアクセスレベルを検索
  for (const level of Object.values(ACCESS_LEVELS)) {
    if (positionCode >= level.min && positionCode <= level.max) {
      return level;
    }
  }

  return null;
}
