// src/constants/httpStatus.ts
// HTTPステータスコードのユーティリティ関数
// マスターデータは packages/shared/constants/http_status.yml で管理

import { CONSTANTS } from './schemas';

const httpStatus = CONSTANTS.HTTP_STATUS;

// ============================================================
// エラー定義からの取得ヘルパー
// ============================================================

interface ErrorDefinition {
  code: number | number[] | null;
  triggers?: string[];
  behavior?: string;
  generic: {
    title: string;
    detail: string;
  };
  [context: string]: unknown;
}

type Errors = Record<string, ErrorDefinition>;

const getErrors = (): Errors => httpStatus.errors || {};

/**
 * ステータスコードからエラーキーを取得
 */
const statusToKey = (status: number): string => {
  const errors = getErrors();

  for (const [key, def] of Object.entries(errors)) {
    const code = def.code;
    if (code === null) continue;

    if (Array.isArray(code)) {
      if (code.includes(status)) return key;
    } else if (code === status) {
      return key;
    }
  }

  return 'default';
};

/**
 * 特定のトリガーを持つステータスコードを取得
 */
const getCodesWithTrigger = (trigger: string): number[] => {
  const errors = getErrors();
  const codes: number[] = [];

  for (const def of Object.values(errors)) {
    if (def.triggers?.includes(trigger)) {
      const code = def.code;
      if (code !== null) {
        if (Array.isArray(code)) {
          codes.push(...code);
        } else {
          codes.push(code);
        }
      }
    }
  }

  return codes;
};

/**
 * 特定のbehaviorを持つステータスコードを取得
 */
const getCodesWithBehavior = (behavior: string): number[] => {
  const errors = getErrors();
  const codes: number[] = [];

  for (const def of Object.values(errors)) {
    if (def.behavior === behavior) {
      const code = def.code;
      if (code !== null) {
        if (Array.isArray(code)) {
          codes.push(...code);
        } else {
          codes.push(code);
        }
      }
    }
  }

  return codes;
};

// ============================================================
// ステータスコード定数（errors定義から動的生成）
// ============================================================

/**
 * HTTPステータスコード定数
 * errors定義から動的に生成
 */
export const HTTP_STATUS = (() => {
  const errors = getErrors();
  const result: Record<string, number> = {};

  // エラーキーからステータスコード定数を生成
  const keyToConstName: Record<string, string> = {
    bad_request: 'BAD_REQUEST',
    unauthorized: 'UNAUTHORIZED',
    forbidden: 'FORBIDDEN',
    not_found: 'NOT_FOUND',
    unprocessable: 'UNPROCESSABLE_ENTITY',
    locked: 'LOCKED',
    too_many_requests: 'TOO_MANY_REQUESTS',
    server_error: 'INTERNAL_SERVER_ERROR',
  };

  for (const [key, def] of Object.entries(errors)) {
    const constName = keyToConstName[key];
    if (constName && def.code !== null) {
      // 配列の場合は最初の値を使用
      result[constName] = Array.isArray(def.code) ? def.code[0] : def.code;
    }
  }

  // 成功系は固定値
  result.OK = 200;
  result.CREATED = 201;
  result.NO_CONTENT = 204;

  // server_errorは複数コードがあるので追加
  result.BAD_GATEWAY = 502;
  result.SERVICE_UNAVAILABLE = 503;
  result.GATEWAY_TIMEOUT = 504;

  return result as {
    OK: number;
    CREATED: number;
    NO_CONTENT: number;
    BAD_REQUEST: number;
    UNAUTHORIZED: number;
    FORBIDDEN: number;
    NOT_FOUND: number;
    UNPROCESSABLE_ENTITY: number;
    LOCKED: number;
    TOO_MANY_REQUESTS: number;
    INTERNAL_SERVER_ERROR: number;
    BAD_GATEWAY: number;
    SERVICE_UNAVAILABLE: number;
    GATEWAY_TIMEOUT: number;
  };
})();

/**
 * トークンリフレッシュを試みるステータスコード
 * errors定義のtriggers: [refresh]から動的生成
 */
export const REFRESH_TRIGGER_CODES = getCodesWithTrigger('refresh');

/**
 * トークンリフレッシュをスキップするエンドポイント（認証前API）
 */
export const SKIP_REFRESH_ENDPOINTS = (CONSTANTS.PERMISSIONS?.publicEndpoints ||
  []) as string[];

/**
 * クライアントエラー（400系）かどうかを判定
 * 400系はユーザーが対処可能なエラー → エラーページに飛ばさない
 */
export const isClientError = (status: number): boolean => {
  return status >= 400 && status <= 499;
};

/**
 * サーバーエラー（500系）かどうかを判定
 * behavior: error_page を持つエラーかどうか
 */
export const isServerError = (status: number): boolean => {
  const errorPageCodes = getCodesWithBehavior('error_page');
  return errorPageCodes.includes(status);
};

/**
 * トークンリフレッシュをスキップすべきエンドポイントかどうかを判定
 */
export const shouldSkipRefresh = (endpoint: string): boolean => {
  return SKIP_REFRESH_ENDPOINTS.some((e) => endpoint.startsWith(e));
};

/**
 * トークンリフレッシュを試みるべきステータスコードかどうかを判定
 */
export const shouldTryRefresh = (status: number): boolean => {
  return REFRESH_TRIGGER_CODES.includes(status);
};

// ============================================================
// エラーメッセージ取得関数
// ============================================================

interface ErrorMessage {
  title: string;
  detail: string;
}

/**
 * エラーキーとコンテキストからメッセージを取得
 *
 * @param key エラーキー（"unauthorized", "password_incorrect"など）
 * @param context コンテキスト（"generic", "pleasanter"など）
 * @param replacements プレースホルダーの置換値
 */
export const getError = (
  key: string,
  context: string = 'generic',
  replacements?: Record<string, string | number>
): string => {
  const errors = getErrors();
  const errorDef = errors[key] || errors.default;

  let message: string;

  // コンテキスト固有メッセージがあればそれを使用
  if (context !== 'generic' && typeof errorDef[context] === 'string') {
    message = errorDef[context] as string;
  } else {
    message = errorDef?.generic?.detail || `エラーが発生しました (${key})`;
  }

  // プレースホルダーを置換
  if (replacements) {
    Object.entries(replacements).forEach(([placeholder, value]) => {
      message = message.replace(`{${placeholder}}`, String(value));
    });
  }

  return message;
};

/**
 * ステータスコードからエラーメッセージを取得
 *
 * @param status HTTPステータスコード
 * @param context コンテキスト（"generic", "pleasanter"など）
 * @param replacements プレースホルダーの置換値
 */
export const getErrorByStatus = (
  status: number,
  context: string = 'generic',
  replacements?: Record<string, string | number>
): string => {
  const key = statusToKey(status);
  return getError(key, context, { status_code: status, ...replacements });
};

/**
 * ステータスコードに対応する汎用エラーメッセージを取得（title/detail形式）
 */
export const getGenericErrorMessage = (status: number): ErrorMessage => {
  const errors = getErrors();
  const key = statusToKey(status);
  const errorDef = errors[key] || errors.default;

  return {
    title: errorDef?.generic?.title || 'エラー',
    detail: errorDef?.generic?.detail || 'エラーが発生しました',
  };
};

/**
 * カテゴリとキーからエラーメッセージを取得
 * @deprecated 後方互換性のため残存。getError(key)を使用してください
 */
export const getErrorMessage = (
  _category: string,
  key: string,
  replacements?: Record<string, string | number>
): string => {
  return getError(key, 'generic', replacements);
};
