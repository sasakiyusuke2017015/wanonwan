/**
 * 定数のバレルエクスポート
 *
 * 使用例:
 * import { ROLE, ROUTES } from '@/constants';
 *
 * NOTE: UI共通定数は @ui-catalog/core/constants から直接インポートすることを推奨
 */

// アプリ固有の定数
export * from './app';
export * from './httpStatus';
export * from './roles';
export * from './routes';
export * from './schemas';
export * from './storage';

// UI共通定数（テーマ型など）
export * from '@ui-catalog/core/constants';
