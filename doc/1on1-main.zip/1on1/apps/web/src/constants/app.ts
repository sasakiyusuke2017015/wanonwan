/**
 * アプリケーション設定定数
 * アプリ固有の設定値を定義
 *
 * NOTE: UI共通定数（LAYOUT_SIZES等）は @ui-catalog/core/constants を使用
 */

/**
 * アプリケーション全般の設定
 */
export const APP_CONFIG = {
  /** 過去何ヶ月分のデータを表示するか */
  RECENT_MONTHS: 24,
  /** APIタイムアウト時間（ミリ秒）- 1分 */
  API_TIMEOUT: 60 * 1000,
  /** アイドルタイムアウト時間（ミリ秒）- 8時間 */
  IDLE_TIMEOUT: 8 * 60 * 60 * 1000,
  /** アイドルチェック間隔（ミリ秒）- 1分 */
  IDLE_CHECK_INTERVAL: 60 * 1000,
} as const;

// UI共通定数（レイアウトサイズ等）
export { LAYOUT_SIZES } from '@ui-catalog/core/constants';
