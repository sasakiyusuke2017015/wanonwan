// src/constants/routes.ts

import type { RouteConfig, BreadcrumbItemConfig } from '@/types';




/**
 * アプリケーションのルートパス定義（拡張版）
 * パス、ラベル、アイコン、ナビゲーション表示フラグ、パンくずを含む
 */
export const ROUTES = {
  HOME: {
    path: '/home',
    label: 'HOME',
    icon: 'home',
    showInNav: false,
    breadcrumb: () => [{ label: import.meta.env.VITE_APP_NAME ?? '1on1', href: '/', size: 'xl' as const }],
  },
  DASHBOARD: {
    path: '/dashboard',
    label: '全社ダッシュボード',
    icon: 'dashboard',
    showInNav: true,
    breadcrumb: () => [{ label: '全社ダッシュボード', href: '/dashboard' }],
  },
  ANSWERS: {
    path: '/answers',
    label: '回答一覧',
    icon: 'employee',
    showInNav: true,
    breadcrumb: () => [{ label: '回答一覧', href: '/answers' }],
  },
  ANSWER_DETAIL: {
    path: '/answers/details',
    label: '回答詳細',
    showInNav: false,
    breadcrumb: () => [{ label: '回答詳細', href: '/answers/details' }],
  },
  SURVEYS: {
    path: '/surveys',
    label: 'アンケート',
    icon: 'survey',
    showInNav: true,
    breadcrumb: () => [{ label: 'アンケート一覧', href: '/surveys' }],
  },
  SCHEDULE: {
    path: '/schedule',
    label: 'スケジュール',
    icon: 'calendar',
    showInNav: true,
    breadcrumb: () => [{ label: 'スケジュール', href: '/schedule' }],
  },
  CHAT: {
    path: '/chat',
    label: 'チャット',
    icon: 'chat',
    showInNav: false,
    breadcrumb: () => [{ label: 'チャット', href: '/chat' }],
  },
  ATTENDANCE: {
    path: '/attendance',
    label: '勤怠',
    icon: 'clock',
    showInNav: false,
    breadcrumb: () => [{ label: '勤怠管理', href: '/attendance' }],
  },
  PROJECT: {
    path: '/project',
    label: 'プロジェクト',
    icon: 'folder',
    showInNav: false,
    breadcrumb: () => [{ label: 'プロジェクト', href: '/project' }],
  },
  SURVEY_DETAIL: {
    path: '/surveys/:id',
    label: 'アンケート詳細',
    showInNav: false,
    breadcrumb: (params?: Record<string, string>) => [
      // { label: 'アンケート', href: '/surveys' },
      { label: params?.title || 'アンケート詳細', href: `/surveys/${params?.id || ':id'}` },
    ],
  },
  ERROR: {
    path: '/error',
    label: 'エラー画面',
    showInNav: false,
  },
  ABOUT: {
    path: '/about',
    label: 'このアプリについて',
    showInNav: false,
  },
  CHANGE_PASSWORD: {
    path: '/change-password',
    label: 'パスワード変更',
    showInNav: false,
  },
  LOGIN: {
    path: '/login',
    label: 'ログイン',
    showInNav: false,
  },
} as const satisfies Record<string, RouteConfig>;

/**
 * ルートパスの型
 */
export type RoutePath = (typeof ROUTES)[keyof typeof ROUTES]['path'];

/** showInNav: true かつ icon を持つルートキーの型 */
type NavRouteKey = {
  [K in keyof typeof ROUTES]: (typeof ROUTES)[K] extends { showInNav: true; icon: string } ? K : never;
}[keyof typeof ROUTES];

/**
 * ナビゲーション表示対象のルートキー（showInNav: true かつ icon を持つもの）
 * 左ペイン・ログイン後遷移先・ヘッダーロゴ遷移先で共通使用
 *
 * ROUTES に showInNav: true を追加すれば自動的にここに含まれる
 */
export const NAV_ROUTE_KEYS = (
  Object.keys(ROUTES) as (keyof typeof ROUTES)[]
).filter((key): key is NavRouteKey => {
  const route = ROUTES[key];
  return route.showInNav && 'icon' in route;
});

/**
 * パンくずリストを生成する関数
 *
 * @param routePattern - ルートパターン（例: '/employees/:id'）
 * @param params - 動的パラメータ（例: { id: '123', name: '田中太郎' }）
 * @returns パンくずリストの配列
 *
 * @example
 * ```tsx
 * // 回答詳細ページ
 * const breadcrumbs = getBreadcrumbs('/answers/details');
 * // => [
 * //   { label: '回答詳細', href: '/answers/details' }
 * // ]
 * ```
 */
export function getBreadcrumbs(
  routePattern: string,
  params?: Record<string, string>
): BreadcrumbItemConfig[] {
  // ROUTESからパスが一致するルートを検索
  const route = Object.values(ROUTES).find((r) => r.path === routePattern);

  if (route && 'breadcrumb' in route && typeof route.breadcrumb === 'function') {
    return route.breadcrumb(params);
  }

  // デフォルトでHOMEのみ返す
  return [{ label: import.meta.env.VITE_APP_NAME ?? '1on1', href: '/', size: 'xl' as const }];
}
