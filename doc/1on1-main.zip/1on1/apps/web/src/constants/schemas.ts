/**
 * スキーマ定義・マスターデータ
 *
 * 区分値（回答状況・掲載状況・健康状態・面談方式）は
 * Pleasanter Wiki サイトが唯一の定義元。
 * libs/domain/generated/schemas.ts から自動生成された定数を使用。
 *
 * DEFINITIONS（評価項目）、PERMISSIONS、HTTP_STATUS は
 * libs/domain/config.ts から取得（Pleasanter 非依存）。
 */
import { DEFINITIONS, PERMISSIONS, HTTP_STATUS } from '@1on1/domain/config'
import { 回答状況, 掲載状況, 健康状態, 面談方式 } from '@1on1/domain/generated/schemas'

/**
 * CONSTANTS - アプリケーション全体で使用するスキーマ定義
 */
export const CONSTANTS = {
  ANSWER_STATUS: 回答状況,
  HEALTH_STATUS: 健康状態,
  PUBLICATION_STATUS: 掲載状況,
  INTERVIEW_METHOD: 面談方式,
  ASSESSMENT_ITEM: DEFINITIONS['評価項目'],
  PERMISSIONS: PERMISSIONS,
  HTTP_STATUS: HTTP_STATUS,
}
