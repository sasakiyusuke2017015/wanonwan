/**
 * テスト用ヘルパー関数
 *
 * Buttonコンポーネントがdiv[role="button"]と<button>の両方を生成する問題に対応
 */
import { screen, within } from '@testing-library/react';

/**
 * role="button"を持つ要素から実際の<button>要素のみを取得
 *
 * Buttonコンポーネントは以下の構造を生成:
 * <div role="button">  ← ラッパー
 *   <button>...</button>  ← 実際のボタン
 * </div>
 *
 * getAllByRoleでは両方がマッチするため、<button>要素のみをフィルタリング
 */
export const getActualButton = (
  name: string | RegExp,
  container?: HTMLElement
): HTMLButtonElement | undefined => {
  const searchContext = container ? within(container) : screen;
  const buttons = searchContext.getAllByRole('button', { name });
  return buttons.find((el) => el.tagName === 'BUTTON') as HTMLButtonElement | undefined;
};

/**
 * role="button"を持つ要素から実際の<button>要素のみを取得（必須版）
 * 要素が見つからない場合はエラーをスロー
 */
export const getActualButtonRequired = (
  name: string | RegExp,
  container?: HTMLElement
): HTMLButtonElement => {
  const button = getActualButton(name, container);
  if (!button) {
    throw new Error(`Button with name "${name}" not found`);
  }
  return button;
};

/**
 * role="button"を持つ要素から実際の<button>要素を全て取得
 */
export const getAllActualButtons = (
  name: string | RegExp,
  container?: HTMLElement
): HTMLButtonElement[] => {
  const searchContext = container ? within(container) : screen;
  const buttons = searchContext.getAllByRole('button', { name });
  return buttons.filter((el) => el.tagName === 'BUTTON') as HTMLButtonElement[];
};

/**
 * queryByRoleの<button>版（見つからない場合はnull）
 */
export const queryActualButton = (
  name: string | RegExp,
  container?: HTMLElement
): HTMLButtonElement | null => {
  const searchContext = container ? within(container) : screen;
  const buttons = searchContext.queryAllByRole('button', { name });
  const button = buttons.find((el) => el.tagName === 'BUTTON');
  return (button as HTMLButtonElement) || null;
};
