import '@testing-library/jest-dom'
import type React from 'react'
import { vi } from 'vitest'

// Type helpers for framer-motion mock forwardRef components
type MockProps = Record<string, unknown> & { children?: React.ReactNode }
type MockRef = React.ForwardedRef<HTMLElement>
type MotionValue<T = number> = {
  get: () => T
  set: ReturnType<typeof vi.fn>
  onChange?: ReturnType<typeof vi.fn>
}

// Mock framer-motion to prevent animation-related hangs in tests
vi.mock('framer-motion', async () => {
  const React = await import('react')
  return {
    motion: {
      div: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('div', { ...props, ref }, children)
      ),
      span: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('span', { ...props, ref }, children)
      ),
      button: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('button', { ...props, ref }, children)
      ),
      ul: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('ul', { ...props, ref }, children)
      ),
      li: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('li', { ...props, ref }, children)
      ),
      a: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('a', { ...props, ref }, children)
      ),
      nav: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('nav', { ...props, ref }, children)
      ),
      header: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('header', { ...props, ref }, children)
      ),
      footer: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('footer', { ...props, ref }, children)
      ),
      section: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('section', { ...props, ref }, children)
      ),
      article: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('article', { ...props, ref }, children)
      ),
      aside: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('aside', { ...props, ref }, children)
      ),
      main: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('main', { ...props, ref }, children)
      ),
      form: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('form', { ...props, ref }, children)
      ),
      input: React.forwardRef((props: Record<string, unknown>, ref: MockRef) =>
        React.createElement('input', { ...props, ref })
      ),
      img: React.forwardRef((props: Record<string, unknown>, ref: MockRef) =>
        React.createElement('img', { ...props, ref })
      ),
      svg: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('svg', { ...props, ref }, children)
      ),
      path: React.forwardRef((props: Record<string, unknown>, ref: MockRef) =>
        React.createElement('path', { ...props, ref })
      ),
      p: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('p', { ...props, ref }, children)
      ),
      h1: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h1', { ...props, ref }, children)
      ),
      h2: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h2', { ...props, ref }, children)
      ),
      h3: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h3', { ...props, ref }, children)
      ),
      h4: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h4', { ...props, ref }, children)
      ),
      h5: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h5', { ...props, ref }, children)
      ),
      h6: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('h6', { ...props, ref }, children)
      ),
      table: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('table', { ...props, ref }, children)
      ),
      thead: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('thead', { ...props, ref }, children)
      ),
      tbody: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('tbody', { ...props, ref }, children)
      ),
      tr: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('tr', { ...props, ref }, children)
      ),
      td: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('td', { ...props, ref }, children)
      ),
      th: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('th', { ...props, ref }, children)
      ),
      label: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('label', { ...props, ref }, children)
      ),
      textarea: React.forwardRef((props: Record<string, unknown>, ref: MockRef) =>
        React.createElement('textarea', { ...props, ref })
      ),
      select: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('select', { ...props, ref }, children)
      ),
      option: React.forwardRef(({ children, ...props }: MockProps, ref: MockRef) =>
        React.createElement('option', { ...props, ref }, children)
      ),
    },
    AnimatePresence: ({ children }: { children?: React.ReactNode }) => children,
    useAnimation: () => ({
      start: vi.fn(),
      stop: vi.fn(),
      set: vi.fn(),
    }),
    useMotionValue: (initial: number): MotionValue => ({
      get: () => initial,
      set: vi.fn(),
      onChange: vi.fn(),
    }),
    useTransform: (_value: MotionValue, _input: number[], output: number[]): MotionValue => ({
      get: () => output[0],
      set: vi.fn(),
    }),
    useSpring: (value: number | MotionValue): MotionValue => ({
      get: () => (typeof value === 'number' ? value : value?.get?.() ?? 0),
      set: vi.fn(),
    }),
    useInView: () => true,
    useScroll: () => ({
      scrollX: { get: () => 0, set: vi.fn() },
      scrollY: { get: () => 0, set: vi.fn() },
      scrollXProgress: { get: () => 0, set: vi.fn() },
      scrollYProgress: { get: () => 0, set: vi.fn() },
    }),
    useReducedMotion: () => false,
    useWillChange: () => 'auto',
    useDragControls: () => ({
      start: vi.fn(),
    }),
  }
})

// ResizeObserver mock for Recharts
class ResizeObserverMock implements ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}
global.ResizeObserver = ResizeObserverMock

// IntersectionObserver mock for framer-motion useInView
class IntersectionObserverMock implements IntersectionObserver {
  readonly root: Element | null = null
  readonly rootMargin: string = ''
  readonly thresholds: ReadonlyArray<number> = []
  observe() {}
  unobserve() {}
  disconnect() {}
  takeRecords(): IntersectionObserverEntry[] {
    return []
  }
}
global.IntersectionObserver = IntersectionObserverMock
