/**
 * Providers
 *
 * クライアントサイドで必要なプロバイダーを統合
 */

import { useState, useEffect } from 'react'
import { Provider as JotaiProvider } from 'jotai'
import { QueryClient, QueryClientProvider, QueryCache, MutationCache } from '@tanstack/react-query'
import { RouterProvider, AuthProvider } from '@/adapters'
import { reactRouterAdapter } from '@/adapters/react-router'
import { useAuthAdapter } from '@/hooks/useAuthAdapter'
import { STORAGE_KEYS } from '@/constants/storage'
import { ApiError } from '@/lib/api'
import { clearAuthTokens, queryClientRef } from '@/lib/auth/index'

/**
 * 認証エラーかどうかを判定
 */
function isUnauthorizedError(error: unknown): boolean {
  if (error instanceof ApiError) {
    return error.status === 401 || error.code === 'UNAUTHORIZED'
  }
  return false
}

/**
 * React Query Provider
 */
function QueryProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () => {
      const client = new QueryClient({
        defaultOptions: {
          queries: {
            retry: (failureCount, error) => {
              if (isUnauthorizedError(error)) {
                return false
              }
              return failureCount < 3
            },
            staleTime: 5 * 60 * 1000, // 5分
          },
        },
        queryCache: new QueryCache({
          onError: (error) => {
            if (isUnauthorizedError(error)) {
              console.log('Unauthorized - logging out')
              clearAuthTokens()
              window.location.href = '/login'
            }
          },
        }),
        mutationCache: new MutationCache({
          onError: (error) => {
            if (isUnauthorizedError(error)) {
              console.log('Unauthorized - logging out')
              clearAuthTokens()
              window.location.href = '/login'
            }
          },
        }),
      })
      // login/logout 時のキャッシュクリアで使用
      queryClientRef.current = client
      return client
    }
  )

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
}

/**
 * 認証プロバイダーラッパー
 * useAuthAdapter フックは React コンポーネント内で呼ぶ必要がある
 *
 * 他タブでのユーザー切り替えを storage イベントで検知し、
 * キャッシュ不整合を防ぐためにリロードする
 */
function AuthProviderWrapper({ children }: { children: React.ReactNode }) {
  const authAdapter = useAuthAdapter()

  // 他タブでのユーザー切り替え検知
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (
        event.key === STORAGE_KEYS.LAST_AUTH_USER_ID &&
        event.oldValue !== null &&
        event.newValue !== null &&
        event.oldValue !== event.newValue
      ) {
        // 別タブで別ユーザーがログインした → キャッシュ不整合を防ぐためリロード
        window.location.reload()
      }
    }
    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])

  return <AuthProvider adapter={authAdapter}>{children}</AuthProvider>
}

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <JotaiProvider>
      <AuthProviderWrapper>
        <RouterProvider adapter={reactRouterAdapter}>
          <QueryProvider>{children}</QueryProvider>
        </RouterProvider>
      </AuthProviderWrapper>
    </JotaiProvider>
  )
}
