/**
 * 日付フィルタリング用ユーティリティ関数
 * 一覧画面と詳細画面で共通使用
 *
 * ドメイン固有のフィルタリング関数（result['開始'] など日本語キー依存）
 */

import { formatDateForComparison } from '@1on1/domain/utils/date';

/** 回答結果レコード（開始日等の日本語キーを持つ） */
type AnswerResultRecord = Record<string, unknown>;

/**
 * displayDateに一致する回答結果を検索
 * @param answerResults - 回答結果の配列
 * @param displayDate - 表示対象日付 例: "2025-01"
 * @returns 一致する回答結果またはnull
 */
export function findAnswerByDisplayDate<T extends AnswerResultRecord>(
  answerResults: T[],
  displayDate: string
): T | null {
  if (!answerResults || !displayDate) return null;

  const targetDate = displayDate.substring(0, 7);
  return answerResults.find(result => {
    const startDate = result['開始'];
    if (!startDate || typeof startDate !== 'string') return false;
    return formatDateForComparison(startDate) === targetDate;
  }) || null;
}

/**
 * displayDateに一致する回答結果があるかチェック
 * @param answerResults - 回答結果の配列
 * @param displayDate - 表示対象日付 例: "2025-01"
 * @returns 一致する結果があるかどうか
 */
export function hasAnswerForDisplayDate<T extends AnswerResultRecord>(
  answerResults: T[],
  displayDate: string
): boolean {
  if (!answerResults || !displayDate) return false;

  const targetDate = displayDate.substring(0, 7);
  return answerResults.some(result => {
    const startDate = result['開始'];
    if (!startDate || typeof startDate !== 'string') return false;
    return formatDateForComparison(startDate) === targetDate;
  });
}

/**
 * displayDateから過去指定か月分のデータを取得
 * @param answerResults - 回答結果の配列
 * @param displayDate - 基準日付 例: "2025-01"
 * @param months - 取得する月数 例: 3
 * @returns 過去指定か月分の回答結果
 */
export function getRecentAnswers<T extends AnswerResultRecord>(
  answerResults: T[],
  displayDate: string,
  months: number = 3
): T[] {
  if (!answerResults || !displayDate) return [];

  // displayDateから過去のターゲット日付を生成
  const baseDate = new Date(displayDate + '-01');
  const targetDates: string[] = [];

  for (let i = 0; i < months; i++) {
    const targetDate = new Date(baseDate);
    targetDate.setMonth(targetDate.getMonth() - i);
    const yearMonth = targetDate.toISOString().substring(0, 7); // "2025-01"
    targetDates.push(yearMonth);
  }

  // 該当する回答結果を抽出・ソート
  const filteredAnswers = answerResults.filter(result => {
    const startDate = result['開始'];
    if (!startDate || typeof startDate !== 'string') return false;
    const yearMonth = formatDateForComparison(startDate);
    return targetDates.includes(yearMonth);
  });

  // 日付順でソート（古い順：過去→現在)
  return filteredAnswers.sort((a, b) => {
    const dateA = new Date(formatDateForComparison(String(a['開始'] || '')) + '-01');
    const dateB = new Date(formatDateForComparison(String(b['開始'] || '')) + '-01');
    return dateA.getTime() - dateB.getTime();
  });
}
