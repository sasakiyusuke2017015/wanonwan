/**
 * apps/web 専用ユーティリティ
 *
 * アプリケーション固有の依存（roles, constants等）を持つユーティリティ
 */

export * from './permissions'
