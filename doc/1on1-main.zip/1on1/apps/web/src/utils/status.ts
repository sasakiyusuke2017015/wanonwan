/**
 * ステータスコード → ラベル変換ユーティリティ（apps/web 専用）
 *
 * libs/domain から移動。generated/schemas に依存するため apps 側に配置。
 */

import { 回答状況, 掲載状況 } from '@1on1/domain/generated/schemas'

// ===========================
// 回答状況ラベル
// ===========================

const VALUE_TO_LABEL = Object.fromEntries(
  Object.entries(回答状況).map(([label, def]) => [def.value, label])
)

/**
 * 回答状況コードをラベルに変換
 * @param code 数値コード
 * @returns ラベル文字列
 */
export function getAnswerStatusLabel(code: number | undefined): string {
  if (code === undefined) return '未回答'
  return VALUE_TO_LABEL[code] ?? '未回答'
}

// ===========================
// 健康状態ラベル
// ===========================

/** 健康状態コード → ラベル マッピング */
const HEALTH_STATUS_MAP: Record<number, string> = {
  100: '未判定',
  200: '非常に良好',
  300: '良好',
  400: '要観察',
  500: '環境課題あり',
  600: '不満あり',
  700: '疲労あり',
  800: '要注意',
  900: '過重負荷',
  999: '要緊急対応',
}

/**
 * 健康状態コードをラベルに変換
 * @param code 数値コード
 * @returns ラベル文字列（該当なしは null）
 */
export function getHealthStatusLabel(code: number | undefined): string | null {
  if (code === undefined) return null
  return HEALTH_STATUS_MAP[code] ?? null
}

// ===========================
// 掲載状況判定
// ===========================

/**
 * 掲載状況が実施中かどうか判定
 */
export function isPublishActive(status: number | undefined): boolean {
  return status === 掲載状況['実施中'].value
}

/**
 * 掲載状況が完了かどうか判定
 */
export function isPublishCompleted(status: number | undefined): boolean {
  return status === 掲載状況['完了'].value
}
