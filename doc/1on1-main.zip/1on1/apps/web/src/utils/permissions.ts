/**
 * 権限フィルタリングユーティリティ（RBAC）
 * ユーザーのロールから許可されたリンク・API・機能の一覧を抽出
 *
 * 使用方法:
 * - userInfo['役職コード'] から自動的にロールを判定
 * - 判定されるロール: 'employee' | 'section_head' | 'department_head' | 'division_head' | 'admin'
 */
import type { Permissions, RolePermissions } from '@1on1/domain/types/config';
import { CONSTANTS } from '@/constants';
import {
  ROLE,
  type RoleName,
  getRoleByPositionCode,
  getAccessLevel,
} from '@/constants/roles';

/** 継承対応ロール（将来の拡張用にinheritsフィールドをオプショナルで保持） */
interface RoleWithInheritance {
  description: string;
  inherits?: string;
  permissions: RolePermissions;
  positionCode: { min: number; max: number };
}

/** 継承解決済みロール */
interface ResolvedRole {
  description: string;
  permissions: RolePermissions;
}

export interface AllowedFeatures {
  notifications?: boolean;
  export?: boolean;
  userManagement?: boolean;
  systemSettings?: boolean;
}

export interface PermissionData {
  allowedLinks: string[];
  allowedAPIs: string[];
  allowedFeatures: AllowedFeatures;
}

/**
 * 回答データ閲覧判定用の情報
 */
export interface AnswerViewTarget {
  userId: string;           // 対象ユーザーID
  positionCode?: number;    // 対象ユーザーの役職コード
  division?: string;        // 対象ユーザーの所属本部
  department?: string;      // 対象ユーザーの所属部
  section?: string;         // 対象ユーザーの所属課
  interviewerIds?: string[]; // 面談者IDリスト
}

/**
 * ロールから権限を継承して展開する
 */
function resolveRoleWithInheritance(
  roleName: string,
  permissions: Permissions
): ResolvedRole | null {
  const role = permissions.roles?.[roleName] as RoleWithInheritance | undefined;
  if (!role) return null;

  // 継承がない場合はそのまま返す
  if (!role.inherits) {
    return role;
  }

  // 継承元を再帰的に解決
  const parentRole = resolveRoleWithInheritance(role.inherits, permissions);
  if (!parentRole) {
    return role;
  }

  // 親ロールと現在のロールの権限をマージ
  return {
    description: role.description,
    permissions: {
      page: [
        ...(parentRole.permissions?.page || []),
        ...(role.permissions?.page || []),
      ],
      api: [
        ...(parentRole.permissions?.api || []),
        ...(role.permissions?.api || []),
      ],
      feature: [
        ...(parentRole.permissions?.feature || []),
        ...(role.permissions?.feature || []),
      ],
    },
  };
}

/**
 * ユーザー情報から権限情報を抽出する（RBAC）
 * @param userInfo ユーザー情報オブジェクト（userInfo['ロール']が必須）
 * @returns 許可されたリンク・API・機能の一覧
 */
export const filterPermissions = (
  userInfo: Record<string, unknown> | null | undefined
): PermissionData => {
  if (!userInfo) {
    return { allowedLinks: [], allowedAPIs: [], allowedFeatures: {} };
  }

  const permissions = CONSTANTS.PERMISSIONS;

  // ユーザーのロールを決定
  // 役職コードから基本ロールを判定

  // 役職コードから基本ロールを取得
  const positionCodeStr = userInfo['役職コード'] as string | undefined;
  const positionCode = positionCodeStr ? parseInt(positionCodeStr, 10) : undefined;
  const userRole = getRoleByPositionCode(positionCode);

  if (!userRole || !permissions.roles?.[userRole]) {
    return { allowedLinks: [], allowedAPIs: [], allowedFeatures: {} };
  }

  // 継承を含めてロールを解決
  const role = resolveRoleWithInheritance(userRole, permissions);

  if (!role || !role.permissions) {
    return { allowedLinks: [], allowedAPIs: [], allowedFeatures: {} };
  }

  // allowedLinks, allowedAPIs, allowedFeatures を展開
  const allAllowedLinks = new Set<string>();
  const allAllowedAPIs = new Set<string>();
  const allAllowedFeatures: AllowedFeatures = {};

  // ページ権限を展開（新しい構造: permissions.page.{ページ名}.path）
  if (role.permissions.page && Array.isArray(role.permissions.page)) {
    role.permissions.page.forEach((pageKey: string) => {
      const pageDef = permissions.permissions?.page?.[pageKey];
      if (pageDef && typeof pageDef === 'object') {
        const path = pageDef.path;
        if (path && typeof path === 'string') {
          allAllowedLinks.add(path);
        }
      }
    });
  }

  // API権限を展開（新しい構造: permissions.api.{API名}.endpoints）
  if (role.permissions.api && Array.isArray(role.permissions.api)) {
    role.permissions.api.forEach((apiKey: string) => {
      const apiDef = permissions.permissions?.api?.[apiKey];
      if (apiDef && typeof apiDef === 'object') {
        const endpoints = apiDef.endpoints;
        if (endpoints && Array.isArray(endpoints)) {
          endpoints.forEach((endpoint: string) => allAllowedAPIs.add(endpoint));
        }
      }
    });
  }

  // 機能権限を展開
  if (role.permissions.feature && Array.isArray(role.permissions.feature)) {
    role.permissions.feature.forEach((featureKey: string) => {
      if (featureKey === 'notifications') allAllowedFeatures.notifications = true;
      if (featureKey === 'export') allAllowedFeatures.export = true;
      if (featureKey === 'user_management') allAllowedFeatures.userManagement = true;
      if (featureKey === 'system_settings') allAllowedFeatures.systemSettings = true;
    });
  }

  return {
    allowedLinks: Array.from(allAllowedLinks),
    allowedAPIs: Array.from(allAllowedAPIs),
    allowedFeatures: allAllowedFeatures,
  };
};


/**
 * 回答データの閲覧権限を判定
 * @param currentUser 現在のユーザー情報
 * @param target 閲覧対象の情報
 * @returns 閲覧可能かどうか
 */
export const canViewAnswer = (
  currentUser: Record<string, unknown> | null | undefined,
  target: AnswerViewTarget
): boolean => {
  if (!currentUser) return false;

  // 管理者ロールは全て閲覧可能
  const userRole = currentUser['ロール'] as RoleName | undefined;
  if (userRole === ROLE.ADMIN) {
    return true;
  }

  // 現在のユーザー情報を取得
  const currentUserId = currentUser['ユーザーID'] as string | undefined;
  const currentPositionCode = parseInt(currentUser['役職コード'] as string, 10);
  const currentDivision = currentUser['所属本部'] as string | undefined;
  const currentDepartment = currentUser['所属部'] as string | undefined;
  const currentSection = currentUser['所属課'] as string | undefined;

  // アクセスレベルを取得
  const accessLevel = getAccessLevel(currentPositionCode);
  if (!accessLevel) return false;

  // 1. 自分自身のデータ
  if (accessLevel.canViewSelf && currentUserId === target.userId) {
    return true;
  }

  // 2. 面談者に設定されている人のデータ
  if (accessLevel.canViewInterviewees && target.interviewerIds?.includes(currentUserId || '')) {
    return true;
  }

  // 3. チームメンバーのデータ
  if (accessLevel.canViewTeam && target.positionCode) {
    // 対象者の役職が自分より下位（数値が小さい）かチェック
    if (target.positionCode > (accessLevel.canViewSubordinates || 0)) {
      return false;
    }

    // 所属組織のチェック
    if (accessLevel.canViewTeam === 'section') {
      // 同じ課
      return currentDivision === target.division &&
             currentDepartment === target.department &&
             currentSection === target.section;
    } else if (accessLevel.canViewTeam === 'department') {
      // 同じ部
      return currentDivision === target.division &&
             currentDepartment === target.department;
    } else if (accessLevel.canViewTeam === 'division') {
      // 同じ本部
      return currentDivision === target.division;
    }
  }

  return false;
};
