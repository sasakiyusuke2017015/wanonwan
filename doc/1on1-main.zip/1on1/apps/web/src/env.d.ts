/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL: string
  /** デフォルトカラーテーマ: emerald | slate | indigo | blue | rose | light */
  readonly VITE_DEFAULT_COLOR_THEME?: string
  /** デフォルト形状テーマ: soft | rounded | sharp */
  readonly VITE_DEFAULT_SHAPE_THEME?: string
  /** デフォルト背景テーマ: default | wood | paper | fabric | stone | cream */
  readonly VITE_DEFAULT_BACKGROUND_THEME?: string
  /** UIスタイル設定メニュー表示: true | false */
  readonly VITE_SHOW_STYLE_SETTINGS?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
