/**
 * 認証ヘルパー関数
 *
 * Cookie ベースの認証を提供します。
 */

/**
 * Cookie名の定数
 */
export const AUTH_COOKIE_NAMES = {
  ACCESS_TOKEN: 'access_token',
  REFRESH_TOKEN: 'refresh_token',
} as const

/**
 * Cookieオプション
 */
const COOKIE_OPTIONS = {
  path: '/',
  // HttpOnly はクライアント側で設定できないため、XSS対策として重要なデータは暗号化推奨
  sameSite: 'lax' as const,
  // Secure フラグ: 本番ビルドでは自動的に有効化
  secure: import.meta.env.PROD,
}

/**
 * Cookieにトークンを保存
 */
export function setAuthTokens(accessToken: string, refreshToken: string): void {
  // アクセストークン（30分）
  const accessTokenExpiry = new Date()
  accessTokenExpiry.setMinutes(accessTokenExpiry.getMinutes() + 30)

  document.cookie = `${AUTH_COOKIE_NAMES.ACCESS_TOKEN}=${accessToken}; expires=${accessTokenExpiry.toUTCString()}; path=${COOKIE_OPTIONS.path}; SameSite=${COOKIE_OPTIONS.sameSite}${COOKIE_OPTIONS.secure ? '; Secure' : ''}`

  // リフレッシュトークン（7日）
  const refreshTokenExpiry = new Date()
  refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + 7)

  document.cookie = `${AUTH_COOKIE_NAMES.REFRESH_TOKEN}=${refreshToken}; expires=${refreshTokenExpiry.toUTCString()}; path=${COOKIE_OPTIONS.path}; SameSite=${COOKIE_OPTIONS.sameSite}${COOKIE_OPTIONS.secure ? '; Secure' : ''}`
}

/**
 * Cookieからトークンを取得
 */
export function getAuthToken(name: keyof typeof AUTH_COOKIE_NAMES): string | null {
  const cookieName = AUTH_COOKIE_NAMES[name]

  if (typeof document === 'undefined') {
    // サーバーサイドの場合はnullを返す
    return null
  }

  const cookies = document.cookie.split(';')
  for (const cookie of cookies) {
    const [key, value] = cookie.trim().split('=')
    if (key === cookieName) {
      return value
    }
  }
  return null
}

/**
 * 認証Cookieをクリア（ログアウト）
 */
export function clearAuthTokens(): void {
  // 過去の日付を設定して削除
  const pastDate = new Date(0).toUTCString()

  document.cookie = `${AUTH_COOKIE_NAMES.ACCESS_TOKEN}=; expires=${pastDate}; path=${COOKIE_OPTIONS.path}`
  document.cookie = `${AUTH_COOKIE_NAMES.REFRESH_TOKEN}=; expires=${pastDate}; path=${COOKIE_OPTIONS.path}`
}

/**
 * 認証状態をチェック
 */
export function isAuthenticated(): boolean {
  return getAuthToken('ACCESS_TOKEN') !== null
}
