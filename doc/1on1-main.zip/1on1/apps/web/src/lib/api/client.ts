/**
 * REST API Client
 *
 * fetch ベースの API クライアント
 */

import { getAuthToken, clearAuthTokens } from '@/lib/auth/index'
import { getApiUrl } from '@/config/env'

/**
 * API エラー
 */
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public detail?: string
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

/**
 * fetch ラッパー
 *
 * - 認証ヘッダーを自動付与
 * - エラーハンドリング
 * - 401 時の自動ログアウト
 */
export async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const apiUrl = getApiUrl()
  const url = `${apiUrl}${endpoint}`

  const token = getAuthToken('ACCESS_TOKEN')
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  }

  const response = await fetch(url, {
    ...options,
    headers,
  })

  if (!response.ok) {
    // 401 の場合はログアウト
    if (response.status === 401) {
      console.log('Unauthorized - logging out')
      clearAuthTokens()
      window.location.href = '/login'
      throw new ApiError(401, 'UNAUTHORIZED', '認証が必要です')
    }

    // エラーレスポンスをパース
    let errorData: { code?: string; message?: string; detail?: string } = {}
    try {
      errorData = await response.json()
    } catch {
      // JSON パース失敗時は空のまま
    }

    throw new ApiError(
      response.status,
      errorData.code || String(response.status),
      errorData.message || response.statusText,
      errorData.detail
    )
  }

  return response.json()
}

/**
 * GET リクエスト
 */
export function apiGet<T>(endpoint: string, params?: Record<string, unknown>): Promise<T> {
  let url = endpoint
  if (params) {
    const searchParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value))
      }
    })
    const queryString = searchParams.toString()
    if (queryString) {
      url = `${endpoint}?${queryString}`
    }
  }
  return apiFetch<T>(url, { method: 'GET' })
}

/**
 * POST リクエスト
 */
export function apiPost<T>(endpoint: string, data?: unknown): Promise<T> {
  return apiFetch<T>(endpoint, {
    method: 'POST',
    body: data ? JSON.stringify(data) : undefined,
  })
}

/**
 * PUT リクエスト
 */
export function apiPut<T>(endpoint: string, data?: unknown): Promise<T> {
  return apiFetch<T>(endpoint, {
    method: 'PUT',
    body: data ? JSON.stringify(data) : undefined,
  })
}

/**
 * DELETE リクエスト
 */
export function apiDelete<T>(endpoint: string): Promise<T> {
  return apiFetch<T>(endpoint, { method: 'DELETE' })
}
