import { describe, it, expect, beforeEach } from 'vitest'
import {
  THEME_STORAGE_KEYS,
  COMPONENT_THEMES_STORAGE_KEY,
} from '@ui-catalog/core/infra/theme'
import { STORAGE_KEYS } from '@/constants/storage'
import {
  clearBusinessDataFromStorage,
  getLastAuthUserId,
  setLastAuthUserId,
  removeLastAuthUserId,
} from './clearUserCache'

/**
 * 保持されるべきキーの一覧（clearUserCache.ts の PRESERVE_KEYS と同期）
 */
const EXPECTED_PRESERVE_KEYS = new Set<string>([
  STORAGE_KEYS.USER_INFO,
  // テーマ・アニメーション設定（ui-catalog から管理）
  THEME_STORAGE_KEYS.SHAPE_THEME,
  THEME_STORAGE_KEYS.COLOR_THEME,
  THEME_STORAGE_KEYS.BACKGROUND_THEME,
  THEME_STORAGE_KEYS.TABLE_ROW_ANIMATION,
  THEME_STORAGE_KEYS.CARD_ANIMATION,
  THEME_STORAGE_KEYS.DROP_MENU_ANIMATION,
  THEME_STORAGE_KEYS.ANIMATION_SPEED,
  COMPONENT_THEMES_STORAGE_KEY,
  // レイアウト設定
  STORAGE_KEYS.LEFT_PANE_OPEN,
  STORAGE_KEYS.DISPLAY_DATE,
  STORAGE_KEYS.REMEMBERED_USERNAME,
  STORAGE_KEYS.REMEMBER_ME,
  STORAGE_KEYS.LAST_AUTH_USER_ID,
])

/** STORAGE_KEYS の全キー値 */
const ALL_STORAGE_KEY_VALUES = Object.values(STORAGE_KEYS)

describe('clearUserCache', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  describe('clearBusinessDataFromStorage', () => {
    it('STORAGE_KEYS の全キーに対し、保持対象のみ残り業務データは削除される', () => {
      // Arrange: 全キーに値をセット
      for (const key of ALL_STORAGE_KEY_VALUES) {
        localStorage.setItem(key, 'test-value')
      }

      // Act
      clearBusinessDataFromStorage()

      // Assert: 保持対象キーは残る
      for (const key of ALL_STORAGE_KEY_VALUES) {
        if (EXPECTED_PRESERVE_KEYS.has(key)) {
          expect(localStorage.getItem(key), `保持キー "${key}" が削除されている`).toBe('test-value')
        } else {
          expect(localStorage.getItem(key), `業務キー "${key}" が残っている`).toBeNull()
        }
      }
    })

    it('LAST_AUTH_USER_ID を削除しない', () => {
      localStorage.setItem(STORAGE_KEYS.LAST_AUTH_USER_ID, 'user-123')

      clearBusinessDataFromStorage()

      expect(localStorage.getItem(STORAGE_KEYS.LAST_AUTH_USER_ID)).toBe('user-123')
    })

    it('STORAGE_KEYS に定義されていないキーは影響を受けない', () => {
      localStorage.setItem('unrelated-key', 'should-remain')

      clearBusinessDataFromStorage()

      expect(localStorage.getItem('unrelated-key')).toBe('should-remain')
    })
  })

  describe('getLastAuthUserId', () => {
    it('未設定時に null を返す', () => {
      expect(getLastAuthUserId()).toBeNull()
    })
  })

  describe('setLastAuthUserId + getLastAuthUserId', () => {
    it('保存した値を正しく取得できる', () => {
      setLastAuthUserId('user-456')

      expect(getLastAuthUserId()).toBe('user-456')
    })
  })

  describe('removeLastAuthUserId', () => {
    it('保存済みの値を正しく削除する', () => {
      setLastAuthUserId('user-789')
      expect(getLastAuthUserId()).toBe('user-789')

      removeLastAuthUserId()

      expect(getLastAuthUserId()).toBeNull()
    })
  })
})
