/**
 * QueryClient 外部参照
 *
 * React コンポーネントツリー外から QueryClient にアクセスするための参照。
 * providers.tsx で生成時にセットされ、login/logout 時のキャッシュクリアに使用。
 */
import type { QueryClient } from '@tanstack/react-query'

export const queryClientRef: { current: QueryClient | null } = { current: null }
