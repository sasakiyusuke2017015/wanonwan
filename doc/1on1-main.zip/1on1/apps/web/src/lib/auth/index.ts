/**
 * 認証モジュール
 */

// 既存のauth.tsからエクスポート
export {
  AUTH_COOKIE_NAMES,
  setAuthTokens,
  getAuthToken,
  clearAuthTokens,
  isAuthenticated,
} from '../auth'

// キャッシュ管理
export {
  clearBusinessDataFromStorage,
  getLastAuthUserId,
  setLastAuthUserId,
  removeLastAuthUserId,
} from './clearUserCache'

// QueryClient参照
export { queryClientRef } from './queryClientRef'
