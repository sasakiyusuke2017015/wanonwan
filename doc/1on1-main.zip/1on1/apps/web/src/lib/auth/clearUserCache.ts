/**
 * ユーザーキャッシュ管理
 *
 * ユーザー切り替え・ログアウト時に業務データのキャッシュをクリアする。
 * UI設定（テーマ、アニメーション等）とログイン情報記憶は保持する。
 */

import {
  THEME_STORAGE_KEYS,
  COMPONENT_THEMES_STORAGE_KEY,
} from '@ui-catalog/core/infra/theme'
import { STORAGE_KEYS } from '@/constants/storage'

/**
 * ユーザー切り替え・ログアウト時に保持するキーのホワイトリスト
 *
 * ここに含まれないキーは全て削除される（セーフ・バイ・デフォルト）。
 * 新しい業務データキーが STORAGE_KEYS に追加された場合、
 * 自動的にクリア対象となるため、漏れによる権限外データ閲覧を防ぐ。
 */
const PRESERVE_KEYS = new Set<string>([
  // 認証関連（ユーザー情報はログアウト後も保持）
  STORAGE_KEYS.USER_INFO,
  // UI設定（テーマ・アニメーション）- ui-catalog から管理
  THEME_STORAGE_KEYS.SHAPE_THEME,
  THEME_STORAGE_KEYS.COLOR_THEME,
  THEME_STORAGE_KEYS.BACKGROUND_THEME,
  THEME_STORAGE_KEYS.TABLE_ROW_ANIMATION,
  THEME_STORAGE_KEYS.CARD_ANIMATION,
  THEME_STORAGE_KEYS.DROP_MENU_ANIMATION,
  THEME_STORAGE_KEYS.ANIMATION_SPEED,
  COMPONENT_THEMES_STORAGE_KEY,
  // UI設定（レイアウト）
  STORAGE_KEYS.LEFT_PANE_OPEN,
  STORAGE_KEYS.DISPLAY_DATE,
  // ログイン情報記憶
  STORAGE_KEYS.REMEMBERED_USERNAME,
  STORAGE_KEYS.REMEMBERED_PASSWORD,
  STORAGE_KEYS.REMEMBER_ME,
  // ユーザー切り替え検知用
  STORAGE_KEYS.LAST_AUTH_USER_ID,
])

/**
 * 業務データの localStorage をクリア
 * PRESERVE_KEYS に含まれるキーは保持する（セーフ・バイ・デフォルト）
 */
export function clearBusinessDataFromStorage(): void {
  const allStorageKeys = Object.values(STORAGE_KEYS)
  for (const key of allStorageKeys) {
    if (!PRESERVE_KEYS.has(key)) {
      localStorage.removeItem(key)
    }
  }
}

/**
 * 前回ログインユーザーIDを取得
 */
export function getLastAuthUserId(): string | null {
  return localStorage.getItem(STORAGE_KEYS.LAST_AUTH_USER_ID)
}

/**
 * 前回ログインユーザーIDを保存
 */
export function setLastAuthUserId(userId: string): void {
  localStorage.setItem(STORAGE_KEYS.LAST_AUTH_USER_ID, userId)
}

/**
 * 前回ログインユーザーIDを削除
 */
export function removeLastAuthUserId(): void {
  localStorage.removeItem(STORAGE_KEYS.LAST_AUTH_USER_ID)
}
