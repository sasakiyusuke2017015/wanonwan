/**
 * React Router 設定
 */

import { lazy, Suspense } from 'react'
import { createBrowserRouter, Navigate } from 'react-router-dom'
import { RouteGuard } from '@/layouts/RouteGuard'
import ErrorPage from '@/pages/Error'
import LoginPage from '@/pages/Auth/Login'
// 認証後ページは遅延読み込み（初期バンドルサイズ削減）
const DashboardPage = lazy(() => import('@/pages/Dashboard'))
const SurveyListPage = lazy(() => import('@/pages/Survey/List/1on1'))
const SurveyDetailPage = lazy(() => import('@/pages/Survey/Detail/1on1'))
const AnswerListPage = lazy(() => import('@/pages/Answer/List/1on1'))
const AnswerDetailPage = lazy(() => import('@/pages/Answer/Detail/1on1'))
const ChangePasswordPage = lazy(() => import('@/pages/Auth/ChangePassword'))
const SchedulePage = lazy(() => import('@/pages/Schedule'))

function LazyPage({ children }: { children: React.ReactNode }) {
  return <Suspense fallback={null}>{children}</Suspense>
}

export const router = createBrowserRouter([
  // ルート → ログインにリダイレクト
  {
    path: '/',
    element: <Navigate to="/login" replace />,
    errorElement: <ErrorPage />,
  },
  // ログインページ（認証不要）
  {
    path: '/login',
    element: <LoginPage />,
    errorElement: <ErrorPage />,
  },
  // 認証必須ルート
  {
    element: <RouteGuard />,
    errorElement: <ErrorPage />,
    children: [
      // /home → /dashboard にリダイレクト
      {
        path: '/home',
        element: <Navigate to="/dashboard" replace />,
      },
      {
        path: '/dashboard',
        element: <LazyPage><DashboardPage /></LazyPage>,
      },
      {
        path: '/surveys',
        element: <LazyPage><SurveyListPage /></LazyPage>,
      },
      {
        path: '/surveys/:id',
        element: <LazyPage><SurveyDetailPage /></LazyPage>,
      },
      {
        path: '/answers',
        element: <LazyPage><AnswerListPage /></LazyPage>,
      },
      {
        path: '/answers/details',
        element: <LazyPage><AnswerDetailPage /></LazyPage>,
      },
      {
        path: '/schedule',
        element: <Navigate to="/schedule/day" replace />,
      },
      {
        path: '/schedule/:view',
        element: <LazyPage><SchedulePage /></LazyPage>,
      },
      {
        path: '/change-password',
        element: <LazyPage><ChangePasswordPage /></LazyPage>,
      },
    ],
  },
  // 404 キャッチオール
  {
    path: '*',
    element: <ErrorPage />,
  },
])
