/**
 * 認証・認可ガードコンポーネント
 *
 * 1. 未認証ユーザーをログインページにリダイレクト
 * 2. 権限のないページへのアクセスはエラーページを表示
 */

import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { isAuthenticated } from '@/lib/auth.js'
import { usePermissions } from '@/hooks'
import { ROUTES, NAV_ROUTE_KEYS } from '@/constants/routes'
import { ErrorPage } from './ErrorBoundary'

/** 権限チェック対象のページパス（ナビゲーション表示対象ルートから動的生成） */
const PERMISSION_CHECKED_PATHS = NAV_ROUTE_KEYS.map((key) => ROUTES[key].path)

export function RouteGuard() {
  const location = useLocation()
  const authenticated = isAuthenticated()
  const { canAccessPage, loading } = usePermissions()

  if (!authenticated) {
    // 未認証時はログインにリダイレクト（元のパスを保存）
    const redirectTo = encodeURIComponent(location.pathname + location.search)
    return <Navigate to={`/login?redirect=${redirectTo}`} replace />
  }

  // 権限情報の読み込み中はチェックをスキップ
  if (loading) {
    return <Outlet />
  }

  // 権限チェック対象のページかどうか判定
  const currentPath = location.pathname
  const isPermissionCheckedPage = PERMISSION_CHECKED_PATHS.some(
    (path) => currentPath === path || currentPath.startsWith(path + '/')
  )

  if (isPermissionCheckedPage && !canAccessPage(currentPath)) {
    return (
      <ErrorPage
        code="403"
        title="アクセス権限がありません"
        message={`「${currentPath}」へのアクセス権限がありません。`}
      />
    )
  }

  return <Outlet />
}
