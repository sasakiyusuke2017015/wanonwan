import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import { SurveyModeHeader } from './SurveyModeHeader';

describe('SurveyModeHeader', () => {
  const title = '2024年度 第1回 従業員満足度調査';

  it('successモードで正しくレンダリングされる', () => {
    const { getByText } = render(<SurveyModeHeader title={title} mode="success" />);
    expect(getByText(title)).toBeInTheDocument();
    expect(getByText('アンケートの送信が完了しました')).toBeInTheDocument();
  });

  it('errorモードで正しくレンダリングされる', () => {
    const { getByText } = render(<SurveyModeHeader title={title} mode="error" />);
    expect(getByText(title)).toBeInTheDocument();
    expect(getByText('アンケートの送信に失敗しました')).toBeInTheDocument();
  });

  it('previewモードで正しくレンダリングされる', () => {
    const { getByText } = render(<SurveyModeHeader title={title} mode="preview" />);
    expect(getByText(title)).toBeInTheDocument();
    expect(getByText('入力内容をご確認ください')).toBeInTheDocument();
  });

  it('reviewモードで正しくレンダリングされる', () => {
    const { getByText } = render(<SurveyModeHeader title={title} mode="review" />);
    expect(getByText(title)).toBeInTheDocument();
    expect(getByText('過去の回答内容を確認できます')).toBeInTheDocument();
  });

  it('editモードで正しくレンダリングされる', () => {
    const { getByText } = render(<SurveyModeHeader title={title} mode="edit" />);
    expect(getByText(title)).toBeInTheDocument();
    expect(getByText('あなたの現在の状況や気持ちについて、率直に回答してください')).toBeInTheDocument();
  });

  it('successモードで正しいスタイルが適用される', () => {
    const { container } = render(<SurveyModeHeader title={title} mode="success" />);
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.className).toContain('border-green-500');
    expect(wrapper.className).toContain('bg-green-50');
  });

  it('errorモードで正しいスタイルが適用される', () => {
    const { container } = render(<SurveyModeHeader title={title} mode="error" />);
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.className).toContain('border-red-500');
    expect(wrapper.className).toContain('bg-red-50');
  });
});
