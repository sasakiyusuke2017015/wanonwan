import React from 'react';

import AppSideNav from './AppSideNav';

/**
 * AppSideNav コンポーネントの Storybook 設定
 */
export default {
  title: 'レイアウト/AppSideNav',
  component: AppSideNav,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
左側ナビゲーションペインコンポーネント。
• アイコンベースのナビゲーション
• トグル可能な開閉機能
• パーミッションベースのメニュー項目フィルタリング
• モバイル対応（オーバーレイ表示）`,
      },
    },
  },
  argTypes: {
    isOpen: {
      control: { type: 'boolean' },
      description: 'ペインの開閉状態',
      table: { defaultValue: { summary: true } },
    },
    onToggle: {
      action: 'toggled',
      description: '開閉トグル時のハンドラ',
    },
    children: {
      control: { type: 'text' },
      description: 'カスタムコンテンツ',
    },
  },
};

// 開いた状態
export const Open = {
  args: {
    isOpen: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'ペインが開いた状態',
      },
    },
  },
};

// 閉じた状態
export const Closed = {
  args: {
    isOpen: false,
  },
  parameters: {
    docs: {
      description: {
        story: 'ペインが閉じた状態',
      },
    },
  },
};

// カスタムコンテンツ
export const CustomContent = {
  args: {
    isOpen: true,
    children: (
      <div style={{ padding: '1rem', color: 'white' }}>
        <h3 style={{ fontWeight: 'bold', marginBottom: '1rem' }}>
          カスタムメニュー
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <a
            href="#"
            style={{
              padding: '0.5rem',
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: '0.25rem',
              textDecoration: 'none',
              color: 'white',
            }}
          >
            メニュー1
          </a>
          <a
            href="#"
            style={{
              padding: '0.5rem',
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: '0.25rem',
              textDecoration: 'none',
              color: 'white',
            }}
          >
            メニュー2
          </a>
          <a
            href="#"
            style={{
              padding: '0.5rem',
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: '0.25rem',
              textDecoration: 'none',
              color: 'white',
            }}
          >
            メニュー3
          </a>
        </div>
      </div>
    ),
  },
  parameters: {
    docs: {
      description: {
        story: 'カスタムコンテンツを表示する例',
      },
    },
  },
};

// インタラクティブデモ
const AppSideNavDemo = () => {
  const [isOpen, setIsOpen] = React.useState(true);

  return (
    <div style={{ position: 'relative', height: '500px' }}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          position: 'absolute',
          top: '1rem',
          right: '1rem',
          padding: '0.5rem 1rem',
          backgroundColor: '#3b82f6',
          color: 'white',
          border: 'none',
          borderRadius: '0.25rem',
          cursor: 'pointer',
          zIndex: 100,
        }}
      >
        {isOpen ? '閉じる' : '開く'}
      </button>
      <AppSideNav isOpen={isOpen} onToggle={() => setIsOpen(!isOpen)} />
      <div
        style={{
          marginLeft: isOpen ? '250px' : '0',
          padding: '2rem',
          transition: 'margin-left 300ms ease-in-out',
        }}
      >
        <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          メインコンテンツ
        </h2>
        <p>左ペインの開閉に応じてコンテンツが移動します。</p>
      </div>
    </div>
  );
};

export const InteractiveDemo = {
  render: () => <AppSideNavDemo />,
  parameters: {
    controls: { hideNoControlsWarning: true },
    docs: {
      description: {
        story: '左ペインの開閉をインタラクティブに操作できるデモ',
      },
    },
  },
};
