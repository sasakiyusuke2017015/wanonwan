// src/components/templates/Layout.jsx
import React from 'react';

import { useAtom } from 'jotai';

import { type BreadcrumbItem } from '@ui-catalog/core/molecules';
import { FloatingMenuButton } from '@ui-catalog/core/organisms';
import { Footer } from '@ui-catalog/core/templates';
import type { BreadcrumbItemConfig } from '@/types';
import { useDevice } from '@ui-catalog/core/hooks';
import { useThemeConfig, useNavigationItems } from '@/hooks';
import { BackgroundTexture } from '@ui-catalog/core/organisms';

import { LAYOUT_SIZES } from '@/constants/app';
import BottomTabBar from '@1on1/layouts/organisms/BottomTabBar';
import AppHeader from '@1on1/layouts/organisms/AppHeader';
import AppSubHeader, { type Tab } from '@1on1/layouts/organisms/AppSubHeader';
import { useAuth } from '@/adapters/AuthContext';
import { leftPaneOpenAtom, uiBackgroundAtom } from '../../state';

import AppSideNav from './AppSideNav';


interface AppLayoutProps {
  mainContent: React.ReactNode;
  footerContent?: React.ReactNode;
  hasSubHeader?: boolean;
  /** パンくずリスト（BreadcrumbItemConfig[] を受け入れ、内部で BreadcrumbItem[] に変換） */
  breadcrumbItems?: BreadcrumbItemConfig[];
  rightExtraContent?: React.ReactNode;
  subHeaderTabs?: Tab[];
  subHeaderDefaultActiveTabKey?: string;
  onSubHeaderTabChange?: (key: string) => void;
  subHeaderLoading?: boolean;
  /** カスタムSubHeaderコンテンツ（subHeaderTabsより優先） */
  subHeaderContent?: React.ReactNode;
  /** SubHeaderコンテンツのpadding（デフォルト: '0.5rem 1rem'） */
  subHeaderContentPadding?: string;
  /** メインコンテンツのoverflowY（デフォルト: 'auto'） */
  mainOverflowY?: 'auto' | 'hidden';
  /** メインコンテンツのパディングを無効化（CalendarPage 等のフルスクリーンコンテンツ用） */
  noPadding?: boolean;
}

/**
 * アプリケーションの基本レイアウトテンプレート
 *
 * @param {Object} props
 * @param {React.ReactNode} props.mainContent - メインコンテンツ
 * @param {React.ReactNode} props.footerContent - フッターコンテンツ
 * @param {BreadcrumbItem[]} props.breadcrumbItems - パンくずリストの項目
 * @param {React.ReactNode} props.rightExtraContent - ヘッダー右側の追加コンテンツ
 */
export default function Layout({
  mainContent,
  footerContent,
  hasSubHeader = false,
  breadcrumbItems,
  rightExtraContent,
  subHeaderTabs,
  subHeaderDefaultActiveTabKey,
  onSubHeaderTabChange,
  subHeaderLoading = false,
  subHeaderContent,
  subHeaderContentPadding,
  mainOverflowY = 'auto',
  noPadding = false,
}: AppLayoutProps) {
  const { shapes } = useThemeConfig('AppLayout');
  const { colors: floatingMenuColors } = useThemeConfig('FloatingMenuButton');
  const { isAuthenticated } = useAuth();
  const { isMobile } = useDevice();
  const navigationItems = useNavigationItems();
  const [isLeftPaneOpen, setIsLeftPaneOpen] = useAtom(leftPaneOpenAtom);
  const [backgroundTheme] = useAtom(uiBackgroundAtom);

  // ナビゲーションアイテムが2つ以上ある場合のみ左ペインを表示（スマホでは非表示）
  const showLeftPane = navigationItems.length > 1 && !isMobile;
  // スマホではBottomTabBarを表示
  const showBottomTabBar = navigationItems.length > 1 && isMobile;

  // BreadcrumbItemConfig[] を BreadcrumbItem[] に変換（href がない場合は '#' をデフォルト値として使用）
  const convertedBreadcrumbItems: BreadcrumbItem[] | undefined = breadcrumbItems?.map((item) => ({
    ...item,
    href: item.href ?? '#',
  }));

  const handleToggleLeftPane = () => {
    setIsLeftPaneOpen(!isLeftPaneOpen);
  };

  return (
    <div className="relative flex h-screen flex-col overflow-hidden" data-component="app-layout">
      {/* 背景テクスチャ */}
      <BackgroundTexture theme={backgroundTheme} />

      {/* フローティングハンバーガーボタン（ナビアイテムが2つ以上の場合のみ表示） */}
      {isAuthenticated && showLeftPane && (
        <FloatingMenuButton
          isOpen={isLeftPaneOpen}
          onToggle={handleToggleLeftPane}
          backgroundColor={floatingMenuColors.primaryBgColor}
          borderColor={floatingMenuColors.primaryBorderColor}
          color={floatingMenuColors.primaryContrastText}
          openIcon={'hamburger'}
          closeIcon={'x'}
        />
      )}

      {/* 左ペイン（ナビアイテムが2つ以上の場合のみ表示） */}
      {isAuthenticated && showLeftPane && (
        <AppSideNav
          isOpen={isLeftPaneOpen}
          onToggle={handleToggleLeftPane}
          hasFooter={!!footerContent}
        />
      )}

      {/* ヘッダーバー */}
      {isAuthenticated && (
        <AppHeader
          breadcrumbItems={convertedBreadcrumbItems}
          rightExtraContent={rightExtraContent}
        />
      )}

      {/* サブヘッダー */}
      {isAuthenticated && subHeaderContent}
      {isAuthenticated && !subHeaderContent && subHeaderTabs && (
        <AppSubHeader
          isLeftPaneOpen={showLeftPane && isLeftPaneOpen}
          tabs={subHeaderTabs}
          defaultActiveTabKey={subHeaderDefaultActiveTabKey}
          onTabChange={onSubHeaderTabChange}
          loading={subHeaderLoading}
          contentPadding={subHeaderContentPadding}
        />
      )}

      {/* メインコンテンツ */}
      <main
        data-component="app-main"
        className={`flex-grow transition-all duration-300 ${
          isAuthenticated && showLeftPane && isLeftPaneOpen
            ? 'ml-[var(--left-pane-width)] w-[calc(100%-var(--left-pane-width))]'
            : 'w-full'
        }`}
        style={
          {
            '--left-pane-width': `${LAYOUT_SIZES.LEFT_PANE_WIDTH}px`,
            paddingTop: isAuthenticated
              ? hasSubHeader
                ? `calc(${LAYOUT_SIZES.HEADER_HEIGHT}px + var(--subheader-height))`
                : `${LAYOUT_SIZES.HEADER_HEIGHT}px`
              : '0',
            paddingBottom: showBottomTabBar
              ? footerContent
                ? `${LAYOUT_SIZES.BOTTOM_TAB_HEIGHT + LAYOUT_SIZES.FOOTER_HEIGHT}px`
                : `${LAYOUT_SIZES.BOTTOM_TAB_HEIGHT + 8}px`
              : footerContent
                ? `${LAYOUT_SIZES.FOOTER_HEIGHT}px`
                : '1rem',
            overflowY: mainOverflowY,
          } as React.CSSProperties
        }
      >
        {/* メインセクション */}
        <div className={noPadding ? 'h-full' : 'overflow-x-hidden px-2 sm:px-4'} style={noPadding ? undefined : { borderRadius: shapes.cardRadius }}>
          {mainContent}
        </div>
      </main>

      {/* フッターセクション */}
      <Footer
        height={LAYOUT_SIZES.FOOTER_HEIGHT}
        leftOffset={isMobile ? 0 : (showLeftPane && isLeftPaneOpen) ? LAYOUT_SIZES.LEFT_PANE_WIDTH : 0}
        bottomOffset={isMobile ? LAYOUT_SIZES.BOTTOM_TAB_HEIGHT : 0}
        className="text-white"
      >
        {footerContent}
      </Footer>

      {/* スマホ用下部タブバー */}
      {isAuthenticated && showBottomTabBar && (
        <BottomTabBar />
      )}
    </div>
  );
}
