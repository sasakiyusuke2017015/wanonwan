import { describe, it, expect, vi } from 'vitest';
import { render } from '@testing-library/react';
import AppLayout from './AppLayout';
import { AuthProvider } from '@/adapters/AuthContext';
import { RouterProvider } from '@/adapters/RouterContext';
import type { AuthAdapter, RouterAdapter, LinkProps } from '@/adapters/types';
import type { User } from '@/types';

// テスト用のモックRouterアダプター
const createMockRouterAdapter = (): RouterAdapter => ({
  useNavigate: () => vi.fn(),
  usePathname: () => '/',
  Link: ({ href, children, className, style, ...props }: LinkProps) => (
    <a href={href} className={className} style={style} {...props}>
      {children}
    </a>
  ),
});

// テスト用のモックAuthアダプター
const createMockAuthAdapter = (withUser = false): AuthAdapter<User> => ({
  user: withUser ? { id: 1, email: 'test@test.com', name: 'Test User' } as User : null,
  token: withUser ? 'mock-token' : null,
  loading: false,
  isAuthenticated: withUser,
  login: async () => ({ success: true }),
  logout: async () => {},
  getAuthHeaders: () => ({}),
});

// テスト用のラッパーコンポーネント
const TestWrapper = ({ children, withUser = false }: { children: React.ReactNode; withUser?: boolean }) => (
  <RouterProvider adapter={createMockRouterAdapter()}>
    <AuthProvider adapter={createMockAuthAdapter(withUser)}>{children}</AuthProvider>
  </RouterProvider>
);

describe('AppLayout', () => {
  it('data-component属性が設定される', () => {
    const { container } = render(
      <TestWrapper>
        <AppLayout mainContent={<div>メインコンテンツ</div>} />
      </TestWrapper>
    );
    const layout = container.querySelector('[data-component="app-layout"]');
    expect(layout).toBeInTheDocument();
  });

  it('mainContentが表示される', () => {
    render(
      <TestWrapper>
        <AppLayout mainContent={<div data-testid="main">メインコンテンツ</div>} />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="main"]')).toBeInTheDocument();
  });

  it('footerContentが指定された場合、フッターが表示される', () => {
    const { container } = render(
      <TestWrapper>
        <AppLayout
          mainContent={<div>メイン</div>}
          footerContent={<div>フッター</div>}
        />
      </TestWrapper>
    );
    const footer = container.querySelector('[data-component="footer"]');
    expect(footer).toBeInTheDocument();
  });

  it('breadcrumbItemsが指定された場合、パンくずリストが表示される（認証時）', () => {
    const breadcrumbs = [
      { label: 'ホーム', href: '/' },
      { label: '現在のページ', href: '' },
    ];
    const { container } = render(
      <TestWrapper withUser={true}>
        <AppLayout mainContent={<div>メイン</div>} breadcrumbItems={breadcrumbs} />
      </TestWrapper>
    );
    const breadcrumb = container.querySelector('.breadcrumb-in-header');
    expect(breadcrumb).toBeInTheDocument();
  });

  it('rightExtraContentが表示される（認証時）', () => {
    render(
      <TestWrapper withUser={true}>
        <AppLayout
          mainContent={<div>メイン</div>}
          rightExtraContent={<div data-testid="extra">追加</div>}
        />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="extra"]')).toBeInTheDocument();
  });

  it('subHeaderTabsが指定された場合、SubHeaderが表示される（認証時）', () => {
    const tabs = [
      { key: 'tab1', label: 'タブ1', content: <div>内容1</div> },
      { key: 'tab2', label: 'タブ2', content: <div>内容2</div> },
    ];
    render(
      <TestWrapper withUser={true}>
        <AppLayout mainContent={<div>メイン</div>} subHeaderTabs={tabs} />
      </TestWrapper>
    );
    // SubHeaderのタブが表示されることを確認
    expect(document.querySelector('.fixed.right-0.z-20')).toBeInTheDocument();
  });

  it('subHeaderContentが指定された場合、カスタムSubHeaderが表示される（認証時）', () => {
    render(
      <TestWrapper withUser={true}>
        <AppLayout
          mainContent={<div>メイン</div>}
          subHeaderContent={<div data-testid="custom-subheader">カスタム</div>}
        />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="custom-subheader"]')).toBeInTheDocument();
  });

  it('hasSubHeader=trueの場合、メインコンテンツのpaddingTopが設定される（認証時）', () => {
    const { container } = render(
      <TestWrapper withUser={true}>
        <AppLayout mainContent={<div>メイン</div>} hasSubHeader={true} />
      </TestWrapper>
    );
    const main = container.querySelector('main');
    expect(main).toBeInTheDocument();
    // paddingTopが設定されていることを確認（jsdomではcalc()の完全一致は困難）
    const style = main?.getAttribute('style');
    expect(style).toContain('padding-top');
  });

  it('背景テクスチャが表示される', () => {
    const { container } = render(
      <TestWrapper>
        <AppLayout mainContent={<div>メイン</div>} />
      </TestWrapper>
    );
    const background = container.querySelector('[data-component="background-texture"]');
    expect(background).toBeInTheDocument();
  });
});
