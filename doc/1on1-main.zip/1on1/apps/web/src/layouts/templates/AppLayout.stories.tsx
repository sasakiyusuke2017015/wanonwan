import React from 'react';

import AppLayout from './AppLayout';

/**
 * AppLayout コンポーネントの Storybook 設定
 */
export default {
  title: 'レイアウト/AppLayout',
  component: AppLayout,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
アプリケーションの基本レイアウトテンプレート。
• ヘッダー、左ペイン、メインコンテンツ、フッターを含む
• 認証状態に応じた表示制御
• パンくずリストとサブヘッダーのサポート`,
      },
    },
  },
  argTypes: {
    mainContent: {
      control: { type: 'text' },
      description: 'メインコンテンツ',
    },
    footerContent: {
      control: { type: 'text' },
      description: 'フッターコンテンツ',
    },
    hasSubHeader: {
      control: { type: 'boolean' },
      description: 'サブヘッダーの有無',
      table: { defaultValue: { summary: false } },
    },
  },
};

// 基本的なレイアウト
export const Default = {
  args: {
    mainContent: (
      <div style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          メインコンテンツ
        </h1>
        <p>ここにページのコンテンツが表示されます。</p>
      </div>
    ),
  },
  parameters: {
    docs: {
      description: {
        story: '基本的なアプリケーションレイアウト',
      },
    },
  },
};

// フッター付き
export const WithFooter = {
  args: {
    mainContent: (
      <div style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          メインコンテンツ
        </h1>
        <p>フッター付きのレイアウト例です。</p>
      </div>
    ),
    footerContent: (
      <div style={{ textAlign: 'center', color: '#4b5563' }}>
        © 2024 Company Name. All rights reserved.
      </div>
    ),
  },
  parameters: {
    docs: {
      description: {
        story: 'フッターを含むレイアウト',
      },
    },
  },
};

// パンくずリスト付き
export const WithBreadcrumbs = {
  args: {
    mainContent: (
      <div style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          メインコンテンツ
        </h1>
        <p>パンくずリスト付きのレイアウト例です。</p>
      </div>
    ),
    breadcrumbItems: [
      { label: 'ホーム', href: '/' },
      { label: 'カテゴリ', href: '/category' },
      { label: '現在のページ' },
    ],
  },
  parameters: {
    docs: {
      description: {
        story: 'パンくずリストを含むレイアウト',
      },
    },
  },
};

// サブヘッダー付き
export const WithSubHeader = {
  args: {
    mainContent: (
      <div style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          メインコンテンツ
        </h1>
        <p>サブヘッダー付きのレイアウト例です。</p>
      </div>
    ),
    hasSubHeader: true,
    subHeaderLeft: <div>左側のコンテンツ</div>,
    subHeaderCenter: <div>中央のコンテンツ</div>,
    subHeaderRight: <div>右側のコンテンツ</div>,
  },
  parameters: {
    docs: {
      description: {
        story: 'サブヘッダーを含むレイアウト',
      },
    },
  },
};

// 複雑なコンテンツ
export const ComplexContent = {
  args: {
    mainContent: (
      <div style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          ダッシュボード
        </h1>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '1rem',
            marginTop: '1rem',
          }}
        >
          <div
            style={{
              padding: '1rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.5rem',
            }}
          >
            <h3 style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>統計1</h3>
            <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>1,234</p>
          </div>
          <div
            style={{
              padding: '1rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.5rem',
            }}
          >
            <h3 style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>統計2</h3>
            <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>567</p>
          </div>
          <div
            style={{
              padding: '1rem',
              backgroundColor: '#f3f4f6',
              borderRadius: '0.5rem',
            }}
          >
            <h3 style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>統計3</h3>
            <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>89</p>
          </div>
        </div>
      </div>
    ),
    breadcrumbItems: [{ label: 'ホーム', href: '/' }, { label: 'ダッシュボード' }],
    footerContent: (
      <div style={{ textAlign: 'center', color: '#4b5563' }}>
        © 2024 Company Name
      </div>
    ),
  },
  parameters: {
    docs: {
      description: {
        story: '複雑なコンテンツを含む完全なレイアウト例',
      },
    },
  },
};
