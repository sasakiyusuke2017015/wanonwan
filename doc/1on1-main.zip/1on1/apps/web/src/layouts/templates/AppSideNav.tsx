'use client';

import React, { useState, useRef, useCallback, memo } from 'react';

import { useLink, usePathname } from '@/adapters/RouterContext';
import { Icon } from '@ui-catalog/core/atoms';
import { SideNav } from '@ui-catalog/core/templates';
import { LAYOUT_SIZES } from '@/constants/app';
import { useNavigationItems, useThemeConfig } from '@/hooks';

interface AppSideNavProps {
  isOpen?: boolean;
  onToggle?: () => void;
  children?: React.ReactNode;
  hasFooter?: boolean;
}

interface TooltipState {
  id: string;
  label: string;
  top: number;
}

const AppSideNav: React.FC<AppSideNavProps> = ({
  isOpen = true,
  onToggle,
  children,
  hasFooter: _hasFooter = false,
}) => {
  const { colors } = useThemeConfig('SlideNavi');
  const primaryBgColor = colors.primaryBgColor;
  const navActiveBgColor = colors.navActiveBgColor;
  const navHoverTextColor = colors.navHoverTextColor;
  const secondaryTextColor = colors.secondaryTextColor;

  const [internalIsOpen] = useState(isOpen);
  const [tooltip, setTooltip] = useState<TooltipState | null>(null);
  const Link = useLink();
  const pathname = usePathname();
  const navigationItems = useNavigationItems();
  const itemRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  const currentIsOpen = onToggle ? isOpen : internalIsOpen;

  const handleMouseEnter = useCallback((id: string, label: string) => {
    const el = itemRefs.current.get(id);
    if (el) {
      const rect = el.getBoundingClientRect();
      setTooltip({ id, label, top: rect.top + rect.height / 2 });
    }
  }, []);

  const handleMouseLeave = useCallback(() => {
    setTooltip(null);
  }, []);

  // デフォルトのナビゲーションコンテンツ
  const defaultNavContent = (
    <div className="space-y-1">
      {/* ナビゲーションメニュー */}
      {navigationItems.map((item) => {
        const isActive = pathname.startsWith(item.to);
        const isHovered = tooltip?.id === item.id;

        return (
          <Link
            key={item.id}
            href={item.to}
            className={`group relative block h-full w-full transition-all duration-200 ${
              isHovered && !isActive ? 'backdrop-blur-sm' : ''
            }`}
            style={{
              backgroundColor: isHovered && !isActive ? 'rgba(255, 255, 255, 0.15)' : undefined,
              color: isActive ? navActiveBgColor : undefined,
            }}
            onClick={handleMouseLeave}
          >
            <div
              ref={(el) => { if (el) itemRefs.current.set(item.id, el); }}
              onMouseEnter={() => handleMouseEnter(item.id, item.label)}
              onMouseLeave={handleMouseLeave}
              className="flex h-full w-full flex-col items-center justify-center py-2"
            >
              <Icon
                name={item.icon}
                size={24}
                fill="none"
                stroke="currentColor"
                hover="auto"
                className="transition-colors duration-200"
                style={{
                  color: isActive
                    ? navActiveBgColor
                    : isHovered && !isActive
                      ? navHoverTextColor
                      : secondaryTextColor
                }}
              />
            </div>
          </Link>
        );
      })}
    </div>
  );

  return (
    <>
      <SideNav
        width={LAYOUT_SIZES.LEFT_PANE_WIDTH}
        topOffset={LAYOUT_SIZES.HEADER_HEIGHT}
        isOpen={currentIsOpen}
        bgColor={primaryBgColor}
      >
        {children || defaultNavContent}
      </SideNav>

      {/* ツールチップ（transform の影響を受けないよう AppSideNav の外に配置） */}
      {tooltip && currentIsOpen && (
        <div
          className="pointer-events-none fixed whitespace-nowrap bg-gray-800 px-2 py-1 text-fluid-xs text-white shadow-lg rounded-theme-card"
          style={{
            left: `${LAYOUT_SIZES.LEFT_PANE_WIDTH + 4}px`,
            top: `${tooltip.top}px`,
            zIndex: 10000,
            transform: 'translateY(-50%)',
          }}
        >
          {tooltip.label}
          <div className="absolute left-0 top-1/2 -translate-x-full -translate-y-1/2 transform border-4 border-transparent border-r-gray-800"></div>
        </div>
      )}
    </>
  );
};

export default memo(AppSideNav);
