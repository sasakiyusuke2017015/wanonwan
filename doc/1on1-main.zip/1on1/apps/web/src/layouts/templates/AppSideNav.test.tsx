import { describe, it, expect, vi } from 'vitest';
import { render } from '@testing-library/react';
import AppSideNav from './AppSideNav';
import { AuthProvider } from '@/adapters/AuthContext';
import { RouterProvider } from '@/adapters/RouterContext';
import type { AuthAdapter, RouterAdapter, LinkProps } from '@/adapters/types';
import type { User } from '@/types';

// テスト用のモックRouterアダプター
const createMockRouterAdapter = (): RouterAdapter => ({
  useNavigate: () => vi.fn(),
  usePathname: () => '/',
  Link: ({ href, children, className, style, ...props }: LinkProps) => (
    <a href={href} className={className} style={style} {...props}>
      {children}
    </a>
  ),
});

// テスト用のモックAuthアダプター
const createMockAuthAdapter = (): AuthAdapter<User> => ({
  user: null,
  token: null,
  loading: false,
  isAuthenticated: false,
  login: async () => ({ success: true }),
  logout: async () => {},
  getAuthHeaders: () => ({}),
});

// テスト用のラッパーコンポーネント
const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <RouterProvider adapter={createMockRouterAdapter()}>
    <AuthProvider adapter={createMockAuthAdapter()}>{children}</AuthProvider>
  </RouterProvider>
);

describe('AppSideNav', () => {
  it('isOpen=trueの場合、左ペインが表示される', () => {
    const { container } = render(
      <TestWrapper>
        <AppSideNav isOpen={true} />
      </TestWrapper>
    );
    const pane = container.querySelector('[data-component="SideNav"]');
    expect(pane).toHaveStyle({ left: '0' });
  });

  it('isOpen=falseの場合、左ペインが非表示になる', () => {
    const { container } = render(
      <TestWrapper>
        <AppSideNav isOpen={false} />
      </TestWrapper>
    );
    const pane = container.querySelector('[data-component="SideNav"]');
    expect(pane).toHaveStyle({ left: '-36px' }); // LAYOUT_SIZES.LEFT_PANE_WIDTH
  });

  it('data-component属性が設定される', () => {
    const { container } = render(
      <TestWrapper>
        <AppSideNav isOpen={true} />
      </TestWrapper>
    );
    const pane = container.querySelector('[data-component="SideNav"]');
    expect(pane).toBeInTheDocument();
  });

  it('childrenが表示される', () => {
    render(
      <TestWrapper>
        <AppSideNav isOpen={true}>
          <div data-testid="custom-content">カスタムコンテンツ</div>
        </AppSideNav>
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="custom-content"]')).toBeInTheDocument();
  });

  it('children未指定の場合、デフォルトナビゲーションが表示される', () => {
    const { container } = render(
      <TestWrapper>
        <AppSideNav isOpen={true} />
      </TestWrapper>
    );
    // ナビゲーションアイテムが存在する場合、リンクが表示される
    const links = container.querySelectorAll('a');
    expect(links.length).toBeGreaterThanOrEqual(0);
  });

  it('ツールチップが適切な位置に配置される', () => {
    const { container } = render(
      <TestWrapper>
        <AppSideNav isOpen={true} />
      </TestWrapper>
    );
    const tooltip = container.querySelector('.pointer-events-none.fixed');
    if (tooltip) {
      expect(tooltip).toHaveStyle({ left: '40px' }); // LAYOUT_SIZES.LEFT_PANE_WIDTH + 4
    }
  });
});
