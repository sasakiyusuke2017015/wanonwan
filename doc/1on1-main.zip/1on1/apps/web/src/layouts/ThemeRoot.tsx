/**
 * テーマルートコンポーネント
 * テーマ設定を適用するシンプルなラッパー
 */
import React from 'react';

import { PWAInstallPrompt } from '@ui-catalog/core/molecules';

interface ThemeRootProps {
  children: React.ReactNode;
}

/**
 * テーマ設定を適用するルートコンポーネント
 * main.tsxでアプリ全体をラップして使用
 */
export function ThemeRoot({ children }: ThemeRootProps) {
  return (
    <div className="contents">
      {/* PWA インストールプロンプト */}
      <PWAInstallPrompt />
      {children}
    </div>
  );
}
