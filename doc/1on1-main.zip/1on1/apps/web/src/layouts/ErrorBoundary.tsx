/**
 * ErrorBoundary - エラー発生時にフォールバックUIを表示
 *
 * - React Router の errorElement として使用
 * - RouteGuard から権限エラー表示にも使用
 */

import { useRouteError, isRouteErrorResponse, useNavigate } from 'react-router-dom'
import { Icon } from '@ui-catalog/core/atoms'
import { usePermissions } from '@/hooks'
import { ROUTES, NAV_ROUTE_KEYS } from '@/constants/routes'

interface RouteError {
  status?: number
  statusText?: string
  message?: string
  data?: unknown
}

export interface ErrorPageProps {
  code?: string
  title?: string
  message?: string
}


/**
 * useRouteError のラッパー
 * errorElement 外で呼ばれた場合は null を返す
 */
function useRouteErrorSafe(): RouteError | null {
  try {
    return useRouteError() as RouteError | null
  } catch {
    return null
  }
}

/**
 * エラーページコンポーネント
 *
 * - props指定: RouteGuardなどから直接呼び出す場合
 * - props未指定: React Router の errorElement として使用（useRouteErrorから取得）
 */
export function ErrorPage(props?: ErrorPageProps) {
  const navigate = useNavigate()
  const { canAccessPage } = usePermissions()
  const routeError = useRouteErrorSafe()

  // 権限ベースのHOME遷移先
  const firstAllowed = NAV_ROUTE_KEYS.find((key) => canAccessPage(ROUTES[key].path))
  const homePath = firstAllowed ? ROUTES[firstAllowed].path : '/'

  // エラー情報（props優先、なければuseRouteError）
  const errorInfo = (() => {
    if (props?.code) {
      return {
        code: props.code,
        title: props.title ?? 'エラーが発生しました',
        message: props.message ?? '',
        details: null,
      }
    }

    if (routeError && isRouteErrorResponse(routeError)) {
      return {
        code: routeError.status.toString(),
        title: routeError.status === 404 ? 'ページが見つかりません' : 'エラーが発生しました',
        message: routeError.statusText || 'リクエストを処理できませんでした',
        details: routeError.data?.message || null,
      }
    }

    return {
      code: 'ERROR',
      title: 'エラーが発生しました',
      message: routeError?.message || '予期しないエラーが発生しました',
      details: null,
    }
  })()

  const timestamp = new Date().toLocaleString('ja-JP')

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 px-4">
      <div className="w-full max-w-2xl">
        <div className="overflow-hidden rounded-2xl bg-white shadow-2xl">
          <div className="p-8">
            {/* エラーアイコン */}
            <div className="mb-6 flex justify-center">
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-red-100">
                <Icon
                  name="info-triangle"
                  size={48}
                  stroke="#DC2626"
                  strokeWidth={2}
                />
              </div>
            </div>

            {/* エラーメッセージ */}
            <h1 className="mb-2 text-center text-fluid-3xl font-bold text-gray-900">
              {errorInfo.title}
            </h1>

            <div className="mb-6 rounded-xl border-2 border-red-200 bg-red-50 p-6">
              <p className="mb-2 text-fluid-lg font-bold text-red-800">
                {errorInfo.message}
              </p>
              {errorInfo.details && (
                <p className="whitespace-pre-wrap text-fluid-sm text-red-700">
                  {String(errorInfo.details)}
                </p>
              )}
            </div>

            {/* エラーコード・時刻 */}
            <div className="mb-6 text-center">
              <div className="inline-block rounded-lg bg-gray-100 px-6 py-3 space-y-1">
                <p className="font-mono text-fluid-lg text-gray-700">
                  エラーコード:{' '}
                  <span className="font-bold text-red-600">{errorInfo.code}</span>
                </p>
                <p className="font-mono text-fluid-sm text-gray-600">
                  発生時刻: <span className="font-bold">{timestamp}</span>
                </p>
              </div>
            </div>

            {/* アクションボタン */}
            <div className="mb-6 flex flex-wrap justify-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="rounded-lg border border-gray-300 bg-white px-6 py-3 font-medium text-gray-700 transition-colors hover:bg-gray-50"
              >
                戻る
              </button>
              <button
                onClick={() => window.location.reload()}
                className="rounded-lg border border-gray-300 bg-white px-6 py-3 font-medium text-gray-700 transition-colors hover:bg-gray-50"
              >
                再読み込み
              </button>
              <button
                onClick={() => navigate(homePath, { replace: true })}
                className="rounded-lg bg-blue-600 px-6 py-3 font-medium text-white transition-colors hover:bg-blue-700"
              >
                ホームに戻る
              </button>
            </div>

            {/* サポート情報 */}
            <div className="border-t-2 border-gray-200 pt-6 text-center">
              <p className="text-gray-600">
                問題が解決しない場合は、
                <span className="font-bold text-red-600">エラーコード</span>
                を添えてシステム管理者にお問い合わせください。
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ErrorPage
