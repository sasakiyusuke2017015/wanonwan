import React from 'react';

export type SurveyMode = 'success' | 'error' | 'preview' | 'review' | 'edit';

export interface SurveyModeHeaderProps {
  /** アンケートのタイトル */
  title: string;
  /** 表示モード */
  mode: SurveyMode;
}

/**
 * SurveyModeHeader
 *
 * アンケート詳細画面のヘッダー部分。
 * モードに応じてメッセージと枠の色を変更する。
 */
export const SurveyModeHeader: React.FC<SurveyModeHeaderProps> = ({ title, mode }) => {
  // モードごとの設定を定義
  const modeConfig = {
    success: {
      message: 'アンケートの送信が完了しました',
      borderColor: 'border-green-500',
      bgColor: 'bg-green-50',
    },
    error: {
      message: 'アンケートの送信に失敗しました',
      borderColor: 'border-red-500',
      bgColor: 'bg-red-50',
    },
    preview: {
      message: '入力内容をご確認ください',
      borderColor: 'border-blue-500',
      bgColor: 'bg-blue-50',
    },
    review: {
      message: '過去の回答内容を確認できます',
      borderColor: 'border-gray-500',
      bgColor: 'bg-gray-50',
    },
    edit: {
      message: 'あなたの現在の状況や気持ちについて、率直に回答してください',
      borderColor: 'border-teal-500',
      bgColor: 'bg-teal-50',
    },
  };

  const config = modeConfig[mode];

  return (
    <div className={`flex flex-col border-l-4 p-4 ${config.borderColor} ${config.bgColor}`}>
      <h2 className="text-fluid-xl font-bold text-gray-800">{title}</h2>
      <p className="mt-1 text-fluid-sm text-gray-600">{config.message}</p>
    </div>
  );
};
