import type { Meta, StoryObj } from '@storybook/react';
import { SurveyModeHeader } from './SurveyModeHeader';

const meta = {
  title: 'アンケート/SurveyModeHeader',
  component: SurveyModeHeader,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
  args: {
    title: '',
    mode: 'success',
  },
} satisfies Meta<typeof SurveyModeHeader>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Success: Story = {
  args: {
    title: '2024年度 第1回 従業員満足度調査',
    mode: 'success',
  },
};

export const Error: Story = {
  args: {
    title: '2024年度 第1回 従業員満足度調査',
    mode: 'error',
  },
};

export const Preview: Story = {
  args: {
    title: '2024年度 第1回 従業員満足度調査',
    mode: 'preview',
  },
};

export const Review: Story = {
  args: {
    title: '2024年度 第1回 従業員満足度調査',
    mode: 'review',
  },
};

export const Edit: Story = {
  args: {
    title: '2024年度 第1回 従業員満足度調査',
    mode: 'edit',
  },
};

/**
 * 全モードを一覧表示
 */
export const AllModes: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="mb-2 text-fluid-sm font-semibold text-gray-700">Success</h3>
        <SurveyModeHeader title="2024年度 第1回 従業員満足度調査" mode="success" />
      </div>
      <div>
        <h3 className="mb-2 text-fluid-sm font-semibold text-gray-700">Error</h3>
        <SurveyModeHeader title="2024年度 第1回 従業員満足度調査" mode="error" />
      </div>
      <div>
        <h3 className="mb-2 text-fluid-sm font-semibold text-gray-700">Preview</h3>
        <SurveyModeHeader title="2024年度 第1回 従業員満足度調査" mode="preview" />
      </div>
      <div>
        <h3 className="mb-2 text-fluid-sm font-semibold text-gray-700">Review</h3>
        <SurveyModeHeader title="2024年度 第1回 従業員満足度調査" mode="review" />
      </div>
      <div>
        <h3 className="mb-2 text-fluid-sm font-semibold text-gray-700">Edit</h3>
        <SurveyModeHeader title="2024年度 第1回 従業員満足度調査" mode="edit" />
      </div>
    </div>
  ),
};
