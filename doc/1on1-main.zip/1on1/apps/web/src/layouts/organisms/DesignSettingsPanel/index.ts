export { default } from './DesignSettingsPanel';
