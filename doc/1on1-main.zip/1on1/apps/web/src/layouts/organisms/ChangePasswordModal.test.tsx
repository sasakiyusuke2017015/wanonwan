import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ChangePasswordModal from './ChangePasswordModal';
import { AuthProvider } from '@/adapters/AuthContext';
import type { AuthAdapter } from '@/adapters/types';
import type { User } from '@/types';
import {
  getActualButton,
  getActualButtonRequired,
} from '../../__tests__/helpers';

// テスト用のモックアダプター
const mockChangePassword = vi.fn();

const createMockAuthAdapter = (): AuthAdapter<User> => ({
  user: null,
  token: 'mock-token',
  loading: false,
  isAuthenticated: true,
  login: vi.fn(),
  logout: vi.fn(),
  getAuthHeaders: () => ({ Authorization: 'Bearer mock-token' }),
  changePassword: mockChangePassword,
});

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <AuthProvider adapter={createMockAuthAdapter()}>{children}</AuthProvider>
);

describe('ChangePasswordModal', () => {
  it('isOpen=falseの場合、モーダルが表示されない', () => {
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={false} onClose={() => {}} />
      </TestWrapper>
    );
    expect(screen.queryByText('パスワード変更')).not.toBeInTheDocument();
  });

  it('isOpen=trueの場合、モーダルが表示される', () => {
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );
    expect(screen.getByText('パスワード変更')).toBeInTheDocument();
  });

  it('3つの入力フィールドが表示される', () => {
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );
    expect(screen.getByLabelText('現在のパスワード')).toBeInTheDocument();
    expect(screen.getByLabelText('新しいパスワード')).toBeInTheDocument();
    expect(screen.getByLabelText('新しいパスワード（確認）')).toBeInTheDocument();
  });

  it('キャンセルボタンと変更するボタンが表示される', () => {
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );
    expect(getActualButton(/キャンセル/)).toBeInTheDocument();
    expect(getActualButton(/変更する/)).toBeInTheDocument();
  });

  it('キャンセルボタンをクリックするとonCloseが呼ばれる', async () => {
    const handleClose = vi.fn();
    const user = userEvent.setup();

    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={handleClose} />
      </TestWrapper>
    );

    await user.click(getActualButtonRequired(/キャンセル/));
    expect(handleClose).toHaveBeenCalledTimes(1);
  });

  it('パスワード表示切り替えアイコンが表示される', () => {
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );
    // 3つの入力フィールドにはそれぞれアイコン用のボタン（aria-label="Icon button"）が表示される
    const iconButtons = screen.getAllByRole('button', { name: /Icon button/ });
    expect(iconButtons.length).toBeGreaterThanOrEqual(3);
  });

  it('パスワード表示切り替えが機能する', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    const currentPasswordInput = screen.getByLabelText('現在のパスワード') as HTMLInputElement;
    expect(currentPasswordInput.type).toBe('password');

    // アイコンボタンをクリックして表示切り替え
    const iconButtons = screen.getAllByRole('button', { name: /Icon button/ });
    if (iconButtons[0]) {
      await user.click(iconButtons[0]);
      await waitFor(() => {
        expect(currentPasswordInput.type).toBe('text');
      });
    }
  });

  it('現在のパスワードが未入力の場合、エラーが表示される', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      expect(screen.getByText(/現在のパスワードを入力してください/)).toBeInTheDocument();
    });
  });

  it('新しいパスワードが未入力の場合、エラーが表示される', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    const currentPasswordInput = screen.getByLabelText('現在のパスワード');
    await user.type(currentPasswordInput, 'current123');

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      expect(screen.getByText(/新しいパスワードを入力してください/)).toBeInTheDocument();
    });
  });

  it('新しいパスワードが8文字未満の場合、エラーが表示される', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    const currentPasswordInput = screen.getByLabelText('現在のパスワード');
    const newPasswordInput = screen.getByLabelText('新しいパスワード');
    const confirmPasswordInput = screen.getByLabelText('新しいパスワード（確認）');

    await user.type(currentPasswordInput, 'current123');
    await user.type(newPasswordInput, 'short');
    await user.type(confirmPasswordInput, 'short');

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      // config.ts: password_too_short.generic.detail
      expect(screen.getByText(/パスワードは8文字以上である必要があります/)).toBeInTheDocument();
    });
  });

  it('確認パスワードが一致しない場合、エラーが表示される', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    const currentPasswordInput = screen.getByLabelText('現在のパスワード');
    const newPasswordInput = screen.getByLabelText('新しいパスワード');
    const confirmPasswordInput = screen.getByLabelText('新しいパスワード（確認）');

    await user.type(currentPasswordInput, 'current123');
    await user.type(newPasswordInput, 'newpassword123');
    await user.type(confirmPasswordInput, 'different123');

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      // config.ts: password_confirm_mismatch.generic.detail
      expect(screen.getByText(/新しいパスワードと確認用パスワードが一致しません/)).toBeInTheDocument();
    });
  });

  it('現在のパスワードと新しいパスワードが同じ場合、エラーが表示される', async () => {
    const user = userEvent.setup();
    render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} />
      </TestWrapper>
    );

    const currentPasswordInput = screen.getByLabelText('現在のパスワード');
    const newPasswordInput = screen.getByLabelText('新しいパスワード');
    const confirmPasswordInput = screen.getByLabelText('新しいパスワード（確認）');

    await user.type(currentPasswordInput, 'samepassword123');
    await user.type(newPasswordInput, 'samepassword123');
    await user.type(confirmPasswordInput, 'samepassword123');

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      // config.ts: password_same_as_current.generic.detail
      expect(screen.getByText(/新しいパスワードは現在のパスワードと異なるものにしてください/)).toBeInTheDocument();
    });
  });

  it('cardRadiusがエラーメッセージのスタイルに適用される', async () => {
    const user = userEvent.setup();
    const { container } = render(
      <TestWrapper>
        <ChangePasswordModal isOpen={true} onClose={() => {}} cardRadius="1rem" />
      </TestWrapper>
    );

    await user.click(getActualButtonRequired(/変更する/));

    await waitFor(() => {
      const errorBox = container.querySelector('.bg-red-50');
      expect(errorBox).toHaveStyle({ borderRadius: '1rem' });
    });
  });
});
