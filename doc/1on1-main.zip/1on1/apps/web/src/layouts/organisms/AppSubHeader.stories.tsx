import { Button } from '@ui-catalog/core/atoms';
import { DatePicker } from '@ui-catalog/core/molecules';
import { APP_CONFIG } from '@/constants/app';

import AppSubHeader, { createTabLayout, type Tab } from './AppSubHeader';

import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta<typeof AppSubHeader> = {
  title: 'ナビゲーション/AppSubHeader',
  component: AppSubHeader,
  parameters: {
    layout: 'fullscreen',
  },
  tags: ['autodocs'],
  argTypes: {
    tabs: {
      control: false,
    },
    className: {
      control: 'text',
    },
    isLeftPaneOpen: {
      control: 'boolean',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const sampleTabs: Tab[] = [
  {
    key: 'overview',
    label: '概要',
    content: createTabLayout(
      <div className="font-medium text-gray-700">
        <span>メンバー120名中 回答済み 95名 (79.2%) / 未回答 25名</span>
      </div>,
      <DatePicker
        variant="dark"
        size="medium"
        navigationMode="month"
        value="2024-12"
        onChange={() => {}}
        recentMonths={APP_CONFIG.RECENT_MONTHS}
      />
    ),
  },
  {
    key: 'filter',
    label: 'フィルター',
    content: createTabLayout(
      <div className="font-medium text-gray-700">フィルター設定</div>,
      <Button variant="outline" size="small" rightIcon="funnel">
        フィルター
      </Button>
    ),
  },
];

export const Default: Story = {
  args: {
    isLeftPaneOpen: true,
    tabs: sampleTabs,
    defaultActiveTabKey: 'overview',
  },
};

export const WithLeftPaneClosed: Story = {
  args: {
    isLeftPaneOpen: false,
    tabs: sampleTabs,
    defaultActiveTabKey: 'overview',
  },
};

export const WithLoading: Story = {
  args: {
    isLeftPaneOpen: true,
    tabs: sampleTabs,
    defaultActiveTabKey: 'overview',
    loading: true,
  },
};

const alertTabs: Tab[] = [
  {
    key: 'status',
    label: 'ステータス',
    content: createTabLayout(
      <div className="font-medium text-gray-700">
        <div className="flex items-center gap-4">
          <span>個人ステータス詳細:</span>
          <div className="flex gap-2">
            <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-fluid-xs font-medium text-red-800">
              健康: 要緊急対応
            </span>
          </div>
        </div>
      </div>
    ),
  },
];

export const AlertStatus: Story = {
  args: {
    isLeftPaneOpen: true,
    tabs: alertTabs,
    defaultActiveTabKey: 'status',
  },
};

export const WithCustomClass: Story = {
  args: {
    isLeftPaneOpen: true,
    tabs: sampleTabs,
    defaultActiveTabKey: 'overview',
    className: 'border-t-4 border-blue-500 bg-gradient-to-b from-gray-100 to-gray-50 shadow-lg border-b-2 border-gray-300',
  },
};
