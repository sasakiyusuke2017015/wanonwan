import type { Meta, StoryObj } from '@storybook/react';
import DesignSettingsPanel from './DesignSettingsPanel';

const meta: Meta<typeof DesignSettingsPanel> = {
  title: '設定/DesignSettingsPanel',
  component: DesignSettingsPanel,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof DesignSettingsPanel>;

export const Default: Story = {
  render: () => (
    <div className="max-w-7xl">
      <DesignSettingsPanel />
    </div>
  ),
};

export const InModal: Story = {
  render: () => (
    <div className="mx-auto max-w-7xl rounded-lg border-2 border-gray-300 bg-white p-6 shadow-lg">
      <h2 className="mb-4 text-fluid-xl font-bold">デザイン設定</h2>
      <DesignSettingsPanel />
    </div>
  ),
};

export const Fullscreen: Story = {
  parameters: {
    layout: 'fullscreen',
  },
  render: () => (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mx-auto max-w-7xl">
        <h1 className="mb-6 text-fluid-2xl font-bold">デザイン設定パネル</h1>
        <DesignSettingsPanel />
      </div>
    </div>
  ),
};
