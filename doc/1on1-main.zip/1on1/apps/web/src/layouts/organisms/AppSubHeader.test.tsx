import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AppSubHeader from './AppSubHeader';

describe('AppSubHeader', () => {
  const singleTab = [
    {
      key: 'tab1',
      label: 'タブ1',
      content: <div>コンテンツ1</div>,
    },
  ];

  const multipleTabs = [
    {
      key: 'tab1',
      label: 'タブ1',
      content: <div>コンテンツ1</div>,
    },
    {
      key: 'tab2',
      label: 'タブ2',
      content: <div>コンテンツ2</div>,
    },
  ];

  it('タブが1つの場合、タブバーが表示されない', () => {
    render(<AppSubHeader isLeftPaneOpen={false} tabs={singleTab} />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('タブが2つ以上の場合、タブバーが表示される', () => {
    render(<AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} />);
    // 最小化ボタンが表示される
    const buttons = screen.getAllByRole('button');
    expect(buttons.length).toBeGreaterThan(0);
  });

  it('アクティブなタブのコンテンツが表示される', () => {
    render(<AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} />);
    expect(screen.getByText('コンテンツ1')).toBeInTheDocument();
  });

  it('タブをクリックすると、アクティブタブが切り替わる', async () => {
    const user = userEvent.setup();
    render(<AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} />);

    // 最初はコンテンツ1が表示
    expect(screen.getByText('コンテンツ1')).toBeInTheDocument();

    // タブ2をクリック
    const tab2Button = screen.getAllByRole('button')[2]; // 0: 最小化, 1: タブ1, 2: タブ2
    await user.click(tab2Button);

    // コンテンツ2が表示される
    expect(screen.getByText('コンテンツ2')).toBeInTheDocument();
  });

  it('onTabChangeが呼ばれる', async () => {
    const handleTabChange = vi.fn();
    const user = userEvent.setup();

    render(
      <AppSubHeader
        isLeftPaneOpen={false}
        tabs={multipleTabs}
        onTabChange={handleTabChange}
      />
    );

    const tab2Button = screen.getAllByRole('button')[2];
    await user.click(tab2Button);

    expect(handleTabChange).toHaveBeenCalledWith('tab2');
  });

  it('defaultActiveTabKeyが指定された場合、初期アクティブタブが設定される', () => {
    render(
      <AppSubHeader
        isLeftPaneOpen={false}
        tabs={multipleTabs}
        defaultActiveTabKey="tab2"
      />
    );
    expect(screen.getByText('コンテンツ2')).toBeInTheDocument();
  });

  it('loading=trueの場合、ローディング表示される', () => {
    render(<AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} loading={true} />);
    // LoadingZoneのvariant="inline"でローディングメッセージが表示される
    expect(screen.getByText('データを読み込み中...')).toBeInTheDocument();
  });

  it('data-component属性が設定される', () => {
    const { container } = render(
      <AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} />
    );
    const subHeader = container.querySelector('[data-component="SubHeader"]');
    expect(subHeader).toBeInTheDocument();
  });

  it('isLeftPaneOpen=falseの場合、left:0になる', () => {
    const { container } = render(
      <AppSubHeader isLeftPaneOpen={false} tabs={multipleTabs} />
    );
    const subHeader = container.querySelector('[data-component="SubHeader"]');
    expect(subHeader).toHaveStyle({ left: '0px' });
  });

  it('isLeftPaneOpen=trueの場合、leftが左ペイン幅になる', () => {
    const { container } = render(
      <AppSubHeader isLeftPaneOpen={true} tabs={multipleTabs} />
    );
    const subHeader = container.querySelector('[data-component="SubHeader"]');
    expect(subHeader).toHaveStyle({ left: '36px' }); // LAYOUT_SIZES.LEFT_PANE_WIDTH
  });
});
