// src/components/organisms/AppSubHeader.tsx
// アプリケーション固有のサブヘッダーコンポーネント
import { FC, ReactNode, useState, useEffect, useRef } from 'react'; // useEffect/useRef: ResizeObserver用

import { Animated } from '@ui-catalog/core/atoms';
import { Icon } from '@ui-catalog/core/atoms';
import { SubHeader as BaseSubHeader } from '@ui-catalog/core/templates';
import { LoadingZone } from '@ui-catalog/core/organisms';
import { LAYOUT_SIZES } from '@/constants/app';
import { type IconName } from '@/constants';
import { useThemeConfig } from '@/hooks';
import { useDevice } from '@ui-catalog/core/hooks';
import { cn } from '@ui-catalog/core/utils';

export interface Tab {
  key: string;
  label: string;
  icon?: IconName;
  content: ReactNode;
  isHighlighted?: boolean; // フィルターや設定が適用されている場合にtrue
  headerRight?: ReactNode; // タイトル行の右側に表示するコンテンツ
}

/**
 * タブコンテンツの共通レイアウトヘルパー
 * 左右に要素を配置するレイアウトを生成
 * @param left - 左側に配置するコンテンツ
 * @param right - 右側に配置するコンテンツ（オプショナル）
 */
export const createTabLayout = (
  left?: ReactNode,
  right?: ReactNode
): ReactNode => (
  <div className="flex items-end justify-between gap-2 sm:gap-4">
    <div className="flex gap-8 flex-1">{left}</div>
    <div className="flex justify-end gap-3 flex-shrink-0">{right}</div>
  </div>
);

interface AppSubHeaderProps {
  isLeftPaneOpen: boolean;
  className?: string;
  tabs: Tab[];
  defaultActiveTabKey?: string;
  onTabChange?: (key: string) => void;
  loading?: boolean;
  /** コンテンツのpadding（デフォルト: '0.5rem 1rem'） */
  contentPadding?: string;
}

/**
 * アプリケーションサブヘッダー
 * タブモードと通常モードをサポート
 */
const AppSubHeader: FC<AppSubHeaderProps> = ({
  isLeftPaneOpen,
  className = 'bg-gradient-to-b from-gray-100 to-gray-50 shadow-lg border-b-2 border-gray-300',
  tabs,
  defaultActiveTabKey,
  onTabChange,
  loading = false,
  contentPadding = '0.5rem 1rem', // デフォルト値
}) => {
  const { shapes } = useThemeConfig('SubHeader');
  const tabBorderRadius = shapes.cardRadius;
  const { isMobile } = useDevice();

  // タブが2つ以上ある場合のみタブバーを表示
  const showTabBar = tabs.length > 1;
  const [isMinimized, setIsMinimized] = useState(showTabBar);
  // アニメーション中はoverflow:hiddenにし、展開完了後はvisibleにしてポップアップを領域外に表示可能にする
  const [isAnimating, setIsAnimating] = useState(false);
  const subHeaderRef = useRef<HTMLDivElement>(null);
  const contentScrollRef = useRef<HTMLDivElement>(null);
  const [needsScroll, setNeedsScroll] = useState(false);
  const [activeTabKey, setActiveTabKey] = useState<string>(
    defaultActiveTabKey || tabs?.[0]?.key || ''
  );

  // タブが減ってアクティブタブが消えた場合、最小化して先頭タブに切り替え
  useEffect(() => {
    if (tabs.length === 0) return;
    const activeExists = tabs.some((tab) => tab.key === activeTabKey);
    if (!activeExists) {
      setActiveTabKey(tabs[0].key);
      setIsAnimating(true);
      setIsMinimized(true);
      onTabChange?.(tabs[0].key);
    }
  }, [tabs, activeTabKey, onTabChange]);

  // タブ切り替えハンドラー
  const handleTabClick = (key: string) => {
    setActiveTabKey(key);
    onTabChange?.(key);
    // 最小化状態なら展開する
    if (isMinimized) {
      setIsAnimating(true);
      setIsMinimized(false);
    }
  };

  // SubHeaderの高さを監視してCSS変数として設定
  useEffect(() => {
    if (!subHeaderRef.current) return;

    const updateHeight = () => {
      if (subHeaderRef.current) {
        const height = subHeaderRef.current.offsetHeight;
        document.documentElement.style.setProperty('--subheader-height', `${height}px`);
      }
    };

    // 実際の高さを設定
    updateHeight();

    // ResizeObserverで高さの変更を監視
    const resizeObserver = new ResizeObserver(updateHeight);
    resizeObserver.observe(subHeaderRef.current);

    return () => {
      resizeObserver.disconnect();
    };
  }, [tabs, activeTabKey, isMinimized]);

  // コンテンツが30vhを超えるか監視し、超える場合のみスクロールを有効化
  useEffect(() => {
    if (!contentScrollRef.current) return;

    const checkOverflow = () => {
      if (contentScrollRef.current) {
        const maxH = window.innerHeight * 0.3;
        const scrollH = contentScrollRef.current.scrollHeight;
        setNeedsScroll(scrollH > maxH);
      }
    };

    checkOverflow();

    const resizeObserver = new ResizeObserver(checkOverflow);
    resizeObserver.observe(contentScrollRef.current);
    window.addEventListener('resize', checkOverflow);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', checkOverflow);
    };
  }, [activeTabKey, isMinimized]);

  // アクティブなタブのコンテンツを取得
  const activeTab = tabs.find((tab) => tab.key === activeTabKey);
  const activeContent = activeTab?.content;

  // leftOffset の計算
  const leftOffset = isMobile ? 0 : isLeftPaneOpen ? LAYOUT_SIZES.LEFT_PANE_WIDTH : 0;

  return (
    <BaseSubHeader
      topOffset={LAYOUT_SIZES.HEADER_HEIGHT}
      leftOffset={leftOffset}
      className={className}
      style={{ borderBottomLeftRadius: tabBorderRadius }}
      innerRef={subHeaderRef}
    >
      <LoadingZone
        loading={loading}
        variant="inline"
        preset="morph"
        size={40}
        fill="green"
        message="データを読み込み中..."
      >
        <div className="flex h-full flex-col">
          {/* タブバー（上部に配置） */}
          {showTabBar && (
            <div
              className="flex items-start border-gray-300 bg-gray-300 shadow-md"
              style={{ borderBottomLeftRadius: tabBorderRadius }}
            >
              {/* 最小化/展開ボタン */}
              <button
                onClick={() => {
                  setIsAnimating(true);
                  setIsMinimized(!isMinimized);
                }}
                className={cn(
                  'relative px-4 text-fluid-sm font-medium transition-all duration-200 bg-gray-300 text-gray-600 z-0 border-r',
                  tabs[0]?.key !== activeTabKey ? 'border-gray-400' : 'border-transparent'
                )}
                style={{
                  borderBottomLeftRadius: tabBorderRadius,
                }}
                title={isMinimized ? '展開' : '最小化'}
              >
                <Animated type="rotate" show={!isMinimized} className="flex items-center gap-2 flex-shrink-0">
                  <Icon
                    name={'chevron-down'}
                    size={20}
                    stroke="#6b7280"
                  />
                </Animated>
              </button>

              {tabs.map((tab, index) => {
                const isActive = tab.key === activeTabKey;
                const nextTabIsActive = index < tabs.length - 1 && tabs[index + 1].key === activeTabKey;
                return (
                  <button
                    key={tab.key}
                    onClick={() => handleTabClick(tab.key)}
                    className={cn(
                      'relative px-4 text-fluid-sm font-medium transition-all duration-200 border-r',
                      isActive
                        ? 'bg-white text-gray-900 z-10 border-transparent'
                        : 'bg-gray-300 text-gray-600 hover:bg-sky-100 z-0',
                      !isActive && !nextTabIsActive ? 'border-gray-400' : 'border-transparent'
                    )}
                    style={{
                      borderBottomLeftRadius: isActive ? tabBorderRadius : '0px',
                      borderBottomRightRadius: isActive ? tabBorderRadius : '0px',
                      boxShadow: isActive ? '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' : 'none',
                    }}
                  >
                    <div className="flex items-center gap-2" style={{ minHeight: '24px' }}>
                      {tab.icon && (
                        <Icon
                          name={tab.icon}
                          size={20}
                          hover="auto"
                          stroke={
                            isActive
                              ? '#0d9488' // ティール色 (text-teal-600)
                              : '#6b7280' // グレー色 (text-gray-500)
                          }
                          fill={
                            tab.isHighlighted
                              ? '#93c5fd' // 青色 (blue-300)
                              : 'none'
                          }
                        />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* タブコンテンツ */}
          <div
            className={isAnimating || isMinimized ? 'overflow-hidden' : 'overflow-visible'}
            style={{
              maxHeight: (!isMinimized || !showTabBar) ? '30vh' : '0px',
              opacity: (!isMinimized || !showTabBar) ? 1 : 0,
              transition: 'max-height 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55), opacity 600ms ease-in-out',
            }}
            onTransitionEnd={() => setIsAnimating(false)}
          >
            <div
              className={cn(
                'bg-white z-20 relative flex flex-col',
                !showTabBar && 'shadow-md'
              )}
              style={{
                maxHeight: (!isMinimized || !showTabBar) ? '30vh' : undefined,
                padding: isMobile ? '0.25rem 0.5rem' : contentPadding,
                transform: (!isMinimized || !showTabBar) ? 'translateY(0)' : 'translateY(-20px)',
                opacity: (!isMinimized || !showTabBar) ? 1 : 0,
                transition: 'transform 600ms cubic-bezier(0.68, -0.55, 0.265, 1.55), opacity 600ms ease-in-out',
              }}
            >
              {showTabBar && activeTab?.label && (
                <div className="flex-shrink-0 flex justify-between items-center mb-3 pb-1 border-b border-gray-300">
                  <h2 className="text-fluid-base font-semibold text-gray-800">
                    {activeTab.label}
                  </h2>
                  {activeTab.headerRight}
                </div>
              )}
              <div ref={contentScrollRef} className={cn('min-h-0', needsScroll ? 'overflow-y-auto' : 'overflow-visible')}>
                {activeContent}
              </div>
            </div>
          </div>
        </div>
      </LoadingZone>
    </BaseSubHeader>
  );
};

export default AppSubHeader;
