'use client';

import React, { useState, useRef } from 'react';

import { useLink, useNavigate } from '@/adapters/RouterContext';
import { Icon } from '@ui-catalog/core/atoms';
import { Header as BaseHeader } from '@ui-catalog/core/templates';
import { Breadcrumb, type BreadcrumbItem } from '@ui-catalog/core/molecules';
import { MenuItemList, DropdownMenu, BlurFade, ShimmerButton } from '@ui-catalog/core/organisms';
import { LAYOUT_SIZES } from '@/constants/app';

import { ROUTES, NAV_ROUTE_KEYS } from '@/constants/routes';
import { useAuth } from '@/adapters/AuthContext';
import { useDevice } from '@ui-catalog/core/hooks';
import { usePermissions, useThemeConfig } from '@/hooks';

import { SHOW_STYLE_SETTINGS } from '@/config/env';

import ChangePasswordModal from './ChangePasswordModal';
import ThemeSettingsModal from './ThemeSettingsModal';

interface AppHeaderProps {
  leftContent?: React.ReactNode;
  centerContent?: React.ReactNode;
  rightContent?: React.ReactNode;
  rightExtraContent?: React.ReactNode;
  breadcrumbItems?: BreadcrumbItem[];
}

/**
 * アプリケーション共通ヘッダー
 *
 * @param {Object} props
 * @param {React.ReactNode} props.leftContent - 左コンテンツ（未指定時はデフォルトロゴ + パンくずリスト）
 * @param {React.ReactNode} props.centerContent - 中央コンテンツ
 * @param {React.ReactNode} props.rightContent - 右コンテンツ（未指定時はデフォルトメニュー）
 * @param {React.ReactNode} props.rightExtraContent - 右側の追加コンテンツ（通知ベルの左に表示）
 * @param {BreadcrumbItem[]} props.breadcrumbItems - パンくずリストの項目
 */
export default function AppHeader({
  leftContent,
  centerContent,
  rightContent,
  rightExtraContent,
  breadcrumbItems,
}: AppHeaderProps) {
  const { colors } = useThemeConfig('Header');
  const primaryBgColor = colors.primaryBgColor;
  const primaryContrastText = colors.primaryContrastText;
  const primaryBgColorDark = colors.primaryBgColorDark;

  const { user, logout } = useAuth();
  const { canUseFeature, canAccessPage } = usePermissions();
  const { isMobile } = useDevice();

  // 左上ロゴのリンク先: 権限のある最初のページ
  const homePath = NAV_ROUTE_KEYS.find((key) => canAccessPage(ROUTES[key].path));
  const logoHref = homePath ? ROUTES[homePath].path : '/';
  const navigate = useNavigate();
  const Link = useLink();
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const closeMenuRef = useRef<(() => void) | null>(null);

  // スマホではパンくずリストの最後のアイテムのみ表示
  const displayBreadcrumbItems = isMobile && breadcrumbItems && breadcrumbItems.length > 1
    ? [breadcrumbItems[breadcrumbItems.length - 1]]
    : breadcrumbItems;

  // デフォルトの左コンテンツ
  const defaultLeftContent = breadcrumbItems ? (
    <div className="flex items-center space-x-3">
      <Link
        href={logoHref}
        className="flex items-center rounded-lg transition-all duration-200 hover:bg-white/10"
      >
        <img
          src="/images/favicon_1on1.svg"
          alt="1on1 Logo"
          className="h-8 w-8"
        />
      </Link>
      <Breadcrumb
        items={displayBreadcrumbItems!}
        separator=">"
        className="breadcrumb-in-header"
        primaryContrastText={primaryContrastText}
      />
    </div>
  ) : (
    <div className="flex items-center space-x-4">
      <Link
        href={logoHref}
        className="flex items-center rounded-lg text-fluid-xl font-semibold transition-all duration-200 hover:opacity-80"
      >
        <img
          src="/images/favicon_1on1.svg"
          alt="1on1 Logo"
          className="h-8 w-8"
        />
        <span>1on1</span>
      </Link>
    </div>
  );

  // デフォルトの右コンテンツ
  const defaultRightContent = user ? (
    <div className="flex items-center justify-end space-x-1">
      {/* ページから渡された追加コンテンツ */}
      {rightExtraContent}

      {/* 通知ドロップダウン（権限チェック） */}
      {canUseFeature('notifications') && (
        <DropdownMenu
          icon={'bell'}
          iconShake
          menuWidth="w-60"
          primaryContrastText={primaryContrastText}
          menuContent={(closeMenu) => (
            <MenuItemList onClose={closeMenu}>
              <MenuItemList.Item>
                <span className="text-gray-500">お知らせはありません</span>
              </MenuItemList.Item>
            </MenuItemList>
          )}
        />
      )}

      {/* ユーザーメニュードロップダウン */}
      <DropdownMenu
        label={isMobile ? undefined : user['名前']}
        icon={'person'}
        menuWidth="w-64"
        primaryContrastText={primaryContrastText}
        menuContent={(closeMenu) => {
          closeMenuRef.current = closeMenu;
          return (
            <MenuItemList
              menuHeader={
                <div>
                  <p className="text-fluid-sm font-medium text-gray-900">
                    {user['名前']}
                  </p>
                  <p className="mt-0.5 text-fluid-xs text-gray-500">
                    {user['メールアドレス']}
                  </p>
                </div>
              }
              onClose={closeMenu}
            >
              {SHOW_STYLE_SETTINGS && (
                <MenuItemList.Item
                  onClick={() => {
                    setIsSettingsOpen(true);
                  }}
                >
                  <BlurFade delay={0.1}>
                    <div className="flex items-center gap-2">
                      <Icon name={'sliders'} size={20} hover="auto" />
                      <span>テーマ設定</span>
                    </div>
                  </BlurFade>
                </MenuItemList.Item>
              )}
              <MenuItemList.Item
                onClick={() => {
                  setIsPasswordDialogOpen(true);
                }}
              >
                <BlurFade delay={SHOW_STYLE_SETTINGS ? 0.15 : 0.1}>
                  <div className="flex items-center gap-2">
                    <Icon name={'lock'} size={20} hover="auto" />
                    <span>パスワード変更</span>
                  </div>
                </BlurFade>
              </MenuItemList.Item>
              <MenuItemList.Item
                preventClose={true}
                onClick={async () => {
                  setIsLoggingOut(true);
                  try {
                    await logout();
                  } catch {
                    setIsLoggingOut(false);
                  }
                }}
              >
                <BlurFade delay={SHOW_STYLE_SETTINGS ? 0.2 : 0.15}>
                  <div className="flex items-center gap-2">
                    {isLoggingOut ? (
                      <>
                        <Icon
                          preset="spinner"
                          size={20}
                        />
                        <span>ログアウト中...</span>
                      </>
                    ) : (
                      <>
                        <Icon name={'door-out'} size={20} hover="auto" />
                        <span>ログアウト</span>
                      </>
                    )}
                  </div>
                </BlurFade>
              </MenuItemList.Item>
            </MenuItemList>
          );
        }}
      />
    </div>
  ) : (
    <div className="flex items-center justify-end">
      <BlurFade delay={0.2}>
        <ShimmerButton
          onClick={() => navigate('/login')}
          shimmerColor={primaryContrastText}
          background={primaryBgColorDark}
          borderRadius="9999px"
          shimmerDuration="2s"
          className="px-4 py-2 text-fluid-sm font-medium"
        >
          <div className="flex items-center gap-2">
            <Icon name={'door-out'} size={18} hover="auto" />
            <span>ログイン</span>
          </div>
        </ShimmerButton>
      </BlurFade>
    </div>
  );

  return (
    <>
      <BaseHeader
        height={LAYOUT_SIZES.HEADER_HEIGHT}
        bgColor={primaryBgColor}
        textColor={primaryContrastText}
        borderColor={primaryBgColorDark}
        leftContent={leftContent ?? defaultLeftContent}
        centerContent={centerContent}
        rightContent={rightContent ?? defaultRightContent}
      />

      {/* パスワード変更モーダル */}
      <ChangePasswordModal
        isOpen={isPasswordDialogOpen}
        onClose={() => setIsPasswordDialogOpen(false)}
      />

      {/* テーマ設定モーダル */}
      <ThemeSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </>
  );
}
