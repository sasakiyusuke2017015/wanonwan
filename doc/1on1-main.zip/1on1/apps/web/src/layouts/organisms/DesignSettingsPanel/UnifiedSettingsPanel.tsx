/**
 * 統合設定パネル
 * コンポーネントごとに利用可能な設定項目を表示
 */
import React, { FC } from 'react';

import { useAtom, useAtomValue, useSetAtom } from 'jotai';

import { Slider } from '@ui-catalog/core/atoms';
import { ToggleableSection } from '@ui-catalog/core/organisms';
import {
  getThemeConfig,
  ANIMATIONS,
  getConditionalAnimationStyle,
  type ColorTheme,
  type ShapeTheme,
  type BackgroundTheme,
  type TableRowAnimationVariant,
  type CardAnimationVariant,
  type DropMenuAnimationVariant,
} from '@ui-catalog/core/constants';
import { getBackgroundStyle } from '@ui-catalog/core/organisms';
import { BACKGROUND_CONFIG } from '@/constants';
import {
  uiColorThemeAtom,
  uiShapeAtom,
  uiBackgroundAtom,
  uiTableRowAnimationVariantAtom,
  uiCardAnimationVariantAtom,
  uiDropMenuAnimationVariantAtom,
  uiAnimationSpeedAtom,
} from '@/state';
import {
  type ThemeableComponent,
  type ThemeValue,
  COMPONENT_CATEGORIES,
  COMPONENT_LABELS,
  COMPONENT_THEME_USAGE,
  componentThemesAtom,
  updateComponentThemeAtom,
  resetComponentThemesAtom,
} from '@/theme/componentThemes';

import {
  COLOR_OPTIONS,
  SHAPE_OPTIONS,
  BACKGROUND_OPTIONS,
  UI_COLOR_LABELS,
  UI_SHAPE_LABELS,
  TABLE_ROW_ANIMATION_OPTIONS,
  CARD_ANIMATION_OPTIONS,
  DROP_MENU_ANIMATION_OPTIONS,
  type AnimationValue,
} from './constants';

// ============================================
// 設定項目表示用アイコン
// ============================================
const SettingIcons = {
  color: '🎨',
  shape: '⬜',
  background: '🖼️',
  tableRowAnimation: '📊',
  cardAnimation: '🃏',
  dropMenuAnimation: '📝',
  speed: '⚡',
} as const;

// ============================================
// カラー選択
// ============================================
interface ColorSelectorProps {
  value: ThemeValue<ColorTheme>;
  onChange: (value: ThemeValue<ColorTheme>) => void;
  globalColor: ColorTheme;
  showGlobalOption?: boolean;
}

const ColorSelector: FC<ColorSelectorProps> = ({
  value,
  onChange,
  globalColor,
  showGlobalOption = true,
}) => (
  <div className="grid grid-cols-4 gap-2">
    {showGlobalOption && (
      <button
        onClick={() => onChange('global')}
        className={`rounded-lg border-2 p-2 text-center transition-all ${
          value === 'global'
            ? 'border-blue-500 bg-blue-50 shadow-md'
            : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-sm'
        }`}
      >
        <div
          className="mx-auto mb-1.5 h-8 w-8 rounded-full border border-gray-300"
          style={{
            background: `linear-gradient(135deg, ${getThemeConfig(globalColor, 'soft').colors.primaryBgColor} 50%, #e5e7eb 50%)`,
          }}
        />
        <div className={`text-fluid-xs font-medium ${value === 'global' ? 'text-blue-700' : 'text-gray-600'}`}>
          基本
        </div>
      </button>
    )}
    {COLOR_OPTIONS.map((color) => {
      const isSelected = value === color;
      const config = getThemeConfig(color, 'soft');
      return (
        <button
          key={color}
          onClick={() => onChange(color)}
          className={`rounded-lg border-2 p-2 text-center transition-all ${
            isSelected
              ? 'border-blue-500 bg-blue-50 shadow-md'
              : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
          }`}
        >
          <div
            className="mx-auto mb-1.5 h-8 w-8 rounded-full"
            style={{ backgroundColor: config.colors.primaryBgColor }}
          />
          <div className={`text-fluid-xs font-medium ${isSelected ? 'text-blue-700' : 'text-gray-600'}`}>
            {UI_COLOR_LABELS[color]}
          </div>
        </button>
      );
    })}
  </div>
);

// ============================================
// 形状選択
// ============================================
interface ShapeSelectorProps {
  value: ThemeValue<ShapeTheme>;
  onChange: (value: ThemeValue<ShapeTheme>) => void;
  globalShape: ShapeTheme;
  showGlobalOption?: boolean;
}

const ShapeSelector: FC<ShapeSelectorProps> = ({
  value,
  onChange,
  globalShape,
  showGlobalOption = true,
}) => (
  <div className="grid grid-cols-4 gap-2">
    {showGlobalOption && (
      <button
        onClick={() => onChange('global')}
        className={`rounded-lg border-2 p-2 text-center transition-all ${
          value === 'global'
            ? 'border-blue-500 bg-blue-50 shadow-md'
            : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-sm'
        }`}
      >
        <div
          className="mx-auto mb-1.5 h-8 w-8 bg-gray-400"
          style={{ borderRadius: getThemeConfig('emerald', globalShape).shapes.buttonRadius }}
        />
        <div className={`text-fluid-xs font-medium ${value === 'global' ? 'text-blue-700' : 'text-gray-600'}`}>
          基本
        </div>
      </button>
    )}
    {SHAPE_OPTIONS.map((shape) => {
      const isSelected = value === shape;
      const config = getThemeConfig('emerald', shape);
      return (
        <button
          key={shape}
          onClick={() => onChange(shape)}
          className={`rounded-lg border-2 p-2 text-center transition-all ${
            isSelected
              ? 'border-blue-500 bg-blue-50 shadow-md'
              : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
          }`}
        >
          <div
            className="mx-auto mb-1.5 h-8 w-8 bg-gray-400"
            style={{ borderRadius: config.shapes.buttonRadius }}
          />
          <div className={`text-fluid-xs font-medium ${isSelected ? 'text-blue-700' : 'text-gray-600'}`}>
            {UI_SHAPE_LABELS[shape]}
          </div>
        </button>
      );
    })}
  </div>
);

// ============================================
// 背景選択
// ============================================
interface BackgroundSelectorProps {
  value: BackgroundTheme;
  onChange: (value: BackgroundTheme) => void;
}

const BackgroundSelector: FC<BackgroundSelectorProps> = ({ value, onChange }) => (
  <div className="grid grid-cols-3 gap-2">
    {BACKGROUND_OPTIONS.map((bg) => {
      const isSelected = value === bg;
      const bgConfig = BACKGROUND_CONFIG[bg];
      return (
        <button
          key={bg}
          onClick={() => onChange(bg)}
          className={`rounded-lg border-2 p-2 text-center transition-all ${
            isSelected
              ? 'border-purple-500 bg-purple-100 shadow-md'
              : 'border-gray-200 bg-white hover:border-purple-300 hover:shadow-sm'
          }`}
        >
          <div
            className="mx-auto mb-1.5 h-10 w-full border border-gray-200 rounded"
            style={getBackgroundStyle(bg)}
          />
          <div className={`text-fluid-xs font-medium ${isSelected ? 'text-purple-700' : 'text-gray-600'}`}>
            {bgConfig.label}
          </div>
        </button>
      );
    })}
  </div>
);

// ============================================
// アニメーション選択（汎用）
// ============================================
interface AnimationSelectorProps<T extends string> {
  value: AnimationValue<T>;
  onChange: (value: AnimationValue<T>) => void;
  options: { value: AnimationValue<T>; label: string; icon: string }[];
  colorClass: string;
  previewKey: number;
  onReplay: () => void;
  renderPreview: (variant: T, index: number, speed: number) => React.ReactNode;
  speed: number;
}

function AnimationSelector<T extends string>({
  value,
  onChange,
  options,
  colorClass,
  previewKey,
  onReplay,
  renderPreview,
  speed,
}: AnimationSelectorProps<T>) {
  const isNone = value === 'none';

  return (
    <div className="space-y-3">
      {/* 選択ボタン */}
      <div className="grid grid-cols-4 gap-2">
        {options.map((opt) => {
          const isSelected = value === opt.value;
          return (
            <button
              key={opt.value}
              onClick={() => onChange(opt.value)}
              className={`rounded-lg border-2 p-2 text-center transition-all ${
                isSelected
                  ? `${colorClass} shadow-md`
                  : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
              }`}
            >
              <div className="text-fluid-lg mb-1">{opt.icon}</div>
              <div className={`text-fluid-xs font-medium ${isSelected ? 'text-current' : 'text-gray-600'}`}>
                {opt.label}
              </div>
            </button>
          );
        })}
      </div>

      {/* プレビュー（「なし」以外の場合） */}
      {!isNone && (
        <div className="rounded-lg border border-gray-200 bg-white p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-fluid-xs text-gray-500">プレビュー</span>
            <button
              onClick={onReplay}
              className="px-2 py-1 text-fluid-xs text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors"
            >
              ▶ 再生
            </button>
          </div>
          <div key={previewKey} className="overflow-hidden space-y-1">
            {[0, 1, 2].map((index) => renderPreview(value as T, index, speed))}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// コンポーネント設定行
// ============================================
interface ComponentSettingsRowProps {
  component: ThemeableComponent;
  isExpanded: boolean;
  onToggle: () => void;
}

const ComponentSettingsRow: FC<ComponentSettingsRowProps> = ({
  component,
  isExpanded,
  onToggle,
}) => {
  const usage = COMPONENT_THEME_USAGE[component];

  // グローバル設定
  const [globalColor] = useAtom(uiColorThemeAtom);
  const [globalShape] = useAtom(uiShapeAtom);
  const [background, setBackground] = useAtom(uiBackgroundAtom);

  // コンポーネントテーマ
  const componentThemes = useAtomValue(componentThemesAtom);
  const updateTheme = useSetAtom(updateComponentThemeAtom);
  const config = componentThemes[component] ?? { color: 'global', shape: 'global' };

  // アニメーション設定
  const [tableRowVariant, setTableRowVariant] = useAtom(uiTableRowAnimationVariantAtom);
  const [cardVariant, setCardVariant] = useAtom(uiCardAnimationVariantAtom);
  const [dropMenuVariant, setDropMenuVariant] = useAtom(uiDropMenuAnimationVariantAtom);
  const [animationSpeed, setAnimationSpeed] = useAtom(uiAnimationSpeedAtom);

  // プレビュー再生用のキー
  const [tableRowPreviewKey, setTableRowPreviewKey] = React.useState(0);
  const [cardPreviewKey, setCardPreviewKey] = React.useState(0);
  const [dropMenuPreviewKey, setDropMenuPreviewKey] = React.useState(0);

  // AnimationValue型への変換（none = アニメーションなし）
  const tableRowValue: AnimationValue<TableRowAnimationVariant> = tableRowVariant;
  const cardValue: AnimationValue<CardAnimationVariant> = cardVariant;
  const dropMenuValue: AnimationValue<DropMenuAnimationVariant> = dropMenuVariant;

  // 使用可能な設定項目があるかチェック
  const hasAnySettings =
    usage.usesColor ||
    usage.usesShape ||
    usage.usesBackground ||
    usage.usesTableRowAnimation ||
    usage.usesCardAnimation ||
    usage.usesDropMenuAnimation;

  if (!hasAnySettings) return null;

  // カスタマイズ状態
  const isCustomized =
    (usage.usesColor && config.color !== 'global') ||
    (usage.usesShape && config.shape !== 'global');

  // プレビュー用テーマ
  const resolvedColor = config.color === 'global' ? globalColor : (config.color ?? globalColor);
  const resolvedShape = config.shape === 'global' ? globalShape : (config.shape ?? globalShape);
  const themeConfig = getThemeConfig(resolvedColor, resolvedShape);

  // 利用可能な設定アイコンを生成
  const availableSettingIcons: string[] = [];
  if (usage.usesColor) availableSettingIcons.push(SettingIcons.color);
  if (usage.usesShape) availableSettingIcons.push(SettingIcons.shape);
  if (usage.usesBackground) availableSettingIcons.push(SettingIcons.background);
  if (usage.usesTableRowAnimation) availableSettingIcons.push(SettingIcons.tableRowAnimation);
  if (usage.usesCardAnimation) availableSettingIcons.push(SettingIcons.cardAnimation);
  if (usage.usesDropMenuAnimation) availableSettingIcons.push(SettingIcons.dropMenuAnimation);

  // ヘッダー部分（ToggleableSectionのtitleとして渡す）
  const headerContent = (
    <div className="flex items-center gap-3 flex-1">
      {/* プレビュー */}
      <div className="flex items-center gap-1.5">
        {usage.usesColor && (
          <div
            className="w-6 h-6 rounded-full shadow-sm border border-gray-200"
            style={{ backgroundColor: themeConfig.colors.primaryBgColor }}
          />
        )}
        {usage.usesShape && (
          <div
            className="w-5 h-5 bg-gray-400"
            style={{ borderRadius: themeConfig.shapes.buttonRadius }}
          />
        )}
        {usage.usesBackground && (
          <div
            className="w-6 h-6 rounded border border-gray-200"
            style={getBackgroundStyle(background)}
          />
        )}
      </div>

      {/* コンポーネント名 */}
      <div className="flex-1">
        <span className="text-fluid-sm font-medium text-gray-800">
          {COMPONENT_LABELS[component]}
        </span>
        {isCustomized && (
          <span className="ml-2 px-1.5 py-0.5 text-fluid-xs bg-amber-200 text-amber-800 rounded">
            カスタム
          </span>
        )}
      </div>

      {/* 利用可能な設定アイコン */}
      <div className="text-fluid-xs text-gray-400">
        {availableSettingIcons.join(' ')}
      </div>
    </div>
  );

  return (
    <ToggleableSection
      title={headerContent}
      borderColor={isCustomized ? themeConfig.colors.primaryBgColor : 'border-gray-300'}
      isOpen={isExpanded}
      onToggle={onToggle}
      defaultOpen={false}
      marginClassName="mb-2"
      buttonBgColor={isCustomized ? 'rgba(255, 251, 235, 1)' : 'rgba(255, 255, 255, 1)'}
      contentBgColor="rgba(255, 255, 255, 1)"
      hoverBgColor="rgba(249, 250, 251, 1)"
      cardRadius="0.5rem"
      contentPaddingClassName="px-3 py-3"
    >
      <div className="space-y-4">
          {/* カラー設定 */}
          {usage.usesColor && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.color} カラー
              </div>
              <ColorSelector
                value={config.color ?? 'global'}
                onChange={(v) => updateTheme({ component, config: { color: v } })}
                globalColor={globalColor}
              />
            </div>
          )}

          {/* 形状設定 */}
          {usage.usesShape && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.shape} 形状
              </div>
              <ShapeSelector
                value={config.shape ?? 'global'}
                onChange={(v) => updateTheme({ component, config: { shape: v } })}
                globalShape={globalShape}
              />
            </div>
          )}

          {/* 背景設定 */}
          {usage.usesBackground && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.background} 背景
              </div>
              <BackgroundSelector value={background} onChange={setBackground} />
            </div>
          )}

          {/* テーブル行アニメーション */}
          {usage.usesTableRowAnimation && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.tableRowAnimation} テーブル行アニメーション
              </div>
              <AnimationSelector<Exclude<TableRowAnimationVariant, 'none'>>
                value={tableRowValue === 'none' ? 'none' : tableRowValue}
                onChange={(v) => setTableRowVariant(v as TableRowAnimationVariant)}
                options={TABLE_ROW_ANIMATION_OPTIONS as { value: AnimationValue<Exclude<TableRowAnimationVariant, 'none'>>; label: string; icon: string }[]}
                colorClass="border-blue-500 bg-blue-50 text-blue-700"
                previewKey={tableRowPreviewKey}
                onReplay={() => setTableRowPreviewKey((k) => k + 1)}
                speed={animationSpeed}
                renderPreview={(variant, index, speed) => {
                  const animConfig = ANIMATIONS.tableRow[variant];
                  return (
                    <div
                      key={index}
                      style={getConditionalAnimationStyle(true, animConfig, index, speed)}
                      className="rounded bg-blue-100 px-3 py-2 text-fluid-xs text-blue-800"
                    >
                      行 {index + 1}
                    </div>
                  );
                }}
              />
            </div>
          )}

          {/* カードアニメーション */}
          {usage.usesCardAnimation && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.cardAnimation} カードアニメーション
              </div>
              <AnimationSelector<Exclude<CardAnimationVariant, 'none'>>
                value={cardValue === 'none' ? 'none' : cardValue}
                onChange={(v) => setCardVariant(v as CardAnimationVariant)}
                options={CARD_ANIMATION_OPTIONS as { value: AnimationValue<Exclude<CardAnimationVariant, 'none'>>; label: string; icon: string }[]}
                colorClass="border-purple-500 bg-purple-50 text-purple-700"
                previewKey={cardPreviewKey}
                onReplay={() => setCardPreviewKey((k) => k + 1)}
                speed={animationSpeed}
                renderPreview={(variant, index, speed) => {
                  const animConfig = ANIMATIONS.card[variant];
                  return (
                    <div
                      key={index}
                      style={getConditionalAnimationStyle(true, animConfig, index, speed)}
                      className="inline-block rounded-lg border border-purple-200 bg-purple-100 p-2 mr-2 text-fluid-xs text-purple-700"
                    >
                      カード{index + 1}
                    </div>
                  );
                }}
              />
            </div>
          )}

          {/* ドロップメニューアニメーション */}
          {usage.usesDropMenuAnimation && (
            <div>
              <div className="text-fluid-xs font-medium text-gray-600 mb-2">
                {SettingIcons.dropMenuAnimation} ドロップメニューアニメーション
              </div>
              <AnimationSelector<Exclude<DropMenuAnimationVariant, 'none'>>
                value={dropMenuValue === 'none' ? 'none' : dropMenuValue}
                onChange={(v) => setDropMenuVariant(v as DropMenuAnimationVariant)}
                options={DROP_MENU_ANIMATION_OPTIONS as { value: AnimationValue<Exclude<DropMenuAnimationVariant, 'none'>>; label: string; icon: string }[]}
                colorClass="border-green-500 bg-green-50 text-green-700"
                previewKey={dropMenuPreviewKey}
                onReplay={() => setDropMenuPreviewKey((k) => k + 1)}
                speed={animationSpeed}
                renderPreview={(variant, index, speed) => {
                  const animConfig = ANIMATIONS.dropMenu[variant];
                  return (
                    <div
                      key={index}
                      style={getConditionalAnimationStyle(true, animConfig, index, speed)}
                      className="border-b border-green-200 bg-green-50 px-3 py-2 text-fluid-xs text-green-800 last:border-b-0"
                    >
                      メニュー{index + 1}
                    </div>
                  );
                }}
              />
            </div>
          )}

          {/* 共通アニメーション速度（アニメーションを使うコンポーネントのみ） */}
          {(usage.usesTableRowAnimation || usage.usesCardAnimation || usage.usesDropMenuAnimation) && (
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-3">
              <div className="text-fluid-xs font-medium text-gray-700 mb-2">
                {SettingIcons.speed} アニメーション速度
              </div>
              <Slider
                value={animationSpeed}
                onChange={setAnimationSpeed}
                min={0.5}
                max={2.0}
                step={0.1}
                formatValue={(v) => `${v.toFixed(1)}x`}
              />
            </div>
          )}
        </div>
      </ToggleableSection>
  );
};

// ============================================
// メインコンポーネント
// ============================================
const UnifiedSettingsPanel: FC = () => {
  const [globalColor, setGlobalColor] = useAtom(uiColorThemeAtom);
  const [globalShape, setGlobalShape] = useAtom(uiShapeAtom);
  const [background, setBackground] = useAtom(uiBackgroundAtom);
  const componentThemes = useAtomValue(componentThemesAtom);
  const resetThemes = useSetAtom(resetComponentThemesAtom);

  const [expandedComponents, setExpandedComponents] = React.useState<Set<ThemeableComponent>>(new Set());

  // カスタマイズ数
  const customizedCount = Object.entries(componentThemes).filter(([key, config]) => {
    const usage = COMPONENT_THEME_USAGE[key as ThemeableComponent];
    if (!usage) return false;
    return (
      (usage.usesColor && config?.color !== 'global') ||
      (usage.usesShape && config?.shape !== 'global')
    );
  }).length;

  return (
    <div className="space-y-6">
      {/* 基本設定 */}
      <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-fluid-sm font-bold text-blue-900">🎨 基本テーマ</h4>
            <p className="text-fluid-xs text-blue-700 mt-0.5">
              全体のデフォルト設定
            </p>
          </div>
          {customizedCount > 0 && (
            <button
              onClick={resetThemes}
              className="px-3 py-1.5 text-fluid-xs font-medium text-red-600 bg-white hover:bg-red-50 border border-red-200 rounded-lg transition-colors"
            >
              全てリセット
            </button>
          )}
        </div>

        <div className="mb-4">
          <div className="text-fluid-xs font-medium text-gray-600 mb-2">カラー</div>
          <ColorSelector
            value={globalColor}
            onChange={(v) => v !== 'global' && setGlobalColor(v)}
            globalColor={globalColor}
            showGlobalOption={false}
          />
        </div>

        <div className="mb-4">
          <div className="text-fluid-xs font-medium text-gray-600 mb-2">形状</div>
          <ShapeSelector
            value={globalShape}
            onChange={(v) => v !== 'global' && setGlobalShape(v)}
            globalShape={globalShape}
            showGlobalOption={false}
          />
        </div>

        <div>
          <div className="text-fluid-xs font-medium text-gray-600 mb-2">背景</div>
          <BackgroundSelector value={background} onChange={setBackground} />
        </div>
      </div>

      {/* コンポーネント別設定 */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-fluid-sm font-bold text-gray-800">
            コンポーネント別設定
            {customizedCount > 0 && (
              <span className="ml-2 text-fluid-xs font-normal text-amber-600">
                ({customizedCount}件カスタム中)
              </span>
            )}
          </h4>
        </div>

        <div className="space-y-4">
          {Object.entries(COMPONENT_CATEGORIES).map(([categoryKey, category]) => {
            // 設定項目があるコンポーネントのみフィルタ
            const componentsWithSettings = category.components.filter((c) => {
              const usage = COMPONENT_THEME_USAGE[c];
              return (
                usage.usesColor ||
                usage.usesShape ||
                usage.usesBackground ||
                usage.usesTableRowAnimation ||
                usage.usesCardAnimation ||
                usage.usesDropMenuAnimation
              );
            });

            if (componentsWithSettings.length === 0) return null;

            return (
              <div key={categoryKey}>
                <div className="text-fluid-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  {category.label}
                </div>
                <div className="space-y-2">
                  {componentsWithSettings.map((component) => (
                    <ComponentSettingsRow
                      key={component}
                      component={component}
                      isExpanded={expandedComponents.has(component)}
                      onToggle={() => {
                        setExpandedComponents((prev) => {
                          const next = new Set(prev);
                          if (next.has(component)) {
                            next.delete(component);
                          } else {
                            next.add(component);
                          }
                          return next;
                        });
                      }}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default UnifiedSettingsPanel;
