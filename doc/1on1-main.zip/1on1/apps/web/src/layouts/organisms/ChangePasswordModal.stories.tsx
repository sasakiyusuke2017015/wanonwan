import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import ChangePasswordModal from './ChangePasswordModal';
import { Button } from '@ui-catalog/core/atoms';
import { AuthProvider } from '@/adapters/AuthContext';
import type { AuthAdapter } from '@/adapters/types';
import type { User } from '@/types';

// Storybook用のモックアダプター
const createMockAuthAdapter = (): AuthAdapter<User> => ({
  user: null,
  token: 'mock-token',
  loading: false,
  isAuthenticated: true,
  login: async () => ({ success: true }),
  logout: async () => {},
  getAuthHeaders: () => ({ Authorization: 'Bearer mock-token' }),
  changePassword: async () => ({ success: true }),
});

const meta: Meta<typeof ChangePasswordModal> = {
  title: '認証/ChangePasswordModal',
  component: ChangePasswordModal,
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <AuthProvider adapter={createMockAuthAdapter()}>
        <Story />
      </AuthProvider>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ChangePasswordModal>;

export const Default: Story = {
  render: () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <>
        <Button onClick={() => setIsOpen(true)}>パスワード変更を開く</Button>
        <ChangePasswordModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          onSuccess={() => {
            console.log('パスワード変更成功');
          }}
        />
      </>
    );
  },
};

export const Opened: Story = {
  args: {
    isOpen: true,
    onClose: () => {},
  },
};

export const CustomRadius: Story = {
  args: {
    isOpen: true,
    onClose: () => {},
    cardRadius: '1rem',
  },
};

export const WithCallback: Story = {
  render: () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <>
        <Button onClick={() => setIsOpen(true)}>パスワード変更を開く</Button>
        <ChangePasswordModal
          isOpen={isOpen}
          onClose={() => {
            console.log('モーダルが閉じられました');
            setIsOpen(false);
          }}
          onSuccess={() => {
            console.log('パスワード変更に成功しました');
          }}
        />
      </>
    );
  },
};
