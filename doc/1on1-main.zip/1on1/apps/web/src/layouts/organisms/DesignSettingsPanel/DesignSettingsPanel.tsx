// src/components/project/organisms/DesignSettingsPanel.tsx
import { FC } from 'react';

import { useAtomValue } from 'jotai';

import { DevelopmentBanner } from '@ui-catalog/core/molecules';
import { getBackgroundStyle } from '@ui-catalog/core/organisms';
import { themeConfigAtom, uiBackgroundAtom } from '../../../state';

import UnifiedSettingsPanel from './UnifiedSettingsPanel';

/**
 * デザイン設定パネル
 * 統合設定パネル + プレビュー
 */
const DesignSettingsPanel: FC = () => {
  const themeConfig = useAtomValue(themeConfigAtom);
  const uiBackground = useAtomValue(uiBackgroundAtom);

  return (
    <div className="space-y-4">
      {/* 開発中バナー */}
      <DevelopmentBanner
        message="テーマ設定は開発中です。一部の設定が反映されない場合があります。"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 左カラム: 統合設定 */}
        <div>
          <UnifiedSettingsPanel />
        </div>

      {/* 右カラム: プレビュー（sticky固定） */}
      <div className="lg:sticky lg:top-4 lg:self-start space-y-4">
        <h3 className="flex items-center text-fluid-sm font-bold text-gray-900">
          <span className="mr-2">👁️</span>
          プレビュー
        </h3>

        <div
          className="min-h-[400px] max-h-[calc(100vh-8rem)] overflow-auto rounded-xl border-2 border-gray-200 p-6 shadow-inner"
          style={getBackgroundStyle(uiBackground)}
        >
          <div className="space-y-4">
            {/* カード */}
            <div
              className="bg-white/90 p-4 shadow-lg backdrop-blur-sm"
              style={{ borderRadius: themeConfig.shapes.cardRadius }}
            >
              <h4 className="mb-2 text-fluid-sm font-bold text-gray-800">カード</h4>
              <p className="text-fluid-xs text-gray-600">
                背景とテーマの組み合わせを確認できます。
              </p>
            </div>

            {/* ボタン群 */}
            <div className="flex flex-wrap gap-2">
              <button
                className="px-4 py-2 text-fluid-sm font-medium text-white shadow-md transition-transform hover:scale-105"
                style={{
                  backgroundColor: themeConfig.colors.primaryBgColor,
                  borderRadius: themeConfig.shapes.buttonRadius,
                }}
              >
                プライマリ
              </button>
              <button
                className="border-2 px-4 py-2 text-fluid-sm font-medium shadow-sm transition-transform hover:scale-105 bg-white/80"
                style={{
                  borderColor: themeConfig.colors.primaryBorderColor,
                  color: themeConfig.colors.primaryTextColor,
                  borderRadius: themeConfig.shapes.buttonRadius,
                }}
              >
                セカンダリ
              </button>
              <button
                className="px-4 py-2 text-fluid-sm font-medium text-white shadow-md transition-transform hover:scale-105"
                style={{
                  backgroundColor: themeConfig.colors.accentBgColor,
                  borderRadius: themeConfig.shapes.buttonRadius,
                }}
              >
                アクセント
              </button>
            </div>

            {/* バッジ */}
            <div className="flex flex-wrap gap-2">
              <span
                className="inline-flex items-center px-3 py-1 text-fluid-xs font-medium shadow-sm"
                style={{
                  backgroundColor: themeConfig.colors.primaryBgColor,
                  color: themeConfig.colors.primaryContrastText,
                  borderRadius: themeConfig.shapes.badgeRadius,
                }}
              >
                ステータス
              </span>
              <span
                className="inline-flex items-center px-3 py-1 text-fluid-xs font-medium shadow-sm"
                style={{
                  backgroundColor: themeConfig.colors.accentBgColor,
                  color: themeConfig.colors.accentContrastText,
                  borderRadius: themeConfig.shapes.badgeRadius,
                }}
              >
                新着
              </span>
            </div>

            {/* テーブルヘッダー風 */}
            <div
              className="overflow-hidden shadow-md"
              style={{ borderRadius: themeConfig.shapes.borderRadius }}
            >
              <div
                className="px-4 py-3 text-fluid-sm font-semibold"
                style={{
                  backgroundColor: themeConfig.colors.tableHeaderBgColor,
                  color: themeConfig.colors.tableHeaderTextColor,
                }}
              >
                テーブルヘッダー
              </div>
              <div className="bg-white/90 px-4 py-3 text-fluid-xs text-gray-600">
                テーブルコンテンツ
              </div>
            </div>

            {/* 入力フィールド */}
            <input
              type="text"
              placeholder="入力フィールド"
              className="w-full border-2 bg-white/90 px-3 py-2 text-fluid-sm focus:outline-none shadow-sm"
              style={{
                borderColor: themeConfig.colors.secondaryBorderColor,
                borderRadius: themeConfig.shapes.inputRadius,
              }}
              readOnly
            />
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};

export default DesignSettingsPanel;
