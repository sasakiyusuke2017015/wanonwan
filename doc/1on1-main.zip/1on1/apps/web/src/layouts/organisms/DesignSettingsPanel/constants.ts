import type {
  ColorTheme,
  ShapeTheme,
  BackgroundTheme,
  TableRowAnimationVariant,
  CardAnimationVariant,
  DropMenuAnimationVariant,
} from '@/constants';

// 形状オプション
export const SHAPE_OPTIONS: ShapeTheme[] = ['rounded', 'soft', 'sharp'];

// 色オプション
export const COLOR_OPTIONS: ColorTheme[] = ['indigo', 'slate', 'blue', 'emerald', 'rose', 'light'];

// 背景オプション
export const BACKGROUND_OPTIONS: BackgroundTheme[] = ['wood', 'flooring', 'fabric', 'concrete', 'leather', 'marble', 'cream', 'lavender', 'sky'];

// 形状の表示ラベル
export const UI_SHAPE_LABELS: Record<ShapeTheme, string> = {
  rounded: 'まるい',
  soft: 'ふつう',
  sharp: 'かくばった',
};

// 色テーマの表示ラベル
export const UI_COLOR_LABELS: Record<ColorTheme, string> = {
  indigo: 'インディゴ',
  slate: 'スレート',
  blue: 'ブルー',
  emerald: 'エメラルド',
  rose: 'ローズ',
  light: 'ライト',
};

// 色テーマの説明
export const UI_COLOR_DESCRIPTIONS: Record<ColorTheme, string> = {
  indigo: '深みのある紫がかった青',
  slate: '落ち着いたグレー系',
  blue: '爽やかな青',
  emerald: '鮮やかな緑',
  rose: '華やかなピンク系',
  light: '明るいライトモード',
};

// ============================================
// アニメーション設定
// ============================================

// 「なし」を含むアニメーション値型
export type AnimationValue<T> = 'none' | T;

// テーブル行アニメーションオプション
export const TABLE_ROW_ANIMATION_OPTIONS: { value: AnimationValue<TableRowAnimationVariant>; label: string; icon: string }[] = [
  { value: 'none', label: 'なし', icon: '⏹️' },
  { value: 'slideDown', label: '下から', icon: '⬇️' },
  { value: 'slideLeft', label: '左から', icon: '⬅️' },
  { value: 'fadeIn', label: 'フェード', icon: '🌫️' },
];

// カードアニメーションオプション
export const CARD_ANIMATION_OPTIONS: { value: AnimationValue<CardAnimationVariant>; label: string; icon: string }[] = [
  { value: 'none', label: 'なし', icon: '⏹️' },
  { value: 'slideRight', label: '右から', icon: '➡️' },
  { value: 'slideDown', label: '下から', icon: '⬇️' },
  { value: 'fadeIn', label: 'フェード', icon: '🌫️' },
  { value: 'scaleUp', label: '拡大', icon: '🔍' },
  { value: 'bounceIn', label: 'バウンス', icon: '🎾' },
];

// ドロップメニューアニメーションオプション
export const DROP_MENU_ANIMATION_OPTIONS: { value: AnimationValue<DropMenuAnimationVariant>; label: string; icon: string }[] = [
  { value: 'none', label: 'なし', icon: '⏹️' },
  { value: 'slideDown', label: '下から', icon: '⬇️' },
  { value: 'fadeIn', label: 'フェード', icon: '🌫️' },
  { value: 'scaleY', label: '縦伸び', icon: '↕️' },
];
