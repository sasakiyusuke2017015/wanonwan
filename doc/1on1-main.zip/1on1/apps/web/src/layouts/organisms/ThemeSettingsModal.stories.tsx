import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import ThemeSettingsModal from './ThemeSettingsModal';
import { Button } from '@ui-catalog/core/atoms';

const meta: Meta<typeof ThemeSettingsModal> = {
  title: '設定/ThemeSettingsModal',
  component: ThemeSettingsModal,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ThemeSettingsModal>;

export const Default: Story = {
  render: () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <>
        <Button onClick={() => setIsOpen(true)}>テーマ設定を開く</Button>
        <ThemeSettingsModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
      </>
    );
  },
};

export const Opened: Story = {
  args: {
    isOpen: true,
    onClose: () => {},
  },
};

export const DesignTab: Story = {
  args: {
    isOpen: true,
    onClose: () => {},
  },
};

export const WithInteraction: Story = {
  render: () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <div className="p-8">
        <div className="mb-4 rounded-lg bg-blue-50 p-4">
          <p className="text-fluid-sm text-blue-800">
            このストーリーでは、モーダルを開いてデザイン設定とアニメーション設定を切り替えることができます。
          </p>
        </div>
        <Button onClick={() => setIsOpen(true)}>テーマ設定を開く</Button>
        <ThemeSettingsModal
          isOpen={isOpen}
          onClose={() => {
            console.log('モーダルが閉じられました');
            setIsOpen(false);
          }}
        />
      </div>
    );
  },
};
