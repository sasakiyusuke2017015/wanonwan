import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ThemeSettingsModal from './ThemeSettingsModal';

describe('ThemeSettingsModal', () => {
  it('isOpen=falseの場合、モーダルが表示されない', () => {
    render(<ThemeSettingsModal isOpen={false} onClose={() => {}} />);
    expect(screen.queryByText('設定')).not.toBeInTheDocument();
  });

  it('isOpen=trueの場合、モーダルが表示される', () => {
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    expect(screen.getByText('設定')).toBeInTheDocument();
  });

  it('2つのタブボタンが表示される', () => {
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    expect(screen.getByText(/デザイン設定/)).toBeInTheDocument();
    expect(screen.getByText(/アニメーション設定/)).toBeInTheDocument();
  });

  it('初期状態ではデザイン設定タブがアクティブ', () => {
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    const designTab = screen.getByText(/デザイン設定/).closest('button');
    expect(designTab).toHaveClass('border-b-2');
    expect(designTab).toHaveClass('border-blue-500');
  });

  it('初期状態ではDesignSettingsPanelが表示される', () => {
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    expect(screen.getByText(/背景設定（ページレベル）/)).toBeInTheDocument();
  });

  it('アニメーション設定タブをクリックすると表示が切り替わる', async () => {
    const user = userEvent.setup();
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);

    const animationTab = screen.getByText(/アニメーション設定/).closest('button');
    if (animationTab) {
      await user.click(animationTab);

      // AnimationSettingsPanelが表示される
      expect(screen.getByText(/アニメーション速度（全体）/)).toBeInTheDocument();
    }
  });

  it('デザイン設定タブをクリックすると表示が切り替わる', async () => {
    const user = userEvent.setup();
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);

    // まずアニメーションタブに切り替え
    const animationTab = screen.getByText(/アニメーション設定/).closest('button');
    if (animationTab) {
      await user.click(animationTab);
    }

    // デザインタブに戻す
    const designTab = screen.getByText(/デザイン設定/).closest('button');
    if (designTab) {
      await user.click(designTab);

      // DesignSettingsPanelが表示される
      expect(screen.getByText(/背景設定（ページレベル）/)).toBeInTheDocument();
    }
  });

  it('リセットボタンが表示される', () => {
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    // ResetButtonは「リセット」というテキストを持つButtonを使用
    expect(screen.getByRole('button', { name: /リセット/ })).toBeInTheDocument();
  });

  it('リセットボタンをクリックすると設定がリセットされる', async () => {
    const user = userEvent.setup();
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);

    const resetButton = screen.getByRole('button', { name: /リセット/ });
    await user.click(resetButton);
    // リセット処理が実行される（Jotai atomの状態がリセットされる）
  });

  it('タブ切り替え時にアクティブなタブのスタイルが変わる', async () => {
    const user = userEvent.setup();
    render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);

    const animationTab = screen.getByText(/アニメーション設定/).closest('button');
    if (animationTab) {
      await user.click(animationTab);

      // アニメーションタブがアクティブになる
      expect(animationTab).toHaveClass('border-b-2');
      expect(animationTab).toHaveClass('border-blue-500');
      expect(animationTab).toHaveClass('text-blue-600');

      // デザインタブが非アクティブになる
      const designTab = screen.getByText(/デザイン設定/).closest('button');
      expect(designTab).not.toHaveClass('border-b-2');
      expect(designTab).toHaveClass('text-gray-600');
    }
  });

  it('モーダルのコンテンツエリアが適切な高さを持つ', () => {
    const { container } = render(<ThemeSettingsModal isOpen={true} onClose={() => {}} />);
    const contentArea = container.querySelector('.min-h-\\[500px\\]');
    expect(contentArea).toBeInTheDocument();
  });
});
