import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import DesignSettingsPanel from './DesignSettingsPanel';

describe('DesignSettingsPanel', () => {
  it('背景設定セクションが表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText(/背景設定（ページレベル）/)).toBeInTheDocument();
  });

  it('要素テーマ設定セクションが表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText(/要素テーマ設定（エレメントレベル）/)).toBeInTheDocument();
  });

  it('プレビューセクションが表示される', () => {
    render(<DesignSettingsPanel />);
    // 「👁️ プレビュー」というタイトルを持つセクションを確認
    expect(screen.getByText('👁️')).toBeInTheDocument();
  });

  it('背景オプションボタンが9つ表示される', () => {
    render(<DesignSettingsPanel />);
    // 背景テーマのラベルを確認（BACKGROUND_CONFIGの値に合わせる）
    expect(screen.getByText('木目')).toBeInTheDocument();
    expect(screen.getByText('フロア')).toBeInTheDocument();
    expect(screen.getByText('布')).toBeInTheDocument();
    expect(screen.getByText('タイル')).toBeInTheDocument();
    expect(screen.getByText('紙')).toBeInTheDocument();
    expect(screen.getByText('ミント')).toBeInTheDocument();
    expect(screen.getByText('クリーム')).toBeInTheDocument();
    expect(screen.getByText('ラベンダー')).toBeInTheDocument();
    expect(screen.getByText('スカイ')).toBeInTheDocument();
  });

  it('カラーテーマオプションが6つ表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('インディゴ')).toBeInTheDocument();
    expect(screen.getByText('スレート')).toBeInTheDocument();
    expect(screen.getByText('ブルー')).toBeInTheDocument();
    expect(screen.getByText('エメラルド')).toBeInTheDocument();
    expect(screen.getByText('ローズ')).toBeInTheDocument();
    expect(screen.getByText('ライト')).toBeInTheDocument();
  });

  it('形状オプションが3つ表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('まるい')).toBeInTheDocument();
    expect(screen.getByText('ふつう')).toBeInTheDocument();
    expect(screen.getByText('かくばった')).toBeInTheDocument();
  });

  it('プレビューエリアが表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('カード要素')).toBeInTheDocument();
    expect(screen.getByText('プライマリボタン')).toBeInTheDocument();
    expect(screen.getByText('セカンダリボタン')).toBeInTheDocument();
    expect(screen.getByText('アクセントボタン')).toBeInTheDocument();
  });

  it('バッジプレビューが表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('ステータス')).toBeInTheDocument();
    expect(screen.getByText('新着')).toBeInTheDocument();
  });

  it('折りたたみセクションプレビューが表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('折りたたみセクション')).toBeInTheDocument();
  });

  it('入力フィールドプレビューが表示される', () => {
    render(<DesignSettingsPanel />);
    const input = screen.getByPlaceholderText('入力フィールド');
    expect(input).toBeInTheDocument();
  });

  it('現在の設定情報が表示される', () => {
    render(<DesignSettingsPanel />);
    expect(screen.getByText('現在の設定')).toBeInTheDocument();
  });

  it('背景ボタンをクリックすると選択が変更される', async () => {
    const user = userEvent.setup();
    render(<DesignSettingsPanel />);

    // 木目調ボタンを探してクリック
    const woodButton = screen.getByText('木目調').closest('button');
    if (woodButton) {
      await user.click(woodButton);

      // 選択されたことを確認（border-purple-500クラスが適用される）
      expect(woodButton).toHaveClass('border-purple-500');
    }
  });

  it('カラーテーマボタンをクリックすると選択が変更される', async () => {
    const user = userEvent.setup();
    render(<DesignSettingsPanel />);

    const blueButton = screen.getByText('ブルー').closest('button');
    if (blueButton) {
      await user.click(blueButton);

      // 選択されたことを確認
      expect(blueButton).toHaveClass('border-blue-500');
    }
  });

  it('形状ボタンをクリックすると選択が変更される', async () => {
    const user = userEvent.setup();
    render(<DesignSettingsPanel />);

    const roundedButton = screen.getByText('まるい').closest('button');
    if (roundedButton) {
      await user.click(roundedButton);

      // 選択されたことを確認
      expect(roundedButton).toHaveClass('border-blue-500');
    }
  });

  it('背景プレビューが表示される', () => {
    const { container } = render(<DesignSettingsPanel />);
    const previewArea = container.querySelector('.min-h-\\[500px\\]');
    expect(previewArea).toBeInTheDocument();
  });

  it('カラーテーマプレビューの色見本が表示される', () => {
    const { container } = render(<DesignSettingsPanel />);
    const colorSamples = container.querySelectorAll('.rounded-full');
    expect(colorSamples.length).toBeGreaterThanOrEqual(6); // 6つのカラーテーマ
  });

  it('形状プレビューの四角が表示される', () => {
    const { container } = render(<DesignSettingsPanel />);
    // 形状プレビューの四角は h-8 w-8 bg-gray-400
    const shapeSamples = container.querySelectorAll('.h-8.w-8.bg-gray-400');
    expect(shapeSamples.length).toBe(3); // 3つの形状オプション
  });
});
