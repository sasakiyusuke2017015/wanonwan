import { describe, it, expect, vi } from 'vitest';
import { render } from '@testing-library/react';
import AppHeader from './AppHeader';
import { AuthProvider } from '@/adapters/AuthContext';
import { RouterProvider } from '@/adapters/RouterContext';
import type { AuthAdapter, RouterAdapter, LinkProps } from '@/adapters/types';
import type { User } from '@/types';

// テスト用のモックRouterアダプター
const createMockRouterAdapter = (): RouterAdapter => ({
  useNavigate: () => vi.fn(),
  usePathname: () => '/',
  Link: ({ href, children, className, style, ...props }: LinkProps) => (
    <a href={href} className={className} style={style} {...props}>
      {children}
    </a>
  ),
});

// テスト用のモックAuthアダプター
const createMockAuthAdapter = (withUser = false): AuthAdapter<User> => ({
  user: withUser ? { id: 1, email: 'test@test.com', name: 'Test User' } as User : null,
  token: withUser ? 'mock-token' : null,
  loading: false,
  isAuthenticated: withUser,
  login: async () => ({ success: true }),
  logout: async () => {},
  getAuthHeaders: () => ({}),
});

// テスト用のラッパーコンポーネント
const TestWrapper = ({ children, withUser = false }: { children: React.ReactNode; withUser?: boolean }) => (
  <RouterProvider adapter={createMockRouterAdapter()}>
    <AuthProvider adapter={createMockAuthAdapter(withUser)}>{children}</AuthProvider>
  </RouterProvider>
);

describe('AppHeader', () => {
  it('ヘッダーが表示される', () => {
    const { container } = render(
      <TestWrapper>
        <AppHeader />
      </TestWrapper>
    );
    const header = container.querySelector('header');
    expect(header).toBeInTheDocument();
  });

  it('data-component 属性が設定される', () => {
    const { container } = render(
      <TestWrapper>
        <AppHeader />
      </TestWrapper>
    );
    const header = container.querySelector('[data-component="Header"]');
    expect(header).toBeInTheDocument();
  });

  it('leftContentが指定された場合、カスタムコンテンツが表示される', () => {
    render(
      <TestWrapper>
        <AppHeader leftContent={<div data-testid="custom-left">カスタム左</div>} />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="custom-left"]')).toBeInTheDocument();
  });

  it('centerContentが表示される', () => {
    render(
      <TestWrapper>
        <AppHeader centerContent={<div data-testid="custom-center">中央</div>} />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="custom-center"]')).toBeInTheDocument();
  });

  it('rightContentが指定された場合、カスタムコンテンツが表示される', () => {
    render(
      <TestWrapper>
        <AppHeader rightContent={<div data-testid="custom-right">カスタム右</div>} />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="custom-right"]')).toBeInTheDocument();
  });

  it('rightExtraContentが表示される', () => {
    // rightExtraContentはuser存在時のみ表示される
    render(
      <TestWrapper withUser={true}>
        <AppHeader rightExtraContent={<div data-testid="extra">追加</div>} />
      </TestWrapper>
    );
    expect(document.querySelector('[data-testid="extra"]')).toBeInTheDocument();
  });

  it('breadcrumbItemsが指定された場合、パンくずリストが表示される', () => {
    const breadcrumbs = [
      { label: 'ホーム', href: '/' },
      { label: '現在のページ', href: '' },
    ];
    const { container } = render(
      <TestWrapper>
        <AppHeader breadcrumbItems={breadcrumbs} />
      </TestWrapper>
    );
    const breadcrumb = container.querySelector('.breadcrumb-in-header');
    expect(breadcrumb).toBeInTheDocument();
  });
});
