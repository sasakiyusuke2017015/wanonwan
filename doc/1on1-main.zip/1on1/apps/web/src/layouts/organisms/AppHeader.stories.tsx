// src/components/project/organisms/AppHeader.stories.tsx
import type { StoryFn } from '@storybook/react';
import { BrowserRouter } from 'react-router-dom';

import AppHeader from './AppHeader';

export default {
  title: '表示/AppHeader',
  component: AppHeader,
  tags: ['autodocs'],
  decorators: [
    (Story: StoryFn) => (
      <BrowserRouter>
        <Story />
      </BrowserRouter>
    ),
  ],
  parameters: {
    layout: 'fullscreen',
  },
};

/**
 * デフォルト（パンくずリストなし）
 */
export const Default = {
  args: {},
};

/**
 * パンくずリスト付き（HOME > カテゴリ）
 */
export const WithBreadcrumbs = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      { label: 'カテゴリ', href: '/category' },
    ],
  },
};

/**
 * パンくずリスト付き（3階層）
 */
export const WithBreadcrumbsThreeLevels = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      { label: 'アンケート一覧', href: '/surveys' },
      { label: 'アンケート回答', href: '/surveys/123' },
    ],
  },
};

/**
 * 実際の使用例：回答詳細ページ
 */
export const EmployeeDetailPage = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      { label: '配下メンバー一覧', href: '/employees' },
      { label: '田中太郎', href: '/employees/123' },
    ],
  },
};

/**
 * 実際の使用例：アンケート回答ページ
 */
export const SurveyInputPage = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      { label: 'アンケート一覧', href: '/surveys' },
      { label: '2024年度 メンバー満足度調査', href: '/surveys/456' },
    ],
  },
};

/**
 * 実際の使用例：深い階層
 */
export const DeepHierarchy = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      { label: 'カテゴリ1', href: '/category1' },
      { label: 'カテゴリ2', href: '/category1/category2' },
      { label: 'カテゴリ3', href: '/category1/category2/category3' },
      { label: '現在のページ', href: '/category1/category2/category3/current' },
    ],
  },
};

/**
 * 長いタイトルのパンくずリスト
 */
export const LongTitles = {
  args: {
    breadcrumbItems: [
      { label: 'HOME', href: '/' },
      {
        label: '非常に長いカテゴリ名が表示される場合のテスト',
        href: '/category',
      },
      {
        label: '現在の非常に長いページ名が表示される場合',
        href: '/category/current',
      },
    ],
  },
};

/**
 * カスタム左コンテンツ
 */
export const CustomLeftContent = {
  args: {
    leftContent: <div className="text-white">カスタム左コンテンツ</div>,
  },
};

/**
 * カスタム中央コンテンツ
 */
export const CustomCenterContent = {
  args: {
    centerContent: (
      <div className="text-fluid-xl font-bold text-white">カスタム中央コンテンツ</div>
    ),
  },
};

/**
 * カスタム右コンテンツ
 */
export const CustomRightContent = {
  args: {
    rightContent: (
      <button className="rounded bg-white px-4 py-2 text-blue-600 hover:bg-gray-100">
        カスタムボタン
      </button>
    ),
  },
};

/**
 * 全てカスタマイズ
 */
export const FullyCustomized = {
  args: {
    leftContent: <div className="text-white">左</div>,
    centerContent: <div className="text-white">中央</div>,
    rightContent: <div className="text-white">右</div>,
  },
};
