import React, { memo } from 'react';

import { useLink, usePathname } from '@/adapters/RouterContext';
import { Icon } from '@ui-catalog/core/atoms';
import { LAYOUT_SIZES } from '@/constants/app';
import { useNavigationItems, useThemeConfig } from '@/hooks';
import { cn } from '@ui-catalog/core/utils';

/**
 * スマホ用下部タブバー
 * LeftPaneの代替としてモバイルで表示
 */
const BottomTabBar: React.FC = () => {
  const { colors } = useThemeConfig('BottomTabBar');
  const primaryBgColor = colors.primaryBgColor;
  const activeColor = colors.primaryContrastText;
  const inactiveColor = colors.secondaryTextColor;

  const Link = useLink();
  const pathname = usePathname();
  const navigationItems = useNavigationItems();

  if (navigationItems.length <= 1) return null;

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 border-t border-white/20 backdrop-blur-sm"
      style={{
        height: `${LAYOUT_SIZES.BOTTOM_TAB_HEIGHT}px`,
        zIndex: 9999,
        backgroundColor: primaryBgColor,
      }}
      data-component="bottom-tab-bar"
    >
      <div className="flex h-full items-stretch">
        {navigationItems.map((item) => {
          const isActive = pathname.startsWith(item.to);
          return (
            <Link
              key={item.id}
              href={item.to}
              className={cn(
                'flex flex-1 flex-col items-center justify-center gap-0.5 transition-colors duration-200',
                isActive && 'bg-white/15'
              )}
            >
              <Icon
                name={item.icon}
                size={22}
                fill="none"
                stroke="currentColor"
                hover="auto"
                style={{ color: isActive ? activeColor : inactiveColor }}
              />
              <span
                className="text-fluid-xs leading-none"
                style={{ color: isActive ? activeColor : inactiveColor }}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default memo(BottomTabBar);
