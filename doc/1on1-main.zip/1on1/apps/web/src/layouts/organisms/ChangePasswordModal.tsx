// src/components/project/organisms/ChangePasswordModal.tsx
import { FC, useState, useEffect, FormEvent } from 'react';

import { Banner, Button, Input } from '@ui-catalog/core/molecules';
import { AlertDialog } from '@ui-catalog/core/organisms';
import { Modal } from '@ui-catalog/core/organisms';
import { PasswordValidation } from '@ui-catalog/core/organisms';
import { getErrorMessage } from '@/constants/httpStatus';

import { useAuth } from '@/adapters/AuthContext';

export interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  /** カードの角丸 - Layout から props で渡す */
  cardRadius?: string;
}

/**
 * パスワード変更モーダルコンポーネント
 */
const ChangePasswordModal: FC<ChangePasswordModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  cardRadius = '0.5rem', // デフォルト値
}) => {
  const { changePassword: changePasswordFn } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);

  // モーダルが開いたときにフィールドをリセット
  useEffect(() => {
    if (isOpen) {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setError('');
      setShowCurrentPassword(false);
      setShowNewPassword(false);
      setShowConfirmPassword(false);
    }
  }, [isOpen]);

  // バリデーション
  const validateForm = (): boolean => {
    if (!currentPassword) {
      setError(getErrorMessage('password', 'current_password_required'));
      return false;
    }
    if (!newPassword) {
      setError(getErrorMessage('password', 'new_password_required'));
      return false;
    }
    if (newPassword.length < 8) {
      setError(getErrorMessage('validation', 'password_too_short'));
      return false;
    }
    if (newPassword.length > 30) {
      setError(getErrorMessage('validation', 'password_too_long'));
      return false;
    }
    if (newPassword !== confirmPassword) {
      setError(getErrorMessage('password', 'password_confirm_mismatch'));
      return false;
    }
    if (currentPassword === newPassword) {
      setError(getErrorMessage('password', 'password_same_as_current'));
      return false;
    }
    return true;
  };

  // フォーム送信
  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');

    if (!validateForm()) {
      return;
    }

    if (!changePasswordFn) {
      setError(getErrorMessage('password', 'auth_not_found'));
      return;
    }

    setLoading(true);

    try {
      const result = await changePasswordFn(currentPassword, newPassword, confirmPassword);

      if (!result.success) {
        setError(result.error || getErrorMessage('password', 'change_failed'));
        return;
      }

      // 成功時の処理
      onSuccess?.();
      setShowSuccessAlert(true);
    } catch (error) {
      console.error('Password change error:', error);
      setError(
        error instanceof Error
          ? error.message
          : getErrorMessage('password', 'change_failed')
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="パスワード変更"
      maxWidth="max-w-md"
    >
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
            {/* エラーメッセージ */}
            {error && (
              <Banner variant="error" message={error} className={cardRadius ? `rounded-[${cardRadius}]` : ''} />
            )}

            {/* 現在のパスワード */}
            <div>
              <label
                htmlFor="current-password"
                className="mb-1 block text-fluid-sm font-medium text-gray-700"
              >
                現在のパスワード
              </label>
              <Input
                id="current-password"
                type={showCurrentPassword ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="現在のパスワードを入力"
                disabled={loading}
                icon={showCurrentPassword ? 'eye-slashed' : 'eye'}
                iconPosition="right"
                onIconClick={() => setShowCurrentPassword(!showCurrentPassword)}
              />
            </div>

            {/* 新しいパスワード */}
            <div>
              <label
                htmlFor="new-password"
                className="mb-1 block text-fluid-sm font-medium text-gray-700"
              >
                新しいパスワード
              </label>
              <Input
                id="new-password"
                type={showNewPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="8～30文字で入力"
                disabled={loading}
                icon={showNewPassword ? 'eye-slashed' : 'eye'}
                iconPosition="right"
                onIconClick={() => setShowNewPassword(!showNewPassword)}
              />
            </div>

            {/* 新しいパスワード（確認） */}
            <div>
              <label
                htmlFor="confirm-password"
                className="mb-1 block text-fluid-sm font-medium text-gray-700"
              >
                新しいパスワード（確認）
              </label>
              <Input
                id="confirm-password"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="新しいパスワードを再入力"
                disabled={loading}
                icon={showConfirmPassword ? 'eye-slashed' : 'eye'}
                iconPosition="right"
                onIconClick={() => setShowConfirmPassword(!showConfirmPassword)}
              />
            </div>

            {/* パスワードバリデーション表示 */}
            <PasswordValidation
              password={newPassword}
              confirmPassword={confirmPassword}
              showValidation={newPassword.length > 0}
            />
        </div>

        {/* ボタン */}
        <div className="mt-6 flex justify-end gap-2">
          <Button
            type="button"
            variant="secondary"
            size="small"
            onClick={onClose}
            disabled={loading}
          >
            キャンセル
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="small"
            disabled={loading}
          >
            {loading ? '変更中...' : '変更する'}
          </Button>
        </div>
      </form>

      {/* 成功アラート */}
      <AlertDialog
        isOpen={showSuccessAlert}
        onClose={() => {
          setShowSuccessAlert(false);
          onClose();
        }}
        title="成功"
        message="パスワードが正常に変更されました。"
        type="success"
      />
    </Modal>
  );
};

export default ChangePasswordModal;
