// src/layouts/organisms/ThemeSettingsModal.tsx
import { FC } from 'react';

import { useSetAtom } from 'jotai';

import { ResetButton } from '@ui-catalog/core/molecules';
import { Modal } from '@ui-catalog/core/organisms';
import { resetThemeAtom } from '../../state';
import { resetComponentThemesAtom } from '@/theme/componentThemes';

import DesignSettingsPanel from './DesignSettingsPanel';

export interface ThemeSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * テーマ設定モーダル
 * 統合設定パネル（カラー・形状・背景・アニメーション）
 */
const ThemeSettingsModal: FC<ThemeSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const resetTheme = useSetAtom(resetThemeAtom);
  const resetComponentThemes = useSetAtom(resetComponentThemesAtom);

  const handleResetAll = () => {
    resetTheme();
    resetComponentThemes();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="設定"
      maxWidth="max-w-6xl"
    >
      <DesignSettingsPanel />

      <div className="mt-6 flex justify-end">
        <ResetButton onClick={handleResetAll} label="全てリセット" />
      </div>
    </Modal>
  );
};

export default ThemeSettingsModal;
