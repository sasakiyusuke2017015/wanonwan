/**
 * 回答詳細 Atoms (Jotai)
 * 回答詳細ページの表示設定を管理
 */
import { atomWithStorage } from 'jotai/utils';

import { STORAGE_KEYS } from '../../constants/storage';

/**
 * トレンドチャート表示期間（月数）
 * デフォルト: 3ヶ月
 */
export const trendChartPeriodAtom = atomWithStorage<number>(
  STORAGE_KEYS.TREND_CHART_PERIOD,
  3
);
trendChartPeriodAtom.debugLabel = 'trendChartPeriod';
