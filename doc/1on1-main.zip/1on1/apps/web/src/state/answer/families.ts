/**
 * 回答詳細 atomFamily (Jotai)
 * 複数の回答詳細を同時に管理するための動的atom
 */
import { atom } from 'jotai';
import { atomFamily, atomWithStorage } from 'jotai/utils';

import { STORAGE_KEYS } from '../../constants/storage';

// ============================================
// 型定義
// ============================================

/**
 * 回答詳細の個別状態
 */
export interface AnswerDetailState {
  /** 面談メモ */
  memo: string;
  /** 面談方式 */
  interviewMethod: string;
  /** 記録中フラグ */
  recording: boolean;
  /** バリデーションエラー: 面談方式 */
  interviewMethodError: boolean;
  /** バリデーションエラー: メモ */
  memoError: boolean;
  /** アンケートモーダル表示 */
  isSurveyModalOpen: boolean;
  /** AIコメントモーダル表示 */
  isAiCommentModalOpen: boolean;
  /** データ再取得トリガー */
  refreshKey: number;
}

/**
 * 開いているタブ情報
 */
export interface OpenedAnswerTab {
  /** メンバーID */
  answerId: string;
  /** メンバー名（タブ表示用） */
  name: string;
  /** 開いた時刻（ソート用） */
  openedAt: number;
}

// ============================================
// 初期値
// ============================================

const initialAnswerDetailState: AnswerDetailState = {
  memo: '',
  interviewMethod: '',
  recording: false,
  interviewMethodError: false,
  memoError: false,
  isSurveyModalOpen: false,
  isAiCommentModalOpen: false,
  refreshKey: 0,
};

// ============================================
// atomFamily: メンバーIDごとの状態管理
// ============================================

/**
 * 回答詳細状態 atomFamily
 * メンバーIDをキーとして、各メンバーの編集状態を個別管理
 */
export const answerDetailStateFamily = atomFamily(
  (answerId: string) => {
    const stateAtom = atom<AnswerDetailState>(initialAnswerDetailState);
    stateAtom.debugLabel = `answerDetailState:${answerId}`;
    return stateAtom;
  },
  (a: string, b: string) => a === b
);

// ============================================
// タブ管理 atoms
// ============================================

/**
 * 開いている回答詳細タブリスト（localStorage永続化）
 */
export const openedAnswerTabsAtom = atomWithStorage<OpenedAnswerTab[]>(
  STORAGE_KEYS.ANSWER_DETAIL_OPENED_TABS || 'employeeDetailOpenedTabs',
  []
);
openedAnswerTabsAtom.debugLabel = 'openedEmployeeTabs';

/**
 * 現在アクティブな回答詳細ID（localStorage永続化）
 */
export const activeAnswerIdAtom = atomWithStorage<string | null>(
  STORAGE_KEYS.ANSWER_DETAIL_ACTIVE_ID || 'employeeDetailActiveId',
  null
);
activeAnswerIdAtom.debugLabel = 'activeEmployeeId';

// ============================================
// タブ操作用の派生atoms
// ============================================

/**
 * タブを追加する（write-only atom）
 */
export const addAnswerTabAtom = atom(
  null,
  (get, set, newTab: { answerId: string; name: string }) => {
    const currentTabs = get(openedAnswerTabsAtom);

    // 既に開いている場合はアクティブにするだけ
    const existingTab = currentTabs.find(tab => tab.answerId === newTab.answerId);
    if (existingTab) {
      set(activeAnswerIdAtom, newTab.answerId);
      return;
    }

    // 新しいタブを追加
    const newTabEntry: OpenedAnswerTab = {
      ...newTab,
      openedAt: Date.now(),
    };

    set(openedAnswerTabsAtom, [...currentTabs, newTabEntry]);
    set(activeAnswerIdAtom, newTab.answerId);
  }
);
addAnswerTabAtom.debugLabel = 'addEmployeeTab';

/**
 * タブを閉じる（write-only atom）
 */
export const closeAnswerTabAtom = atom(
  null,
  (get, set, answerId: string) => {
    const currentTabs = get(openedAnswerTabsAtom);
    const activeId = get(activeAnswerIdAtom);

    // タブを削除
    const newTabs = currentTabs.filter(tab => tab.answerId !== answerId);
    set(openedAnswerTabsAtom, newTabs);

    // 閉じたタブがアクティブだった場合、別のタブをアクティブに
    if (activeId === answerId) {
      const newActiveId = newTabs.length > 0 ? newTabs[newTabs.length - 1].answerId : null;
      set(activeAnswerIdAtom, newActiveId);
    }
  }
);
closeAnswerTabAtom.debugLabel = 'closeEmployeeTab';

/**
 * 全タブを閉じる（write-only atom）
 */
export const closeAllAnswerTabsAtom = atom(
  null,
  (_get, set) => {
    set(openedAnswerTabsAtom, []);
    set(activeAnswerIdAtom, null);
  }
);
closeAllAnswerTabsAtom.debugLabel = 'closeAllEmployeeTabs';

// ============================================
// 個別状態更新用のヘルパーatom
// ============================================

/**
 * 回答詳細状態を部分更新するatomを作成するファクトリ
 */
export const createAnswerDetailUpdater = (answerId: string) => {
  return atom(
    (get) => get(answerDetailStateFamily(answerId)),
    (get, set, update: Partial<AnswerDetailState>) => {
      const current = get(answerDetailStateFamily(answerId));
      set(answerDetailStateFamily(answerId), { ...current, ...update });
    }
  );
};

/**
 * refreshKeyをインクリメントする（データ再取得用）
 */
export const incrementRefreshKeyAtom = atom(
  null,
  (get, set, answerId: string) => {
    const current = get(answerDetailStateFamily(answerId));
    set(answerDetailStateFamily(answerId), {
      ...current,
      refreshKey: current.refreshKey + 1,
    });
  }
);
incrementRefreshKeyAtom.debugLabel = 'incrementRefreshKey';

/**
 * バリデーションエラーをクリアする
 */
export const clearValidationErrorsAtom = atom(
  null,
  (get, set, answerId: string) => {
    const current = get(answerDetailStateFamily(answerId));
    set(answerDetailStateFamily(answerId), {
      ...current,
      interviewMethodError: false,
      memoError: false,
    });
  }
);
clearValidationErrorsAtom.debugLabel = 'clearValidationErrors';

/**
 * 回答詳細状態をリセットする
 */
export const resetAnswerDetailStateAtom = atom(
  null,
  (_get, set, answerId: string) => {
    set(answerDetailStateFamily(answerId), initialAnswerDetailState);
  }
);
resetAnswerDetailStateAtom.debugLabel = 'resetEmployeeDetailState';
