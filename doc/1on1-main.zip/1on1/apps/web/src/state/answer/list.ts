/**
 * メンバー一覧 Atoms (Jotai)
 * メンバー一覧ページの表示設定を管理
 */
import { atom } from 'jotai';
import { atomWithStorage } from 'jotai/utils';

import { atomWithStorageSync } from '@ui-catalog/core/infra/theme';
import { STORAGE_KEYS } from '../../constants/storage';

// ============================================
// 表示モード設定
// ============================================

/** 表示モードタイプ */
export type ViewMode = 'table' | 'card';

/**
 * 表示モード Atom（テーブル/カード切り替え）
 * PC時のユーザー選択を保存
 * atomWithStorageSync を使用してフラッシュを防止
 */
export const viewModeAtom = atomWithStorageSync<ViewMode>(
  STORAGE_KEYS.ANSWER_LIST_VIEW_MODE,
  'table' // デフォルトはテーブル表示
);
viewModeAtom.debugLabel = 'viewMode';

// ============================================
// 列表示設定
// ============================================

/**
 * 表示列 Atom（どの列を表示するか）
 * 空配列の場合はデフォルト（全て表示）として扱う
 */
export const visibleColumnsAtom = atomWithStorage<string[]>(
  STORAGE_KEYS.ANSWER_LIST_VISIBLE_COLUMNS,
  [] // 空 = デフォルト全表示
);
visibleColumnsAtom.debugLabel = 'visibleColumns';

/**
 * 列順序 Atom（列の並び順）
 * 空配列の場合はデフォルト順序として扱う
 */
export const columnOrderAtom = atomWithStorage<string[]>(
  STORAGE_KEYS.ANSWER_LIST_COLUMN_ORDER,
  [] // 空 = デフォルト順序
);
columnOrderAtom.debugLabel = 'columnOrder';

// ============================================
// フィルタ設定（種別別atom）
// ============================================

/**
 * テキストフィルタ Atom（名前、部署、役職など）
 */
export const textFiltersAtom = atomWithStorage<Record<string, string>>(
  STORAGE_KEYS.ANSWER_LIST_TEXT_FILTERS,
  {}
);
textFiltersAtom.debugLabel = 'textFilters';

/**
 * ステータスフィルタ Atom（回答状況、健康状態）
 */
export const statusFiltersAtom = atomWithStorage<Record<string, string[]>>(
  STORAGE_KEYS.ANSWER_LIST_STATUS_FILTERS,
  {}
);
statusFiltersAtom.debugLabel = 'statusFilters';

/**
 * スコアフィルタ Atom（満足度、業務負荷など）
 */
export const scoreFiltersAtom = atomWithStorage<Record<string, [number, number]>>(
  STORAGE_KEYS.ANSWER_LIST_SCORE_FILTERS,
  {}
);
scoreFiltersAtom.debugLabel = 'scoreFilters';

/**
 * 日付範囲フィルタ Atom（回答日、面談日）
 */
export const dateRangeFiltersAtom = atomWithStorage<Record<string, string>>(
  STORAGE_KEYS.ANSWER_LIST_DATE_RANGE_FILTERS,
  {}
);
dateRangeFiltersAtom.debugLabel = 'dateRangeFilters';

// ============================================
// 統合フィルタ（派生atom - 後方互換性用）
// ============================================

/**
 * 統合フィルタ値 Atom（読み取り専用 - 派生）
 * 全フィルタ種別を統合したビューを提供
 */
export const filterValuesAtom = atom(
  (get) => {
    const textFilters = get(textFiltersAtom);
    const statusFilters = get(statusFiltersAtom);
    const scoreFilters = get(scoreFiltersAtom);
    const dateRangeFilters = get(dateRangeFiltersAtom);

    return {
      ...textFilters,
      ...statusFilters,
      ...scoreFilters,
      ...dateRangeFilters,
    } as Record<string, unknown>;
  },
  (_get, set, update: Record<string, unknown>) => {
    // 各フィルタ種別に振り分けて更新
    const textFilters: Record<string, string> = {};
    const statusFilters: Record<string, string[]> = {};
    const scoreFilters: Record<string, [number, number]> = {};
    const dateRangeFilters: Record<string, string> = {};

    Object.entries(update).forEach(([key, value]) => {
      if (typeof value === 'string') {
        // text または dateRange（JSONかどうかで判別は難しいのでtextとして扱う）
        // dateRange は JSON 文字列だが、text フィルタと同じstring型
        // 後でフィルタ適用時に判別される
        textFilters[key] = value;
        dateRangeFilters[key] = value;
      } else if (Array.isArray(value)) {
        if (value.length === 2 && typeof value[0] === 'number') {
          // score: [number, number]
          scoreFilters[key] = value as [number, number];
        } else {
          // status: string[]
          statusFilters[key] = value as string[];
        }
      }
    });

    set(textFiltersAtom, textFilters);
    set(statusFiltersAtom, statusFilters);
    set(scoreFiltersAtom, scoreFilters);
    set(dateRangeFiltersAtom, dateRangeFilters);
  }
);
filterValuesAtom.debugLabel = 'filterValues';
