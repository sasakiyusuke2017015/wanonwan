/**
 * 表示日付 Atom (Jotai)
 * 表示日付をlocalStorageで永続化管理
 */
import { atom } from 'jotai';

import { isNullish, isBrowser } from '@1on1/domain/utils';
import { STORAGE_KEYS } from '../../constants/storage';

// デフォルト値として現在の年月を取得
const getDefaultDisplayDate = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};

/**
 * localStorageから同期的に初期値を取得
 * キャッシュが空の場合は今月を設定して返す
 */
function getStoredDisplayDate(): string {
  const defaultDate = getDefaultDisplayDate();
  if (!isBrowser()) return defaultDate;

  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DISPLAY_DATE);
    const parsed = isNullish(raw) ? null : JSON.parse(raw) as string;

    if (isNullish(parsed)) {
      localStorage.setItem(STORAGE_KEYS.DISPLAY_DATE, JSON.stringify(defaultDate));
      return defaultDate;
    }
    return parsed;
  } catch {
    return defaultDate;
  }
}

// 初期値を同期的に取得
const initialDisplayDate = getStoredDisplayDate();
const baseDisplayDateAtom = atom(initialDisplayDate);

/**
 * 表示日付 Atom（localStorage同期永続化）
 */
export const displayDateAtom = atom(
  (get) => get(baseDisplayDateAtom),
  (_get, set, newValue: string) => {
    set(baseDisplayDateAtom, newValue);
    if (isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.DISPLAY_DATE, JSON.stringify(newValue));
    }
  }
);
displayDateAtom.debugLabel = 'displayDate';

/**
 * 表示年 Atom（派生）
 */
export const displayYearAtom = atom((get) => {
  const date = get(displayDateAtom);
  return date.split('-')[0];
});
displayYearAtom.debugLabel = 'displayYear';

/**
 * 表示月 Atom（派生）
 */
export const displayMonthAtom = atom((get) => {
  const date = get(displayDateAtom);
  return date.split('-')[1];
});
displayMonthAtom.debugLabel = 'displayMonth';

/**
 * 表示日付リセット用 Atom（write-only）
 */
export const resetDisplayDateAtom = atom(
  null,
  (_get, set) => {
    set(displayDateAtom, getDefaultDisplayDate());
  }
);
resetDisplayDateAtom.debugLabel = 'resetDisplayDate';
