/**
 * テーマ設定 Atoms (Jotai)
 *
 * @ui-catalog/core/theme から re-export（互換性のためエイリアス名を維持）
 */

import { atom } from 'jotai'
import {
  shapeThemeAtom,
  colorThemeAtom,
  backgroundThemeAtom,
  tableRowAnimationAtom,
  cardAnimationAtom,
  dropMenuAnimationAtom,
  animationSpeedAtom,
  themeConfigAtom as uiCatalogThemeConfigAtom,
  resetThemeAtom as uiCatalogResetThemeAtom,
  resetAnimationAtom,
} from '@ui-catalog/core/infra/theme'

// 基本 Atoms（エイリアス）
export const uiShapeAtom = shapeThemeAtom
export const uiColorThemeAtom = colorThemeAtom
export const uiBackgroundAtom = backgroundThemeAtom

// アニメーション Atoms（エイリアス）
export const uiTableRowAnimationVariantAtom = tableRowAnimationAtom
export const uiCardAnimationVariantAtom = cardAnimationAtom
export const uiDropMenuAnimationVariantAtom = dropMenuAnimationAtom
export const uiAnimationSpeedAtom = animationSpeedAtom

// 統合テーマ
export const themeConfigAtom = uiCatalogThemeConfigAtom
export const uiBackgroundThemeAtom = uiBackgroundAtom

// リセット（基本テーマ + アニメーションを一括）
export const resetThemeAtom = atom(null, (_get, set) => {
  set(uiCatalogResetThemeAtom)
  set(resetAnimationAtom)
})
