/**
 * レイアウト Atoms (Jotai)
 * アプリ全体のレイアウト状態を管理
 */
import { atomWithStorage } from 'jotai/utils';

import { STORAGE_KEYS } from '../../constants/storage';

// ============================================
// 左ペイン（サイドバー）
// ============================================

/**
 * 左ペイン開閉状態 Atom（localStorage自動永続化）
 */
export const leftPaneOpenAtom = atomWithStorage<boolean>(
  STORAGE_KEYS.LEFT_PANE_OPEN,
  true // デフォルトは開いた状態
);
leftPaneOpenAtom.debugLabel = 'leftPaneOpen';
