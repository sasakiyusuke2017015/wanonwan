/**
 * ログイン情報の記憶機能
 *
 * 注意: Jotai atomWithStorage は使用しない。
 * atomWithStorage は初期化時にデフォルト値でlocalStorageを上書きする問題があるため、
 * Login コンポーネントで localStorage を直接操作する。
 *
 * 保存されるキー:
 * - rememberedUsername: ユーザー名
 * - rememberedPassword: パスワード（平文、XSSリスクあり）
 * - rememberMe: 記憶フラグ
 */

// このファイルは参照用のドキュメントとして残す
// 実際の読み書きは src/pages/Login/index.tsx で行う
