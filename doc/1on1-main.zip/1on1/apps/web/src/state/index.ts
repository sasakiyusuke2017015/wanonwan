/**
 * Jotai Atoms - 統一エクスポート
 *
 * 機能ドメイン別に整理された状態管理
 * 明示的な re-export で型推論を確実に
 */

// ============================================
// Core: アプリ全体で使用される状態
// ============================================

// 表示日付
export {
  displayDateAtom,
  displayYearAtom,
  displayMonthAtom,
  resetDisplayDateAtom,
} from './core/displayDate';

// テーマ設定（形状・カラーテーマ・背景・アニメーション）
export {
  uiShapeAtom,
  uiColorThemeAtom,
  uiBackgroundAtom,
  uiBackgroundThemeAtom,
  themeConfigAtom,
  resetThemeAtom,
  // アニメーション設定（variant が 'none' の場合は無効）
  uiTableRowAnimationVariantAtom,
  uiCardAnimationVariantAtom,
  uiDropMenuAnimationVariantAtom,
  uiAnimationSpeedAtom,
} from './core/theme';

// レイアウト
export { leftPaneOpenAtom } from './core/layout';

// ============================================
// Auth: 認証関連の状態
// ============================================

// ログイン情報はlocalStorageを直接操作（src/pages/Login/index.tsx）
// atomWithStorage の上書き問題を回避するため

// ============================================
// Answer: 回答者ドメインの状態
// ============================================

// 回答者一覧
export type { ViewMode } from './answer/list';
export {
  viewModeAtom,
  visibleColumnsAtom,
  columnOrderAtom,
  textFiltersAtom,
  statusFiltersAtom,
  scoreFiltersAtom,
  dateRangeFiltersAtom,
  filterValuesAtom,
} from './answer/list';

// 回答者詳細
export { trendChartPeriodAtom } from './answer/detail';

// 回答者詳細タブ管理（atomFamily）
export type { AnswerDetailState, OpenedAnswerTab } from './answer/families';
export {
  answerDetailStateFamily,
  openedAnswerTabsAtom,
  activeAnswerIdAtom,
  addAnswerTabAtom,
  closeAnswerTabAtom,
  closeAllAnswerTabsAtom,
  createAnswerDetailUpdater,
  incrementRefreshKeyAtom,
  clearValidationErrorsAtom,
  resetAnswerDetailStateAtom,
} from './answer/families';
