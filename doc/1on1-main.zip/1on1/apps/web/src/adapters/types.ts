/**
 * Adapter Types - ui-catalog の型を re-export + アプリ固有の型
 */

// Router 関連の型は ui-catalog から re-export
export type {
  RouterAdapter,
  LinkProps,
  NavigateFunction,
} from '@ui-catalog/core/hooks/router'

// Auth 関連の型はアプリ固有

/**
 * AuthAdapter - 認証の抽象化層（ジェネリック）
 */
export interface LoginResult<TUser = unknown> {
  success: boolean
  error?: string
  user?: TUser
  requirePasswordChange?: boolean
}

export interface ChangePasswordResult {
  success: boolean
  error?: string
}

export interface AuthAdapter<TUser = unknown> {
  isAuthenticated: boolean
  loading: boolean
  user: TUser | null
  token?: string | null
  login: (username: string, password: string) => Promise<LoginResult<TUser>>
  logout: () => Promise<void>
  getAuthHeaders: () => Record<string, string>
  changePassword?: (
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ) => Promise<ChangePasswordResult>
}
