/**
 * RouterContext - ui-catalog の RouterContext を re-export
 *
 * InternalLink などのコンポーネントと同じ Context を共有するため
 */

export {
  RouterProvider,
  RouterContext,
  useRouterAdapter,
  useNavigate,
  usePathname,
  useLink,
  RouterLink,
} from '@ui-catalog/core/hooks/router'

export type { RouterProviderProps } from '@ui-catalog/core/hooks/router'
