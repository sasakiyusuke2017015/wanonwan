/**
 * Router & Auth Adapters
 *
 * React Router と認証の抽象化層
 *
 * @example
 * import { RouterProvider, reactRouterAdapter, AuthProvider } from '@/adapters';
 */

// Types
export type {
  RouterAdapter,
  LinkProps,
  NavigateFunction,
  AuthAdapter,
  LoginResult,
  ChangePasswordResult,
} from './types'

// Router Context & Hooks
export {
  RouterProvider,
  RouterContext,
  useRouterAdapter,
  useNavigate,
  usePathname,
  useLink,
  RouterLink,
} from './RouterContext'

// Auth Context & Hooks
export {
  AuthProvider,
  AuthContext,
  useAuthAdapter,
  useAuth,
  useIsAuthenticated,
  useCurrentUser,
  useLogout,
} from './AuthContext'

// Router Adapters
export { reactRouterAdapter } from './react-router'
