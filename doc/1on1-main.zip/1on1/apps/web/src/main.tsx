import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { initUICatalog, configureDevTools } from '@ui-catalog/core'
import uiCatalogVersions from '../ui-catalog.versions.json'
import { App } from './App'
import './globals.css'

// @ui-catalog/core 初期化（versions.json 必須チェック + 開発環境でバージョン差分表示）
initUICatalog(uiCatalogVersions)

// DevTools 設定（開発環境のみ有効化）
if (import.meta.env.DEV) {
  configureDevTools({
    enabled: true,
    logOperations: true,
    consoleOutput: true,
    serverOutput: false,
    generateUids: true,
    uidPrefix: '1on1',
  })
}

const rootElement = document.getElementById('root')
if (!rootElement) throw new Error('Root element not found')

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>
)
