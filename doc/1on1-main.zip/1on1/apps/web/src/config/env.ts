/**
 * 環境変数ヘルパー
 *
 * Vite の import.meta.env を安全にアクセスするための関数
 * 全ての VITE_* 環境変数をここで一元管理
 */

import type { ColorTheme, ShapeTheme, BackgroundTheme } from '@/constants'

/**
 * 環境変数を安全に取得
 *
 * @param key 環境変数のキー
 * @returns 環境変数の値
 * @throws 必須環境変数が未設定の場合
 */
export function getEnvValue(key: keyof ImportMetaEnv): string {
  const env = import.meta.env as ImportMetaEnv
  const value = env[key]

  if (value === undefined || value === null || value === '') {
    // VITE_API_URL は必須ではない（開発時はproxyを使用）
    return ''
  }

  return String(value)
}

/**
 * API URLを取得
 * VITE_API_URL が設定されていれば使用、なければ同一オリジン（Vite proxy経由）
 */
export function getApiUrl(): string {
  return getEnvValue('VITE_API_URL') || '/api'
}

/**
 * 開発モードかどうか
 */
export function isDev(): boolean {
  return import.meta.env.DEV
}

/**
 * 本番モードかどうか
 */
export function isProd(): boolean {
  return import.meta.env.PROD
}

// ============================================
// UIデザイン デフォルト値
// ============================================

/** デフォルトカラーテーマ */
export const DEFAULT_COLOR_THEME: ColorTheme =
  (import.meta.env.VITE_DEFAULT_COLOR_THEME as ColorTheme) || 'emerald'

/** デフォルト形状テーマ */
export const DEFAULT_SHAPE_THEME: ShapeTheme =
  (import.meta.env.VITE_DEFAULT_SHAPE_THEME as ShapeTheme) || 'sharp'

/** デフォルト背景テーマ */
export const DEFAULT_BACKGROUND_THEME: BackgroundTheme =
  (import.meta.env.VITE_DEFAULT_BACKGROUND_THEME as BackgroundTheme) || 'wood'

// ============================================
// UI表示フラグ
// ============================================

/** UIスタイル設定メニューを表示するか */
export const SHOW_STYLE_SETTINGS: boolean =
  import.meta.env.VITE_SHOW_STYLE_SETTINGS !== 'false'
