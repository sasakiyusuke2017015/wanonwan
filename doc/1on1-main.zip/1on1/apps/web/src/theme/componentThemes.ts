/**
 * コンポーネントテーマ設定（1on1アプリ固有）
 *
 * ui-catalog の汎用基盤を使用しつつ、
 * アプリ固有のコンポーネント名・ラベル・デフォルト設定を定義
 */

import { atom } from 'jotai'

import { atomWithStorageSync } from '@ui-catalog/core/infra/theme'

// 汎用型・関数を re-export
export type {
  ThemeValue,
  ComponentThemeConfig,
  ComponentThemeUsage,
} from '@ui-catalog/core/infra/theme'

export {
  COMPONENT_THEMES_STORAGE_KEY,
  getComponentThemeConfig,
  resolveComponentTheme,
} from '@ui-catalog/core/infra/theme'

import type { ComponentThemeConfig, ComponentThemeUsage } from '@ui-catalog/core/infra/theme'

// ============================================
// 1on1アプリ固有の型定義
// ============================================

/**
 * 登録可能なコンポーネント名（1on1アプリ固有）
 * 型安全性のためリテラル型で定義
 */
export type ThemeableComponent =
  // グローバルレイアウト
  | 'AppLayout'
  | 'SlideNavi'
  | 'Header'
  | 'SubHeader'
  | 'FloatingMenuButton'
  | 'BottomTabBar'
  // ページレイアウト
  | 'AnswerList'
  | 'AnswerCardList'
  | 'AnswerDetail'
  | 'Dashboard'
  | 'Attendance'
  | 'Chat'
  | 'Schedule'
  | 'SurveyList'
  // 設定パネル
  | 'DesignSettingsPanel'
  | 'AnimationSettingsPanel'
  | 'ThemeSettingsModal'

/**
 * コンポーネントテーマ設定のマップ型（1on1アプリ固有）
 */
export type ComponentThemesMap = {
  [K in ThemeableComponent]?: ComponentThemeConfig
}

// ============================================
// コンポーネント一覧（UI表示用）
// ============================================

/** コンポーネントのカテゴリ分け */
export const COMPONENT_CATEGORIES = {
  layout: {
    label: 'レイアウト',
    components: ['AppLayout', 'SlideNavi', 'Header', 'SubHeader', 'FloatingMenuButton', 'BottomTabBar'] as ThemeableComponent[],
  },
  pages: {
    label: 'ページ',
    components: ['AnswerList', 'AnswerCardList', 'AnswerDetail', 'Dashboard', 'Attendance', 'Chat', 'Schedule', 'SurveyList'] as ThemeableComponent[],
  },
  settings: {
    label: '設定',
    components: ['DesignSettingsPanel', 'AnimationSettingsPanel', 'ThemeSettingsModal'] as ThemeableComponent[],
  },
} as const

/** コンポーネント名の日本語ラベル */
export const COMPONENT_LABELS: Record<ThemeableComponent, string> = {
  // レイアウト
  AppLayout: 'アプリレイアウト',
  SlideNavi: 'スライドナビ',
  Header: 'ヘッダー',
  SubHeader: 'サブヘッダー',
  FloatingMenuButton: 'メニューボタン',
  BottomTabBar: '下部タブバー',
  // ページ
  AnswerList: '回答一覧',
  AnswerCardList: '回答カード',
  AnswerDetail: '回答詳細',
  Dashboard: 'ダッシュボード',
  Attendance: '勤怠管理',
  Chat: 'チャット',
  Schedule: 'スケジュール',
  SurveyList: 'アンケート一覧',
  // 設定
  DesignSettingsPanel: 'デザイン設定',
  AnimationSettingsPanel: 'アニメーション設定',
  ThemeSettingsModal: 'テーマ設定',
}

/**
 * コンポーネントが使用するテーマ項目
 * 実際のコード使用状況に基づいて定義
 */
export const COMPONENT_THEME_USAGE: Record<ThemeableComponent, ComponentThemeUsage> = {
  // レイアウト
  AppLayout: {
    usesColor: false, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  SlideNavi: {
    usesColor: true, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  Header: {
    usesColor: true, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  SubHeader: {
    usesColor: false, usesShape: true, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  FloatingMenuButton: {
    usesColor: true, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  BottomTabBar: {
    usesColor: true, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  // ページ
  AnswerList: {
    usesColor: true, usesShape: true, usesBackground: false,
    usesTableRowAnimation: true, usesCardAnimation: true, usesDropMenuAnimation: false,
  },
  AnswerCardList: {
    usesColor: true, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: true, usesDropMenuAnimation: false,
  },
  AnswerDetail: {
    usesColor: true, usesShape: true, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  Dashboard: {
    usesColor: true, usesShape: true, usesBackground: false,
    usesTableRowAnimation: true, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  Attendance: {
    usesColor: true, usesShape: true, usesBackground: false,
    usesTableRowAnimation: true, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  Chat: {
    usesColor: false, usesShape: true, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  Schedule: {
    usesColor: false, usesShape: true, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  SurveyList: {
    usesColor: true, usesShape: true, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: true, usesDropMenuAnimation: false,
  },
  // 設定（UI自体はテーマ設定不要）
  DesignSettingsPanel: {
    usesColor: false, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  AnimationSettingsPanel: {
    usesColor: false, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
  ThemeSettingsModal: {
    usesColor: false, usesShape: false, usesBackground: false,
    usesTableRowAnimation: false, usesCardAnimation: false, usesDropMenuAnimation: false,
  },
}

// ============================================
// デフォルト設定
// ============================================

/** デフォルトのコンポーネントテーマ設定（全てグローバル） */
export const DEFAULT_COMPONENT_THEMES: ComponentThemesMap = {
  AppLayout: { color: 'global', shape: 'global' },
  SlideNavi: { color: 'global', shape: 'global' },
  Header: { color: 'global', shape: 'global' },
  SubHeader: { color: 'global', shape: 'global' },
  FloatingMenuButton: { color: 'global', shape: 'global' },
  BottomTabBar: { color: 'global', shape: 'global' },
  AnswerList: { color: 'global', shape: 'global' },
  AnswerCardList: { color: 'global', shape: 'global' },
  AnswerDetail: { color: 'global', shape: 'global' },
  Dashboard: { color: 'global', shape: 'global' },
  Attendance: { color: 'global', shape: 'global' },
  Chat: { color: 'global', shape: 'global' },
  Schedule: { color: 'global', shape: 'global' },
  SurveyList: { color: 'global', shape: 'global' },
  DesignSettingsPanel: { color: 'global', shape: 'global' },
  AnimationSettingsPanel: { color: 'global', shape: 'global' },
  ThemeSettingsModal: { color: 'global', shape: 'global' },
}

// ============================================
// Jotai Atoms
// ============================================

/**
 * コンポーネントテーマ設定 Atom（localStorage永続化）
 */
export const componentThemesAtom = atomWithStorageSync<ComponentThemesMap>(
  'componentThemes',
  DEFAULT_COMPONENT_THEMES
)
componentThemesAtom.debugLabel = 'componentThemes'

/**
 * コンポーネントテーマをリセット（write-only）
 */
export const resetComponentThemesAtom = atom(null, (_get, set) => {
  set(componentThemesAtom, DEFAULT_COMPONENT_THEMES)
})
resetComponentThemesAtom.debugLabel = 'resetComponentThemes'

/**
 * 特定コンポーネントのテーマを更新（write-only）
 */
export const updateComponentThemeAtom = atom(
  null,
  (get, set, update: { component: ThemeableComponent; config: Partial<ComponentThemeConfig> }) => {
    const current = get(componentThemesAtom)
    const currentConfig = current[update.component] ?? { color: 'global', shape: 'global' }
    set(componentThemesAtom, {
      ...current,
      [update.component]: {
        ...currentConfig,
        ...update.config,
      },
    })
  }
)
updateComponentThemeAtom.debugLabel = 'updateComponentTheme'
