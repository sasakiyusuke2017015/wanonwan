# CI/CD パイプライン

このドキュメントでは、Gitea Actions を使用した CI/CD パイプラインの詳細を説明します。

## 目次

- [概要](#概要)
- [TypeScript版 Gitea Actions パイプライン](#typescript版-gitea-actions-パイプライン)
- [Python版（旧） Gitea Actions パイプライン](#python版旧-gitea-actions-パイプライン)
- [ローカルでのCI/CDシミュレーション](#ローカルでのcicdシミュレーション)
- [Gitea Secrets 設定](#gitea-secrets-設定)
- [トラブルシューティング](#トラブルシューティング)

## 概要

このプロジェクトは **Gitea Actions** を使用した CI/CD パイプラインを構築しています。

**TypeScript版（新）**:
- [ts-ci.yml](./ts-ci.yml) - CI（型チェック・Lint・ビルド・テスト）
- [ts-deploy.yml](./ts-deploy.yml) - デプロイ

**Python版（旧）**:
- [ui-tests.yml](./ui-tests.yml) - UI テスト（Vite + Vitest + Playwright）

---

## TypeScript版 Gitea Actions パイプライン

### トリガー条件

**Pull Request 作成時**:
- `apps/api/` 配下のファイル変更時
- `apps/web/` 配下のファイル変更時
- `constants/` 配下のファイル変更時
- `.gitea/workflows/ts-ci.yml` 自体の変更時

**Push時**:
- `main` ブランチへの push
- `develop` ブランチへの push
- `feature/migrate-to-typescript-monorepo` ブランチへの push

### ワークフロー設定

```yaml
name: TypeScript CI (API + Web)

on:
  pull_request:
    paths:
      - 'apps/api/**'
      - 'apps/web/**'
      - 'constants/**'
      - '.gitea/workflows/ts-ci.yml'
  push:
    branches:
      - main
      - develop
      - feature/migrate-to-typescript-monorepo
```

### 実行される4つのジョブ

#### 1. typecheck（TypeScript型チェック）

**目的**: TypeScript型エラーの検出

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Type check - API
5. Type check - Web

**所要時間**: 約2分

**成功条件**:
- すべての型エラーがない

**コマンド例**:
```bash
pnpm typecheck:api
pnpm typecheck:web
```

---

#### 2. lint（ESLint）

**目的**: コード品質チェック

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Lint - Web

**所要時間**: 約1分

**成功条件**:
- すべてのLintルールに準拠

**コマンド例**:
```bash
pnpm --filter @1on1/web lint
```

---

#### 3. build（ビルドテスト）

**目的**: 本番ビルドの成功確認

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Build - API
5. Build - Web

**所要時間**: 約3分

**成功条件**:
- すべてのビルドが成功

**コマンド例**:
```bash
pnpm build:api
pnpm build:web
```

---

#### 4. test-api（API単体テスト）

**目的**: API単体テストの実行

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Run tests - API
5. Upload coverage report

**所要時間**: 約2分

**成功条件**:
- すべてのテストがパス

**コマンド例**:
```bash
pnpm test:api
```

---

## Python版（旧） Gitea Actions パイプライン

### トリガー条件

**Pull Request 作成時**:
- `apps/ui/` 配下のファイル変更時
- `constants/` 配下のファイル変更時
- `.gitea/workflows/ui-tests.yml` 自体の変更時

**Push時**:
- `main` ブランチへの push

### ワークフロー設定

```yaml
name: UI Tests (Vitest + Playwright)

on:
  pull_request:
    paths:
      - 'apps/ui/**'
      - 'constants/**'
      - '.gitea/workflows/ui-tests.yml'
  push:
    branches:
      - main
```

## 実行される3つのジョブ

### 1. Vitest（Unit & Component Tests）

**目的**: Unit テストと Component テストの実行

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Run Vitest（424 tests）
5. Generate coverage report
6. Upload coverage artifacts

**所要時間**: 約2分

**成功条件**:
- すべてのテストがパス
- カバレッジレポートが生成される

**コマンド例**:
```bash
pnpm --filter 1on1-ui test:run
pnpm --filter 1on1-ui test:coverage
```

**設定詳細**:
```yaml
jobs:
  vitest:
    name: Vitest Unit & Component Tests
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup pnpm
        uses: pnpm/action-setup@v2
        with:
          version: 9.0.0

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'

      - name: Install dependencies
        run: pnpm install --frozen-lockfile

      - name: Run Vitest
        run: pnpm --filter 1on1-ui test:run

      - name: Generate coverage report
        run: pnpm --filter 1on1-ui test:coverage

      - name: Upload coverage report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: coverage-report
          path: apps/ui/coverage/
```

### 2. Playwright VRT（Visual Regression Tests）

**目的**: Storybook の全 Stories を自動巡回してスクリーンショット比較

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Install Playwright browsers
5. Build Storybook
6. Run Playwright VRT（48 Stories）
7. Upload Playwright report
8. Upload VRT screenshots

**所要時間**: 約5分

**成功条件**:
- すべてのスクリーンショットが一致
- または許容範囲内の差分（最大100px、閾値20%）

**コマンド例**:
```bash
pnpm --filter 1on1-ui build-storybook
pnpm --filter 1on1-ui test:vrt
```

**設定詳細**:
```yaml
playwright-vrt:
  name: Playwright Visual Regression Tests
  runs-on: ubuntu-latest
  needs: vitest
  steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup pnpm
      uses: pnpm/action-setup@v2
      with:
        version: 9.0.0

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'pnpm'

    - name: Install dependencies
      run: pnpm install --frozen-lockfile

    - name: Install Playwright browsers
      run: pnpm --filter 1on1-ui exec playwright install --with-deps chromium

    - name: Build Storybook
      run: pnpm --filter 1on1-ui build-storybook

    - name: Run Playwright VRT
      run: pnpm --filter 1on1-ui test:vrt
      env:
        TEST_TYPE: vrt

    - name: Upload Playwright report
      if: always()
      uses: actions/upload-artifact@v4
      with:
        name: playwright-vrt-report
        path: apps/ui/playwright-report/

    - name: Upload VRT screenshots
      if: failure()
      uses: actions/upload-artifact@v4
      with:
        name: vrt-screenshots
        path: apps/ui/tests/e2e/visual-regression.spec.ts-snapshots/
```

### 3. Playwright E2E（End-to-End Tests）

**目的**: 実際のアプリケーション動作をテスト

**ステップ**:
1. Checkout code
2. Setup pnpm + Node.js
3. Install dependencies
4. Install Playwright browsers
5. Build UI
6. Start preview server
7. Run Playwright E2E
8. Upload Playwright report

**所要時間**: 約3分（E2E テンプレートのため現在は最小限）

**成功条件**:
- すべてのE2Eテストがパス

**コマンド例**:
```bash
pnpm --filter 1on1-ui build
pnpm --filter 1on1-ui preview &
pnpm --filter 1on1-ui test:e2e
```

**設定詳細**:
```yaml
playwright-e2e:
  name: Playwright E2E Tests
  runs-on: ubuntu-latest
  needs: vitest
  steps:
    - name: Checkout code
      uses: actions/checkout@v4

    - name: Setup pnpm
      uses: pnpm/action-setup@v2
      with:
        version: 9.0.0

    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '20'
        cache: 'pnpm'

    - name: Install dependencies
      run: pnpm install --frozen-lockfile

    - name: Install Playwright browsers
      run: pnpm --filter 1on1-ui exec playwright install --with-deps chromium

    - name: Build UI
      run: pnpm --filter 1on1-ui build

    - name: Run Playwright E2E
      run: pnpm --filter 1on1-ui test:e2e
      env:
        EXTERNAL_HOST: localhost
        DOCKER_HTTP_PORT: 8000
        DOCKER_HTTPS_PORT: 8443
        PROTOCOL_DEV: http
        PROTOCOL_PROD: https
        TEST_EMAIL: ${{ secrets.TEST_EMAIL }}
        TEST_PASSWORD: ${{ secrets.TEST_PASSWORD }}
        CI: true

    - name: Upload Playwright report
      if: always()
      uses: actions/upload-artifact@v4
      with:
        name: playwright-e2e-report
        path: apps/ui/playwright-report/
```

## PR画面での表示

PR作成時、以下の情報が自動的に表示されます:

```
✅ Vitest: All tests passed (424 tests)
✅ Coverage: 72% (+2% from main)
⚠️ Visual changes detected in 3 components
   - Button (Primary, Secondary)
   - Modal (Default)
   → スクリーンショット添付
✅ E2E tests passed
```

## ローカルでのCI/CDシミュレーション

CI/CD パイプラインと同じステップをローカルで実行できます。

```bash
# 1. 依存関係インストール
pnpm install --frozen-lockfile

# 2. リント
pnpm --filter 1on1-ui lint

# 3. 型チェック
pnpm --filter 1on1-ui typecheck

# 4. テスト
pnpm --filter 1on1-ui test:run

# 5. カバレッジ
pnpm --filter 1on1-ui test:coverage

# 6. VRT
pnpm --filter 1on1-ui build-storybook
pnpm --filter 1on1-ui test:vrt

# 7. E2E
pnpm --filter 1on1-ui build
pnpm --filter 1on1-ui test:e2e

# 8. ビルド
pnpm build

# 9. Docker イメージビルド
docker compose --profile prod build

# 10. デプロイ
docker compose --profile prod up -d
```

## Gitea Secrets 設定

Gitea リポジトリの **Settings > Secrets** で以下を設定:

| Secret 名 | 説明 | 例 |
|----------|------|-----|
| `TEST_EMAIL` | テスト用メールアドレス | `test@example.com` |
| `TEST_PASSWORD` | テスト用パスワード | `password123` |

### 設定方法

1. Gitea リポジトリページにアクセス
2. **Settings** をクリック
3. **Secrets** タブを選択
4. **Add Secret** をクリック
5. Name と Value を入力して保存

## トラブルシューティング

### Vitest が失敗する

**原因**:
- テストコードのバグ
- 依存関係の不整合

**解決策**:
```bash
# ローカルで実行して確認
pnpm --filter 1on1-ui test:run

# キャッシュクリア
pnpm --filter 1on1-ui test --clearCache

# 依存関係再インストール
cd apps/ui
rm -rf node_modules
pnpm install
```

### VRT が失敗する（意図しない差分）

**原因**:
- フォントレンダリングの差異
- ブラウザバージョンの違い
- タイミングの問題

**解決策**:
```bash
# ローカルでUI Modeで確認
pnpm --filter 1on1-ui test:vrt:ui

# 意図した変更の場合はスクリーンショット更新
pnpm --filter 1on1-ui test:vrt:update

# Playwright ブラウザ再インストール
pnpm --filter 1on1-ui exec playwright install --with-deps chromium
```

### VRT が失敗する（意図した差分）

**原因**:
- CSS を変更した
- コンポーネントのレイアウトを変更した

**解決策**:
```bash
# スクリーンショット更新
pnpm --filter 1on1-ui test:vrt:update

# コミット
git add apps/ui/tests/e2e/visual-regression.spec.ts-snapshots/
git commit -m "test: VRT スクリーンショット更新"
git push
```

### E2E が失敗する

**原因**:
- API エンドポイントの変更
- ルート構造の変更
- 認証エラー

**解決策**:
```bash
# ローカルでUI Modeで確認
pnpm --filter 1on1-ui test:e2e:ui

# API が起動しているか確認
curl http://localhost:5000/health

# 環境変数確認
echo $TEST_EMAIL
echo $TEST_PASSWORD
```

### Playwright ブラウザがインストールされていない

**エラー**:
```
Error: browserType.launch: Executable doesn't exist
```

**解決策**:
```bash
# Playwright ブラウザインストール
pnpm --filter 1on1-ui exec playwright install --with-deps chromium
```

### pnpm --frozen-lockfile が失敗する

**エラー**:
```
ERR_PNPM_OUTDATED_LOCKFILE
```

**解決策**:
```bash
# pnpm-lock.yaml を更新
pnpm install

# コミット
git add pnpm-lock.yaml
git commit -m "chore: pnpm-lock.yaml を更新"
```

## 関連ドキュメント

- [README.md](../../README.md) - プロジェクト概要とクイックスタート
- [TESTING.md](../../docs/TESTING.md) - テスト戦略とテスト実行方法
- [DEVELOPMENT.md](../../docs/DEVELOPMENT.md) - 開発環境構築ガイド
- [DEBUGGING.md](../../docs/DEBUGGING.md) - デバッグ手順
- [ARCHITECTURE.md](../../docs/ARCHITECTURE.md) - アーキテクチャ詳細

## 参考リンク

- [Gitea Actions ドキュメント](https://docs.gitea.io/en-us/usage/actions/overview/)
- [GitHub Actions 互換性](https://docs.gitea.io/en-us/usage/actions/comparison/)
- [Playwright ドキュメント](https://playwright.dev/)
- [Vitest ドキュメント](https://vitest.dev/)
