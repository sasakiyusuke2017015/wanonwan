#!/bin/bash
set -e

echo "=== Login ==="
RESPONSE=$(curl -s -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "sdt.1@sms-datatech.co.jp", "password": "123123123"}')
TOKEN=$(echo "$RESPONSE" | jq -r '.access_token')

if [ "$TOKEN" = "null" ] || [ -z "$TOKEN" ]; then
  echo "Login failed: $RESPONSE"
  exit 1
fi
echo "Token: ${TOKEN:0:50}..."

echo ""
echo "=== Test answers API ==="
curl -s "http://localhost:8000/api/answers" \
  -H "Authorization: Bearer $TOKEN" | head -200
