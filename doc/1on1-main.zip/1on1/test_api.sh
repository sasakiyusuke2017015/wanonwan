#!/bin/bash
set -e

echo "=== Login ==="
RESPONSE=$(curl -s -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "sdt.1@sms-datatech.co.jp", "password": "123123123"}')
TOKEN=$(echo "$RESPONSE" | grep -o '"access_token":"[^"]*"' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
  echo "Login failed: $RESPONSE"
  exit 1
fi
echo "Token: ${TOKEN:0:50}..."

echo ""
echo "=== Test answers API ==="
curl -s "http://localhost:8000/api/answers" \
  -H "Authorization: Bearer $TOKEN" | head -c 2000
echo ""
