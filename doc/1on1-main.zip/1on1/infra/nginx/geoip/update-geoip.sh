#!/bin/bash
# ========================================
# GeoLite2-Country データベース更新スクリプト
# ========================================
# 使用方法: ./update-geoip.sh
# cron例: 0 3 * * 3 /path/to/update-geoip.sh >> /path/to/logs/geoip-update.log 2>&1
# （毎週水曜 AM3:00に実行 — MaxMindは毎週火曜にDB更新）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
ENV_FILE="$PROJECT_ROOT/.env"

# .envからライセンスキーを読み込み
if [ -f "$ENV_FILE" ]; then
    # MAXMIND_LICENSE_KEY のみ抽出（sourceだと他の変数に影響する可能性があるため）
    MAXMIND_LICENSE_KEY=$(grep -E '^MAXMIND_LICENSE_KEY=' "$ENV_FILE" | cut -d'=' -f2-)
fi

if [ -z "${MAXMIND_LICENSE_KEY:-}" ]; then
    echo "[$(date)] ERROR: MAXMIND_LICENSE_KEY is not set in $ENV_FILE" >&2
    exit 1
fi

GEOIP_DIR="$SCRIPT_DIR"
TEMP_DIR=$(mktemp -d)
trap "rm -rf $TEMP_DIR" EXIT

echo "[$(date)] GeoLite2-Country データベース更新開始..."

# ダウンロード
HTTP_CODE=$(curl -sSL -o "$TEMP_DIR/GeoLite2-Country.tar.gz" -w "%{http_code}" \
    "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-Country&license_key=${MAXMIND_LICENSE_KEY}&suffix=tar.gz")

if [ "$HTTP_CODE" != "200" ]; then
    echo "[$(date)] ERROR: ダウンロード失敗 (HTTP $HTTP_CODE)" >&2
    exit 1
fi

# 解凍
tar xzf "$TEMP_DIR/GeoLite2-Country.tar.gz" -C "$TEMP_DIR"

# mmdbファイルを取り出して配置
MMDB_FILE=$(find "$TEMP_DIR" -name "GeoLite2-Country.mmdb" -type f)

if [ -z "$MMDB_FILE" ]; then
    echo "[$(date)] ERROR: GeoLite2-Country.mmdb not found in archive" >&2
    exit 1
fi

cp "$MMDB_FILE" "$GEOIP_DIR/GeoLite2-Country.mmdb"

echo "[$(date)] GeoLite2-Country データベース更新完了"
ls -la "$GEOIP_DIR/GeoLite2-Country.mmdb"

# Nginx は auto_reload 60m で自動的に新しいDBを読み込む
# 即時反映: docker exec 1on1-Nginx nginx -s reload
echo "[$(date)] Nginxは auto_reload 60m で自動反映されます"
