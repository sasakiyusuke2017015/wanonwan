# 1on1 Nginx リバースプロキシ

UI と API を統合配信する Nginx リバースプロキシ設定

## 概要

1on1 アプリケーションの Web（React SPA）と API（Hono）を単一のドメインで配信するための Nginx リバースプロキシ。

### アーキテクチャ

```
クライアント
    ↓
[Nginx リバースプロキシ] ← infra/nginx/nginx.conf
    ↓
    ├─ /     → [web-prod:80]  ← apps/web/nginx.conf
    │             ↓
    │          静的ファイル配信（React SPA）
    │
    └─ /api/ → [api-prod:8000]
                  ↓
               API処理（Hono）
```

### 2つの nginx.conf の役割

#### 1. `infra/nginx/nginx.conf` （このディレクトリ）

**役割**: リバースプロキシ・ルーティング

- 外部からのHTTP/HTTPSリクエストを受け取る
- パスに応じて Web コンテナ、API コンテナに振り分け
- SSL/TLS終端
- GeoIP2 による海外IPブロック
- クローラー・AIボットのブロック
- セキュリティヘッダーの付与

**Dockerコンテナ**: `nginx` (1on1-Nginx)

**ルーティング**:
- `/` → `web-prod:80` に転送
- `/api/*` → `api-prod:8000` に転送

#### 2. `apps/web/nginx.conf`

**役割**: 静的ファイル配信

- Reactのビルド済み静的ファイル（HTML/CSS/JS）を配信
- SPAルーティング（`try_files $uri /index.html`）
- 静的アセットのキャッシュ制御
- クローラー・AIボットのブロック（多層防御）

**Dockerコンテナ**: `web-prod` (1on1-web-prod)

#### なぜ2層構造？

1. **関心の分離**: リバースプロキシ（振り分け）とファイル配信（静的ホスティング）を分離
2. **スケーラビリティ**: 将来的にWebを複数台に増やせる（ロードバランシング）
3. **独立性**: Webコンテナが単独でも動作可能（開発・テスト環境）
4. **保守性**: 各レイヤーの責務が明確で変更の影響範囲が限定的

## ディレクトリ構成

```
infra/nginx/
├── Dockerfile           # GeoIP2モジュール入りNginxイメージ
├── nginx.main.conf      # Nginx メイン設定（worker, log format）
├── nginx.conf           # サーバー設定（ルーティング, SSL, セキュリティ）
├── geoip/               # GeoIP2データベース
├── ssl/                 # SSL証明書
└── README.md
```

## ルーティング

| パス | 転送先 | 説明 |
|------|--------|------|
| `/` | `web-prod:80` | Web 静的ファイル配信 |
| `/api/*` | `api-prod:8000` | API リクエスト |
| `/health` | Nginx | Nginx ヘルスチェック |
| `/health/ui` | `web-prod:80/health` | Web ヘルスチェック |
| `/health/api` | `api-prod:8000/health` | API ヘルスチェック |

## 起動・停止

プロジェクトルートから実行（docker-compose.yml はルートにある）:

```bash
# 本番ビルド・起動
pnpm prod:build

# ログ確認
pnpm prod:logs

# ヘルスチェック
curl -f -k https://localhost/health
curl -f -k https://localhost/health/ui
curl -f -k https://localhost/health/api

# 停止
pnpm prod:down
```

## SSL/TLS 設定

### 証明書の配置

```bash
# 証明書をコピー
cp /path/to/server.crt infra/nginx/ssl/
cp /path/to/server.key infra/nginx/ssl/
```

証明書は `docker-compose.yml` で `./infra/nginx/ssl:/etc/nginx/ssl:ro` としてマウントされる。

## トラブルシューティング

### ポート競合エラー

```bash
# ポート使用状況確認
sudo lsof -i :443
```

### Web/API に接続できない

```bash
# ネットワーク確認
docker network inspect 1on1-app-network

# サービス状態確認
docker compose --profile prod ps

# ログ確認
docker compose --profile prod logs nginx
docker compose --profile prod logs web-prod
docker compose --profile prod logs api-prod
```

### ヘルスチェック失敗

```bash
# 個別にヘルスチェック
docker exec 1on1-Nginx wget -O- http://localhost/health
docker exec 1on1-web-prod wget -O- http://localhost/health
docker exec 1on1-api-prod curl http://localhost:8000/health
```

## メンテナンス

### 設定変更の反映

```bash
# 設定テスト後にリロード
docker exec 1on1-Nginx nginx -t
docker exec 1on1-Nginx nginx -s reload
```

## セキュリティ

### クローラー・AIボットのブロック

本システムは内部システムのため、クローラーとAIボットをブロック。

**ブロック対象**:
- 検索エンジン: Googlebot, Bingbot, Slurp, DuckDuckBot, Baiduspider, YandexBot
- AIボット: GPTBot, ChatGPT-User, Claude-Web, Google-Extended, CCBot, Amazonbot 等
- SNSクローラー: FacebookBot, TwitterBot, LinkedInBot
- 汎用ツール: curl, python-requests, scrapy 等

**新しいボットを追加する場合**: `nginx.conf` の `map $http_user_agent $block_crawler` セクションに追加。

### GeoIP2 海外IPブロック

日本国外からのアクセスを遮断。GeoLite2データベースを使用。
