# Pleasanter サイトパッケージ インポートエラー調査レポート

**調査日**: 2026-04-06
**調査者**: Claude Code
**対象ファイル**:
- 旧（エラー発生）: `infra/pleasanter/site_package_alpha.json` (116KB)
- 新（正常）: `infra/pleasanter/site_package_2026_04.json` (115KB)

---

## エラー原因の特定

### 問題箇所

旧ファイルのスケジュールサイト (SiteId: 12081) において、**親子関係の矛盾**が存在していました。

#### 旧ファイルの矛盾した構造

```json
// スケジュールサイトの定義
{
  "SiteId": 12081,
  "Title": "スケジュール",
  "ParentId": 1,                    // ← ルートフォルダ直下
  "InheritPermission": 12065,       // ← α版から権限継承
  ...
}

// 親サイト（α版）の Order フィールド
{
  "SiteId": 12065,
  "Title": "α版",
  "ParentId": 1,
  "SiteSettings": {
    ...
  },
  "Order": "[12074,0,12066,12071,12081]"  // ← スケジュール (12081) が含まれている！
}
```

**矛盾点**:
- スケジュールの `ParentId: 1`（ルート直下）
- しかし、α版サイトの `Order` にスケジュールが含まれている
- Pleasanter は、`ParentId: 1` のサイトが別サイトの `Order` に含まれることを許容しない

### 新ファイル（正常）の構造

```json
// スケジュールサイトの定義
{
  "SiteId": 27929,
  "Title": "スケジュール",
  "ParentId": 1,                    // ← ルートフォルダ直下
  "InheritPermission": 27914,       // ← 2026年4月版から権限継承
  ...
}

// 親サイト（2026年4月版）の Order フィールド
{
  "SiteId": 27914,
  "Title": "2026年4月版",
  "ParentId": 1,
  "SiteSettings": {
    ...
  },
  "Order": "[27920,0,27915,27926]"  // ← スケジュールは含まれていない
}
```

**正しい構造**:
- スケジュールの `ParentId: 1`（ルート直下）
- 親サイトの `Order` にスケジュールは**含まれない**
- `InheritPermission` のみで権限継承を設定

---

## エラーが発生したシナリオの推測

### 旧ファイル作成時の手順（推測）

1. 最初、スケジュールを α版サイト（12065）の**子サイト**として作成
   - この時点で `Order` に追加された
2. その後、スケジュールを**ルート直下に移動**
   - `ParentId` が 1 に変更された
3. **しかし、移動元の `Order` フィールドが更新されなかった**
   - α版の `Order` にスケジュール (12081) が残存

### Pleasanter のインポート処理

1. Sites セクションを読み込み、親子関係を構築
2. `Order` フィールドを元に、各親サイトの子サイトリストを検証
3. **矛盾を検出**: `ParentId: 1` のサイトが別サイトの `Order` に含まれている
4. **内部サーバーエラー** (500) を返す

---

## 今後の推奨事項

### 1. サイトパッケージ作成時の注意点

- サイトを移動した場合、**移動元の `Order` フィールドから削除されているか確認**
- エクスポート前に、Pleasanter UI で階層構造を確認

### 2. サイトパッケージの検証スクリプト

以下のチェックを行うスクリプトを作成推奨：

```typescript
// 検証項目
1. ParentId と Order の整合性チェック
   - ParentId: X のサイトは、SiteId: X の Order に含まれているか
   - ParentId: 1 のサイトは、他サイトの Order に含まれていないか

2. InheritPermission の有効性チェック
   - InheritPermission で指定された SiteId が存在するか

3. Convertors と Sites の整合性チェック
   - Convertors に含まれる SiteId が Sites セクションに存在するか
```

### 3. API 経由でのサイト作成を優先

- サイトパッケージのインポートよりも、**API 経由でのサイト作成**を推奨
- 今回成功した方法：
  ```bash
  USER_MASTER_SITE_ID=12077 pnpm tsx scripts/create-schedule-site.ts
  ```
- この方法では、Pleasanter が自動的に正しい階層構造を構築

### 4. エクスポート直後の確認

- サイトパッケージをエクスポートした直後に、**そのファイルを別環境でインポートテスト**
- CI/CD パイプラインに統合することも検討

---

## 修正方法（旧ファイルを修正する場合）

`site_package_alpha.json` を修正する場合、以下の手順を実施：

### 手動修正

1. α版サイト (12065) の `Order` フィールドを修正：
   ```json
   // 修正前
   "Order": "[12074,0,12066,12071,12081]"

   // 修正後（12081 を削除）
   "Order": "[12074,0,12066,12071]"
   ```

2. HeaderInfo の `Convertors` セクションでも確認：
   ```json
   {
     "SiteId": 12065,
     "Order": "[12074,0,12066,12071,12081]"  // ← ここも修正
   }
   ```

### 自動修正スクリプト（参考）

```typescript
import fs from 'fs'

const packageFile = 'infra/pleasanter/site_package_alpha.json'
const content = JSON.parse(fs.readFileSync(packageFile, 'utf-8'))

// OrderフィールドでParentId: 1のサイトを削除
const rootSites = content.Sites
  .filter(s => s.ParentId === 1)
  .map(s => s.SiteId)

for (const site of content.Sites) {
  if (site.SiteSettings?.Order) {
    const order = JSON.parse(site.SiteSettings.Order)
    const filtered = order.filter(id => !rootSites.includes(id))
    site.SiteSettings.Order = JSON.stringify(filtered)
  }
}

fs.writeFileSync(packageFile, JSON.stringify(content, null, 2))
```

---

## まとめ

| 項目 | 旧ファイル（エラー） | 新ファイル（正常） |
|------|---------------------|-------------------|
| スケジュール ParentId | 1 (ルート) | 1 (ルート) |
| 親サイト Order | `[..., 12081]` ❌ | `[...]`（スケジュールなし） ✅ |
| エラー原因 | 親子関係の矛盾 | 整合性あり |

**結論**: 旧ファイルは、サイト移動時に `Order` フィールドが更新されなかったことが原因で、Pleasanter のインポートバリデーションに失敗していました。新ファイルは正しく構造化されており、問題なくインポート可能です。

---

**次のアクション**:
- [x] 新ファイル (`site_package_2026_04.json`) を `infra/pleasanter/` に配置
- [ ] `.env` の `SITE_CONFIG_MODE` を `2026_04` に変更
- [ ] API 動作確認（CRUD テスト）
