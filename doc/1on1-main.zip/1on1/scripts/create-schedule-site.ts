/**
 * Pleasanter API 経由でスケジュールサイトを作成
 *
 * Usage:
 *   pnpm tsx scripts/create-schedule-site.ts
 */

import { PleasanterClient } from '@pleasync/client'

// 環境変数チェック
const PLEASANTER_URL = process.env.PLEASANTER_URL
const PLEASANTER_API_KEY = process.env.PLEASANTER_API_KEY

if (!PLEASANTER_URL || !PLEASANTER_API_KEY) {
  console.error('❌ 環境変数が設定されていません:')
  console.error('   PLEASANTER_URL, PLEASANTER_API_KEY')
  process.exit(1)
}

// スケジュールサイトの SiteSettings
const SCHEDULE_SITE_SETTINGS = {
  Version: 1.017,
  ReferenceType: 'Issues',
  GridColumns: ['IssueId', 'Title', 'StartTime', 'CompletionTime', 'CheckA', 'ClassC', 'ClassE', 'UpdatedTime'],
  EditorColumnHash: {
    General: [
      'IssueId',
      'Title',
      'Body',
      'StartTime',
      'CompletionTime',
      'CheckA',
      'ClassA',
      'ClassB',
      'ClassC',
      'ClassD',
      'DateA',
      'DateB',
      'ClassE',
      'Comments',
    ],
  },
  LinkColumns: ['IssueId', 'Title', 'StartTime', 'CompletionTime', 'ClassC', 'UpdatedTime'],
  Columns: [
    {
      ColumnName: 'IssueId',
      LabelText: 'イベントID',
    },
    {
      ColumnName: 'Title',
      LabelText: 'タイトル',
      ValidateRequired: true,
      FieldCss: 'field-wide',
    },
    {
      ColumnName: 'Body',
      LabelText: '説明',
      FieldCss: 'field-wide',
    },
    {
      ColumnName: 'StartTime',
      LabelText: '開始日時',
      ValidateRequired: true,
    },
    {
      ColumnName: 'CompletionTime',
      LabelText: '終了日時',
      ValidateRequired: true,
    },
    {
      ColumnName: 'CheckA',
      LabelText: '終日',
    },
    {
      ColumnName: 'ClassA',
      LabelText: '色',
      DefaultInput: '#3b82f6',
      FieldCss: 'field-normal',
    },
    {
      ColumnName: 'ClassB',
      LabelText: 'アイコン',
      ChoicesText: 'calendar,カレンダー\nusers-group,会議\nlist,タスク\nbell,リマインダー\nstar,重要\nflag,フラグ',
      DefaultInput: 'calendar',
      FieldCss: 'field-normal',
    },
    {
      ColumnName: 'ClassC',
      LabelText: 'イベント種別',
      ChoicesText: '会議,会議\nタスク,タスク\nリマインダー,リマインダー\nその他,その他',
      DefaultInput: 'その他',
      ValidateRequired: true,
      FieldCss: 'field-normal',
    },
    {
      ColumnName: 'ClassD',
      LabelText: '繰り返し曜日',
      Description: 'JSON配列形式: ["月","水","金"]',
      FieldCss: 'field-wide',
    },
    {
      ColumnName: 'DateA',
      LabelText: '繰り返し期間開始',
    },
    {
      ColumnName: 'DateB',
      LabelText: '繰り返し期間終了',
    },
    {
      ColumnName: 'ClassE',
      LabelText: '作成者',
      ChoicesText: '[[USER_MASTER_SITE_ID]]', // 後で置換
      Link: true,
      FieldCss: 'field-normal',
    },
  ],
  Links: [
    {
      ColumnName: 'ClassE',
      SiteId: 0, // 後で置換
    },
  ],
  TitleSeparator: '_',
  NoDisplayIfReadOnly: false,
  NotInheritPermissionsWhenCreatingSite: false,
}

async function main() {
  console.log('🚀 Pleasanter スケジュールサイト作成スクリプト')
  console.log(`📍 サーバー: ${PLEASANTER_URL}`)

  const client = new PleasanterClient({
    baseUrl: PLEASANTER_URL,
    apiKey: PLEASANTER_API_KEY,
    apiVersion: '1.1',
  })

  try {
    // 1. ユーザーマスタの SiteId を取得（既存サイトから）
    console.log('\n📋 ユーザーマスタを検索中...')

    // NOTE: ここではユーザーマスタの SiteId を手動で指定する必要があります
    // 実際の環境に合わせて変更してください
    const userMasterSiteId = parseInt(process.env.USER_MASTER_SITE_ID || '0', 10)

    if (!userMasterSiteId) {
      console.error('❌ 環境変数 USER_MASTER_SITE_ID が設定されていません')
      console.error('   例: export USER_MASTER_SITE_ID=12077')
      process.exit(1)
    }

    console.log(`✅ ユーザーマスタ SiteId: ${userMasterSiteId}`)

    // 2. SiteSettings の ClassE と Links を更新
    const siteSettings = {
      ...SCHEDULE_SITE_SETTINGS,
      Columns: SCHEDULE_SITE_SETTINGS.Columns.map((col) => {
        if (col.ColumnName === 'ClassE') {
          return {
            ...col,
            ChoicesText: `[[${userMasterSiteId}]]`,
          }
        }
        return col
      }),
      Links: [
        {
          ColumnName: 'ClassE',
          SiteId: userMasterSiteId,
        },
      ],
    }

    // 3. スケジュールサイトを作成
    console.log('\n📝 スケジュールサイトを作成中...')
    const scheduleSiteId = await client.createSite(1, {
      Title: 'スケジュール',
      Body: 'ユーザーのスケジュール・予定を管理',
      ReferenceType: 'Issues',
      SiteSettings: siteSettings,
    })

    console.log(`✅ スケジュールサイトが作成されました`)
    console.log(`   SiteId: ${scheduleSiteId}`)
    console.log(`   URL: ${PLEASANTER_URL}/items/${scheduleSiteId}`)

    // 4. 作成されたサイトを確認
    console.log('\n🔍 作成されたサイトを確認中...')
    const site = await client.getSite(scheduleSiteId)
    console.log(`   タイトル: ${site.Title}`)
    console.log(`   タイプ: ${site.ReferenceType}`)

    console.log('\n✨ 完了しました！')
    console.log('\n📌 次のステップ:')
    console.log(`   1. apps/api/src/infrastructure/pleasyncClient.ts を更新`)
    console.log(`      export const SITE_SCHEDULE_ID = ${scheduleSiteId}`)
    console.log(`   2. API 動作確認:`)
    console.log(`      curl -X GET "http://localhost:8000/api/schedules" -H "Authorization: Bearer <token>"`)
  } catch (error) {
    console.error('❌ エラーが発生しました:', error)
    process.exit(1)
  }
}

main()
