/**
 * 区分値マスタ生成スクリプト
 *
 * site_package_*.json の Wiki サイト Body から
 * libs/domain/generated/schemas.ts を自動生成する。
 *
 * 使い方:
 *   pnpm generate:schemas
 *
 * 生成されるファイル:
 *   libs/domain/generated/schemas.ts
 */

import fs from 'fs'
import path from 'path'
import { config } from 'dotenv'
import { parseSitePackage } from '@pleasync/client'

// .env を読み込み
config()

// ============================================================
// 設定
// ============================================================

const SITE_CONFIG_MODE = process.env.SITE_CONFIG_MODE
if (!SITE_CONFIG_MODE) {
  throw new Error('SITE_CONFIG_MODE is not set')
}

/**
 * value 値から color を推定（Wiki に {color=xxx} がない場合のフォールバック）
 *
 * 0-99:    white  （未使用帯）
 * 100-149: gray   （初期状態: 未回答、未掲載）
 * 150-199: blue   （準備中: 予約、処理中）
 * 200-299: green  （進行中: 回答済、実施中）
 * 300-399: blue   （中間状態）
 * 400-499: yellow （注意: 日程調整済、要観察）
 * 500-699: yellow （警告帯）
 * 700-799: orange （危険帯）
 * 800-899: orange （高リスク）
 * 900-949: green  （完了系）
 * 950-989: yellow （保留系）
 * 990+:    red    （エラー系）
 */
function inferColorFromValue(value: number): string {
  if (value < 100) return 'white'
  if (value < 150) return 'gray'
  if (value < 200) return 'blue'
  if (value < 300) return 'green'
  if (value < 400) return 'blue'
  if (value < 500) return 'yellow'
  if (value < 700) return 'yellow'
  if (value < 900) return 'orange'
  if (value < 910) return 'green'
  if (value < 990) return 'yellow'
  return 'red'
}


// ============================================================
// メイン処理
// ============================================================

function findPleasanterDir(): string {
  let dir = process.cwd()
  for (let i = 0; i < 5; i++) {
    const candidate = path.join(dir, 'infra', 'pleasanter')
    if (fs.existsSync(candidate)) return candidate
    dir = path.dirname(dir)
  }
  throw new Error('infra/pleasanter/ ディレクトリが見つかりません')
}

function findOutputDir(): string {
  let dir = process.cwd()
  for (let i = 0; i < 5; i++) {
    const candidate = path.join(dir, 'libs', 'domain')
    if (fs.existsSync(candidate)) return path.join(candidate, 'generated')
    dir = path.dirname(dir)
  }
  throw new Error('libs/domain/ ディレクトリが見つかりません')
}

interface ChoiceItem {
  value: string
  label: string
  shortLabel?: string | null
  [key: string]: unknown
}

function main() {
  // site_package を読み込み
  const pleasanterDir = findPleasanterDir()
  const filePath = path.join(pleasanterDir, `site_package_${SITE_CONFIG_MODE}.json`)
  const raw = fs.readFileSync(filePath, 'utf-8').replace(/^\uFEFF/, '')
  const schema = parseSitePackage(JSON.parse(raw))

  // 「〇〇区分」の Wiki サイトを全て走査して TS コードを生成
  const blocks: string[] = []
  const titles = schema.getSiteTitles() as string[]

  for (const wikiTitle of titles) {
    if (!wikiTitle.endsWith('区分')) continue
    const exportName = wikiTitle.replace(/区分$/, '')
    if (!exportName) continue

    const site = schema.getSite(wikiTitle)
    if (!site) continue

    const choices = site.getChoices('Body') as ChoiceItem[]
    const entries: string[] = []

    for (const choice of choices) {
      const value = parseInt(choice.value, 10)
      if (isNaN(value)) continue

      const label = choice.label
      const props: string[] = [`value: ${value}`]

      if (choice.shortLabel) {
        props.push(`shortLabel: '${choice.shortLabel}'`)
      }

      // 動的プロパティ（{key=value} で定義されたもの）
      const skip = new Set(['value', 'label', 'shortLabel'])
      let hasColor = false
      for (const [k, v] of Object.entries(choice)) {
        if (skip.has(k) || v === null || v === undefined) continue
        props.push(`${k}: '${v}'`)
        if (k === 'color') hasColor = true
      }

      // color が未定義の場合、value 値から自動割り当て
      if (!hasColor) {
        props.push(`color: '${inferColorFromValue(value)}'`)
      }

      entries.push(`  '${label}': { ${props.join(', ')} }`)
    }

    blocks.push(`export const ${exportName} = {\n${entries.join(',\n')},\n} as const`)
  }

  // ファイル出力
  const outputDir = findOutputDir()
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  const outputPath = path.join(outputDir, 'schemas.ts')
  const content = `/**
 * 区分値マスタ（自動生成）
 *
 * このファイルは scripts/generate-schemas.ts によって自動生成されます。
 * 手動で編集しないでください。
 *
 * 生成元: infra/pleasanter/site_package_${SITE_CONFIG_MODE}.json
 * 生成日時: ${new Date().toISOString()}
 */

${blocks.join('\n\n')}
`

  fs.writeFileSync(outputPath, content, 'utf-8')
  console.log(`生成完了: ${outputPath}`)
}

main()
