#!/bin/bash
if [ ! -f .env ]; then
  echo '❌ .env が見つかりません。cp .env.example .env で作成してください'
  exit 1
fi
echo '✅ .env 確認OK'
