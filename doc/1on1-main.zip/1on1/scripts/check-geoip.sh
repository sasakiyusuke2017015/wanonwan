#!/bin/bash
GEOIP_PATH="infra/nginx/geoip/GeoLite2-Country.mmdb"
if [ ! -f "$GEOIP_PATH" ]; then
  echo '📥 GeoIP データベースをダウンロード中...'
  bash infra/nginx/geoip/update-geoip.sh
else
  echo '✅ GeoIP 確認OK'
fi
