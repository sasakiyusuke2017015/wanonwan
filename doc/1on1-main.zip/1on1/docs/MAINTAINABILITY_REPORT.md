# Calendar コンポーネント 保守性調査レポート

## 📊 エグゼクティブサマリー

Calendar 関連コンポーネント（CalendarPage, AgendaView, Timeline, WeekView, MonthView, EventModal）の保守性を3つの観点から調査しました。

**総合評価: 7.1/10**

| 観点 | スコア | 評価 |
|------|--------|------|
| アーキテクチャ・設計 | 7.5/10 | 良好（Atomic Design 遵守、Jotai 活用） |
| 型安全性 | 6.3/10 | 堅牢だが改善余地あり（discriminated union 未採用） |
| テスト・エラーハンドリング | 7.5/10 | 基本テストあり、エラーハンドリング不足 |

---

## 🎯 主要な発見事項

### ✅ 強み

1. **明確なアーキテクチャ**
   - Atomic Design パターンの一貫した適用
   - レイヤー間の依存方向が正しい（atoms → molecules → organisms → templates → pages）
   - Jotai によるグローバル状態管理が適切

2. **パフォーマンス最適化**
   - Timeline の仮想スクロール実装
   - lazy loading によるコード分割
   - memo化と ref ベースの DOM 操作

3. **型安全性の基盤**
   - readonly 修飾子の徹底使用
   - union 型による ViewMode/EventMode 定義
   - Props 型の明示的な定義

4. **テストの基盤**
   - 57 個のテストケース
   - 基本的なレンダリングテストあり
   - Vitest + Testing Library の活用

### ⚠️ 改善が必要な領域

#### 🔴 Critical（即対応）

1. **非同期エラーハンドリングの欠如**
   ```typescript
   // EventModal.tsx, Timeline.tsx, WeekView.tsx, MonthView.tsx
   try {
     await persistEvent({...})
     close()
   } catch (error) {
     throw new Error(`Failed to save event: ${error}`)  // ❌ ユーザーに通知されない
   }
   ```
   - **影響**: イベント保存・削除失敗時にユーザーが気づかない
   - **対応**: ローディング状態とエラー状態の UI 実装

2. **型安全性の問題**
   ```typescript
   // AgendaView.tsx
   event.icon as any  // ❌ 型チェック完全スキップ
   ```
   - **影響**: 無効なアイコン名が渡される可能性
   - **対応**: IconName 型の厳密化

#### 🟠 High（1-2週間以内）

3. **Atoms の肥大化**
   - `calendar.ts` に 10+ の atom が混在
   - 概念的な分類がない
   - **対応**: atoms を navigation/events/ui-state に分散

4. **イベントデータ管理の二重化**
   - Schedule page の `localEvents` (useState)
   - CalendarPage の `eventsAtom` (Jotai)
   - **対応**: eventsAtom に統一

5. **テストカバレッジの不足**
   - エラーハンドリングのテスト: 0件
   - ドラッグ&ドロップのテスト: 不十分
   - Schedule ページのテスト: 0件
   - **対応**: 60+ テストケース追加（目標 117 ケース）

#### 🟡 Medium（2-4週間以内）

6. **Discriminated Union の未採用**
   - `CalendarEvent` が normal/allDay/repeat を条件的に使用
   - **対応**: 型を分離して安全性向上

7. **EventModal の責務過多**
   - フォーム、バリデーション、位置計算、キーボード操作を1つに集約
   - **対応**: useEventForm, useModalPosition に分割

---

## 📋 改善計画（優先度順）

### Phase 1: Critical 対応（1週間）

**1.1 非同期エラーハンドリング実装**

実装箇所:
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/EventModal/EventModal.tsx`
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/Timeline/Timeline.tsx`
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/WeekView/WeekView.tsx`
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/MonthView/MonthView.tsx`

実装内容:
```typescript
// 状態管理
const [isSubmitting, setIsSubmitting] = useState(false)
const [submitError, setSubmitError] = useState<string | null>(null)

// エラーハンドリング
try {
  setIsSubmitting(true)
  await persistEvent({...})
  close()
} catch (error) {
  setSubmitError(error instanceof Error ? error.message : 'イベントの保存に失敗しました')
} finally {
  setIsSubmitting(false)
}

// UI 表示
{submitError && <ErrorMessage>{submitError}</ErrorMessage>}
```

成功基準:
- [ ] すべての非同期操作にローディング状態
- [ ] エラーメッセージが UI に表示される
- [ ] 15+ エラーハンドリングテスト追加

**1.2 Icon 型の厳密化**

実装箇所:
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/types/calendar.ts`
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/AgendaView/AgendaView.tsx`

実装内容:
```typescript
// Icon 型定義を import
import type { IconName } from '../../atoms/Icon/Icon'

interface CalendarEvent {
  readonly icon?: IconName  // string → IconName
}

// as any を削除
<Icon name={event.icon} size="sm" />
```

成功基準:
- [ ] `as any` が 0 件
- [ ] 型エラー 0 件

---

### Phase 2: High 対応（2週間）

**2.1 Atoms の分散**

実装箇所:
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/hooks/calendar/`

ディレクトリ構造:
```
core/hooks/calendar/
  ├── atoms/
  │   ├── navigation.ts     (viewModeAtom, selectedDateAtom)
  │   ├── events.ts         (eventsAtom, editingEventAtom, add/update/remove)
  │   ├── ui-state.ts       (hoveredEventAtom, eventModalAtom, dragAtom, etc.)
  │   └── index.ts          (一括 export)
  ├── calendar.ts           (後方互換のための re-export)
  └── index.ts
```

成功基準:
- [ ] 各ファイル 40 行以下
- [ ] import パス更新完了（11 ファイル）
- [ ] 型チェック・lint 通過

**2.2 イベントデータ管理の統一**

実装箇所:
- `/home/sdt_op/project/1on1/apps/web/src/pages/Schedule/index.tsx`
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/hooks/calendar/atoms/events.ts`

実装内容:
```typescript
// Schedule/index.tsx
// useState を削除し、eventsAtom に統一
useEffect(() => {
  if (rawData) {
    const transformed = rawData.map(transformToUIEvent)
    setEventsAtom(transformed)  // Jotai atom に直接設定
  }
}, [rawData])

const handlePersistEvent = useCallback(async (event: UICatalogEvent) => {
  setEventsAtom((prev) => {
    const existingIndex = prev.findIndex((e) => e.id === event.id)
    if (existingIndex >= 0) {
      const updated = [...prev]
      updated[existingIndex] = event
      return updated
    }
    return [...prev, event]
  })
}, [])
```

成功基準:
- [ ] 単一の真実の源（eventsAtom のみ）
- [ ] 状態同期の問題解消
- [ ] EventModal の重複チェック正常動作

**2.3 テストカバレッジ向上**

追加テスト:
- エラーハンドリング: 15 ケース
- ドラッグ&ドロップ: 10 ケース
- エッジケース: 15 ケース
- Schedule ページ: 10 ケース
- 統合テスト: 10 ケース

成功基準:
- [ ] 合計 117+ テストケース
- [ ] カバレッジ 80%+
- [ ] すべてのテスト通過

---

### Phase 3: Medium 対応（4週間）

**3.1 Discriminated Union 導入**

実装箇所:
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/types/calendar.ts`

実装内容:
```typescript
export type CalendarEvent = NormalEvent | AllDayEvent | RepeatEvent

interface BaseEvent {
  readonly id: string
  readonly title: string
  readonly color: string
  readonly description?: string
  readonly icon?: IconName
}

interface NormalEvent extends BaseEvent {
  readonly type: 'normal'
  readonly startTime: Date
  readonly endTime: Date
  readonly allDay?: false
  readonly repeat?: never
}

interface AllDayEvent extends BaseEvent {
  readonly type: 'allDay'
  readonly startTime: Date
  readonly endTime: Date
  readonly allDay: true
  readonly repeat?: never
}

interface RepeatEvent extends BaseEvent {
  readonly type: 'repeat'
  readonly repeat: readonly DayOfWeek[]
  readonly repeatPeriodStart: Date
  readonly repeatPeriodEnd: Date
  readonly startTime: Date
  readonly endTime: Date
}
```

成功基準:
- [ ] EventModal で mode と event の整合性を型レベルで保証
- [ ] switch 文が網羅性チェックされる
- [ ] repeat イベント処理が明示的

**3.2 EventModal の責務分割**

実装箇所:
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/hooks/useEventForm.ts` (新規)
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/hooks/useModalPosition.ts` (新規)
- `/home/sdt_op/project/1on1/packages/ui-catalog/core/organisms/EventModal/EventModal.tsx`

実装内容:
```typescript
// useEventForm.ts (120 行)
export function useEventForm(initialEvent?: CalendarEvent) {
  const [title, setTitle] = useState(...)
  const [mode, setMode] = useState<EventMode>(...)
  // ... バリデーション、submit ロジック
  return { title, setTitle, mode, setMode, submit, validate, ... }
}

// useModalPosition.ts (50 行)
export function useModalPosition(isOpen: boolean, targetDate: Date) {
  const [position, setPosition] = useState(...)
  useLayoutEffect(() => { /* DOM 測定 */ }, [isOpen, targetDate])
  return position
}

// EventModal.tsx (150 行以下に削減)
const form = useEventForm(modal.editingEvent)
const position = useModalPosition(modal.isOpen, modal.date)
```

成功基準:
- [ ] EventModal が 150 行以下
- [ ] 各フックが独立してテスト可能
- [ ] ユニットテスト追加

---

## 📊 改善効果の見込み

### 保守性スコアの推移

| 観点 | 現在 | Phase 1 完了後 | Phase 2 完了後 | Phase 3 完了後 |
|------|------|----------------|----------------|----------------|
| アーキテクチャ | 7.5 | 7.5 | 8.5 | 9.0 |
| 型安全性 | 6.3 | 7.0 | 7.5 | 8.5 |
| テスト・エラーハンドリング | 7.5 | 8.5 | 9.0 | 9.5 |
| **総合** | **7.1** | **7.7** | **8.3** | **9.0** |

### 工数見積もり

| Phase | 工数 | 期間 | リソース |
|-------|------|------|----------|
| Phase 1 (Critical) | 5-7 人日 | 1 週間 | 開発者 1 名 |
| Phase 2 (High) | 10-14 人日 | 2 週間 | 開発者 1-2 名 |
| Phase 3 (Medium) | 15-20 人日 | 4 週間 | 開発者 1 名 |
| **合計** | **30-41 人日** | **7 週間** | - |

---

## ⚠️ リスクと注意事項

### 1. packages/ui-catalog の独立管理

- packages/ui-catalog は別リポジトリとして管理
- 変更は project/1on1 → main への PR が必要
- アーキテクチャ変更は統一ガイドの文書化が重要

### 2. 段階的な実装

- 現在の実装は破壊的な問題がない
- 一度にすべて変更せず、Phase ごとに検証
- 各 Phase 完了後に動作確認とレビュー

### 3. 後方互換性

- calendar.ts を re-export 層として残す
- 既存の import パスも動作するように配慮
- 他の page への影響を最小化

### 4. テストの追加

- 各 Phase でテストを追加
- リファクタリング前後で動作が変わらないことを確認
- CI/CD での自動テスト実行

---

## 📝 次のステップ

### 即座に着手可能

1. **Phase 1 (Critical) の実装計画作成**
   - タスク分割
   - スプリント計画
   - レビュアーの確保

2. **エラーハンドリングの設計**
   - エラーメッセージの文言決定
   - UI デザイン（ErrorMessage コンポーネント）
   - リトライロジックの仕様

3. **テスト環境の整備**
   - カバレッジレポート設定
   - モック戦略の決定
   - テストデータの準備

### チームで議論すべき事項

1. **優先度の最終確認**
   - ビジネス要求との整合性
   - リリース計画への影響
   - リソース配分

2. **Discriminated Union の採用判断**
   - 既存コードへの影響範囲
   - 移行コスト
   - 長期的なメリット

3. **テストカバレッジの目標値**
   - 80% で十分か
   - E2E テストの必要性
   - パフォーマンステストの実施時期

---

## 📚 参考資料

- [リファクタリング計画](./REFACTORING_PLAN.md)
- [アーキテクチャ調査詳細](./調査レポート/ARCHITECTURE_ANALYSIS.md)
- [型安全性調査詳細](./調査レポート/TYPE_SAFETY_ANALYSIS.md)
- [テスト・エラーハンドリング調査詳細](./調査レポート/TEST_ERROR_HANDLING_ANALYSIS.md)

---

## 🎯 結論

Calendar コンポーネントは**良好な基盤**を持っていますが、以下の改善により**エンタープライズグレードの保守性**を実現できます：

1. **非同期エラーハンドリングの実装**（最優先）
2. **Atoms の分散と状態管理の統一**
3. **テストカバレッジの向上**
4. **型安全性の強化**

これらの改善により、長期的な保守性が大幅に向上し、**将来の機能追加やバグ修正が容易**になります。

---

**作成日**: 2026-04-06
**調査対象**: packages/ui-catalog/core/templates/CalendarPage, organisms/{AgendaView, Timeline, WeekView, MonthView, EventModal}, apps/web/src/pages/Schedule
**調査者**: Claude Code
**レビュー状態**: Draft
