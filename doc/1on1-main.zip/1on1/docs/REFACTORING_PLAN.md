# Calendar コンポーネント リファクタリング計画

## 📋 概要

保守性・拡張性向上のためのリファクタリング計画。
アーキテクチャ調査の結果に基づき、3つの改善項目を段階的に実装する。

---

## 🎯 改善項目と優先度

### 優先度 1: Atoms の分散 (1-2日) 🔴

**現状の問題**:
- `calendar.ts` に 10+ の atom が混在
- 概念的な分類がなく、保守性が低い

**改善内容**:
```
core/hooks/calendar/
  ├── atoms/
  │   ├── navigation.ts     (viewModeAtom, selectedDateAtom)
  │   ├── events.ts         (eventsAtom, editingEventAtom, add/update/remove atoms)
  │   ├── ui-state.ts       (hoveredEventAtom, eventModalAtom, activeSlotAtom, dragAtom, anyDragActiveAtom)
  │   └── index.ts          (一括 export)
  ├── calendar.ts           (後方互換のための re-export)
  └── index.ts
```

**影響範囲**: 11 ファイル（import パス更新）

**実装ステップ**:
1. [ ] 新しいディレクトリ構造を作成
2. [ ] atoms を概念別に分割
3. [ ] 後方互換のための re-export 層を追加
4. [ ] 各コンポーネントの import を更新（または calendar.ts 経由で互換性維持）
5. [ ] 型チェック・lint 確認
6. [ ] テスト実行

---

### 優先度 2: イベントデータ管理の統一 (2-3日) 🟠

**現状の問題**:
- Schedule page の `localEvents` (useState) と CalendarPage の `eventsAtom` (Jotai) が混在
- 状態同期が曖昧で、将来的な拡張（undo/redo など）の障害

**改善内容**:
- **Option A (推奨)**: eventsAtom へ統一
  - Schedule page では UI のみ管理
  - Provider 内で eventsAtom を初期化
  - persistEvent → setEventsAtom に変更

- **Option B**: ローカル状態のみ使用
  - eventsAtom を削除
  - EventModal で重複チェックは親に問い合わせ

**実装ステップ (Option A)**:
1. [ ] データフロー図を作成
2. [ ] Provider 外側で eventsAtom を初期化するパターン確定
3. [ ] Schedule page の persistEvent / removeEvent を eventsAtom 更新に変更
4. [ ] EventModal の重複チェックロジックを検証
5. [ ] 型チェック・lint 確認
6. [ ] ユニットテスト追加

---

### 優先度 3: EventModal の責務分割 (1-2日) 🟡

**現状の問題**:
- EventModal が複数責務を持つ
  - フォーム入力値の状態管理
  - バリデーションロジック
  - 位置計算（DOM 測定）
  - キーボード操作
  - イベント保存/削除

**改善内容**:
1. **useEventForm フック化** (120 行)
   ```typescript
   function useEventForm(initialEvent?: CalendarEvent) {
     const [title, setTitle] = useState(...)
     const [mode, setMode] = useState<EventMode>(...)
     // ... validation, submit logic
     return { title, setTitle, mode, setMode, submit, validate, ... }
   }
   ```

2. **useModalPosition フック化** (50 行)
   ```typescript
   function useModalPosition(isOpen: boolean, targetDate: Date) {
     const [position, setPosition] = useState(...)
     useLayoutEffect(() => { /* DOM 測定 */ }, [isOpen, targetDate])
     return position
   }
   ```

3. **EventModal 本体を 150 行以下に削減**

**実装ステップ**:
1. [ ] useEventForm フック化
2. [ ] useModalPosition フック化
3. [ ] EventModal 本体をリファクタリング
4. [ ] ユニットテスト追加（各フック）
5. [ ] 統合テスト確認
6. [ ] 型チェック・lint 確認

---

## 📅 実施スケジュール

### Phase 1: 計画と検証（1日）
- [x] アーキテクチャ調査完了
- [ ] 各 atom の使用箇所を確認
- [ ] EventModal の form state 抽出案を作成
- [ ] 他 page との依存度確認
- [ ] チーム/ユーザーへの優先度確認

### Phase 2: Atoms 分散（1-2日）
- [ ] 新ディレクトリ構造作成
- [ ] atoms を 3 ファイルに分割
- [ ] 再 export 層を作成
- [ ] import パス修正
- [ ] テスト実行

### Phase 3: イベント管理統一（2-3日）
- [ ] データフロー図作成
- [ ] eventsAtom 初期化パターン確定
- [ ] Schedule page の persistEvent 修正
- [ ] EventModal の重複チェック検証
- [ ] テスト追加

### Phase 4: EventModal 分割（1-2日）
- [ ] useEventForm フック化
- [ ] useModalPosition フック化
- [ ] ユニットテスト追加
- [ ] 統合テスト確認

**合計工数**: 4-7日

---

## ⚠️ 注意事項

### 1. packages/ui-catalog の独立管理
- packages/ui-catalog は別リポジトリとして管理
- 変更は project/1on1 → main への PR が必要
- アーキテクチャ変更は統一ガイドの文書化が重要

### 2. 段階的な実装
- 現在の実装は破壊的な問題がない
- 一度にすべて変更せず、Phase ごとに検証
- 各 Phase 完了後に動作確認

### 3. 後方互換性
- calendar.ts を re-export 層として残す
- 既存の import パスも動作するように配慮
- 他の page への影響を最小化

### 4. テストの追加
- 各 Phase でテストを追加
- リファクタリング前後で動作が変わらないことを確認

---

## 🎯 成功基準

### Phase 2 完了時
- [ ] atoms が概念別に分散され、ファイルサイズが各 40 行程度
- [ ] すべての既存テストが通過
- [ ] 型エラー 0 件、lint エラー 0 件

### Phase 3 完了時
- [ ] イベントデータの真実の源が単一
- [ ] EventModal での重複チェックが正常動作
- [ ] 状態同期の問題が解消

### Phase 4 完了時
- [ ] EventModal が 150 行以下
- [ ] useEventForm, useModalPosition が独立してテスト可能
- [ ] カバレッジが向上

---

## 📝 メモ

- Phase 1 の調査後、ユーザーやチームに優先度を確認してから実施
- 現在の設計は良好なため、無理に全て変更する必要はない
- ビジネス要求に応じて優先度を調整

---

## 📚 参考資料

- [アーキテクチャ調査報告](./ARCHITECTURE_ANALYSIS.md)
- [Atomic Design 原則](https://atomicdesign.bradfrost.com/)
- [Jotai 公式ドキュメント](https://jotai.org/)
