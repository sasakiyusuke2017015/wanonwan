# ネットワーク設定

ポート番号・ホスト名は全て固定値（コード直書き）で管理。環境変数による変更は不可。

## ポート

| ポート | 用途 | 使用箇所 |
|--------|------|----------|
| 3000 | Web（Vite dev server） | vite.config.ts, docker-compose.yml |
| 8000 | API（Hono） | env.ts, docker-compose.yml, nginx.conf |
| 6006 | Storybook | docker-compose.yml |
| 9230 | API デバッグ（Node.js inspector） | ローカル開発時のみ |
| 443 | Docker 本番（HTTPS） | docker-compose.yml, nginx.conf |

## ホスト

| ホスト | 用途 | 使用箇所 |
|--------|------|----------|
| `0.0.0.0` | API バインドアドレス | env.ts, docker-compose.yml |
| `api-dev` | API 内部ホスト（Docker サービス名） | docker-compose.yml, vite.config.ts |
| `api-prod` | API 本番ホスト（Docker サービス名） | nginx.conf |
| `web-prod` | Web 本番ホスト（Docker サービス名） | nginx.conf |
| `localhost` | API 内部ホスト（ローカル開発時フォールバック） | vite.config.ts |
| `localhost` | E2Eテスト対象 | playwright.config.ts |

## 外部接続先（環境変数で管理）

| 環境変数 | 用途 | 例 |
|----------|------|-----|
| `PLEASANTER_URL` | Pleasanter API ベースURL | `http://192.168.10.64` |
| `PLEASANTER_API_KEY` | Pleasanter API キー | （秘匿） |
