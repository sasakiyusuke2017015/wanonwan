# PostgreSQL 直接接続 実装プラン

## 背景

現在の Pleasanter API 経由のデータ取得には以下の制限がある：
- PageSize 上限 200 件（サーバー設定による制限）
- ページネーションが必要（367 件のユーザーで 2 リクエスト必要）
- REST API のオーバーヘッド

Python 版の実装では PostgreSQL 直接接続により、これらの制限を回避している。

## 目標

1. **読み取りの高速化**: SELECT クエリで一括取得（件数制限なし）
2. **書き込みの高速化**: INSERT/UPDATE を直接実行（計算式等の Pleasanter 内部ロジックは回避）
3. **既存 API との併用**: REST API も引き続き使用可能（用途に応じて使い分け）

---

## 設計方針：固定メソッド + 自由 SQL

### 二層構造

```
┌─────────────────────────────────────────────────┐
│  高レベル API（便利関数）                          │
│  db.getResults(), db.insertResult(), etc.       │
├─────────────────────────────────────────────────┤
│  低レベル API（自由 SQL）                          │
│  db.query(), db.execute()                       │
└─────────────────────────────────────────────────┘
```

### 使い分け

| ユースケース | 推奨 API | 例 |
|-------------|---------|-----|
| 単純な CRUD | 高レベル | `db.getResults(siteId)` |
| 複雑な JOIN | 自由 SQL | `db.query("SELECT ... JOIN ...")` |
| 集計・分析 | 自由 SQL | `db.query("SELECT COUNT(*) GROUP BY ...")` |
| 一括更新 | 自由 SQL | `db.execute("UPDATE ... WHERE ...")` |

### API 設計

```typescript
// 高レベル API（Pleasanter 固有の便利関数）
const users = await db.getResults(SITE_USER.tableId)
const user = await db.getResult(resultId)
const newId = await db.insertResult(siteId, data)
await db.updateResult(resultId, data)
await db.addLink(idA, idB)

// 低レベル API（自由 SQL）
const result = await db.query(`
  SELECT r."ClassA", r."ClassB", r."ClassE", COUNT(*) as cnt
  FROM "Implem.Pleasanter"."Results" r
  WHERE r."SiteId" = $1
    AND r."ClassE" LIKE $2
  GROUP BY r."ClassA", r."ClassB", r."ClassE"
  ORDER BY cnt DESC
`, [siteId, '%@sms-datatech.co.jp'])

const affected = await db.execute(`
  UPDATE "Implem.Pleasanter"."Results"
  SET "NumA" = "NumA" + 1
  WHERE "ResultId" = $1
`, [resultId])
```

### セキュリティ

1. **SQL インジェクション対策**: プレースホルダ（`$1`, `$2`）必須
2. **読み取り専用モード**: オプションで SELECT 以外を禁止可能
3. **タイムアウト設定**: 長時間クエリの強制終了

---

## フェーズ 1: 基盤構築（必須）

### 1.1 環境変数の追加

`.env` に PostgreSQL 接続情報を追加：

```env
# PostgreSQL 直接接続（Pleasanter DB）
PG_HOST=192.168.10.64
PG_PORT=5432
PG_USER=postgres
PG_PASSWORD=xxxxx
PG_DB_NAME=Implem.Pleasanter
```

### 1.2 Rust クライアントに PostgreSQL 対応を追加

**packages/pleasync-client/Cargo.toml**:
```toml
[dependencies]
# 既存
reqwest = { ... }
serde = { ... }
# 追加
tokio-postgres = { version = "0.7", features = ["with-serde_json-1"] }
deadpool-postgres = "0.14"  # コネクションプール
```

**新規ファイル: packages/pleasync-client/src/db.rs**:
```rust
// PostgreSQL 直接接続クライアント
pub struct PleasanterDb {
    pool: Pool,
}

impl PleasanterDb {
    pub fn new(config: DbConfig) -> Self { ... }

    // ========================================
    // 低レベル API（自由 SQL）
    // ========================================

    /// SELECT クエリを実行（複数行）
    pub async fn query(&self, sql: &str, params: &[&(dyn ToSql + Sync)]) -> Vec<Value> { ... }

    /// SELECT クエリを実行（単一行）
    pub async fn query_one(&self, sql: &str, params: &[&(dyn ToSql + Sync)]) -> Option<Value> { ... }

    /// INSERT/UPDATE/DELETE を実行（影響行数を返す）
    pub async fn execute(&self, sql: &str, params: &[&(dyn ToSql + Sync)]) -> u64 { ... }

    // ========================================
    // 高レベル API（Pleasanter 固有の便利関数）
    // ========================================

    // 読み取り
    pub async fn get_results(&self, site_id: u64) -> Vec<Value> { ... }
    pub async fn get_results_filtered(&self, site_id: u64, filter: HashMap<String, String>) -> Vec<Value> { ... }
    pub async fn get_result(&self, result_id: u64) -> Option<Value> { ... }

    // 書き込み（Items + Results の両方に INSERT が必要）
    pub async fn insert_result(&self, site_id: u64, data: Value) -> u64 { ... }
    pub async fn update_result(&self, result_id: u64, data: Value) { ... }
    pub async fn delete_result(&self, result_id: u64) { ... }

    // リンク操作（双方向）
    pub async fn add_link(&self, id_a: u64, id_b: u64) { ... }
    pub async fn remove_link(&self, id_a: u64, id_b: u64) { ... }
}
```

### 1.3 Node.js バインディング（napi-rs）

```rust
#[napi(js_name = "PleasanterDb")]
pub struct JsPleasanterDb { ... }

#[napi]
impl JsPleasanterDb {
    #[napi(constructor)]
    pub fn new(config: JsDbConfig) -> Self { ... }

    #[napi]
    pub async fn get_results(&self, site_id: f64) -> Vec<Value> { ... }
}
```

---

## フェーズ 2: apps/api への統合

### 2.1 インフラ層に PostgreSQL クライアントを追加

**apps/api/src/infrastructure/pleasanterDb.ts** (新規):
```typescript
import { PleasanterDb } from '@pleasync/client'

export const db = new PleasanterDb({
  host: process.env.PG_HOST,
  port: parseInt(process.env.PG_PORT || '5432'),
  user: process.env.PG_USER,
  password: process.env.PG_PASSWORD,
  database: process.env.PG_DB_NAME,
})

// ラッパー関数
export async function getResultsDirect(siteId: number): Promise<Record<string, any>[]> {
  return db.getResults(siteId)
}
```

### 2.2 既存コードの段階的移行

**優先度高（読み取り頻度が高い）**:
- `auth.ts` の `login()` → ユーザーマスタ取得
- `answers.ts` の回答一覧取得
- `surveys.ts` のアンケート一覧取得

**優先度中（書き込み）**:
- 回答結果の保存
- ログイン試行回数の更新

**優先度低（REST API のまま）**:
- サイト設定の更新（Pleasanter の内部ロジックが必要）
- 添付ファイル操作

---

## フェーズ 3: Pleasanter スキーマ対応

### 3.1 テーブル構造

Pleasanter のデータは以下の構造：

```
"Implem.Pleasanter"."Items"    -- メタデータ（ReferenceId, Title, FullText 等）
"Implem.Pleasanter"."Results"  -- 実データ（ClassA-Z, NumA-Z, DateA-Z 等）
"Implem.Pleasanter"."Links"    -- レコード間リンク
```

### 3.2 カラムマッピング

Python 版と同様に A-Z の全カラムをサポート：

```rust
const ALPHA_LIST: [char; 26] = ['A', 'B', ..., 'Z'];

struct PleasanterColumns {
    class: Vec<String>,  // ClassA, ClassB, ..., ClassZ
    num: Vec<String>,    // NumA, NumB, ..., NumZ
    desc: Vec<String>,   // DescriptionA, ..., DescriptionZ
    check: Vec<String>,  // CheckA, ..., CheckZ
    date: Vec<String>,   // DateA, ..., DateZ
}
```

### 3.3 スキーマ自動変換

`site_package_*.json` のラベル定義を使用して、ラベル名 ↔ カラム名（ClassA 等）の変換を提供：

```typescript
// 例: ユーザーマスタ
const user = await db.getResults(SITE_USER.tableId)
// user[0] = { ClassA: "2025093", ClassB: "テスト 三郎", ClassE: "sdt.3@sms-datatech.co.jp", ... }

// スキーマを使ってラベル名に変換
const labeled = schema.applyLabels(user[0])
// labeled = { ユーザーコード: "2025093", 名前: "テスト 三郎", メールアドレス: "sdt.3@...", ... }
```

### 3.4 SQL ヘルパー

自由 SQL を書きやすくするためのヘルパー関数：

```typescript
import { sql, TABLES } from '@pleasync/client'

// テーブル名の定数
const { RESULTS, ITEMS, LINKS } = TABLES
// → "Implem.Pleasanter"."Results" 等

// カラム名のエスケープ
const cols = sql.columns(['ClassA', 'ClassB', 'NumA'])
// → "ClassA", "ClassB", "NumA"

// WHERE 句の構築
const where = sql.filter({ ClassE: 'sdt.1@example.com', SiteId: 27924 })
// → "ClassE" = $1 AND "SiteId" = $2

// 完全な例
const users = await db.query(`
  SELECT ${sql.columns(['ResultId', 'ClassA', 'ClassB', 'ClassE'])}
  FROM ${TABLES.RESULTS}
  WHERE "SiteId" = $1
  ORDER BY "ResultId" DESC
`, [siteId])
```

---

## フェーズ 4: Docker 対応

### 4.1 docker-compose.yml

```yaml
api-dev:
  environment:
    # 既存
    PLEASANTER_URL: ${PLEASANTER_URL}
    # 追加
    PG_HOST: ${PG_HOST}
    PG_PORT: ${PG_PORT}
    PG_USER: ${PG_USER}
    PG_PASSWORD: ${PG_PASSWORD}
    PG_DB_NAME: ${PG_DB_NAME}
```

### 4.2 ネットワーク考慮

Pleasanter の PostgreSQL サーバーへの接続：
- 開発環境: `192.168.10.64:5432` へ直接接続
- 本番環境: VPN or SSH トンネル経由（セキュリティ考慮）

---

## 実装順序

| 順序 | タスク | 工数目安 | 依存 |
|------|--------|---------|------|
| 1 | `.env` に PG 接続情報追加 | 5分 | - |
| 2 | Rust: tokio-postgres 追加 + db.rs 作成（低レベル API） | 2時間 | 1 |
| 3 | Rust: 高レベル API（getResults, insertResult 等）追加 | 1-2時間 | 2 |
| 4 | Rust: napi-rs バインディング追加 | 1時間 | 3 |
| 5 | Rust: SQL ヘルパー関数追加 | 30分 | 4 |
| 6 | Rust: ビルド + テスト | 30分 | 5 |
| 7 | apps/api: pleasanterDb.ts 作成 | 30分 | 6 |
| 8 | apps/api: auth.ts を DB 直接接続に移行 | 1時間 | 7 |
| 9 | Docker 設定更新 | 15分 | 7 |
| 10 | 統合テスト | 1時間 | 8, 9 |

---

## リスクと対策

### リスク 1: Pleasanter の内部ロジック回避

**問題**: Pleasanter の計算式・トリガーが動作しない
**対策**:
- 読み取り専用から始める
- 書き込みは単純なフィールドのみ（計算式のあるフィールドは REST API を使用）

### リスク 2: スキーマ変更への追従

**問題**: Pleasanter のバージョンアップでテーブル構造が変わる可能性
**対策**:
- `site_package_*.json` をマスタデータとして使用
- バージョン固定（Pleasanter 1.4.x 系）

### リスク 3: 接続エラー

**問題**: PostgreSQL への接続が不安定
**対策**:
- コネクションプール使用（deadpool-postgres）
- リトライロジック実装
- REST API へのフォールバック

---

## 質問事項（確認が必要）

1. **PostgreSQL 接続情報**: ホスト、ポート、ユーザー、パスワード、DB名
2. **ネットワーク制限**: 開発マシンから Pleasanter DB への直接接続は可能か？
3. **書き込みの必要性**: 読み取り専用で十分か、書き込みも必要か？
4. **Pleasanter バージョン**: 現在使用中のバージョン（スキーマ互換性確認）
