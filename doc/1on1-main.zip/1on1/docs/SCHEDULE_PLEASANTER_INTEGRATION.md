# Schedule ページ Pleasanter 統合計画

## 📋 概要

Schedule ページのイベントデータを Pleasanter に永続化する実装計画。
`pleasync-client` を使用し、日本語フィールド名で統一することでメンテナンス性を向上。

---

## 🎯 設計原則

### 1. pleasync-client の厳守

- **リポジトリ内で独自の Pleasanter API 処理を持たない**
- すべての操作は `pleasync-client` 経由
- 環境変数: `PLEASANTER_URL`, `PLEASANTER_API_VERSION` を使用

### 2. 日本語フィールド名の使用

- Pleasanter の分類項目を日本語名で定義
- コードの可読性とメンテナンス性を向上
- ドメイン専門家との共通言語

### 3. 型安全性の確保

- Pleasanter フィールド型定義を作成
- `pleasync-client` の型と CalendarEvent の型を橋渡し

---

## 📦 Site Package 設計

### サイト構成

**サイト名**: `スケジュール`
**サイトID**: (環境変数 `SCHEDULE_SITE_ID` で管理)

### フィールド定義

| Pleasanter フィールド | 型 | 必須 | 説明 | CalendarEvent マッピング |
|---------------------|-----|------|------|-------------------------|
| タイトル | 文字列 | ✓ | イベントタイトル | `title` |
| 開始日時 | 日時 | ✓ | イベント開始日時 | `startTime` |
| 終了日時 | 日時 | ✓ | イベント終了日時 | `endTime` |
| 終日フラグ | チェックボックス | - | 終日イベントか | `allDay` |
| 説明 | 文字列（長文） | - | イベント詳細 | `description` |
| 色 | 文字列 | ✓ | イベント表示色 (hex) | `color` |
| アイコン | 文字列 | - | アイコン名 | `icon` |
| 繰り返し曜日 | JSON文字列 | - | 繰り返し曜日配列 | `repeat` |
| 繰り返し期間開始 | 日時 | - | 繰り返し期間開始 | `repeatPeriodStart` |
| 繰り返し期間終了 | 日時 | - | 繰り返し期間終了 | `repeatPeriodEnd` |
| イベント種別 | 分類 | ✓ | meeting/task/reminder/other | - |

### Site Package JSON

```json
{
  "Version": 1.0,
  "SiteSettings": {
    "SiteName": "スケジュール",
    "Columns": [
      {
        "ColumnName": "タイトル",
        "LabelText": "タイトル",
        "ControlType": "TextBox",
        "ValidateRequired": true,
        "MaxLength": 200
      },
      {
        "ColumnName": "開始日時",
        "LabelText": "開始日時",
        "ControlType": "DateTime",
        "ValidateRequired": true
      },
      {
        "ColumnName": "終了日時",
        "LabelText": "終了日時",
        "ControlType": "DateTime",
        "ValidateRequired": true
      },
      {
        "ColumnName": "終日フラグ",
        "LabelText": "終日",
        "ControlType": "CheckBox"
      },
      {
        "ColumnName": "説明",
        "LabelText": "説明",
        "ControlType": "TextBox",
        "MultiLine": true,
        "MaxLength": 2000
      },
      {
        "ColumnName": "色",
        "LabelText": "色",
        "ControlType": "TextBox",
        "ValidateRequired": true,
        "DefaultValue": "#3b82f6",
        "MaxLength": 7
      },
      {
        "ColumnName": "アイコン",
        "LabelText": "アイコン",
        "ControlType": "TextBox",
        "MaxLength": 50
      },
      {
        "ColumnName": "繰り返し曜日",
        "LabelText": "繰り返し曜日",
        "ControlType": "TextBox",
        "Description": "JSON形式: [0,1,2] (0=日, 1=月, ...)",
        "MaxLength": 100
      },
      {
        "ColumnName": "繰り返し期間開始",
        "LabelText": "繰り返し期間開始",
        "ControlType": "DateTime"
      },
      {
        "ColumnName": "繰り返し期間終了",
        "LabelText": "繰り返し期間終了",
        "ControlType": "DateTime"
      },
      {
        "ColumnName": "イベント種別",
        "LabelText": "イベント種別",
        "ControlType": "ChoicesText",
        "ChoicesText": "会議\nタスク\nリマインダー\nその他",
        "ValidateRequired": true,
        "DefaultValue": "その他"
      }
    ]
  }
}
```

---

## 🔧 実装

### 1. 型定義

**ファイル**: `apps/api/src/types/schedule.ts` (新規)

```typescript
import type { CalendarEvent as UICatalogEvent, DayOfWeek } from '@ui-catalog/core/types'

/**
 * Pleasanter スケジュールレコード（日本語フィールド名）
 */
export interface PleasanterScheduleRecord {
  readonly IssueId: number
  readonly タイトル: string
  readonly 開始日時: string  // ISO 8601
  readonly 終了日時: string  // ISO 8601
  readonly 終日フラグ?: boolean
  readonly 説明?: string
  readonly 色: string
  readonly アイコン?: string
  readonly 繰り返し曜日?: string  // JSON: "[0,1,2]"
  readonly 繰り返し期間開始?: string
  readonly 繰り返し期間終了?: string
  readonly イベント種別: '会議' | 'タスク' | 'リマインダー' | 'その他'
}

/**
 * Pleasanter → UI Catalog の変換
 */
export function toCalendarEvent(record: PleasanterScheduleRecord): UICatalogEvent {
  const repeatDays = record.繰り返し曜日
    ? (JSON.parse(record.繰り返し曜日) as DayOfWeek[])
    : undefined

  return {
    id: String(record.IssueId),
    title: record.タイトル,
    startTime: new Date(record.開始日時),
    endTime: new Date(record.終了日時),
    color: record.色,
    description: record.説明,
    icon: record.アイコン,
    allDay: record.終日フラグ,
    repeat: repeatDays,
    repeatPeriodStart: record.繰り返し期間開始
      ? new Date(record.繰り返し期間開始)
      : undefined,
    repeatPeriodEnd: record.繰り返し期間終了
      ? new Date(record.繰り返し期間終了)
      : undefined,
  }
}

/**
 * UI Catalog → Pleasanter の変換
 */
export function toPleasanterRecord(
  event: UICatalogEvent
): Omit<PleasanterScheduleRecord, 'IssueId'> {
  return {
    タイトル: event.title,
    開始日時: event.startTime.toISOString(),
    終了日時: event.endTime.toISOString(),
    終日フラグ: event.allDay,
    説明: event.description,
    色: event.color,
    アイコン: event.icon,
    繰り返し曜日: event.repeat ? JSON.stringify(event.repeat) : undefined,
    繰り返し期間開始: event.repeatPeriodStart?.toISOString(),
    繰り返し期間終了: event.repeatPeriodEnd?.toISOString(),
    イベント種別: inferEventType(event),  // イベント種別を推論
  }
}

function inferEventType(event: UICatalogEvent): PleasanterScheduleRecord['イベント種別'] {
  // アイコンやタイトルから種別を推論
  if (event.icon === 'users-group') return '会議'
  if (event.icon === 'list') return 'タスク'
  if (event.icon === 'bell') return 'リマインダー'
  return 'その他'
}
```

---

### 2. サービス層

**ファイル**: `apps/api/src/services/scheduleService.ts` (新規)

```typescript
import { pleasyncClient } from '@/infrastructure/pleasyncClient'
import type { CalendarEvent } from '@ui-catalog/core/types'
import { toCalendarEvent, toPleasanterRecord } from '@/types/schedule'

const SCHEDULE_SITE_ID = Number(process.env.SCHEDULE_SITE_ID)

/**
 * スケジュール一覧取得
 */
export async function getSchedules(params?: {
  startDate?: Date
  endDate?: Date
}): Promise<readonly CalendarEvent[]> {
  const view = params?.startDate && params?.endDate
    ? {
        Filters: [
          {
            ColumnName: '開始日時',
            Operator: 'GreaterThanOrEqual',
            Value: params.startDate.toISOString(),
          },
          {
            ColumnName: '終了日時',
            Operator: 'LessThanOrEqual',
            Value: params.endDate.toISOString(),
          },
        ],
      }
    : undefined

  const response = await pleasyncClient.getRecords({
    siteId: SCHEDULE_SITE_ID,
    view,
  })

  return response.Response.Data.map(toCalendarEvent)
}

/**
 * スケジュール作成
 */
export async function createSchedule(event: CalendarEvent): Promise<CalendarEvent> {
  const record = toPleasanterRecord(event)

  const response = await pleasyncClient.createRecord({
    siteId: SCHEDULE_SITE_ID,
    body: record,
  })

  return toCalendarEvent(response.Response.Data)
}

/**
 * スケジュール更新
 */
export async function updateSchedule(event: CalendarEvent): Promise<CalendarEvent> {
  const record = toPleasanterRecord(event)

  const response = await pleasyncClient.updateRecord({
    siteId: SCHEDULE_SITE_ID,
    recordId: Number(event.id),
    body: record,
  })

  return toCalendarEvent(response.Response.Data)
}

/**
 * スケジュール削除
 */
export async function deleteSchedule(id: string): Promise<void> {
  await pleasyncClient.deleteRecord({
    siteId: SCHEDULE_SITE_ID,
    recordId: Number(id),
  })
}

/**
 * スケジュール保存（作成 or 更新）
 */
export async function persistSchedule(event: CalendarEvent): Promise<CalendarEvent> {
  // id が数値（既存レコード）なら更新、それ以外なら作成
  const isExisting = /^\d+$/.test(event.id)

  if (isExisting) {
    return updateSchedule(event)
  } else {
    return createSchedule(event)
  }
}
```

---

### 3. ルーター層

**ファイル**: `apps/api/src/routes/schedules.ts` (新規)

```typescript
import { Hono } from 'hono'
import { vValidator } from '@hono/valibot-validator'
import * as v from 'valibot'
import { getSchedules, persistSchedule, deleteSchedule } from '@/services/scheduleService'

const schedulesRouter = new Hono()

// スケジュール一覧取得
schedulesRouter.get(
  '/',
  vValidator(
    'query',
    v.object({
      startDate: v.optional(v.string()),
      endDate: v.optional(v.string()),
    })
  ),
  async (c) => {
    const { startDate, endDate } = c.req.valid('query')

    const events = await getSchedules({
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    })

    return c.json({ events })
  }
)

// スケジュール作成・更新
schedulesRouter.post(
  '/',
  vValidator(
    'json',
    v.object({
      id: v.string(),
      title: v.string(),
      startTime: v.string(),
      endTime: v.string(),
      color: v.string(),
      description: v.optional(v.string()),
      icon: v.optional(v.string()),
      allDay: v.optional(v.boolean()),
      repeat: v.optional(v.array(v.number())),
      repeatPeriodStart: v.optional(v.string()),
      repeatPeriodEnd: v.optional(v.string()),
    })
  ),
  async (c) => {
    const body = c.req.valid('json')

    const event = {
      ...body,
      startTime: new Date(body.startTime),
      endTime: new Date(body.endTime),
      repeatPeriodStart: body.repeatPeriodStart
        ? new Date(body.repeatPeriodStart)
        : undefined,
      repeatPeriodEnd: body.repeatPeriodEnd
        ? new Date(body.repeatPeriodEnd)
        : undefined,
    }

    const saved = await persistSchedule(event)

    return c.json({ event: saved })
  }
)

// スケジュール削除
schedulesRouter.delete('/:id', async (c) => {
  const id = c.req.param('id')

  await deleteSchedule(id)

  return c.json({ success: true })
})

export default schedulesRouter
```

---

### 4. Web アプリ統合

**ファイル**: `apps/web/src/pages/Schedule/index.tsx`

```typescript
import { useEffect, useMemo, useState, useCallback } from 'react'
import { Provider } from 'jotai'
import type { CalendarEvent as UICatalogEvent } from '@ui-catalog/core/types'
import { CalendarPage } from '@ui-catalog/core/templates'
import AppLayout from '@1on1/layouts/templates/AppLayout'
import { getBreadcrumbs, ROUTES } from '@/constants/routes'

export default function Schedule() {
  const [events, setEvents] = useState<readonly UICatalogEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // イベント一覧取得
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        setLoading(true)
        setError(null)

        const response = await fetch('/api/schedules')
        if (!response.ok) throw new Error('Failed to fetch schedules')

        const data = await response.json()
        setEvents(data.events)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error')
      } finally {
        setLoading(false)
      }
    }

    fetchEvents()
  }, [])

  // イベント保存
  const handlePersistEvent = useCallback(async (event: UICatalogEvent) => {
    try {
      const response = await fetch('/api/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...event,
          startTime: event.startTime.toISOString(),
          endTime: event.endTime.toISOString(),
          repeatPeriodStart: event.repeatPeriodStart?.toISOString(),
          repeatPeriodEnd: event.repeatPeriodEnd?.toISOString(),
        }),
      })

      if (!response.ok) throw new Error('Failed to save event')

      const data = await response.json()

      // ローカル状態を更新
      setEvents((prev) => {
        const existingIndex = prev.findIndex((e) => e.id === data.event.id)
        if (existingIndex >= 0) {
          const updated = [...prev]
          updated[existingIndex] = data.event
          return updated
        }
        return [...prev, data.event]
      })
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Failed to save event')
    }
  }, [])

  // イベント削除
  const handleRemoveEvent = useCallback(async (id: string) => {
    try {
      const response = await fetch(`/api/schedules/${id}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete event')

      // ローカル状態を更新
      setEvents((prev) => prev.filter((e) => e.id !== id))
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Failed to delete event')
    }
  }, [])

  const breadcrumbs = useMemo(() => getBreadcrumbs(ROUTES.SCHEDULE.path), [])

  if (loading) {
    return (
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={false}
        mainContent={<div>Loading...</div>}
      />
    )
  }

  if (error) {
    return (
      <AppLayout
        breadcrumbItems={breadcrumbs}
        hasSubHeader={false}
        mainContent={<div>Error: {error}</div>}
      />
    )
  }

  return (
    <AppLayout
      breadcrumbItems={breadcrumbs}
      hasSubHeader={false}
      mainContent={
        <Provider>
          <CalendarPage
            events={events}
            persistEvent={handlePersistEvent}
            removeEvent={handleRemoveEvent}
          />
        </Provider>
      }
    />
  )
}
```

---

## 🚀 実装ステップ

### Step 1: Site Package 作成（1日）

1. [ ] Site Package JSON を作成
2. [ ] Pleasanter に Site を作成
3. [ ] SCHEDULE_SITE_ID を .env に設定
4. [ ] フィールド定義の動作確認

### Step 2: 型定義とサービス層（1日）

1. [ ] `apps/api/src/types/schedule.ts` 作成
2. [ ] `apps/api/src/services/scheduleService.ts` 作成
3. [ ] 変換関数のユニットテスト追加
4. [ ] pleasync-client の動作確認

### Step 3: API ルーター（1日）

1. [ ] `apps/api/src/routes/schedules.ts` 作成
2. [ ] ルーターを app に登録
3. [ ] Valibot バリデーション確認
4. [ ] API エンドポイントのテスト

### Step 4: Web アプリ統合（1日）

1. [ ] Schedule/index.tsx を更新
2. [ ] API 呼び出しロジック実装
3. [ ] エラーハンドリング実装
4. [ ] 動作確認

### Step 5: テストとドキュメント（1日）

1. [ ] 統合テスト追加
2. [ ] E2E テスト追加
3. [ ] ドキュメント更新
4. [ ] デプロイ前チェックリスト

**合計工数**: 5日

---

## 📝 環境変数

```bash
# .env
SCHEDULE_SITE_ID=12345  # Pleasanter で作成したサイトID
PLEASANTER_URL=http://192.168.10.64
PLEASANTER_API_VERSION=1.1
```

---

## ✅ チェックリスト

### 設計原則の遵守

- [ ] すべての Pleasanter 操作で pleasync-client を使用
- [ ] 独自の Pleasanter API 処理なし
- [ ] フィールド名がすべて日本語
- [ ] 型定義が完全（CalendarEvent ⇔ PleasanterRecord）

### 機能

- [ ] イベント一覧取得
- [ ] イベント作成
- [ ] イベント更新
- [ ] イベント削除
- [ ] 期間フィルター（開始日時〜終了日時）
- [ ] 繰り返しイベント対応

### エラーハンドリング

- [ ] API エラーの適切な処理
- [ ] ユーザーへのエラー通知
- [ ] ローディング状態の表示
- [ ] リトライロジック（オプション）

### テスト

- [ ] 変換関数のユニットテスト
- [ ] サービス層のテスト
- [ ] API エンドポイントのテスト
- [ ] E2E テスト

---

## 🔒 セキュリティ

1. **API Key 管理**
   - pleasync-client が環境変数から自動取得
   - クライアント側に API Key を露出しない

2. **バリデーション**
   - Valibot でリクエストボディを検証
   - SQL インジェクション対策（pleasync-client が対応）

3. **認証・認可**
   - Hono ミドルウェアで認証チェック
   - ユーザーごとのアクセス制御（将来実装）

---

## 📚 参考資料

- [pleasync-client ドキュメント](../../packages/pleasync-client/README.md)
- [Pleasanter API 仕様](https://pleasanter.org/manual/api)
- [保守性調査レポート](./MAINTAINABILITY_REPORT.md)

---

**作成日**: 2026-04-06
**ステータス**: Draft
**レビュー**: Pending
