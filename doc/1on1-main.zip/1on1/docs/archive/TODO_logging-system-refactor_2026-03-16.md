# TODO

## ログシステム改修（指示書準拠）

### 背景
APIログとアプリケーションログを分離し、障害時の原因特定を迅速にする。

### 現状のギャップ

| 要件 | 現状 | 対応 |
|---|---|---|
| `log_type` フィールド | なし | access / app を付与 |
| アプリケーションログ | ほぼなし（jobs.ts のみ） | サービス層の主要処理に追加 |
| `request_id` 伝搬 | 生成済みだがサービス層に未伝搬 | `createRequestLogger` を活用 |
| stdout 統一 | Pino + 独自 logs.ts + console.error 混在 | Pino に統一 |
| ファイル出力禁止 | `LOG_TO_FILE=true` が .env にあるが未使用 | .env から削除 |

### 改修タスク

- [x] `config/logger.ts` — `createAccessLogger` / `createAppLogger` / `AppLogger` 型を追加
- [x] `index.ts` — アクセスログに `log_type: "access"` + `request_id` 追加
- [x] `middleware/requestLogger.ts` 新設 — Hono Context → サービス層へ `appLogger` を伝搬
- [x] サービス層（auth, users, jobs）— 開始・終了・エラーのアプリログ追加
- [x] `services/logs.ts` — Pino child logger ベースに統合
- [x] `routes/users.ts` の `console.error` を `appLogger.error` に置換
- [x] `.env` / `.env.example` — `LOG_TO_FILE` 関連の変数を削除

### 出力イメージ

```json
{"log_type":"access","method":"POST","path":"/api/auth/login","status":200,"duration":3583,"request_id":"abc-123"}
{"log_type":"app","level":"info","operation":"login","message":"login succeeded","user_id":"15659","request_id":"abc-123"}
{"log_type":"app","level":"error","operation":"change_password","message":"password verification failed","request_id":"def-456"}
```

---

## Nginx SSE バッファリング修正

- [x] `infra/nginx/nginx.conf` — `/api/` の `proxy_buffering off` に変更済み

---

## 完了済み

### パスワード変更 500 エラー修正
- [x] `services/users.ts` — 初期パスワード（平文）でも変更可能にする
- [x] `routes/users.ts` — エラー詳細をログ出力

### Cookie Secure フラグ修正
- [x] `apps/web/src/lib/auth.ts` — `VITE_COOKIE_SECURE === 'true'` に変更
- [x] `.env.example` — `VITE_COOKIE_SECURE` をコメント付きで追加

### ブラウザキャッシュのユーザー分離
- [x] Phase 1: ストレージキー追加
- [x] Phase 2: キャッシュクリア関数
- [x] Phase 3: ログイン/ログアウトにキャッシュクリア組み込み
- [x] Phase 4: QueryClient 外部参照の確保
- [x] Phase 5: 他タブ検知（storage イベント監視）
- [x] Phase 6: Jotai メモリキャッシュ対策
