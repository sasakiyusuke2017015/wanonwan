# TODO: モノレポ構造簡素化

**最終更新日**: 2026-01-21
**ブランチ**: `feature/simplify-monorepo-structure`

---

## 📊 プロジェクト概要

### 目的

`apps/` + `packages/` 構造を `api/` + `web/` + `storybook/` のフラット構造に簡素化

### 背景

- Front/Back 両方 TypeScript + tRPC なのに shared 層は不要な複雑さを生む
- tRPC は型を自動伝播するため、手動インターフェース定義は二重管理になる
- packages 分離による利点より、インポートパス管理のコストが上回っている

---

## 🎯 新構造

```
1on1/
├── api/                    ← Backend
│   ├── src/
│   │   ├── index.ts
│   │   ├── routers/
│   │   ├── services/
│   │   ├── infrastructure/
│   │   ├── shared/         ← 定数・型・ユーティリティ
│   │   └── trpc/           ← tRPC設定
│   └── package.json
│
├── web/                    ← Frontend
│   ├── src/
│   │   ├── app/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── stores/
│   │   ├── utils/
│   │   └── trpc/
│   └── package.json
│
├── storybook/              ← UIカタログ
└── package.json            ← ルートワークスペース
```

---

## 📋 移行段階

### 段階1: shared → api/src/shared ✅ 完了

| タスク | 状態 | 影響ファイル数 |
|--------|------|----------------|
| `api/src/shared/` ディレクトリ作成 | ✅ | - |
| `packages/shared/*` をコピー | ✅ | 14 |
| api内インポートパス置換 | ✅ | 4 |
| `package.json`, `tsconfig.json` 更新 | ✅ | 2 |
| 型チェック確認 | ✅ | - |

**注**: `packages/shared` は web/storybook/ui から参照されているため、段階3完了まで削除不可

### 段階2: trpc → api/src/trpc + routers ✅ 完了

| タスク | 状態 | 影響ファイル数 |
|--------|------|----------------|
| `api/src/trpc/` ディレクトリ作成 | ✅ | - |
| `packages/trpc/*` をコピー | ✅ | 13 |
| api内インポートパス置換 | ✅ | 10 |
| `package.json`, `tsconfig.json` 更新 | ✅ | 2 |
| 型チェック確認 | ✅ | - |

**注**: `packages/trpc` は web から参照されているため、段階3完了まで削除不可

### 段階3: ui → web/src ✅ 完了

| タスク | 状態 | 影響ファイル数 |
|--------|------|----------------|
| `web/src/ui/` ディレクトリ作成 | ✅ | - |
| `packages/ui/*` を `web/src/ui/` へコピー | ✅ | 50+ |
| `web/src/shared/` ディレクトリ作成 | ✅ | - |
| `packages/shared/*` を `web/src/shared/` へコピー | ✅ | 14 |
| tsconfig.json / vite.config.ts パス更新 | ✅ | 2 |
| package.json から workspace 依存削除 | ✅ | 1 |
| Storybook 設定更新 | ✅ | 3 |
| 型チェック確認（web, storybook） | ✅ | - |

**注**: `packages/shared`, `packages/ui`, `packages/trpc` は参照がなくなったため削除可能

### 最終確認

| タスク | 状態 |
|--------|------|
| apps/ → ルートへ移動（api/, web/） | ⬜ |
| pnpm-workspace.yaml 更新 | ⬜ |
| Docker設定更新 | ⬜ |
| ビルド確認 | ⬜ |
| テスト確認 | ⬜ |

---

## 📈 進捗トラッキング

| 段階 | タスク数 | 完了 | 進捗 |
|------|----------|------|------|
| 段階1（shared） | 5 | 5 | 100% |
| 段階2（trpc） | 5 | 5 | 100% |
| 段階3（ui） | 8 | 8 | 100% |
| 最終確認 | 5 | 0 | 0% |
| **合計** | **23** | **18** | **78%** |

---

## ⚠️ リスク・注意点

1. **段階3が最大リスク**: ui は 296 ファイル、37+ 箇所から参照
2. **Storybook 依存**: ui コンポーネントを参照しているため、パス変更が必要
3. **Docker ビルドパス**: Dockerfile 内のパス参照を確認必要

---

## 📝 アーカイブ履歴

| ファイル | 内容 | 日付 |
|----------|------|------|
| `archive/TODO_typescript-migration_2026-01-06.md` | TypeScript完全移行プロジェクト（Phase 0-4） | 2026-01-06 |
