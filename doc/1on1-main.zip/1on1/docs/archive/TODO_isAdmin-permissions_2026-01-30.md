# TODO: isAdmin 削除 + 権限チェック強化

## 概要

- JWTの `isAdmin` フラグは常に `false` で機能していない → 削除
- API側 `permissions.ts` はどこからも呼ばれていない → 削除
- 複数のエンドポイントで権限チェック漏れあり → 修正
- Web側 `permissions.ts` / `roles.ts` は別系統で使用中 → **触らない**

---

## Phase 1: API側 permissions.ts 削除

- [x] `apps/api/src/services/permissions.ts` ファイル削除
- [x] `apps/api/src/services/index.ts` L57 `export * as permissionsService` 削除

## Phase 2: JWT から isAdmin 削除

- [x] `apps/api/src/services/jwt.ts` — `JWTPayload.isAdmin` 削除、`generateAccessToken` の `isAdmin` パラメータ削除
- [x] `apps/api/src/services/auth.ts` L110 — `generateAccessToken(userId, email, role, false)` → `generateAccessToken(userId, email, role)`
- [x] `apps/api/src/services/auth.ts` L173-177 — リフレッシュ時の `payload.isAdmin` 渡し削除
- [x] `apps/api/src/middleware/auth.ts` — `AuthUser` から `isAdmin` 削除、`authMiddleware` / `optionalAuthMiddleware` からセット削除

## Phase 3: answers サービス/ルートから isAdmin 削除

- [x] `apps/api/src/services/answers.ts` — `canAccessAnswer` の `isAdmin` パラメータ削除（回答者 OR 面談候補のみで判定）
- [x] `apps/api/src/services/answers.ts` — `getAllAnswers` の `isAdmin` パラメータ削除（常にユーザーフィルタ適用）
- [x] `apps/api/src/routes/answers.ts` L49, L74, L105 — `user.isAdmin` 渡し削除

## Phase 4: フロントエンドから isAdmin 削除

- [x] `apps/web/src/lib/auth/useAuthAdapter.ts` L36, L89 — `isAdmin` 削除
- [x] `apps/web/src/ui/hooks/useAuth.ts` L29 — `JWTPayload` から `isAdmin` 削除

## Phase 5: テスト修正

- [x] `apps/api/src/__tests__/services/jwt.test.ts` — `isAdmin` 関連テスト修正

## Phase 6: 静的解析

- [x] `pnpm check:type` 通ること（既存の `afterEach` 型エラーのみ。isAdmin変更由来のエラーなし）
- [x] `pnpm check:lint` 通ること（既存のwarning/errorのみ。isAdmin変更由来のエラーなし）

---

## Phase 7: 権限チェック漏れ修正（P1）

他人のアンケート回答を操作できないように `canAccessAnswer` チェックを追加。

### surveys ルート

- [ ] `apps/api/src/routes/surveys.ts` GET /api/surveys/:id — 権限チェック追加（検討：掲載中アンケートは全員閲覧可の可能性）
- [x] `apps/api/src/routes/surveys.ts` POST /api/surveys/:id/ai — `canAccessAnswer` で権限チェック追加
- [x] `apps/api/src/routes/surveys.ts` POST /api/surveys/:id/interview — `canAccessAnswer` で権限チェック追加

### streaming ルート

- [x] `apps/api/src/routes/streaming.ts` POST /api/surveys/:answerId/ai/user — `canAccessAnswer` で権限チェック追加
- [x] `apps/api/src/routes/streaming.ts` POST /api/surveys/:answerId/ai/supporter — `canAccessAnswer` で権限チェック追加

### users ルート

- [x] `apps/api/src/routes/users.ts` PUT /api/users/:id — リソースオーナーシップ確認追加（`user.userId === param.id`）
- [ ] `apps/api/src/routes/users.ts` GET /api/users/:id — 自分のユーザー情報のみに制限（検討）
- [ ] `apps/api/src/routes/users.ts` GET /api/users — 全ユーザー取得の制限（検討）

> **Note**: users の GET 系は面談候補選択UIなどで必要な場合があるため、業務要件を確認の上判断

## Phase 8: 回答詳細画面 403 Forbidden 修正

`GET /api/answers/12089` が 403 を返す問題。

### 根本原因

**フロントエンドの `:id` パラメータはユーザーID（Pleasanter ResultId ではない）。**

- フロントは `ユーザーID`（例: `12089`）を `/api/answers/12089` に渡す
- 旧実装の `getAnswerById` は `getRecord(12089)` で Pleasanter の `items/12089/get` を呼んでいた
- RecordId=12089 は **ユーザーマスタ** (`SiteId: 12077`) のレコードであって、回答結果テーブル (`SiteId: 12067`) のレコードではない
- そのため `ClassB`（回答者）に `"笹木　勇介"` （ユーザー名）が返り、ユーザーID `"12089"` との比較で `canAccessAnswer` が `false` になっていた

### 修正内容

- [x] `apps/api/src/services/answers.ts` — `getEmployeeDetail(targetUserId)` 関数を新規追加
  - ユーザーマスタから対象ユーザー情報を取得
  - 回答結果テーブルから `getRecords` でそのユーザーの回答一覧を取得
  - 掲載設定・アンケートマスタからタイトル・開始月を結合
  - フロントの `EmployeeDetailResponse` 形式で返す
- [x] `apps/api/src/services/answers.ts` — `canAccessUserAnswers()` 関数を新規追加
  - 自分自身のデータ OR 面談候補に含まれる回答がある場合にアクセス可能
- [x] `apps/api/src/routes/answers.ts` — `GET /api/answers/:id` を `getEmployeeDetail` + `canAccessUserAnswers` に変更
- [x] `apps/api/src/infrastructure/pleasanter.ts` — `getRecords` に `columnFilterHash` オプション追加

### 検証

- [x] `GET /api/answers/12089` → 200 OK（名前・ユーザーID・回答結果5件が正しく返る）
- [x] デバッグログ削除済み

## Phase 9: 最終検証

- [x] `pnpm check:type` — 既存エラーのみ（`afterEach` 型エラー）。本変更による新規エラーなし
- [x] `pnpm check:lint` — 既存エラーのみ。本変更による新規エラーなし
- [x] API動作確認（`GET /api/answers/12089` → 200 OK）
- [ ] 回答一覧 → 回答詳細への遷移が正常動作することをブラウザで確認
- [ ] 他人のユーザーIDを直接URLで指定した場合に 403 が返ることを確認
