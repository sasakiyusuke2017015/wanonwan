# TODO: TypeScript完全移行プロジェクト

**最終更新日**: 2026-01-06

---

## 📊 プロジェクト概要

### 目的
1. Python FastAPI → TypeScript (Hono + tRPC) 完全移行
2. apps/ui → apps/web (Next.js) 完全移行
3. モノレポ構成の最適化（統一的なパス管理）
4. **UIコンポーネント統一 + Server Component 最適化**

### 現在の移行状況サマリー

| 領域 | 状態 | 進捗 |
|------|------|------|
| **バックエンド（API）** | ✅ 実質完了 | 9/10タスク（1件保留） |
| **モノレポ構成** | ✅ 完了 | Phase 0 完了 |
| **フロントエンド（ページ）** | ✅ 完了 | Phase 1 完了 |
| **アーキテクチャ改善** | ✅ 完了 | Phase 3 完了 |
| **Python時代UI復元** | ✅ 完了 | Phase 4 完了 |

---

## 🏗️ Phase 0: モノレポ構成リファクタリング ✅ 完了

### 完了したタスク

- [x] **0-1. ルート tsconfig.base.json 作成**
  - [x] 共通コンパイラオプション定義
  - [x] パスエイリアス統一（`@ui/*`, `@shared/*`, `@trpc/*`）

- [x] **0-2. packages/ui 作成**
  - [x] package.json 作成（@1on1/ui）
  - [x] tsconfig.json 作成（extends base）
  - [x] apps/web から参照可能

- [x] **0-3. packages/shared 作成**
  - [x] package.json 作成（@1on1/shared）
  - [x] tsconfig.json 作成（extends base）
  - [x] validators エクスポート

- [x] **0-4. packages/trpc 作成**
  - [x] constants/src/trpc → packages/trpc コピー
  - [x] package.json 作成（@1on1/trpc）
  - [x] tsconfig.json 作成（extends base）
  - [x] tRPC v11 + moduleResolution: bundler 互換性対応

- [x] **0-5. apps 更新**
  - [x] apps/api/tsconfig.json 更新（extends base）
  - [x] apps/web/tsconfig.json 更新（extends base）
  - [x] apps/storybook パス修正・依存追加
  - [x] Next.js 15 params Promise 対応
  - [x] useSearchParams Suspense 対応

- [x] **0-6. ビルド・テスト検証**
  - [x] pnpm install
  - [x] apps/api テスト: 111テスト全パス
  - [x] apps/web ビルド: 成功
  - [x] apps/storybook ビルド: 成功

**Phase 0 実績**: 約4時間

---

## 🖥️ Phase 1: フロントエンド移行 ✅ 完了

### 実装アプローチ

packages/ui の複雑な依存関係（jotai atoms, useThemeConfig など）を避け、
apps/web 用の軽量 AppLayout + 共通コンポーネントで統一しました。

### 完了タスク

- [x] **1-1. Dashboard ページ** (commit: `2eaddd5`)
  - [x] AppLayout 作成（`apps/web/components/layout/AppLayout.tsx`）
  - [x] TrendChart 作成（recharts ベース、`apps/web/components/TrendChart.tsx`）
  - [x] 全社サマリー + トレンド分析表示

- [x] **1-2. AnswerList / SurveyList ページ** (commit: `bbf1b1d`)
  - [x] AppLayout + Card 表示で統一
  - [x] テキスト検索フィルター
  - [x] 統計パネル（件数表示）
  - [x] Card, Badge コンポーネント拡張

- [x] **1-3. その他のページ** (commit: `8b384ce`)
  - [x] AnswerDetail: AppLayout + Card/Badge 統合
  - [x] SurveyDetail: AppLayout + Card/Badge 統合
  - [x] Chat: 独自ヘッダー → AppLayout + Card/Badge/Button
  - [x] Schedule: 同様に AppLayout + 共通コンポーネント化
  - [x] Home: リダイレクトのみ（変更不要）

### 1-4. テーマ・アニメーション統合

- [x] 基本テーマ適用（Tailwind CSS ベース）
- [x] Jotai state 設定（localStorage 永続化実装済み）
- [x] Animated コンポーネント統合（packages/ui/components/index.ts にエクスポート追加）
- [x] SimpleLayout にデザイン設定ボタン追加

**Phase 1 実績**: 約2時間（軽量アプローチにより大幅短縮）

---

## 🔧 Phase 2: バックエンド（完了済み）

| タスク | 状態 |
|--------|------|
| AI Agent連携サービス | ✅ 完了 |
| surveys.generateAIUser | ✅ 完了 |
| surveys.generateAISupporter | ✅ 完了 |
| 面談実施サービス | ✅ 完了 |
| surveys.save | ✅ 完了 |
| surveys.list フィルター・ソート | ✅ 完了 |
| answers.list フィルター | ✅ 完了 |
| users.changePassword | ✅ 完了 |
| auth.logout | ✅ 完了 |
| log / job / public ルーター | ✅ 完了 |
| passwordReset ルーター | ⏸️ 保留（メールインフラ未整備） |

---

## ✅ 完了基準

### Phase 0 ✅
- [x] ルート tsconfig.base.json が存在
- [x] packages/ui, packages/shared, packages/trpc が存在
- [x] 全パッケージで typecheck 成功
- [x] 既存テストがすべて成功

### Phase 1 ✅
- [x] 全ページで統一レイアウト（AppLayout）を使用
- [x] 共通コンポーネント（Card, Badge, Button）で統一
- [x] ビルド成功（全11ページ）

### 統合
- [ ] フロントエンド + バックエンド統合テスト成功
- [ ] 本番デプロイ成功
- [ ] 24時間安定稼働確認

---

## 🏛️ Phase 3: アーキテクチャ改善 🚧 進行中

### 背景・問題点

Phase 1 で「軽量アプローチ」として apps/web/_components を作成したが、
packages/ui との重複管理が発生し、長期的にコスト爆発のリスクがある。

### 運用上の制約（要明記）
- API は単一インスタンス前提（リフレッシュトークン/ログイン試行がメモリ保持）

#### 現状の問題

| # | 問題 | 重大度 |
|---|------|--------|
| 1 | apps/web/app/_components と packages/ui の重複 | 高 |
| 2 | 全 page.tsx が `'use client'`（Server Component 未活用） | 高 |
| 3 | apps/storybook/components 削除予定ファイル大量残存 | 中 |
| 4 | constants パッケージ削除予定残存 | 中 |
| 5 | packages/ui 内の Router 依存（react-router-dom） | 中 |
| 6 | path alias の内部参照問題（@ui/* vs @1on1/ui/*） | 低 |

### 設計方針

**原則**: 「UIは1箇所に集約、Router差分は薄いアダプタ層に閉じ込める」

```
packages/ui/                    ← Single Source of Truth
├── adapters/
│   ├── types.ts               ← RouterAdapter interface
│   ├── react-router.ts        ← React Router 実装
│   └── next.ts                ← Next.js 実装
├── components/                 ← Router非依存（最小限の use client）
└── contexts/
    └── RouterContext.tsx      ← アダプタ注入用

apps/web/app/
├── page.tsx                   ← Server Component（データ取得）
└── _components/               ← 削除予定 → packages/ui に統合
```

**Server/Client 分離ルール**:
- Server Component（デフォルト）: 一覧・詳細表示、データ取得、SEO
- Client Component（必要な箇所のみ）: フォーム、モーダル、インタラクション

---

### 3-1. 準備: 削除予定ファイルのコミット ✅ 完了

- [x] apps/storybook/components 削除をコミット (commit: `bccc225`)
- [x] constants パッケージ削除をコミット (commit: `7d06fe6`)
- [x] apps/storybook hooks/utils/state 削除 (commit: `915c19e`)
- [x] apps/web/components 削除 (commit: `5af4786`)
- [x] git status クリーン (commit: `9ba181a`)

### 3-2. RouterAdapter 設計・実装 ✅ 完了 (commit: `1f69312`)

- [x] `packages/ui/adapters/types.ts` 作成
  - RouterAdapter interface（Link, useNavigate, usePathname）
- [x] `packages/ui/adapters/react-router.tsx` 作成
- [x] `packages/ui/adapters/next.tsx` 作成
- [x] `packages/ui/adapters/RouterContext.tsx` 作成
- [x] `packages/ui/adapters/index.ts` 作成
- [x] `packages/ui/package.json` 更新（adapters export, peerDependencies）

### 3-3. packages/ui の Router 依存解消 ✅ 完了 (commit: `3689bb1`)

- [x] InternalLink.tsx → RouterContext 経由に変更
- [x] useNavigateBack.ts → RouterContext 経由に変更
- [x] useAuth.ts → RouterContext 経由に変更
- [x] useErrorHandler.ts → RouterContext 経由に変更
- [x] RootRedirect.tsx → RouterContext 経由に変更
- [x] ProtectedRoute.tsx → RouterContext 経由に変更
- [x] Header.tsx → RouterContext 経由に変更
- [x] LeftPane.tsx → RouterContext 経由に変更
- [x] 必要なコンポーネントに `'use client'` 付与

### 3-4. apps/web への RouterProvider 適用 ✅ 完了 (commit: `594919c`)

- [x] providers.tsx に RouterProvider + nextAdapter 追加
- [x] packages/ui コンポーネントが Next.js で動作可能に

### 3-5. apps/web/_components 統合・削除 ✅ 完了 (commit: `709bd92`)

- [x] packages/ui Badge に variant API 追加（default/success/warning/error/secondary）
- [x] packages/ui Button に outline variant 追加
- [x] packages/ui Card に onClick サポート追加
- [x] 全ページで packages/ui からコンポーネントを使用
- [x] SimpleLayout を packages/ui/components/atoms に作成
- [x] apps/web/app/_components フォルダを完全削除
- [x] TrendChart は直接パスでインポート（@ui/* パスエイリアス問題回避）

### 3-6. 検証・クリーンアップ ✅ 完了

- [x] apps/web typecheck 成功
- [x] packages/ui typecheck 成功
- [x] path alias 整理（@ui/* → @1on1/ui/* に統一）
- [x] .gitignore 整理（IDE, tsbuildinfo, coverage パターン追加）

### 3-7. 追加アーキテクチャ改善 ✅ 完了 (commit: `efd3602`)

- [x] 実行時環境変数対応: `/api/config` API Route 追加
- [x] tRPC client: ビルド時→実行時の API URL 取得に変更（Fail Fast対応）
- [x] SimpleLayout: `atoms/` → `templates/` へ移動（レイアウトは atoms ではない）

---

### 作業順序（依存関係考慮）

```
3-1 準備（git整理）
 ↓
3-2 RouterAdapter 実装
 ↓
3-3 packages/ui 改修
 ↓
3-4 apps/web Server Component 化
 ↓
3-5 _components 削除
 ↓
3-6 検証・クリーンアップ
```

### 見積もり

| タスク | 所要時間 |
|--------|---------|
| 3-1 準備 | 15分 |
| 3-2 RouterAdapter | 30分 |
| 3-3 packages/ui 改修 | 45分 |
| 3-4 Server Component 化 | 60分 |
| 3-5 _components 削除 | 15分 |
| 3-6 検証 | 30分 |
| **合計** | **約3時間** |

---

## 📈 進捗トラッキング（更新）

### 全体進捗

| Phase | タスク | 完了 | 進捗 |
|-------|--------|------|------|
| Phase 0（構成リファクタ） | 6 | 6 | 100% |
| Phase 1（フロントエンド） | 11 | 11 | 100% |
| Phase 2（バックエンド） | 11 | 10 | 91% |
| Phase 3（アーキテクチャ） | 9 | 9 | 100% |
| Phase 4（Python時代UI復元） | 6 | 5 | 83% |
| **合計** | **43** | **41** | **95%** |

### 残タスク

| タスク | 状態 | 備考 |
|--------|------|------|
| passwordReset ルーター | ⏸️ 保留 | メールインフラ未整備 |
| FloatingElements追加 | ⏸️ 保留 | 現状不要 |
| 部署別/アラートAPI | ⏸️ 保留 | Dashboard用API未実装 |
| 24時間安定稼働確認 | ⏸️ 保留 | - |

---

## 🎨 Phase 4: Python時代UI復元 ✅ 完了

### 背景・問題点

Phase 1 で「軽量アプローチ」として新規UIを作成したが、
**元の apps/ui/src/pages/ にあったリッチなUIデザインを無視**して簡素化した実装に置き換えてしまった。

### 4-1. 不足コンポーネントの追加 ⏸️ 保留

- [ ] `FloatingElements.tsx` → 現状不要（LoginはFloatingElements無しで十分リッチ）

### 4-2. Login ページ復元 ✅ 完了 (2026-01-06)

- [x] 画像ファイル復元 (`logo_login.png`, `character_1on1_stand_1.jpg`)
- [x] 型定義ファイル作成 (`apps/web/app/login/types.ts`)
- [x] LoginLayout コンポーネント作成（2カラムレイアウト）
- [x] page.tsx 書き換え（tRPC + localStorage）
- [x] 動作確認

### 4-3. Surveys / Answers ページ復元 ✅ 完了 (2026-01-06)

- [x] surveys/page.tsx を AppLayout + InteractiveTable に変更
- [x] surveys/[id]/page.tsx を AppLayout + LoadingZone に変更
- [x] answers/page.tsx を AppLayout + InteractiveTable に変更
- [x] answers/[id]/page.tsx を AppLayout + LoadingZone に変更

### 4-4. Dashboard ページ復元 ✅ 完了 (2026-01-06)

- [x] AppLayout + TrendChart + LoadingZone 構成
- [x] 全社サマリー（回答率 + Badge）
- [x] 部署別サマリー（InteractiveTable - APIは未実装）
- [x] 異常検知・アラート一覧（InteractiveTable - APIは未実装）
- [x] トレンド分析（TrendChart）

### 4-5. その他ページ ✅ 完了 (2026-01-06)

- [x] schedule/page.tsx を AppLayout に変更（既に対応済み）
- [x] chat/page.tsx を AppLayout に変更（既に対応済み）

### 4-6. 検証 ✅ 完了 (2026-01-06)

- [x] pnpm run typecheck - エラーなし
- [x] pnpm run build - 12ページ全てビルド成功
- [x] pnpm dev で動作確認 - 全ページアクセス可能

---

**Phase 4 完了**: 全ページで AppLayout + packages/ui コンポーネントを使用したリッチUIに復元完了
