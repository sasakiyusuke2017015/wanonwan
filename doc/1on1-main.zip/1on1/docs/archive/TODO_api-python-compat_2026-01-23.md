# TODO: API Python互換性修正

**最終更新日**: 2026-01-22
**ブランチ**: `feature/simplify-monorepo-structure`

---

## 📊 プロジェクト概要

### 目的

TypeScript APIをPython時代と完全互換にする

### 背景

- tRPC → Hono REST API 移行後、レスポンス形式がPython時代と異なっている
- フロントエンドが期待するフィールドが欠落（回答ID、回答状況、アンケート内容JSON等）
- ステータス値が数値コード→ラベルに変わってしまい、フィルタリングが動作しない

---

## 🎯 修正方針

1. **`setDisplayValue: 'Value'`** に統一（数値コードを返す）
2. **Pleasanter結合クエリ（`~`, `~~`）** を実装してPython同様のデータ取得
3. **レスポンススキーマ** をPython時代のフィールドに合わせる
4. **共通パラメータ**: `limit`/`offset` をオプショナルで全APIに追加

---

## 📋 タスク一覧

### Phase 1: Python時代のコード確認 ✅ 完了

| タスク | 状態 | 備考 |
|--------|------|------|
| surveys/router.py 確認 | ✅ | 結合クエリ（`~`, `~~`）、フィルタリング、ソート |
| surveys/schemas.py 確認 | ✅ | SurveyListResult: 掲載ID,掲載状況,回答ID,回答状況,アンケート内容JSON等 |
| answers/router.py 確認 | ✅ | set_display_value="Both"、結合クエリ、面談候補フィルタ |
| answers/schemas.py 確認 | ✅ | EmployeeDetailResult: 回答結果配列、AnswerResult |
| users/router.py 確認 | ✅ | /me, /password のみ（シンプル） |
| users/schemas.py 確認 | ✅ | User, ChangePasswordRequest |
| dashboard/router.py 確認 | ✅ | モックデータ返却（TODO: 実データ実装） |
| dashboard/schemas.py 確認 | ✅ | DashboardResult: header, companySummary, alerts等 |

### Phase 2: validators (スキーマ) 修正 ✅ 完了

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| common.ts - ステータスを数値型に変更 | ✅ | packages/shared/validators/common.ts |
| survey.ts - SurveyListItem にフィールド追加 | ✅ | packages/shared/validators/survey.ts |
| answer.ts - AnswerListItem 確認・修正 | ✅ | packages/shared/validators/answer.ts |
| user.ts - 確認・修正 | ✅ | 修正不要（ステータス値なし） |
| dashboard.ts - 確認・修正 | ✅ | 将来的に実データ実装時に対応 |

### Phase 3: services 修正 ✅ 完了

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| surveys.ts - setDisplayValue:'Value' | ✅ | apps/api/src/services/surveys.ts |
| answers.ts - setDisplayValue:'Value' | ✅ | apps/api/src/services/answers.ts |
| users.ts - 確認 | ✅ | 既に 'Value' 使用済み |
| dashboard.ts - 確認 | ✅ | 既に 'Value' 使用済み |

### Phase 4: routes 修正 ✅ 完了

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| surveys.ts - パラメータ・レスポンス形式 | ✅ | validators経由で対応済み |
| answers.ts - パラメータ・レスポンス形式 | ✅ | validators経由で対応済み |
| users.ts - 確認 | ✅ | 修正不要 |
| dashboard.ts - 確認 | ✅ | 修正不要 |

### Phase 5: フロントエンド確認 🔄 進行中

| タスク | 状態 | 備考 |
|--------|------|------|
| SurveyList 型チェック | ✅ | 数値コード比較を期待、型一致確認済み |
| AnswerList 型チェック | ✅ | |
| Dashboard 型チェック | ✅ | |
| AnswerDetail 型チェック | ✅ | |
| 実機動作確認 | ⬜ | Docker起動後に確認必要 |

---

## 📈 進捗トラッキング

| Phase | タスク数 | 完了 | 進捗 |
|-------|----------|------|------|
| Phase 1（確認） | 8 | 8 | 100% |
| Phase 2（validators） | 5 | 5 | 100% |
| Phase 3（services） | 4 | 4 | 100% |
| Phase 4（routes） | 4 | 4 | 100% |
| Phase 5（確認） | 5 | 4 | 80% |
| **合計** | **26** | **25** | **96%** |

---

## 📝 実装済みの変更点

### validators (packages/shared/validators/)

1. **common.ts**
   - 数値コードスキーマ追加: `AnswerStatusCodeSchema`, `PublishStatusCodeSchema`, `InterviewStatusCodeSchema`, `HealthStatusCodeSchema`
   - 旧ラベルスキーマは `@deprecated` として残存（後方互換）

2. **survey.ts**
   - `SurveyListItemSchema`: 数値コード型に変更、Python互換フィールド追加（回答ID, 回答状況, アンケート内容JSON, ユーザー用生成回答）
   - `SurveyDetailSchema`: 掲載状況を数値コード型に変更
   - `SurveyListItemLegacySchema`: 旧スキーマを `@deprecated` として残存

3. **answer.ts**
   - `AnswerResultSchema`: 回答状況、面談状況、健康状態を数値コード型に変更
   - `AnswerListItemSchema`: 数値コード型に変更
   - `UpdateAnswerRequestSchema`: 数値コード型に変更
   - `AnswerResultLegacySchema`: 旧スキーマを `@deprecated` として残存

### services (apps/api/src/services/)

1. **surveys.ts**
   - `setDisplayValue: 'Value'` に変更（数値コードを返す）
   - フィルタリングを数値コード比較に変更

2. **answers.ts**
   - `setDisplayValue: 'Value'` に変更（数値コードを返す）
   - フィルタリングを数値コード比較に変更

### テスト修正

- `answers.test.ts`: ステータス比較を数値コードに変更
- `surveys.test.ts`: ステータス比較を数値コードに変更

---

## 📝 残作業

- [ ] Docker起動して実機動作確認

## ✅ 完了した追加実装

### 結合クエリ実装（2段階クエリ方式）

`surveys.ts` の `getAllSurveys` を修正:
1. 掲載設定テーブルから全件取得
2. 回答結果テーブルから認証ユーザーの回答を取得
3. 掲載IDでマージして結合データを返却

返却フィールド:
- 掲載設定: 掲載ID, タイトル, 掲載状況, 開始, 完了, 回答率, アンケート選択
- 回答結果: 回答ID, 回答状況, アンケート内容JSON, ユーザー用生成回答

---

## 📝 アーカイブ履歴

| ファイル | 内容 | 日付 |
|----------|------|------|
| `archive/TODO_simplify-monorepo_2026-01-22.md` | モノレポ構造簡素化 | 2026-01-22 |
| `archive/TODO_typescript-migration_2026-01-06.md` | TypeScript完全移行 | 2026-01-06 |
| `archive/TODO_typescript-migration_2025-01.md` | TypeScript移行（初期） | 2025-01 |
