# TODO: プロジェクト構成改善

**最終更新日**: 2026-01-23
**ブランチ**: `feature/simplify-monorepo-structure`

---

## 📊 概要

構成レビュー結果に基づく改善タスク + MagicUI導入

---

## ✅ 完了: MagicUI導入（2026-01-23）

### 導入済みコンポーネント

| コンポーネント | 用途 | 適用箇所 |
|--------------|------|---------|
| DotPattern | 背景パターン | ログイン画面 |
| NumberTicker | 数値アニメーション | ダッシュボード（回答率）、回答一覧（件数） |
| BlurFade | フェードインアニメーション | アンケート一覧（カード、バナー） |
| ShimmerButton | キラキラボタン | 汎用（未適用） |
| GridPattern | グリッド背景 | 汎用（未適用） |

### 追加ファイル

- `apps/web/src/ui/components/magicui/` - MagicUIコンポーネント群
- `apps/web/tailwind.config.ts` - shimmerアニメーション追加

### 今後の拡張案

| 画面 | 適用案 |
|------|--------|
| 回答詳細 | レーダーチャートにアニメーション追加 |
| 設定画面 | テーマ切替時のトランジション |
| エラー画面 | アニメーション背景 |

---

## ✅ 完了: P0タスク（2026-01-23）

### Hono API

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| console.log/error を全削除 | ✅ | apps/api/src/**/*.ts |
| レート制限ミドルウェア追加 | ✅ | apps/api/src/index.ts, middleware/rate-limit.ts |
| API Keyミドルウェアのエラー処理統一 | ✅ | apps/api/src/middleware/auth.ts |

### Vite

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| 環境変数デフォルト値を削除（Fail Fast） | ✅ | apps/web/vite.config.ts |
| loadEnvプレフィックス設定 | ✅ | apps/web/vite.config.ts, .env, .env.example |

---

## ✅ 完了: P1タスク（2026-01-23）

### Vite ビルド最適化

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| Chunk分割実装（manualChunks） | ✅ | apps/web/vite.config.ts |
| vite.config ↔ tsconfig エイリアス同期 | ✅ | apps/web/vite.config.ts, tsconfig.json |
| Build分析プラグイン導入（rollup-plugin-visualizer） | ✅ | apps/web/vite.config.ts, package.json |
| 環境別ビルド分岐（sourcemap） | ✅ | apps/web/vite.config.ts |

### Hono API

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| リクエストIDトレーシング追加（hono/request-id） | ✅ | apps/api/src/index.ts |
| ジョブエンドポイント実装完了 | ✅ | apps/api/src/routes/jobs.ts |
| vitest/tsconfig エイリアス同期 + tRPC参照削除 | ✅ | apps/api/vitest.config.ts, tsconfig.json |

### Storybook

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| TypeScript型統一パターン確立（Meta/StoryObj） | ✅ | Badge.stories.tsx（パターン適用済） |
| ストーリーカバレッジ向上（50%→80%） | 📋 P2へ | 大規模なため延期 |
| manager.js有効化（ブランドテーマ） | 📋 P2へ | 次回対応 |
| Tailwind設定に.storybook追加 | ✅ | apps/web/tailwind.config.ts |

### Jotai

| タスク | 状態 | 影響ファイル |
|--------|------|--------------|
| UI設定atomグループ化 | ✅ | apps/web/src/ui/state/core/uiStyle.ts |
| atomWithQuery導入検討 | 📋 P2へ | 次回対応 |

---

## ✅ 完了: P2タスク（2026-01-23）

| タスク | 状態 | 備考 |
|--------|------|------|
| ストラクチャードログ導入 | ✅ | pino + pino-pretty |
| OpenAPI / Swagger UI | ✅ | @hono/swagger-ui + openapi.ts |
| Minifyエンジン設定 | ✅ | esbuild + drop console/debugger |

---

## 🟢 残タスク

| タスク | 状態 | 備考 |
|--------|------|------|
| エラーメトリクス収集（Sentry等） | ⬜ | 外部サービス依存 |
| 本番SourceMap（Sentry連携） | ⬜ | Sentry導入後 |
| Storybook Addon追加 | ⬜ | toolbars, interactions |
| Storybook MDXドキュメント | ⬜ | ページレベル説明 |
| Storybook Play関数活用 | ⬜ | インタラクティブテスト |
| ストーリーカバレッジ向上 | ⬜ | 50%→80% |
| Storybook manager.js有効化 | ⬜ | ブランドテーマ |
| atomWithQuery導入検討 | ⬜ | TanStack Query連携 |

---

## 📈 進捗トラッキング

| 優先度 | タスク数 | 完了 | 進捗 |
|--------|----------|------|------|
| P0（即座） | 5 | 5 | 100% |
| P1（次スプリント） | 11 | 9 | 82% |
| P2（今後） | 11 | 3 | 27% |
| **合計** | **27** | **17** | **63%** |

---

## 📝 アーカイブ履歴

| ファイル | 内容 | 日付 |
|----------|------|------|
| `archive/TODO_api-python-compat_2026-01-23.md` | API Python互換性修正 | 2026-01-23 |
| `archive/TODO_simplify-monorepo_2026-01-22.md` | モノレポ構造簡素化 | 2026-01-22 |
| `archive/TODO_typescript-migration_2026-01-06.md` | TypeScript完全移行 | 2026-01-06 |
| `archive/TODO_typescript-migration_2025-12-25.md` | TypeScript移行（初期） | 2025-12-25 |
