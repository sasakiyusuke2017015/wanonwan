# API仕様書

## 概要

1on1アプリケーションのREST API仕様書です。

**技術スタック**:
- **フレームワーク**: Hono (Node.js)
- **API**: REST API + TanStack Query
- **バリデーション**: Valibot
- **認証**: JWT (Cookie-based, HttpOnly)

**ベースURL**:
- 開発: `http://localhost:8000`
- 本番: `https://1on1.sdt-autolabo.com`

**APIドキュメント（インタラクティブ）**:
- 開発: `http://localhost:8000/api-docs`
- 本番: `https://1on1.sdt-autolabo.com/api-docs`

---

## 認証

### 認証方式

**Cookie認証 + JWT**:
- `access_token`: アクセストークン（有効期限: 30分）
- `refresh_token`: リフレッシュトークン（有効期限: 7日）

### トークンリフレッシュ

フロントエンドで自動リフレッシュ（トークン有効期限の80%で実行）

```typescript
// 自動実行（useAuth hookで実装済み）
const { isAuthenticated } = useAuth()
```

---

## エンドポイント一覧

### 認証 (auth)

#### `POST /api/auth/login`

**用途**: ログイン

**リクエスト**:
```typescript
{
  email: string,      // メールアドレス
  password: string    // パスワード
}
```

**レスポンス**:
```typescript
{
  access_token: string,
  refresh_token: string,
  user: {
    id: number,
    email: string,
    name: string,
    role: number
  }
}
```

**使用例**:
```typescript
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'user@example.com', password: 'password123' })
})
const result = await response.json()
```

---

#### `POST /api/auth/refresh`

**用途**: トークンリフレッシュ

**リクエスト**:
```typescript
{
  refresh_token: string
}
```

**レスポンス**:
```typescript
{
  access_token: string,
  refresh_token: string
}
```

---

#### `POST /api/auth/logout`

**用途**: ログアウト

**リクエスト**: なし

**レスポンス**:
```typescript
{
  success: boolean
}
```

---

#### `GET /api/auth/me`

**用途**: 現在のユーザー情報取得

**認証**: 必須

**レスポンス**:
```typescript
{
  id: number,
  email: string,
  name: string,
  role: number
}
```

---

### ユーザー (users)

#### `GET /api/users`

**用途**: ユーザー一覧取得

**認証**: 必須

**クエリパラメータ**:
```typescript
{
  limit?: number,     // 取得件数（デフォルト: 100）
  offset?: number     // オフセット（デフォルト: 0）
}
```

**レスポンス**:
```typescript
{
  users: Array<{
    ユーザーID: number,
    名前: string,
    役職: number,
    所属本部: string,
    所属部: string,
    所属課: string,
    メールアドレス: string
  }>,
  total: number
}
```

---

#### `GET /api/users/:id`

**用途**: ユーザー詳細取得

**認証**: 必須

**レスポンス**:
```typescript
{
  ユーザーID: number,
  名前: string,
  役職: number,
  所属本部: string,
  所属部: string,
  所属課: string,
  メールアドレス: string,
  追加面談候補者?: string
}
```

---

### アンケート (surveys)

#### `GET /api/surveys`

**用途**: アンケート一覧取得

**認証**: 必須

**クエリパラメータ**:
```typescript
{
  limit?: number,
  offset?: number
}
```

**レスポンス**:
```typescript
{
  surveys: Array<{
    アンケートID: number,
    タイトル: string,
    作成日時: string,
    更新日時: string,
    ステータス: string
  }>,
  total: number
}
```

---

#### `GET /api/surveys/:id`

**用途**: アンケート詳細取得

**認証**: 必須

**レスポンス**:
```typescript
{
  アンケートID: number,
  タイトル: string,
  説明: string,
  作成日時: string,
  更新日時: string,
  ステータス: string,
  質問一覧: Array<{
    質問ID: number,
    質問文: string,
    質問タイプ: string
  }>
}
```

---

#### `POST /api/surveys/:id/submit`

**用途**: 回答送信

**認証**: 必須

**リクエスト**:
```typescript
{
  answers: Array<{
    questionId: number,
    answer: string
  }>
}
```

**レスポンス**:
```typescript
{
  answerId: number,
  success: boolean
}
```

---

### ダッシュボード (dashboard)

#### `GET /api/dashboard/stats`

**用途**: 統計情報取得

**認証**: 必須

**レスポンス**:
```typescript
{
  回答率: number,
  総回答数: number,
  総ユーザー数: number,
  最新アンケート: {
    開始: string,
    タイトル: string
  }
}
```

---

### バッチジョブ (job)

#### `GET /api/job/start-surveys`

**用途**: アンケート開始処理

**認証**: X-API-Key ヘッダー

**使用例**:
```bash
curl -X GET "http://localhost:8000/api/job/start-surveys" \
  -H "X-API-Key: your-api-key"
```

---

## エラーハンドリング

### エラーコード

| コード | 説明 | HTTPステータス |
|--------|------|----------------|
| `UNAUTHORIZED` | 認証エラー | 401 |
| `FORBIDDEN` | 権限エラー | 403 |
| `NOT_FOUND` | リソース不存在 | 404 |
| `BAD_REQUEST` | リクエストエラー | 400 |
| `INTERNAL_SERVER_ERROR` | サーバーエラー | 500 |

### エラーレスポンス

```typescript
{
  error: {
    code: 'UNAUTHORIZED',
    message: 'Invalid token'
  }
}
```

### グローバルエラーハンドリング

TanStack Queryで自動処理:

```typescript
// apps/web/src/lib/api/client.ts
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error) => {
        if (error.status === 401) return false
        return failureCount < 3
      }
    }
  }
})
```

---

## Valibotスキーマ定義

### 認証スキーマ

```typescript
// apps/api/src/routes/auth/schema.ts
import * as v from 'valibot'

export const loginSchema = v.object({
  email: v.pipe(v.string(), v.email()),
  password: v.pipe(v.string(), v.minLength(8))
})

export const refreshSchema = v.object({
  refresh_token: v.string()
})
```

---

## 型安全性

### TanStack Query + fetch

```typescript
// apps/web/src/lib/api/index.ts
export const apiGet = async <T>(path: string): Promise<T> => {
  const response = await fetch(`/api${path}`, {
    credentials: 'include'
  })
  if (!response.ok) throw new Error(response.statusText)
  return response.json()
}

// 使用例
const { data } = useQuery({
  queryKey: ['users', userId],
  queryFn: () => apiGet<User>(`/users/${userId}`)
})
```

---

## パフォーマンス

### キャッシング

TanStack Queryによる自動キャッシュ:

```typescript
// 初回: APIリクエスト
const { data: user1 } = useQuery({
  queryKey: ['users', 123],
  queryFn: () => apiGet<User>('/users/123')
})

// 2回目: キャッシュから取得（APIリクエストなし）
const { data: user2 } = useQuery({
  queryKey: ['users', 123],
  queryFn: () => apiGet<User>('/users/123')
})
```

---

## 開発ツール

### TanStack Query Devtools

開発環境で有効:

```typescript
// apps/web/src/App.tsx
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'

<QueryClientProvider client={queryClient}>
  <App />
  <ReactQueryDevtools initialIsOpen={false} />
</QueryClientProvider>
```

### Scalar API Documentation

開発環境・本番環境で利用可能:

- 開発: http://localhost:8000/api-docs
- 本番: https://1on1.sdt-autolabo.com/api-docs

### TypeScript型チェック

```bash
# 型エラー確認
pnpm check:type
```

---

## 参考資料

- [TanStack Query公式ドキュメント](https://tanstack.com/query)
- [Valibot公式ドキュメント](https://valibot.dev/)
- [Hono公式ドキュメント](https://hono.dev/)
- [Scalar API Reference](https://scalar.com/)
- [ARCHITECTURE.md](./ARCHITECTURE.md) - システムアーキテクチャ
