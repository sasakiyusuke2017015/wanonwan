# 開発環境構築ガイド

TypeScript統一の1on1アプリケーション（Vite + React 19 + Hono REST API）の開発環境構築方法を説明します。

## 必要な環境

- **Node.js**: >= 20.0.0
- **pnpm**: >= 9.0.0
- **Docker + Docker Compose**: 最新版（本番環境用）

## クイックスタート

```bash
# リポジトリクローン
git clone http://1on1.sdt-autolabo.com:3000/sasaki_yusuke/1on1.git
cd 1on1

# 依存関係インストール
pnpm install

# 環境変数設定
cp .env.example .env

# 開発サーバー起動
pnpm dev
```

## 開発サーバー起動

### Docker Compose使用（推奨）

```bash
pnpm dev              # 起動
pnpm dev:log          # ログ確認
pnpm dev:down         # 停止
```

### ローカル実行（Docker不使用）

```bash
# Web開発サーバー（Vite + React）
pnpm --filter @1on1/web dev   # http://localhost:3000

# API開発サーバー（Hono）
pnpm --filter @1on1/api dev   # http://localhost:8000
```

## アクセスURL

起動後、以下のURLでアクセス可能：

- **Web**: http://localhost:3000
- **API**: http://localhost:8000
- **API Docs**: http://localhost:8000/api-docs (Scalar)

## 主な開発コマンド

```bash
# ビルド
pnpm build            # 全体

# 型チェック
pnpm check:type       # 全体

# Lint
pnpm check:lint       # 全体

# テスト
pnpm test:unit        # ユニットテスト
pnpm test:e2e         # E2Eテスト (Playwright)
pnpm test:storybook   # Storybookテスト
```

## 本番環境起動

```bash
pnpm prod             # 起動
pnpm prod:logs        # ログ確認
pnpm prod:down        # 停止
```

本番URL: https://1on1.sdt-autolabo.com

## 環境変数

主な環境変数（`.env`）:

```bash
# API
PLEASANTER_API_URL=https://pleasanter.example.com
PLEASANTER_API_KEY=your-key

# JWT認証
JWT_SECRET_KEY=your-secret
```

ポート番号・ホスト名はコード固定値で管理。詳細は [NETWORK.md](./NETWORK.md) を参照。

詳細は [.env.example](./../.env.example) を参照。

## 関連ドキュメント

- [README.md](../README.md) - プロジェクト概要とクイックスタート
- [TESTING.md](./TESTING.md) - テスト戦略とテスト実行方法
- [DEBUGGING.md](./DEBUGGING.md) - デバッグ手順
- [ARCHITECTURE.md](./ARCHITECTURE.md) - アーキテクチャ詳細
- [.gitea/workflows/README.md](../.gitea/workflows/README.md) - CI/CD パイプライン

## トラブルシューティング

### ポート競合

```bash
# ポート使用状況確認（詳細は docs/NETWORK.md 参照）
sudo lsof -i :3000
sudo lsof -i :8000
sudo lsof -i :6006
sudo lsof -i :9230
sudo lsof -i :443

# .env でポート番号を変更
```

### pnpm のキャッシュクリア

```bash
pnpm store prune
pnpm install --force
```

### Docker のクリーンアップ

```bash
# すべてのコンテナ停止
docker compose --profile dev down
docker compose --profile prod down
docker compose --profile test down

# すべてのコンテナとボリュームを削除
docker compose --profile dev down -v
docker compose --profile prod down -v
docker compose --profile test down -v

# Docker イメージのクリーンアップ
docker system prune -a
```

### ワークスペースのリセット

```bash
# すべてのnode_modules削除
pnpm clean

# 再インストール
pnpm install
```
